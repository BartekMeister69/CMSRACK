import net.minecraft.client.renderer.GlStateManager;

class jebac_vexiau5kgy2fm1nlm {
   // $FF: synthetic method
   static void setupBlend(int p_setupBlend_0_, float p_setupBlend_1_) {
      switch(p_setupBlend_0_) {
      case 0:
         GlStateManager.disableAlpha();
         GlStateManager.enableBlend();
         GlStateManager.blendFunc(770, 771);
         GlStateManager.color(1.0F, 1.0F, 1.0F, p_setupBlend_1_);
         break;
      case 1:
         GlStateManager.disableAlpha();
         GlStateManager.enableBlend();
         GlStateManager.blendFunc(770, 1);
         GlStateManager.color(1.0F, 1.0F, 1.0F, p_setupBlend_1_);
         break;
      case 2:
         GlStateManager.disableAlpha();
         GlStateManager.enableBlend();
         GlStateManager.blendFunc(775, 0);
         GlStateManager.color(p_setupBlend_1_, p_setupBlend_1_, p_setupBlend_1_, 1.0F);
         break;
      case 3:
         GlStateManager.disableAlpha();
         GlStateManager.enableBlend();
         GlStateManager.blendFunc(774, 771);
         GlStateManager.color(p_setupBlend_1_, p_setupBlend_1_, p_setupBlend_1_, p_setupBlend_1_);
         break;
      case 4:
         GlStateManager.disableAlpha();
         GlStateManager.enableBlend();
         GlStateManager.blendFunc(1, 1);
         GlStateManager.color(p_setupBlend_1_, p_setupBlend_1_, p_setupBlend_1_, 1.0F);
         break;
      case 5:
         GlStateManager.disableAlpha();
         GlStateManager.enableBlend();
         GlStateManager.blendFunc(0, 769);
         GlStateManager.color(p_setupBlend_1_, p_setupBlend_1_, p_setupBlend_1_, 1.0F);
         break;
      case 6:
         GlStateManager.disableAlpha();
         GlStateManager.enableBlend();
         GlStateManager.blendFunc(1, 769);
         GlStateManager.color(p_setupBlend_1_, p_setupBlend_1_, p_setupBlend_1_, 1.0F);
         break;
      case 7:
         GlStateManager.disableAlpha();
         GlStateManager.enableBlend();
         GlStateManager.blendFunc(774, 768);
         GlStateManager.color(p_setupBlend_1_, p_setupBlend_1_, p_setupBlend_1_, 1.0F);
         break;
      case 8:
         GlStateManager.enableAlpha();
         GlStateManager.disableBlend();
         GlStateManager.color(1.0F, 1.0F, 1.0F, p_setupBlend_1_);
      }

      GlStateManager.enableTexture2D();
   }

   // $FF: synthetic method
   static void clearBlend(float p_clearBlend_0_) {
      GlStateManager.disableAlpha();
      GlStateManager.enableBlend();
      GlStateManager.blendFunc(770, 1);
      GlStateManager.color(1.0F, 1.0F, 1.0F, p_clearBlend_0_);
   }

   // $FF: synthetic method
   static int parseBlend(String p_parseBlend_0_) {
      if (p_parseBlend_0_ == null) {
         return 1;
      } else {
         p_parseBlend_0_ = p_parseBlend_0_.toLowerCase().trim();
         byte var2 = -1;
         switch(p_parseBlend_0_.hashCode()) {
         case -2060248300:
            if (p_parseBlend_0_.equals("subtract")) {
               var2 = 2;
            }
            break;
         case -1091287984:
            if (p_parseBlend_0_.equals("overlay")) {
               var2 = 7;
            }
            break;
         case -907689876:
            if (p_parseBlend_0_.equals("screen")) {
               var2 = 6;
            }
            break;
         case 96417:
            if (p_parseBlend_0_.equals("add")) {
               var2 = 1;
            }
            break;
         case 3035599:
            if (p_parseBlend_0_.equals("burn")) {
               var2 = 5;
            }
            break;
         case 92909918:
            if (p_parseBlend_0_.equals("alpha")) {
               var2 = 0;
            }
            break;
         case 95758295:
            if (p_parseBlend_0_.equals("dodge")) {
               var2 = 4;
            }
            break;
         case 653829668:
            if (p_parseBlend_0_.equals("multiply")) {
               var2 = 3;
            }
            break;
         case 1094496948:
            if (p_parseBlend_0_.equals("replace")) {
               var2 = 8;
            }
         }

         switch(var2) {
         case 0:
            return 0;
         case 1:
            return 1;
         case 2:
            return 2;
         case 3:
            return 3;
         case 4:
            return 4;
         case 5:
            return 5;
         case 6:
            return 6;
         case 7:
            return 7;
         case 8:
            return 8;
         default:
            jebac_vexiakrwecfs16wve.warn("Unknown blend: " + p_parseBlend_0_);
            return 1;
         }
      }
   }
}
