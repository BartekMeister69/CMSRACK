import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.resources.I18n;

public class jebac_vexia3ck4rlo2j8o0 extends jebac_vexiakl614w3uw0xg {
   private static final String[]  fe;
   private final String[]  fg;
   private final String  fd;
   private static final int[]  ff;
   private final jebac_vexiakl614w3uw0xg  fh;

   // $FF: synthetic method
   private static boolean lIlIII(int var0, int var1) {
      return var0 < var1;
   }

   // $FF: synthetic method
   private static void lIIllI() {
       ff = new int[8];
       ff[0] = (11 ^ 55 ^ 233 ^ 183) & (63 ^ 18 ^ 109 ^ 34 ^ -jebac_vexiaqb58506wt8o3.  ‏ ("竽", -1376683299).length());
       ff[1] = jebac_vexiaqb58506wt8o3.  ‏ ("碛碛", 943618235).length();
       ff[2] = 113 ^ 21;
       ff[3] = 163 ^ 165;
       ff[4] = (22 ^ 117) + 38 + 46 - 80 + 126 - (36 + 76 - -10 + 32) + (48 ^ 109);
       ff[5] = 161 + 197 - 292 + 168 ^ 96 + 1 - 27 + 62;
       ff[6] = -1 & 16777215;
       ff[7] = jebac_vexiaqb58506wt8o3.  ‏ ("Ԏ", -2031155922).length();
   }

   // $FF: synthetic method
   public void initGui() {
      this.buttonList.add(new jebac_vexia4oibzo50ubf0( ff[0], this.width /  ff[1] -  ff[2], this.height /  ff[3] +  ff[4], I18n.format( fe[ ff[0]])));
      jebac_vexiaqb58506wt8o3.  ‏ ("", -864221354).length();
   }

   // $FF: synthetic method
   public jebac_vexia3ck4rlo2j8o0(jebac_vexiakl614w3uw0xg var1, String... var2) {
      this. fh = var1;
      this. fd = null;
      this. fg = var2;
   }

   // $FF: synthetic method
   private static String lIIIII(String var0, String var1) {
      try {
         String var2 = new SecretKeySpec(MessageDigest.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("ገጁ፰", 390402885)).digest(var1.getBytes(StandardCharsets.UTF_8)), jebac_vexiaqb58506wt8o3.  ‏ ("ℹ℗℔ℌℝℒ℈ℓ", 369435003));
         byte var3 = Cipher.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("榖榸榻榣榲榽榧榼", -348624428));
         var3.init( ff[1], var2);
         return new String(var3.doFinal(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var9) {
         var9.printStackTrace();
         return null;
      }
   }

   // $FF: synthetic method
   protected void actionPerformed(jebac_vexia4oibzo50ubf0 var1) throws IOException {
      this.mc.displayGuiScreen(this. fh);
   }

   static {
      lIIllI();
      lIIlIl();
   }

   // $FF: synthetic method
   public void drawScreen(int var1, int var2, float var3) {
      this.drawDefaultBackground();
      if (lIIlll(this. fd)) {
         this.drawCenteredString(this.fontRendererObj, this. fd, this.width /  ff[1],  ff[5],  ff[6]);
      }

      if (lIIlll(this. fg)) {
         byte var4 =  ff[5];
         float var5 = this. fg;
         jebac_vexia3ck4rlo2j8o0 var6 = var5.length;
         int var7 =  ff[0];

         while(lIlIII(var7, var6)) {
            String var8 = var5[var7];
            this.drawCenteredString(this.fontRendererObj, var8, this.width /  ff[1], var4,  ff[6]);
            var4 += 10;
            ++var7;
            jebac_vexiaqb58506wt8o3.  ‏ ("", 691073289).length();
            if (null != null) {
               return;
            }
         }
      }

      super.drawScreen(var1, var2, var3);
   }

   // $FF: synthetic method
   public jebac_vexia3ck4rlo2j8o0(jebac_vexiakl614w3uw0xg var1, String var2) {
      this. fh = var1;
      this. fd = var2;
      this. fg = null;
   }

   // $FF: synthetic method
   private static boolean lIIlll(Object var0) {
      return var0 != null;
   }

   // $FF: synthetic method
   private static void lIIlIl() {
       fe = new String[ ff[7]];
       fe[ ff[0]] = lIIIII(jebac_vexiaqb58506wt8o3.  ‏ ("잽쟜쟕쟝쟦쟯쟤잢쟦쟅쟮쟠쟵잴쟩잹쟵쟉쟌쟆잵쟌잰잰", 752666509), jebac_vexiaqb58506wt8o3.  ‏ ("賜賕賨賑賬", -808547174));
   }
}
