public class jebac_vexiau51pw4i3zdqx {
   // $FF: synthetic field
   private String suffix;
   // $FF: synthetic field
   private int release;
   // $FF: synthetic field
   private int major;
   // $FF: synthetic field
   private int minor;

   // $FF: synthetic method
   public int getRelease() {
      return this.release;
   }

   // $FF: synthetic method
   public String toString() {
      return this.suffix == null ? "" + this.major + "." + this.minor + "." + this.release : "" + this.major + "." + this.minor + "." + this.release + this.suffix;
   }

   // $FF: synthetic method
   public int getMajor() {
      return this.major;
   }

   // $FF: synthetic method
   public int getMinor() {
      return this.minor;
   }

   // $FF: synthetic method
   public jebac_vexiau51pw4i3zdqx(int p_i45_1_, int p_i45_2_, int p_i45_3_, String p_i45_4_) {
      this.major = p_i45_1_;
      this.minor = p_i45_2_;
      this.release = p_i45_3_;
      this.suffix = p_i45_4_;
   }

   // $FF: synthetic method
   public jebac_vexiau51pw4i3zdqx(int p_i43_1_, int p_i43_2_) {
      this(p_i43_1_, p_i43_2_, 0);
   }

   // $FF: synthetic method
   public jebac_vexiau51pw4i3zdqx(int p_i44_1_, int p_i44_2_, int p_i44_3_) {
      this(p_i44_1_, p_i44_2_, p_i44_3_, (String)null);
   }

   // $FF: synthetic method
   public int toInt() {
      return this.minor > 9 ? this.major * 100 + this.minor : (this.release > 9 ? this.major * 100 + this.minor * 10 + 9 : this.major * 100 + this.minor * 10 + this.release);
   }
}
