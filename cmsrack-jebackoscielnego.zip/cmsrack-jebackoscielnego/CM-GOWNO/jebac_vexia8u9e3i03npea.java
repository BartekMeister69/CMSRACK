import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;

class jebac_vexia8u9e3i03npea extends Slot {
   final jebac_vexiaenf0dnsihb5s this$0;
   // $FF: synthetic field
   private final Slot slot;

   // $FF: synthetic method
   public boolean isItemValid(ItemStack stack) {
      return this.slot.isItemValid(stack);
   }

   // $FF: synthetic method
   public String getSlotTexture() {
      return this.slot.getSlotTexture();
   }

   // $FF: synthetic method
   public ItemStack decrStackSize(int amount) {
      return this.slot.decrStackSize(amount);
   }

   // $FF: synthetic method
   public boolean getHasStack() {
      return this.slot.getHasStack();
   }

   static Slot access$000(jebac_vexia8u9e3i03npea x0) {
      return x0.slot;
   }

   // $FF: synthetic method
   public boolean isHere(IInventory inv, int slotIn) {
      return this.slot.isHere(inv, slotIn);
   }

   // $FF: synthetic method
   public int getItemStackLimit(ItemStack stack) {
      return this.slot.getItemStackLimit(stack);
   }

   // $FF: synthetic method
   public int getSlotStackLimit() {
      return this.slot.getSlotStackLimit();
   }

   // $FF: synthetic method
   public jebac_vexia8u9e3i03npea(jebac_vexiaenf0dnsihb5s this$0, Slot p_i46313_2_, int p_i46313_3_) {
      super(p_i46313_2_.inventory, p_i46313_3_, 0, 0);
      this.this$0 = this$0;
      this.slot = p_i46313_2_;
   }

   // $FF: synthetic method
   public ItemStack getStack() {
      return this.slot.getStack();
   }

   // $FF: synthetic method
   public void putStack(ItemStack stack) {
      this.slot.putStack(stack);
   }

   // $FF: synthetic method
   public void onSlotChanged() {
      this.slot.onSlotChanged();
   }

   // $FF: synthetic method
   public void onPickupFromSlot(EntityPlayer playerIn, ItemStack stack) {
      this.slot.onPickupFromSlot(playerIn, stack);
   }
}
