import java.net.Proxy;
import java.util.Map;

public class jebac_vexiahtrnwedo9ob6 {
   // $FF: synthetic field
   private Proxy proxy;
   // $FF: synthetic field
   private String method;
   // $FF: synthetic field
   private String file;
   // $FF: synthetic field
   private String http;
   // $FF: synthetic field
   private int port;
   // $FF: synthetic field
   private String host;
   // $FF: synthetic field
   private int redirects = 0;
   // $FF: synthetic field
   private Map headers;
   // $FF: synthetic field
   private byte[] body;

   // $FF: synthetic method
   public Map getHeaders() {
      return this.headers;
   }

   // $FF: synthetic method
   public byte[] getBody() {
      return this.body;
   }

   // $FF: synthetic method
   public String getMethod() {
      return this.method;
   }

   // $FF: synthetic method
   public int getPort() {
      return this.port;
   }

   // $FF: synthetic method
   public String getHttp() {
      return this.http;
   }

   // $FF: synthetic method
   public String getFile() {
      return this.file;
   }

   // $FF: synthetic method
   public Proxy getProxy() {
      return this.proxy;
   }

   // $FF: synthetic method
   public void setRedirects(int p_setRedirects_1_) {
      this.redirects = p_setRedirects_1_;
   }

   // $FF: synthetic method
   public int getRedirects() {
      return this.redirects;
   }

   // $FF: synthetic method
   public String getHost() {
      return this.host;
   }

   // $FF: synthetic method
   public jebac_vexiahtrnwedo9ob6(String p_i60_1_, int p_i60_2_, Proxy p_i60_3_, String p_i60_4_, String p_i60_5_, String p_i60_6_, Map p_i60_7_, byte[] p_i60_8_) {
      this.host = p_i60_1_;
      this.port = p_i60_2_;
      this.proxy = p_i60_3_;
      this.method = p_i60_4_;
      this.file = p_i60_5_;
      this.http = p_i60_6_;
      this.headers = p_i60_7_;
      this.body = p_i60_8_;
   }
}
