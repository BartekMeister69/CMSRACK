import java.io.IOException;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.settings.GameSettings;

public class jebac_vexiaap9sf3l81ao3 extends jebac_vexiakl614w3uw0xg {
   // $FF: synthetic field
   private final jebac_vexiakl614w3uw0xg parentScreen;
   // $FF: synthetic field
   private static final GameSettings.Options[] field_146399_a;
   // $FF: synthetic field
   private String field_146401_i;
   // $FF: synthetic field
   private final GameSettings game_settings;

   // $FF: synthetic method
   public void initGui() {
      int i = 0;
      this.field_146401_i = I18n.format("options.chat.title");
      GameSettings.Options[] var2 = field_146399_a;
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         GameSettings.Options gamesettings$options = var2[var4];
         if (gamesettings$options.getEnumFloat()) {
            this.buttonList.add(new jebac_vexiakfzkq5wmes2e(gamesettings$options.returnEnumOrdinal(), this.width / 2 - 155 + i % 2 * 160, this.height / 6 + 24 * (i >> 1), gamesettings$options));
         } else {
            this.buttonList.add(new jebac_vexiatgc7sxy17ln0(gamesettings$options.returnEnumOrdinal(), this.width / 2 - 155 + i % 2 * 160, this.height / 6 + 24 * (i >> 1), gamesettings$options, this.game_settings.getKeyBinding(gamesettings$options)));
         }

         ++i;
      }

      this.buttonList.add(new jebac_vexia4oibzo50ubf0(200, this.width / 2 - 100, this.height / 6 + 120, I18n.format("gui.done")));
   }

   static {
      field_146399_a = new GameSettings.Options[]{GameSettings.Options.CHAT_VISIBILITY, GameSettings.Options.CHAT_COLOR, GameSettings.Options.CHAT_LINKS, GameSettings.Options.CHAT_OPACITY, GameSettings.Options.CHAT_LINKS_PROMPT, GameSettings.Options.CHAT_SCALE, GameSettings.Options.CHAT_HEIGHT_FOCUSED, GameSettings.Options.CHAT_HEIGHT_UNFOCUSED, GameSettings.Options.CHAT_WIDTH, GameSettings.Options.REDUCED_DEBUG_INFO};
   }

   // $FF: synthetic method
   protected void actionPerformed(jebac_vexia4oibzo50ubf0 button) throws IOException {
      if (button.enabled) {
         if (button.id < 100 && button instanceof jebac_vexiatgc7sxy17ln0) {
            this.game_settings.setOptionValue(((jebac_vexiatgc7sxy17ln0)button).returnEnumOptions(), 1);
            button.displayString = this.game_settings.getKeyBinding(GameSettings.Options.getEnumOptions(button.id));
         }

         if (button.id == 200) {
            this.mc.gameSettings.saveOptions();
            this.mc.displayGuiScreen(this.parentScreen);
         }
      }

   }

   // $FF: synthetic method
   public void drawScreen(int mouseX, int mouseY, float partialTicks) {
      this.drawDefaultBackground();
      this.drawCenteredString(this.fontRendererObj, this.field_146401_i, this.width / 2, 20, 16777215);
      super.drawScreen(mouseX, mouseY, partialTicks);
   }

   // $FF: synthetic method
   public jebac_vexiaap9sf3l81ao3(jebac_vexiakl614w3uw0xg parentScreenIn, GameSettings gameSettingsIn) {
      this.parentScreen = parentScreenIn;
      this.game_settings = gameSettingsIn;
   }
}
