import net.minecraft.block.state.BlockStateBase;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.world.biome.BiomeGenBase;

public class jebac_vexiazz7bslggeoy9 {
   // $FF: synthetic method
   public static boolean block(BlockStateBase p_block_0_, jebac_vexia2nnti3ppoopl[] p_block_1_) {
      if (p_block_1_ == null) {
         return true;
      } else {
         jebac_vexia2nnti3ppoopl[] var2 = p_block_1_;
         int var3 = p_block_1_.length;

         for(int var4 = 0; var4 < var3; ++var4) {
            jebac_vexia2nnti3ppoopl matchblock = var2[var4];
            if (matchblock.matches(p_block_0_)) {
               return true;
            }
         }

         return false;
      }
   }

   // $FF: synthetic method
   public static boolean metadata(int p_metadata_0_, int[] p_metadata_1_) {
      if (p_metadata_1_ == null) {
         return true;
      } else {
         int[] var2 = p_metadata_1_;
         int var3 = p_metadata_1_.length;

         for(int var4 = 0; var4 < var3; ++var4) {
            int value = var2[var4];
            if (value == p_metadata_0_) {
               return true;
            }
         }

         return false;
      }
   }

   // $FF: synthetic method
   public static boolean sprite(TextureAtlasSprite p_sprite_0_, TextureAtlasSprite[] p_sprite_1_) {
      if (p_sprite_1_ == null) {
         return true;
      } else {
         TextureAtlasSprite[] var2 = p_sprite_1_;
         int var3 = p_sprite_1_.length;

         for(int var4 = 0; var4 < var3; ++var4) {
            TextureAtlasSprite textureAtlasSprite = var2[var4];
            if (textureAtlasSprite == p_sprite_0_) {
               return true;
            }
         }

         return false;
      }
   }

   // $FF: synthetic method
   public static boolean block(int p_block_0_, int p_block_1_, jebac_vexia2nnti3ppoopl[] p_block_2_) {
      if (p_block_2_ == null) {
         return true;
      } else {
         jebac_vexia2nnti3ppoopl[] var3 = p_block_2_;
         int var4 = p_block_2_.length;

         for(int var5 = 0; var5 < var4; ++var5) {
            jebac_vexia2nnti3ppoopl matchblock = var3[var5];
            if (matchblock.matches(p_block_0_, p_block_1_)) {
               return true;
            }
         }

         return false;
      }
   }

   // $FF: synthetic method
   public static boolean blockId(int p_blockId_0_, jebac_vexia2nnti3ppoopl[] p_blockId_1_) {
      if (p_blockId_1_ == null) {
         return true;
      } else {
         jebac_vexia2nnti3ppoopl[] var2 = p_blockId_1_;
         int var3 = p_blockId_1_.length;

         for(int var4 = 0; var4 < var3; ++var4) {
            jebac_vexia2nnti3ppoopl matchblock = var2[var4];
            if (matchblock.getBlockId() == p_blockId_0_) {
               return true;
            }
         }

         return false;
      }
   }

   // $FF: synthetic method
   public static boolean biome(BiomeGenBase p_biome_0_, BiomeGenBase[] p_biome_1_) {
      if (p_biome_1_ == null) {
         return true;
      } else {
         BiomeGenBase[] var2 = p_biome_1_;
         int var3 = p_biome_1_.length;

         for(int var4 = 0; var4 < var3; ++var4) {
            BiomeGenBase biomeGenBase = var2[var4];
            if (biomeGenBase == p_biome_0_) {
               return true;
            }
         }

         return false;
      }
   }
}
