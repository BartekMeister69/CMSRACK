import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.util.LinkedHashMap;

public class jebac_vexia6fkuije5g35d extends Thread {
   // $FF: synthetic field
   private jebac_vexiam5jljwh5z5qe httpPipelineConnection = null;
   // $FF: synthetic field
   private static final Charset ASCII = Charset.forName("ASCII");

   // $FF: synthetic method
   private jebac_vexiahx0fynbv9rl1 readResponse(InputStream p_readResponse_1_) throws IOException {
      String s = this.readLine(p_readResponse_1_);
      String[] astring = jebac_vexiakrwecfs16wve.tokenize(s, " ");
      if (astring.length < 3) {
         throw new IOException("Invalid status line: " + s);
      } else {
         int i = jebac_vexiakrwecfs16wve.parseInt(astring[1], 0);
         LinkedHashMap map = new LinkedHashMap();

         while(true) {
            String s3 = this.readLine(p_readResponse_1_);
            String s4;
            String s7;
            if (s3.length() <= 0) {
               byte[] abyte = null;
               s4 = (String)map.get("Content-Length");
               if (s4 != null) {
                  int k = jebac_vexiakrwecfs16wve.parseInt(s4, -1);
                  if (k > 0) {
                     abyte = new byte[k];
                     this.readFull(abyte, p_readResponse_1_);
                  }
               } else {
                  s7 = (String)map.get("Transfer-Encoding");
                  if (jebac_vexiakrwecfs16wve.equals(s7, "chunked")) {
                     abyte = this.readContentChunked(p_readResponse_1_);
                  }
               }

               return new jebac_vexiahx0fynbv9rl1(i, map, abyte);
            }

            int j = s3.indexOf(":");
            if (j > 0) {
               s4 = s3.substring(0, j).trim();
               s7 = s3.substring(j + 1).trim();
               map.put(s4, s7);
            }
         }
      }
   }

   // $FF: synthetic method
   public void run() {
      while(!Thread.interrupted()) {
         jebac_vexiakzpf6k4p0kch httppipelinerequest = null;

         try {
            httppipelinerequest = this.httpPipelineConnection.getNextRequestReceive();
            InputStream inputstream = this.httpPipelineConnection.getInputStream();
            jebac_vexiahx0fynbv9rl1 httpresponse = this.readResponse(inputstream);
            this.httpPipelineConnection.onResponseReceived(httppipelinerequest, httpresponse);
         } catch (InterruptedException var4) {
            return;
         } catch (Exception var5) {
            this.httpPipelineConnection.onExceptionReceive(var5);
         }
      }

   }

   // $FF: synthetic method
   private byte[] readContentChunked(InputStream p_readContentChunked_1_) throws IOException {
      ByteArrayOutputStream bytearrayoutputstream = new ByteArrayOutputStream();

      int i;
      do {
         String s = this.readLine(p_readContentChunked_1_);
         String[] astring = jebac_vexiakrwecfs16wve.tokenize(s, "; ");
         i = Integer.parseInt(astring[0], 16);
         byte[] abyte = new byte[i];
         this.readFull(abyte, p_readContentChunked_1_);
         bytearrayoutputstream.write(abyte);
         this.readLine(p_readContentChunked_1_);
      } while(i != 0);

      return bytearrayoutputstream.toByteArray();
   }

   // $FF: synthetic method
   public jebac_vexia6fkuije5g35d(jebac_vexiam5jljwh5z5qe p_i57_1_) {
      super("HttpPipelineReceiver");
      this.httpPipelineConnection = p_i57_1_;
   }

   // $FF: synthetic method
   private void readFull(byte[] p_readFull_1_, InputStream p_readFull_2_) throws IOException {
      int j;
      for(int i = 0; i < p_readFull_1_.length; i += j) {
         j = p_readFull_2_.read(p_readFull_1_, i, p_readFull_1_.length - i);
         if (j < 0) {
            throw new EOFException();
         }
      }

   }

   // $FF: synthetic method
   private String readLine(InputStream p_readLine_1_) throws IOException {
      ByteArrayOutputStream bytearrayoutputstream = new ByteArrayOutputStream();
      int i = -1;
      boolean flag = false;

      while(true) {
         int j = p_readLine_1_.read();
         if (j < 0) {
            break;
         }

         bytearrayoutputstream.write(j);
         if (i == 13 && j == 10) {
            flag = true;
            break;
         }

         i = j;
      }

      byte[] abyte = bytearrayoutputstream.toByteArray();
      String s = new String(abyte, ASCII);
      if (flag) {
         s = s.substring(0, s.length() - 2);
      }

      return s;
   }
}
