import java.awt.Color;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class jebac_vexiacs3qcki5ln4n {
   private static final int[]  ew;
   private static final String[]  ev;

   // $FF: synthetic method
   private static boolean llIlllIl(int var0, int var1) {
      return var0 < var1;
   }

   // $FF: synthetic method
   public static String toString(Color var0) {
      if (llIlllII(var0, Color.WHITE)) {
         return  ev[ ew[0]];
      } else if (llIlllII(var0, Color.BLACK)) {
         return  ev[ ew[1]];
      } else if (llIlllII(var0, Color.BLUE)) {
         return  ev[ ew[2]];
      } else if (llIlllII(var0, Color.GREEN)) {
         return  ev[ ew[3]];
      } else if (llIlllII(var0, Color.MAGENTA)) {
         return  ev[ ew[4]];
      } else if (llIlllII(var0, Color.RED)) {
         return  ev[ ew[5]];
      } else if (llIlllII(var0, Color.YELLOW)) {
         return  ev[ ew[6]];
      } else if (llIlllII(var0, Color.CYAN)) {
         return  ev[ ew[7]];
      } else if (llIlllII(var0, Color.GRAY)) {
         return  ev[ ew[8]];
      } else if (llIlllII(var0, Color.ORANGE)) {
         return  ev[ ew[9]];
      } else {
         return llIlllII(var0, Color.PINK) ?  ev[ ew[10]] :  ev[ ew[11]];
      }
   }

   // $FF: synthetic method
   private static boolean llIlllII(Object var0, Object var1) {
      return var0 == var1;
   }

   static {
      llIllIll();
      llIllIlI();
   }

   // $FF: synthetic method
   private static String lIlllllI(String var0, String var1) {
      try {
         String var2 = new SecretKeySpec(MessageDigest.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("ுைஹ", -2135094388)).digest(var1.getBytes(StandardCharsets.UTF_8)), jebac_vexiaqb58506wt8o3.  ‏ ("⥠⥎⥍⥕⥄⥋⥑⥊", 1331177762));
         Cipher var3 = Cipher.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("\uf1c3\uf1ed\uf1ee\uf1f6\uf1e7\uf1e8\uf1f2\uf1e9", -1513426559));
         var3.init( ew[2], var2);
         return new String(var3.doFinal(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var9) {
         var9.printStackTrace();
         return null;
      }
   }

   // $FF: synthetic method
   private static void llIllIlI() {
       ev = new String[ ew[12]];
       ev[ ew[0]] = lIlllIlI(jebac_vexiaqb58506wt8o3.  ‏ ("跄趡趁趟趽趛跃趡趻趭趔跊", 532516343), jebac_vexiaqb58506wt8o3.  ‏ ("ŞŁŬłŪ", -1573584636));
       ev[ ew[1]] = lIlllIlI(jebac_vexiaqb58506wt8o3.  ‏ ("밧밀밇뱺밚밊밙뱳밅발밬뱶", -1473987509), jebac_vexiaqb58506wt8o3.  ‏ ("\ue435\ue426\ue402\ue42a\ue413", -61348796));
       ev[ ew[2]] = lIllllIl(jebac_vexiaqb58506wt8o3.  ‏ ("쟍쟷잷쟬쟍쟸잲잲", 1389807503), jebac_vexiaqb58506wt8o3.  ‏ ("稌稚稀程稑", 891648585));
       ev[ ew[3]] = lIllllIl(jebac_vexiaqb58506wt8o3.  ‏ ("䳓䳯䳵䳵䳕䳯䲦䲫", -1159574378), jebac_vexiaqb58506wt8o3.  ‏ ("⾫⾊⾦⾱⾜", 1039347711));
       ev[ ew[4]] = lIlllIlI(jebac_vexiaqb58506wt8o3.  ‏ ("ᆃᆴᇈᆕᆑᆌᆏᆀᆪᆟᆑᇇ", -100855302), jebac_vexiaqb58506wt8o3.  ‏ ("ﱕﱢﱲﱢﱐ", 2041314353));
       ev[ ew[5]] = lIlllllI(jebac_vexiaqb58506wt8o3.  ‏ ("ՇԓԓԻԔԒԕԸԏԯԿՃ", -1541077634), jebac_vexiaqb58506wt8o3.  ‏ ("拈拄拜拉拥", 193487537));
       ev[ ew[6]] = lIlllIlI(jebac_vexiaqb58506wt8o3.  ‏ ("ᥖᥑᤁᥡᥞᥒᥠ\u1941\u196f\u197dᥘᤊ", 1484265783), jebac_vexiaqb58506wt8o3.  ‏ ("䊆䊋䊃䊯䊡", -2128985367));
       ev[ ew[7]] = lIllllIl(jebac_vexiaqb58506wt8o3.  ‏ ("궒궸궳궞궟궧귭귭", -283791920), jebac_vexiaqb58506wt8o3.  ‏ ("㘓㘘㘚㘣㘁", 371144278));
       ev[ ew[8]] = lIlllIlI(jebac_vexiaqb58506wt8o3.  ‏ ("\u05f7מץ\u05ff\u05cd\u05caַ\u05ed׀ֳֶֻ", 532481414), jebac_vexiaqb58506wt8o3.  ‏ ("繚繼繒繸繗", 1343913529));
       ev[ ew[9]] = lIlllIlI(jebac_vexiaqb58506wt8o3.  ‏ ("䑁䑬䑖䑚䐹䐴䑙䑰䑯䑵䑧䐽", -538033152), jebac_vexiaqb58506wt8o3.  ‏ ("赞赫赲资赗", 1156156732));
       ev[ ew[10]] = lIlllllI(jebac_vexiaqb58506wt8o3.  ‏ ("䭆䭬䭚䭅䭚䭍䭄䭭䬛䭲䭜䬖", -1396094165), jebac_vexiaqb58506wt8o3.  ‏ ("맱맹맵맱맗", 1500363155));
       ev[ ew[11]] = lIlllIlI(jebac_vexiaqb58506wt8o3.  ‏ ("\udfca\udf90\udfba\udfc7\udf86\udf97\udfaf\udfbc\udfb3\udfaa\udfab\udfc3", -997531650), jebac_vexiaqb58506wt8o3.  ‏ ("\u18afᢣ\u18aeᢥᢎ", 134158562));
   }

   // $FF: synthetic method
   private static String lIllllIl(String var0, String var1) {
      var0 = new String(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder var2 = new StringBuilder();
      int var3 = var1.toCharArray();
      String var4 =  ew[0];
      String var5 = var0.toCharArray();
      long var6 = var5.length;
      int var7 =  ew[0];

      do {
         if (!llIlllIl(var7, var6)) {
            return String.valueOf(var2);
         }

         int var8 = var5[var7];
         var2.append((char)(var8 ^ var3[var4 % var3.length]));
         jebac_vexiaqb58506wt8o3.  ‏ ("", 16092858).length();
         ++var4;
         ++var7;
         jebac_vexiaqb58506wt8o3.  ‏ ("", 1676101465).length();
      } while((86 ^ 82) != 0);

      return null;
   }

   // $FF: synthetic method
   private static void llIllIll() {
       ew = new int[13];
       ew[0] = (123 ^ 107) & ~(129 ^ 145);
       ew[1] = jebac_vexiaqb58506wt8o3.  ‏ ("㍉", 1725248361).length();
       ew[2] = jebac_vexiaqb58506wt8o3.  ‏ ("恇恇", -911318937).length();
       ew[3] = jebac_vexiaqb58506wt8o3.  ‏ ("賓賓賓", -595030797).length();
       ew[4] = 17 + 152 - 166 + 158 ^ 26 + 57 - -24 + 58;
       ew[5] = 6 ^ 103 ^ 234 ^ 142;
       ew[6] = 2 ^ 4;
       ew[7] = 79 ^ 18 ^ 193 ^ 155;
       ew[8] = 88 + 112 - 129 + 83 ^ 5 + 79 - -20 + 42;
       ew[9] = 94 + 37 - 113 + 160 ^ 91 + 37 - 34 + 93;
       ew[10] = 40 ^ 34;
       ew[11] = 139 ^ 175 ^ 143 ^ 160;
       ew[12] = 14 ^ 2;
   }

   // $FF: synthetic method
   public static Color fromString(String var0) {
      try {
         return (Color)Color.class.getField(var0).get((Object)null);
      } catch (IllegalAccessException | NoSuchFieldException | SecurityException | IllegalArgumentException var4) {
         return Color.WHITE;
      }
   }

   // $FF: synthetic method
   public static Color getRainbow(int var0, int var1) {
      int var2 = (float)((System.currentTimeMillis() + (long)var1) % (long)var0);
      var2 /= (float)var0;
      return Color.getHSBColor(var2, 1.0F, 1.0F);
   }

   // $FF: synthetic method
   private static String lIlllIlI(String var0, String var1) {
      try {
         Exception var2 = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("痆痏疾", -207260277)).digest(var1.getBytes(StandardCharsets.UTF_8)),  ew[8]), jebac_vexiaqb58506wt8o3.  ‏ ("≗≖≀", -1030675949));
         int var3 = Cipher.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("芣芢芴", -559054105));
         var3.init( ew[2], var2);
         return new String(var3.doFinal(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var9) {
         var9.printStackTrace();
         return null;
      }
   }
}
