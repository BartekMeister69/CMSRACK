import java.awt.Dimension;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Array;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.Properties;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.imageio.ImageIO;
import net.minecraft.client.LoadingScreenRenderer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.client.resources.DefaultResourcePack;
import net.minecraft.client.resources.IResource;
import net.minecraft.client.resources.IResourceManager;
import net.minecraft.client.resources.IResourcePack;
import net.minecraft.client.resources.ResourcePackRepository;
import net.minecraft.client.resources.model.ModelManager;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.server.integrated.IntegratedServer;
import net.minecraft.util.BlockPos;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;
import net.minecraft.world.WorldProvider;
import net.minecraft.world.WorldServer;
import org.apache.commons.io.IOUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.LWJGLException;
import org.lwjgl.Sys;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.DisplayMode;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL30;
import org.lwjgl.opengl.GLContext;
import org.lwjgl.opengl.PixelFormat;

public class jebac_vexiakrwecfs16wve {
   // $FF: synthetic field
   private static int texturePackClouds = 0;
   // $FF: synthetic field
   public static String openGlVendor = null;
   // $FF: synthetic field
   public static boolean fancyFogAvailable = false;
   // $FF: synthetic field
   public static String openGlRenderer = null;
   // $FF: synthetic field
   private static DisplayMode desktopDisplayMode = null;
   // $FF: synthetic field
   private static DisplayMode[] displayModes = null;
   // $FF: synthetic field
   public static int minecraftVersionInt = -1;
   // $FF: synthetic field
   private static Minecraft minecraft = Minecraft.getMinecraft();
   // $FF: synthetic field
   private static boolean initialized = false;
   // $FF: synthetic field
   private static final Logger LOGGER = LogManager.getLogger();
   // $FF: synthetic field
   public static boolean zoomMode = false;
   // $FF: synthetic field
   private static boolean notify64BitJava = false;
   // $FF: synthetic field
   public static jebac_vexiau51pw4i3zdqx glVersion = null;
   // $FF: synthetic field
   public static boolean occlusionAvailable = false;
   // $FF: synthetic field
   private static DefaultResourcePack defaultResourcePackLazy = null;
   // $FF: synthetic field
   public static jebac_vexiau51pw4i3zdqx glslVersion = null;
   // $FF: synthetic field
   private static GameSettings gameSettings = null;
   // $FF: synthetic field
   public static String[] openGlExtensions = null;
   // $FF: synthetic field
   private static int antialiasingLevel = 0;
   // $FF: synthetic field
   private static boolean fullscreenModeChecked = false;
   // $FF: synthetic field
   public static String openGlVersion = null;
   // $FF: synthetic field
   private static int availableProcessors = 0;
   // $FF: synthetic field
   public static final Float DEF_ALPHA_FUNC_LEVEL = 0.1F;
   // $FF: synthetic field
   private static boolean desktopModeChecked = false;
   // $FF: synthetic field
   private static Thread minecraftThread = null;
   // $FF: synthetic field
   public static boolean waterOpacityChanged = false;

   // $FF: synthetic method
   public static String[] getOpenGlExtensions() {
      if (openGlExtensions == null) {
         openGlExtensions = detectOpenGlExtensions();
      }

      return openGlExtensions;
   }

   // $FF: synthetic method
   public static boolean isSkyEnabled() {
      return gameSettings.ofSky;
   }

   // $FF: synthetic method
   public static String getVersion() {
      return "OptiFine_1.8.8_HD_U_H8";
   }

   // $FF: synthetic method
   private static DisplayMode[] getDisplayModes(DisplayMode[] p_getDisplayModes_0_, Dimension p_getDisplayModes_1_) {
      List list = new ArrayList();
      DisplayMode[] var3 = p_getDisplayModes_0_;
      int var4 = p_getDisplayModes_0_.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         DisplayMode displaymode = var3[var5];
         if ((double)displaymode.getWidth() == p_getDisplayModes_1_.getWidth() && (double)displaymode.getHeight() == p_getDisplayModes_1_.getHeight()) {
            list.add(displaymode);
         }
      }

      return (DisplayMode[])((DisplayMode[])list.toArray(new DisplayMode[0]));
   }

   // $FF: synthetic method
   public static void error(String p_error_0_) {
      LOGGER.error("[OptiFine] " + p_error_0_);
   }

   // $FF: synthetic method
   public static boolean isCustomFonts() {
      return gameSettings.ofCustomFonts;
   }

   // $FF: synthetic method
   public static TextureManager getTextureManager() {
      return minecraft.getTextureManager();
   }

   // $FF: synthetic method
   public static String arrayToString(int[] p_arrayToString_0_) {
      if (p_arrayToString_0_ == null) {
         return "";
      } else {
         StringBuilder stringbuffer = new StringBuilder(p_arrayToString_0_.length * 5);

         for(int i = 0; i < p_arrayToString_0_.length; ++i) {
            int j = p_arrayToString_0_[i];
            if (i > 0) {
               stringbuffer.append(", ");
            }

            stringbuffer.append(j);
         }

         return stringbuffer.toString();
      }
   }

   // $FF: synthetic method
   public static void log(String p_log_0_) {
      dbg(p_log_0_);
   }

   // $FF: synthetic method
   public static void setNotify64BitJava(boolean p_setNotify64BitJava_0_) {
      notify64BitJava = p_setNotify64BitJava_0_;
   }

   // $FF: synthetic method
   public static boolean isCustomItems() {
      return gameSettings.ofCustomItems;
   }

   // $FF: synthetic method
   public static boolean isBetterSnow() {
      return gameSettings.ofBetterSnow;
   }

   // $FF: synthetic method
   public static WorldServer getWorldServer() {
      World world = minecraft.theWorld;
      if (world == null) {
         return null;
      } else if (!minecraft.isIntegratedServerRunning()) {
         return null;
      } else {
         IntegratedServer integratedserver = minecraft.getIntegratedServer();
         if (integratedserver == null) {
            return null;
         } else {
            WorldProvider worldprovider = world.provider;
            if (worldprovider == null) {
               return null;
            } else {
               int i = worldprovider.getDimensionId();

               try {
                  return integratedserver.worldServerForDimension(i);
               } catch (NullPointerException var5) {
                  return null;
               }
            }
         }
      }
   }

   // $FF: synthetic method
   public static InputStream getResourceStream(IResourceManager p_getResourceStream_0_, ResourceLocation p_getResourceStream_1_) throws IOException {
      IResource iresource = p_getResourceStream_0_.getResource(p_getResourceStream_1_);
      return iresource == null ? null : iresource.getInputStream();
   }

   // $FF: synthetic method
   public static float limitTo1(float p_limitTo1_0_) {
      return p_limitTo1_0_ < 0.0F ? 0.0F : (p_limitTo1_0_ > 1.0F ? 1.0F : p_limitTo1_0_);
   }

   // $FF: synthetic method
   public static Object[] addObjectToArray(Object[] p_addObjectToArray_0_, Object p_addObjectToArray_1_) {
      if (p_addObjectToArray_0_ == null) {
         throw new NullPointerException("The given array is NULL");
      } else {
         int i = p_addObjectToArray_0_.length;
         int j = i + 1;
         Object[] aobject = (Object[])((Object[])Array.newInstance(p_addObjectToArray_0_.getClass().getComponentType(), j));
         System.arraycopy(p_addObjectToArray_0_, 0, aobject, 0, i);
         aobject[i] = p_addObjectToArray_1_;
         return aobject;
      }
   }

   // $FF: synthetic method
   public static boolean isAnimatedFlame() {
      return gameSettings.ofAnimatedFlame;
   }

   // $FF: synthetic method
   private static jebac_vexiau51pw4i3zdqx getGlVersionLwjgl() {
      return GLContext.getCapabilities().OpenGL44 ? new jebac_vexiau51pw4i3zdqx(4, 4) : (GLContext.getCapabilities().OpenGL43 ? new jebac_vexiau51pw4i3zdqx(4, 3) : (GLContext.getCapabilities().OpenGL42 ? new jebac_vexiau51pw4i3zdqx(4, 2) : (GLContext.getCapabilities().OpenGL41 ? new jebac_vexiau51pw4i3zdqx(4, 1) : (GLContext.getCapabilities().OpenGL40 ? new jebac_vexiau51pw4i3zdqx(4, 0) : (GLContext.getCapabilities().OpenGL33 ? new jebac_vexiau51pw4i3zdqx(3, 3) : (GLContext.getCapabilities().OpenGL32 ? new jebac_vexiau51pw4i3zdqx(3, 2) : (GLContext.getCapabilities().OpenGL31 ? new jebac_vexiau51pw4i3zdqx(3, 1) : (GLContext.getCapabilities().OpenGL30 ? new jebac_vexiau51pw4i3zdqx(3, 0) : (GLContext.getCapabilities().OpenGL21 ? new jebac_vexiau51pw4i3zdqx(2, 1) : (GLContext.getCapabilities().OpenGL20 ? new jebac_vexiau51pw4i3zdqx(2, 0) : (GLContext.getCapabilities().OpenGL15 ? new jebac_vexiau51pw4i3zdqx(1, 5) : (GLContext.getCapabilities().OpenGL14 ? new jebac_vexiau51pw4i3zdqx(1, 4) : (GLContext.getCapabilities().OpenGL13 ? new jebac_vexiau51pw4i3zdqx(1, 3) : (GLContext.getCapabilities().OpenGL12 ? new jebac_vexiau51pw4i3zdqx(1, 2) : (GLContext.getCapabilities().OpenGL11 ? new jebac_vexiau51pw4i3zdqx(1, 1) : new jebac_vexiau51pw4i3zdqx(1, 0))))))))))))))));
   }

   // $FF: synthetic method
   public static boolean isMultiTexture() {
      return getAnisotropicFilterLevel() > 1 || getAntialiasingLevel() > 0;
   }

   // $FF: synthetic method
   public static boolean isSunTexture() {
      return isSunMoonEnabled() && (!isShaders() || jebac_vexiaflhnh80r1906.isSun());
   }

   // $FF: synthetic method
   public static jebac_vexiau51pw4i3zdqx getGlVersion() {
      if (glVersion == null) {
         String s = GL11.glGetString(7938);
         glVersion = parseGlVersion(s, (jebac_vexiau51pw4i3zdqx)null);
         if (glVersion == null) {
            glVersion = getGlVersionLwjgl();
         }
      }

      return glVersion;
   }

   // $FF: synthetic method
   public static double limit(double p_limit_0_, double p_limit_2_, double p_limit_4_) {
      return p_limit_0_ < p_limit_2_ ? p_limit_2_ : (p_limit_0_ > p_limit_4_ ? p_limit_4_ : p_limit_0_);
   }

   // $FF: synthetic method
   public static void updateAvailableProcessors() {
      availableProcessors = Runtime.getRuntime().availableProcessors();
   }

   // $FF: synthetic method
   public static boolean isSmoothWorld() {
      return gameSettings.ofSmoothWorld;
   }

   // $FF: synthetic method
   public static boolean isSmoothBiomes() {
      return gameSettings.ofSmoothBiomes;
   }

   // $FF: synthetic method
   public static boolean isAnisotropicFiltering() {
      return getAnisotropicFilterLevel() > 1;
   }

   // $FF: synthetic method
   public static boolean isWaterParticles() {
      return gameSettings.ofWaterParticles;
   }

   // $FF: synthetic method
   private static DisplayMode getDisplayMode(DisplayMode[] p_getDisplayMode_0_, DisplayMode p_getDisplayMode_1_) {
      if (p_getDisplayMode_1_ != null) {
         DisplayMode[] var2 = p_getDisplayMode_0_;
         int var3 = p_getDisplayMode_0_.length;

         for(int var4 = 0; var4 < var3; ++var4) {
            DisplayMode displaymode = var2[var4];
            if (displaymode.getBitsPerPixel() == p_getDisplayMode_1_.getBitsPerPixel() && displaymode.getFrequency() == p_getDisplayMode_1_.getFrequency()) {
               return displaymode;
            }
         }
      }

      if (p_getDisplayMode_0_.length <= 0) {
         return null;
      } else {
         Arrays.sort(p_getDisplayMode_0_, new jebac_vexiaox1xsehsulq4());
         return p_getDisplayMode_0_[p_getDisplayMode_0_.length - 1];
      }
   }

   // $FF: synthetic method
   public static boolean isWeatherEnabled() {
      return gameSettings.ofWeather;
   }

   // $FF: synthetic method
   public static boolean equals(Object p_equals_0_, Object p_equals_1_) {
      return Objects.equals(p_equals_0_, p_equals_1_);
   }

   // $FF: synthetic method
   public static String[] readLines(InputStream p_readLines_0_) throws IOException {
      List list = new ArrayList();
      InputStreamReader inputstreamreader = new InputStreamReader(p_readLines_0_, StandardCharsets.US_ASCII);
      BufferedReader bufferedreader = new BufferedReader(inputstreamreader);

      while(true) {
         String s = bufferedreader.readLine();
         if (s == null) {
            return (String[])((String[])list.toArray(new String[0]));
         }

         list.add(s);
      }
   }

   // $FF: synthetic method
   public static int getRandom(BlockPos p_getRandom_0_, int p_getRandom_1_) {
      int i = intHash(p_getRandom_1_ + 37);
      i = intHash(i + p_getRandom_0_.getX());
      i = intHash(i + p_getRandom_0_.getZ());
      i = intHash(i + p_getRandom_0_.getY());
      return i;
   }

   // $FF: synthetic method
   public static boolean isDynamicHandLight() {
      return isDynamicLights() && (!isShaders() || jebac_vexiaflhnh80r1906.isDynamicHandLight());
   }

   // $FF: synthetic method
   public static boolean isVoidParticles() {
      return gameSettings.ofVoidParticles;
   }

   // $FF: synthetic method
   public static boolean isRainSplash() {
      return gameSettings.ofRainSplash;
   }

   // $FF: synthetic method
   public static int getAvailableProcessors() {
      return availableProcessors;
   }

   // $FF: synthetic method
   public static void dbg(String p_dbg_0_) {
      LOGGER.info("[OptiFine] " + p_dbg_0_);
   }

   // $FF: synthetic method
   public static boolean isFastRender() {
      return gameSettings.ofFastRender;
   }

   // $FF: synthetic method
   public static DisplayMode getDisplayMode(Dimension p_getDisplayMode_0_) throws LWJGLException {
      DisplayMode[] adisplaymode = getDisplayModes();
      DisplayMode[] var2 = adisplaymode;
      int var3 = adisplaymode.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         DisplayMode displaymode = var2[var4];
         if (displaymode.getWidth() == p_getDisplayMode_0_.width && displaymode.getHeight() == p_getDisplayMode_0_.height) {
            return displaymode;
         }
      }

      return desktopDisplayMode;
   }

   // $FF: synthetic method
   public static jebac_vexiau51pw4i3zdqx getGlslVersion() {
      if (glslVersion == null) {
         String s = GL11.glGetString(35724);
         glslVersion = parseGlVersion(s, (jebac_vexiau51pw4i3zdqx)null);
         if (glslVersion == null) {
            glslVersion = new jebac_vexiau51pw4i3zdqx(1, 10);
         }
      }

      return glslVersion;
   }

   // $FF: synthetic method
   private static String[] detectOpenGlExtensions() {
      try {
         jebac_vexiau51pw4i3zdqx glversion = getGlVersion();
         if (glversion.getMajor() >= 3) {
            int i = GL11.glGetInteger(33309);
            if (i > 0) {
               String[] astring = new String[i];

               for(int j = 0; j < i; ++j) {
                  astring[j] = GL30.glGetStringi(7939, j);
               }

               return astring;
            }
         }
      } catch (Exception var5) {
         var5.printStackTrace();
      }

      try {
         String s = GL11.glGetString(7939);
         String[] astring1 = s.split(" ");
         return astring1;
      } catch (Exception var4) {
         var4.printStackTrace();
         return new String[0];
      }
   }

   // $FF: synthetic method
   public static boolean isConnectedTexturesFancy() {
      return gameSettings.ofConnectedTextures == 2;
   }

   // $FF: synthetic method
   public static DynamicTexture getMojangLogoTexture(DynamicTexture p_getMojangLogoTexture_0_) {
      try {
         ResourceLocation resourcelocation = new ResourceLocation("textures/gui/title/mojang.png");
         InputStream inputstream = getResourceStream(resourcelocation);
         if (inputstream == null) {
            return p_getMojangLogoTexture_0_;
         } else {
            BufferedImage bufferedimage = ImageIO.read(inputstream);
            return bufferedimage == null ? p_getMojangLogoTexture_0_ : new DynamicTexture(bufferedimage);
         }
      } catch (Exception var4) {
         warn(var4.getClass().getName() + ": " + var4.getMessage());
         return p_getMojangLogoTexture_0_;
      }
   }

   // $FF: synthetic method
   public static Object[] addObjectToArray(Object[] p_addObjectToArray_0_, Object p_addObjectToArray_1_, int p_addObjectToArray_2_) {
      List list = new ArrayList(Arrays.asList(p_addObjectToArray_0_));
      list.add(p_addObjectToArray_2_, p_addObjectToArray_1_);
      Object[] aobject = (Object[])((Object[])Array.newInstance(p_addObjectToArray_0_.getClass().getComponentType(), list.size()));
      return list.toArray(aobject);
   }

   // $FF: synthetic method
   public static boolean isAnimatedFire() {
      return gameSettings.ofAnimatedFire;
   }

   // $FF: synthetic method
   public static boolean isTimeDayOnly() {
      return gameSettings.ofTime == 1;
   }

   // $FF: synthetic method
   public static void checkDisplayMode() {
      try {
         if (minecraft.isFullScreen()) {
            if (fullscreenModeChecked) {
               return;
            }

            fullscreenModeChecked = true;
            desktopModeChecked = false;
            DisplayMode displaymode = Display.getDisplayMode();
            Dimension dimension = getFullscreenDimension();
            if (dimension == null) {
               return;
            }

            if (displaymode.getWidth() == dimension.width && displaymode.getHeight() == dimension.height) {
               return;
            }

            DisplayMode displaymode1 = getDisplayMode(dimension);
            if (displaymode1 == null) {
               return;
            }

            Display.setDisplayMode(displaymode1);
            minecraft.displayWidth = Display.getDisplayMode().getWidth();
            minecraft.displayHeight = Display.getDisplayMode().getHeight();
            if (minecraft.displayWidth <= 0) {
               minecraft.displayWidth = 1;
            }

            if (minecraft.displayHeight <= 0) {
               minecraft.displayHeight = 1;
            }

            if (minecraft.currentScreen != null) {
               jebac_vexiakl8zv2fyoaq8 scaledresolution = new jebac_vexiakl8zv2fyoaq8(minecraft);
               int i = scaledresolution.getScaledWidth();
               int j = scaledresolution.getScaledHeight();
               minecraft.currentScreen.setWorldAndResolution(minecraft, i, j);
            }

            minecraft.loadingScreen = new LoadingScreenRenderer(minecraft);
            updateFramebufferSize();
            Display.setFullscreen(true);
            minecraft.gameSettings.updateVSync();
            GlStateManager.enableTexture2D();
         } else {
            if (desktopModeChecked) {
               return;
            }

            desktopModeChecked = true;
            fullscreenModeChecked = false;
            minecraft.gameSettings.updateVSync();
            Display.update();
            GlStateManager.enableTexture2D();
            Display.setResizable(false);
            Display.setResizable(true);
         }
      } catch (Exception var6) {
         var6.printStackTrace();
         gameSettings.ofFullscreenMode = "Default";
         gameSettings.saveOfOptions();
      }

   }

   // $FF: synthetic method
   public static boolean isTreesSmart() {
      return gameSettings.ofTrees == 4;
   }

   // $FF: synthetic method
   public static boolean isFogFast() {
      return gameSettings.ofFogType == 1;
   }

   // $FF: synthetic method
   public static IResource getResource(ResourceLocation p_getResource_0_) throws IOException {
      return minecraft.getResourceManager().getResource(p_getResource_0_);
   }

   // $FF: synthetic method
   public static boolean isAnimatedRedstone() {
      return gameSettings.ofAnimatedRedstone;
   }

   // $FF: synthetic method
   public static void showGuiMessage(String p_showGuiMessage_0_, String p_showGuiMessage_1_) {
      jebac_vexiavonyz736wbrj guimessage = new jebac_vexiavonyz736wbrj(minecraft.currentScreen, p_showGuiMessage_0_, p_showGuiMessage_1_);
      minecraft.displayGuiScreen(guimessage);
   }

   // $FF: synthetic method
   public static boolean isDynamicLights() {
      return gameSettings.ofDynamicLights != 3;
   }

   // $FF: synthetic method
   public static boolean isConnectedTextures() {
      return gameSettings.ofConnectedTextures != 3;
   }

   // $FF: synthetic method
   public static boolean isCloudsOff() {
      return gameSettings.ofClouds != 0 ? gameSettings.ofClouds == 3 : (isShaders() && !jebac_vexiaflhnh80r1906.shaderPackClouds.isDefault() ? jebac_vexiaflhnh80r1906.shaderPackClouds.isOff() : texturePackClouds != 0 && texturePackClouds == 3);
   }

   // $FF: synthetic method
   public static float getFogStart() {
      return gameSettings.ofFogStart;
   }

   // $FF: synthetic method
   public static boolean parseBoolean(String p_parseBoolean_0_, boolean p_parseBoolean_1_) {
      try {
         if (p_parseBoolean_0_ == null) {
            return p_parseBoolean_1_;
         } else {
            p_parseBoolean_0_ = p_parseBoolean_0_.trim();
            return Boolean.parseBoolean(p_parseBoolean_0_);
         }
      } catch (NumberFormatException var3) {
         return p_parseBoolean_1_;
      }
   }

   // $FF: synthetic method
   public static boolean isAntialiasing() {
      return getAntialiasingLevel() > 0;
   }

   // $FF: synthetic method
   public static boolean between(int p_between_0_, int p_between_1_, int p_between_2_) {
      return p_between_0_ >= p_between_1_ && p_between_0_ <= p_between_2_;
   }

   // $FF: synthetic method
   protected static String getOpenGlVersionString() {
      jebac_vexiau51pw4i3zdqx glversion = getGlVersion();
      String s = "" + glversion.getMajor() + "." + glversion.getMinor() + "." + glversion.getRelease();
      return s;
   }

   // $FF: synthetic method
   public static boolean isNotify64BitJava() {
      return notify64BitJava;
   }

   // $FF: synthetic method
   public static boolean isRainOff() {
      return gameSettings.ofRain == 3;
   }

   // $FF: synthetic method
   public static boolean hasResource(ResourceLocation p_hasResource_0_) {
      IResourcePack iresourcepack = getDefiningResourcePack(p_hasResource_0_);
      return iresourcepack != null;
   }

   // $FF: synthetic method
   public static boolean isMoonTexture() {
      return isSunMoonEnabled() && (!isShaders() || jebac_vexiaflhnh80r1906.isMoon());
   }

   // $FF: synthetic method
   public static boolean isFogFancy() {
      return isFancyFogAvailable() && gameSettings.ofFogType == 2;
   }

   // $FF: synthetic method
   public static int getAntialiasingLevel() {
      return antialiasingLevel;
   }

   // $FF: synthetic method
   public static void initDisplay() {
      checkInitialized();
      antialiasingLevel = gameSettings.ofAaLevel;
      checkDisplaySettings();
      checkDisplayMode();
      minecraftThread = Thread.currentThread();
      updateThreadPriorities();
      jebac_vexiaflhnh80r1906.startup(Minecraft.getMinecraft());
   }

   // $FF: synthetic method
   public static ModelManager getModelManager() {
      return minecraft.getRenderItem().modelManager;
   }

   // $FF: synthetic method
   public static String getVersionDebug() {
      StringBuffer stringbuffer = new StringBuffer(32);
      if (isDynamicLights()) {
         stringbuffer.append("DL: ");
         stringbuffer.append(jebac_vexiauewcqfp4vafj.getCount());
         stringbuffer.append(", ");
      }

      stringbuffer.append("OptiFine_1.8.8_HD_U_H8");
      String s = jebac_vexiaflhnh80r1906.getShaderPackName();
      if (s != null) {
         stringbuffer.append(", ");
         stringbuffer.append(s);
      }

      return stringbuffer.toString();
   }

   // $FF: synthetic method
   public static IResourcePack[] getResourcePacks() {
      ResourcePackRepository resourcepackrepository = minecraft.getResourcePackRepository();
      List list = resourcepackrepository.getRepositoryEntries();
      List list1 = new ArrayList();
      Iterator var3 = list.iterator();

      while(var3.hasNext()) {
         Object resourcepackrepository$entry = var3.next();
         list1.add(((ResourcePackRepository.Entry)resourcepackrepository$entry).getResourcePack());
      }

      if (resourcepackrepository.getResourcePackInstance() != null) {
         list1.add(resourcepackrepository.getResourcePackInstance());
      }

      return (IResourcePack[])((IResourcePack[])list1.toArray(new IResourcePack[0]));
   }

   // $FF: synthetic method
   public static int limit(int p_limit_0_, int p_limit_1_, int p_limit_2_) {
      return p_limit_0_ < p_limit_1_ ? p_limit_1_ : (p_limit_0_ > p_limit_2_ ? p_limit_2_ : p_limit_0_);
   }

   // $FF: synthetic method
   public static boolean isPotionParticles() {
      return gameSettings.ofPotionParticles;
   }

   // $FF: synthetic method
   public static void drawFps() {
      String s1 = Minecraft.getDebugFPS() + " fps";
      minecraft.fontRendererObj.drawString(s1, 2, 2, -2039584);
   }

   // $FF: synthetic method
   public static IResourceManager getResourceManager() {
      return minecraft.getResourceManager();
   }

   // $FF: synthetic method
   private static ByteBuffer readIconImage(InputStream p_readIconImage_0_) throws IOException {
      BufferedImage bufferedimage = ImageIO.read(p_readIconImage_0_);
      int[] aint = bufferedimage.getRGB(0, 0, bufferedimage.getWidth(), bufferedimage.getHeight(), (int[])null, 0, bufferedimage.getWidth());
      ByteBuffer bytebuffer = ByteBuffer.allocate(4 * aint.length);
      int[] var4 = aint;
      int var5 = aint.length;

      for(int var6 = 0; var6 < var5; ++var6) {
         int i = var4[var6];
         bytebuffer.putInt(i << 8 | i >> 24 & 255);
      }

      bytebuffer.flip();
      return bytebuffer;
   }

   // $FF: synthetic method
   public static Minecraft getMinecraft() {
      return minecraft;
   }

   // $FF: synthetic method
   public static boolean isShowCapes() {
      return gameSettings.ofShowCapes;
   }

   // $FF: synthetic method
   public static boolean isVignetteEnabled() {
      boolean var10000;
      label30: {
         if (!isShaders() || jebac_vexiaflhnh80r1906.isVignette()) {
            if (gameSettings.ofVignette == 0) {
               if (gameSettings.fancyGraphics) {
                  break label30;
               }
            } else if (gameSettings.ofVignette == 2) {
               break label30;
            }
         }

         var10000 = false;
         return var10000;
      }

      var10000 = true;
      return var10000;
   }

   // $FF: synthetic method
   public static boolean isRandomMobs() {
      return gameSettings.ofRandomMobs;
   }

   // $FF: synthetic method
   public static String[] tokenize(String p_tokenize_0_, String p_tokenize_1_) {
      StringTokenizer stringtokenizer = new StringTokenizer(p_tokenize_0_, p_tokenize_1_);
      ArrayList list = new ArrayList();

      while(stringtokenizer.hasMoreTokens()) {
         String s = stringtokenizer.nextToken();
         list.add(s);
      }

      return (String[])((String[])list.toArray(new String[0]));
   }

   // $FF: synthetic method
   public static boolean isCloudsFancy() {
      return gameSettings.ofClouds != 0 ? gameSettings.ofClouds == 2 : (isShaders() && !jebac_vexiaflhnh80r1906.shaderPackClouds.isDefault() ? jebac_vexiaflhnh80r1906.shaderPackClouds.isFancy() : (texturePackClouds != 0 ? texturePackClouds == 2 : gameSettings.fancyGraphics));
   }

   // $FF: synthetic method
   public static int getBitsOs() {
      String s = System.getenv("ProgramFiles(X86)");
      return s != null ? 64 : 32;
   }

   // $FF: synthetic method
   public static boolean isMinecraftThread() {
      return Thread.currentThread() == minecraftThread;
   }

   // $FF: synthetic method
   public static int intHash(int p_intHash_0_) {
      p_intHash_0_ = p_intHash_0_ ^ 61 ^ p_intHash_0_ >> 16;
      p_intHash_0_ += p_intHash_0_ << 3;
      p_intHash_0_ ^= p_intHash_0_ >> 4;
      p_intHash_0_ *= 668265261;
      p_intHash_0_ ^= p_intHash_0_ >> 15;
      return p_intHash_0_;
   }

   // $FF: synthetic method
   public static boolean isTimeDefault() {
      return gameSettings.ofTime == 0;
   }

   // $FF: synthetic method
   public static String arrayToString(Object[] p_arrayToString_0_) {
      if (p_arrayToString_0_ == null) {
         return "";
      } else {
         StringBuffer stringbuffer = new StringBuffer(p_arrayToString_0_.length * 5);

         for(int i = 0; i < p_arrayToString_0_.length; ++i) {
            Object object = p_arrayToString_0_[i];
            if (i > 0) {
               stringbuffer.append(", ");
            }

            stringbuffer.append(object);
         }

         return stringbuffer.toString();
      }
   }

   // $FF: synthetic method
   public static int getMinecraftVersionInt() {
      if (minecraftVersionInt < 0) {
         String[] astring = tokenize("1.8.8", ".");
         int i = 0;
         if (astring.length > 0) {
            i += 10000 * parseInt(astring[0], 0);
         }

         if (astring.length > 1) {
            i += 100 * parseInt(astring[1], 0);
         }

         if (astring.length > 2) {
            i += parseInt(astring[2], 0);
         }

         minecraftVersionInt = i;
      }

      return minecraftVersionInt;
   }

   // $FF: synthetic method
   public static RenderGlobal getRenderGlobal() {
      return minecraft.renderGlobal;
   }

   // $FF: synthetic method
   public static boolean isCullFacesLeaves() {
      return gameSettings.ofTrees == 0 ? !gameSettings.fancyGraphics : gameSettings.ofTrees == 4;
   }

   // $FF: synthetic method
   public static int[] addIntsToArray(int[] p_addIntsToArray_0_, int[] p_addIntsToArray_1_) {
      if (p_addIntsToArray_0_ != null && p_addIntsToArray_1_ != null) {
         int i = p_addIntsToArray_0_.length;
         int j = i + p_addIntsToArray_1_.length;
         int[] aint = new int[j];
         System.arraycopy(p_addIntsToArray_0_, 0, aint, 0, i);
         System.arraycopy(p_addIntsToArray_1_, 0, aint, i, p_addIntsToArray_1_.length);
         return aint;
      } else {
         throw new NullPointerException("The given array is NULL");
      }
   }

   // $FF: synthetic method
   public static DefaultResourcePack getDefaultResourcePack() {
      if (defaultResourcePackLazy == null) {
         Minecraft minecraft = Minecraft.getMinecraft();
         defaultResourcePackLazy = (DefaultResourcePack)jebac_vexiawp5rpzl0e6ma.getFieldValue(minecraft, jebac_vexiawp5rpzl0e6ma.Minecraft_defaultResourcePack);
         if (defaultResourcePackLazy == null) {
            ResourcePackRepository resourcepackrepository = minecraft.getResourcePackRepository();
            if (resourcepackrepository != null) {
               defaultResourcePackLazy = (DefaultResourcePack)resourcepackrepository.rprDefaultResourcePack;
            }
         }
      }

      return defaultResourcePackLazy;
   }

   // $FF: synthetic method
   public static int getMipmapType() {
      switch(gameSettings.ofMipmapType) {
      case 0:
         return 9986;
      case 1:
         return 9986;
      case 2:
         if (isMultiTexture()) {
            return 9985;
         }

         return 9986;
      case 3:
         if (isMultiTexture()) {
            return 9987;
         }

         return 9986;
      default:
         return 9986;
      }
   }

   // $FF: synthetic method
   public static Dimension getFullscreenDimension() {
      if (desktopDisplayMode == null) {
         return null;
      } else if (gameSettings == null) {
         return new Dimension(desktopDisplayMode.getWidth(), desktopDisplayMode.getHeight());
      } else {
         String s = gameSettings.ofFullscreenMode;
         if (s.equals("Default")) {
            return new Dimension(desktopDisplayMode.getWidth(), desktopDisplayMode.getHeight());
         } else {
            String[] astring = tokenize(s, " x");
            return astring.length < 2 ? new Dimension(desktopDisplayMode.getWidth(), desktopDisplayMode.getHeight()) : new Dimension(parseInt(astring[0], -1), parseInt(astring[1], -1));
         }
      }
   }

   // $FF: synthetic method
   public static boolean isDrippingWaterLava() {
      return gameSettings.ofDrippingWaterLava;
   }

   // $FF: synthetic method
   public static boolean isAnimatedTerrain() {
      return gameSettings.ofAnimatedTerrain;
   }

   // $FF: synthetic method
   private static void setThreadPriority(String p_setThreadPriority_0_, int p_setThreadPriority_1_) {
      try {
         ThreadGroup threadgroup = Thread.currentThread().getThreadGroup();
         if (threadgroup == null) {
            return;
         }

         int i = (threadgroup.activeCount() + 10) * 2;
         Thread[] athread = new Thread[i];
         threadgroup.enumerate(athread, false);

         for(int j = 0; j < athread.length; ++j) {
            Thread thread = athread[j];
            if (thread != null && thread.getName().startsWith(p_setThreadPriority_0_)) {
               thread.setPriority(p_setThreadPriority_1_);
            }
         }
      } catch (Throwable var7) {
         warn(var7.getClass().getName() + ": " + var7.getMessage());
      }

   }

   // $FF: synthetic method
   public static float limit(float p_limit_0_, float p_limit_1_, float p_limit_2_) {
      return p_limit_0_ < p_limit_1_ ? p_limit_1_ : (p_limit_0_ > p_limit_2_ ? p_limit_2_ : p_limit_0_);
   }

   // $FF: synthetic method
   public static boolean isAnimatedExplosion() {
      return gameSettings.ofAnimatedExplosion;
   }

   // $FF: synthetic method
   public static boolean isRainFancy() {
      return gameSettings.ofRain == 0 ? gameSettings.fancyGraphics : gameSettings.ofRain == 2;
   }

   // $FF: synthetic method
   public static int getMipmapLevels() {
      return gameSettings.mipmapLevels;
   }

   // $FF: synthetic method
   public static float getAlphaFuncLevel() {
      return DEF_ALPHA_FUNC_LEVEL;
   }

   // $FF: synthetic method
   public static int getAnisotropicFilterLevel() {
      return gameSettings.ofAfLevel;
   }

   // $FF: synthetic method
   public static String normalize(String p_normalize_0_) {
      return p_normalize_0_ == null ? "" : p_normalize_0_;
   }

   // $FF: synthetic method
   public static boolean isSunMoonEnabled() {
      return gameSettings.ofSunMoon;
   }

   // $FF: synthetic method
   public static IResourcePack getDefiningResourcePack(ResourceLocation p_getDefiningResourcePack_0_) {
      ResourcePackRepository resourcepackrepository = minecraft.getResourcePackRepository();
      IResourcePack iresourcepack = resourcepackrepository.getResourcePackInstance();
      if (iresourcepack != null && iresourcepack.resourceExists(p_getDefiningResourcePack_0_)) {
         return iresourcepack;
      } else {
         List list = (List)jebac_vexiawp5rpzl0e6ma.getFieldValue(resourcepackrepository, jebac_vexiawp5rpzl0e6ma.ResourcePackRepository_repositoryEntries);
         if (list != null) {
            for(int i = list.size() - 1; i >= 0; --i) {
               ResourcePackRepository.Entry resourcepackrepository$entry = (ResourcePackRepository.Entry)list.get(i);
               IResourcePack iresourcepack1 = resourcepackrepository$entry.getResourcePack();
               if (iresourcepack1.resourceExists(p_getDefiningResourcePack_0_)) {
                  return iresourcepack1;
               }
            }
         }

         return getDefaultResourcePack().resourceExists(p_getDefiningResourcePack_0_) ? getDefaultResourcePack() : null;
      }
   }

   // $FF: synthetic method
   public static boolean isSwampColors() {
      return gameSettings.ofSwampColors;
   }

   // $FF: synthetic method
   public static boolean isUseAlphaFunc() {
      float f = getAlphaFuncLevel();
      return f > DEF_ALPHA_FUNC_LEVEL + 1.0E-5F;
   }

   // $FF: synthetic method
   public static DisplayMode[] getDisplayModes() {
      if (displayModes == null) {
         try {
            DisplayMode[] adisplaymode = Display.getAvailableDisplayModes();
            Set set = getDisplayModeDimensions(adisplaymode);
            List list = new ArrayList();
            Iterator var3 = set.iterator();

            while(var3.hasNext()) {
               Dimension dimension = (Dimension)var3.next();
               DisplayMode[] adisplaymode1 = getDisplayModes(adisplaymode, dimension);
               DisplayMode displaymode = getDisplayMode(adisplaymode1, desktopDisplayMode);
               if (displaymode != null) {
                  list.add(displaymode);
               }
            }

            DisplayMode[] adisplaymode2 = (DisplayMode[])((DisplayMode[])list.toArray(new DisplayMode[0]));
            Arrays.sort(adisplaymode2, new jebac_vexiaox1xsehsulq4());
            return adisplaymode2;
         } catch (Exception var7) {
            var7.printStackTrace();
            displayModes = new DisplayMode[]{desktopDisplayMode};
         }
      }

      return displayModes;
   }

   // $FF: synthetic method
   private static void checkOpenGlCaps() {
      log("");
      log(getVersion());
      log("OS: " + System.getProperty("os.name") + " (" + System.getProperty("os.arch") + ") version " + System.getProperty("os.version"));
      log("Java: " + System.getProperty("java.version") + ", " + System.getProperty("java.vendor"));
      log("VM: " + System.getProperty("java.vm.name") + " (" + System.getProperty("java.vm.info") + "), " + System.getProperty("java.vm.vendor"));
      log("LWJGL: " + Sys.getVersion());
      openGlVersion = GL11.glGetString(7938);
      openGlRenderer = GL11.glGetString(7937);
      openGlVendor = GL11.glGetString(7936);
      log("OpenGL: " + openGlRenderer + ", version " + openGlVersion + ", " + openGlVendor);
      log("OpenGL Version: " + getOpenGlVersionString());
      if (!GLContext.getCapabilities().OpenGL12) {
         log("OpenGL Mipmap levels: Not available (GL12.GL_TEXTURE_MAX_LEVEL)");
      }

      fancyFogAvailable = GLContext.getCapabilities().GL_NV_fog_distance;
      if (!fancyFogAvailable) {
         log("OpenGL Fancy fog: Not available (GL_NV_fog_distance)");
      }

      occlusionAvailable = GLContext.getCapabilities().GL_ARB_occlusion_query;
      if (!occlusionAvailable) {
         log("OpenGL Occlussion culling: Not available (GL_ARB_occlusion_query)");
      }

      int i = jebac_vexiamg04e8zzk81s.getGLMaximumTextureSize();
      dbg("Maximum texture size: " + i + "x" + i);
   }

   // $FF: synthetic method
   public static float getAmbientOcclusionLevel() {
      return isShaders() && jebac_vexiaflhnh80r1906.aoLevel >= 0.0F ? jebac_vexiaflhnh80r1906.aoLevel : gameSettings.ofAoLevel;
   }

   // $FF: synthetic method
   public static String[] getDisplayModeNames() {
      DisplayMode[] adisplaymode = getDisplayModes();
      String[] astring = new String[adisplaymode.length];

      for(int i = 0; i < adisplaymode.length; ++i) {
         DisplayMode displaymode = adisplaymode[i];
         String s = "" + displaymode.getWidth() + "x" + displaymode.getHeight();
         astring[i] = s;
      }

      return astring;
   }

   // $FF: synthetic method
   public static boolean hasResource(IResourceManager p_hasResource_0_, ResourceLocation p_hasResource_1_) {
      try {
         IResource iresource = p_hasResource_0_.getResource(p_hasResource_1_);
         return iresource != null;
      } catch (IOException var3) {
         return false;
      }
   }

   // $FF: synthetic method
   public static boolean isStarsEnabled() {
      return gameSettings.ofStars;
   }

   // $FF: synthetic method
   private static void checkInitialized() {
      if (!initialized && Display.isCreated()) {
         initialized = true;
         checkOpenGlCaps();
      }

   }

   // $FF: synthetic method
   public static boolean isSingleProcessor() {
      return getAvailableProcessors() <= 1;
   }

   // $FF: synthetic method
   public static void updateFramebufferSize() {
      minecraft.getFramebuffer().createBindFramebuffer(minecraft.displayWidth, minecraft.displayHeight);
      if (minecraft.entityRenderer != null) {
         minecraft.entityRenderer.updateShaderGroupSize(minecraft.displayWidth, minecraft.displayHeight);
      }

   }

   // $FF: synthetic method
   public static jebac_vexiau51pw4i3zdqx parseGlVersion(String p_parseGlVersion_0_, jebac_vexiau51pw4i3zdqx p_parseGlVersion_1_) {
      try {
         if (p_parseGlVersion_0_ == null) {
            return p_parseGlVersion_1_;
         } else {
            Pattern pattern = Pattern.compile("([0-9]+)\\.([0-9]+)(\\.([0-9]+))?(.+)?");
            Matcher matcher = pattern.matcher(p_parseGlVersion_0_);
            if (!matcher.matches()) {
               return p_parseGlVersion_1_;
            } else {
               int i = Integer.parseInt(matcher.group(1));
               int j = Integer.parseInt(matcher.group(2));
               int k = matcher.group(4) != null ? Integer.parseInt(matcher.group(4)) : 0;
               String s = matcher.group(5);
               return new jebac_vexiau51pw4i3zdqx(i, j, k, s);
            }
         }
      } catch (Exception var8) {
         var8.printStackTrace();
         return p_parseGlVersion_1_;
      }
   }

   // $FF: synthetic method
   private static Set getDisplayModeDimensions(DisplayMode[] p_getDisplayModeDimensions_0_) {
      Set set = new HashSet();
      DisplayMode[] var2 = p_getDisplayModeDimensions_0_;
      int var3 = p_getDisplayModeDimensions_0_.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         DisplayMode displaymode = var2[var4];
         Dimension dimension = new Dimension(displaymode.getWidth(), displaymode.getHeight());
         set.add(dimension);
      }

      return set;
   }

   // $FF: synthetic method
   public static boolean isAnimatedWater() {
      return gameSettings.ofAnimatedWater != 2;
   }

   // $FF: synthetic method
   public static int getUpdatesPerFrame() {
      return gameSettings.ofChunkUpdates;
   }

   // $FF: synthetic method
   public static int getChunkViewDistance() {
      return gameSettings == null ? 10 : gameSettings.renderDistanceChunks;
   }

   // $FF: synthetic method
   public static String readInputStream(InputStream p_readInputStream_0_) throws IOException {
      return readInputStream(p_readInputStream_0_, "ASCII");
   }

   // $FF: synthetic method
   public static GameSettings getGameSettings() {
      return gameSettings;
   }

   // $FF: synthetic method
   public static boolean isNaturalTextures() {
      return gameSettings.ofNaturalTextures;
   }

   // $FF: synthetic method
   public static String readInputStream(InputStream p_readInputStream_0_, String p_readInputStream_1_) throws IOException {
      InputStreamReader inputstreamreader = new InputStreamReader(p_readInputStream_0_, p_readInputStream_1_);
      BufferedReader bufferedreader = new BufferedReader(inputstreamreader);
      StringBuffer stringbuffer = new StringBuffer();

      while(true) {
         String s = bufferedreader.readLine();
         if (s == null) {
            return stringbuffer.toString();
         }

         stringbuffer.append(s);
         stringbuffer.append("\n");
      }
   }

   // $FF: synthetic method
   public static boolean isCustomColors() {
      return gameSettings.ofCustomColors;
   }

   // $FF: synthetic method
   public static String getResourcePackNames() {
      if (minecraft.getResourcePackRepository() == null) {
         return "";
      } else {
         IResourcePack[] airesourcepack = getResourcePacks();
         if (airesourcepack.length <= 0) {
            return getDefaultResourcePack().getPackName();
         } else {
            String[] astring = new String[airesourcepack.length];

            for(int i = 0; i < airesourcepack.length; ++i) {
               astring[i] = airesourcepack[i].getPackName();
            }

            String s = arrayToString((Object[])astring);
            return s;
         }
      }
   }

   // $FF: synthetic method
   public static void writeFile(File p_writeFile_0_, String p_writeFile_1_) throws IOException {
      FileOutputStream fileoutputstream = new FileOutputStream(p_writeFile_0_);
      byte[] abyte = p_writeFile_1_.getBytes(StandardCharsets.US_ASCII);
      fileoutputstream.write(abyte);
      fileoutputstream.close();
   }

   // $FF: synthetic method
   public static boolean isDroppedItemsFancy() {
      return gameSettings.ofDroppedItems == 0 ? gameSettings.fancyGraphics : gameSettings.ofDroppedItems == 2;
   }

   // $FF: synthetic method
   public static boolean isFancyFogAvailable() {
      return fancyFogAvailable;
   }

   // $FF: synthetic method
   public static void checkDisplaySettings() {
      int i = getAntialiasingLevel();
      if (i > 0) {
         DisplayMode displaymode = Display.getDisplayMode();
         dbg("FSAA Samples: " + i);

         try {
            Display.destroy();
            Display.setDisplayMode(displaymode);
            Display.create((new PixelFormat()).withDepthBits(24).withSamples(i));
            Display.setResizable(false);
            Display.setResizable(true);
         } catch (LWJGLException var15) {
            warn("Error setting FSAA: " + i + "x");
            var15.printStackTrace();

            try {
               Display.setDisplayMode(displaymode);
               Display.create((new PixelFormat()).withDepthBits(24));
               Display.setResizable(false);
               Display.setResizable(true);
            } catch (LWJGLException var14) {
               var14.printStackTrace();

               try {
                  Display.setDisplayMode(displaymode);
                  Display.create();
                  Display.setResizable(false);
                  Display.setResizable(true);
               } catch (LWJGLException var13) {
                  var13.printStackTrace();
               }
            }
         }

         if (!Minecraft.isRunningOnMac && getDefaultResourcePack() != null) {
            InputStream inputstream = null;
            InputStream inputstream1 = null;

            try {
               inputstream = getDefaultResourcePack().getInputStreamAssets(new ResourceLocation("icons/icon_16x16.png"));
               inputstream1 = getDefaultResourcePack().getInputStreamAssets(new ResourceLocation("icons/icon_32x32.png"));
               if (inputstream != null && inputstream1 != null) {
                  Display.setIcon(new ByteBuffer[]{readIconImage(inputstream), readIconImage(inputstream1)});
               }
            } catch (IOException var11) {
               warn("Error setting window icon: " + var11.getClass().getName() + ": " + var11.getMessage());
            } finally {
               IOUtils.closeQuietly(inputstream);
               IOUtils.closeQuietly(inputstream1);
            }
         }
      }

   }

   // $FF: synthetic method
   public static boolean isAnimatedPortal() {
      return gameSettings.ofAnimatedPortal;
   }

   // $FF: synthetic method
   public static boolean isAnimatedSmoke() {
      return gameSettings.ofAnimatedSmoke;
   }

   // $FF: synthetic method
   public static boolean isFireworkParticles() {
      return gameSettings.ofFireworkParticles;
   }

   // $FF: synthetic method
   public static boolean isTimeNightOnly() {
      return gameSettings.ofTime == 2;
   }

   // $FF: synthetic method
   public static void sleep(long p_sleep_0_) {
      try {
         Thread.sleep(p_sleep_0_);
      } catch (InterruptedException var3) {
         var3.printStackTrace();
      }

   }

   // $FF: synthetic method
   public static void warn(String p_warn_0_) {
      LOGGER.warn("[OptiFine] " + p_warn_0_);
   }

   // $FF: synthetic method
   public static void updateThreadPriorities() {
      updateAvailableProcessors();
      if (isSingleProcessor()) {
         if (isSmoothWorld()) {
            minecraftThread.setPriority(10);
            setThreadPriority("Server thread", 1);
         } else {
            minecraftThread.setPriority(5);
            setThreadPriority("Server thread", 5);
         }
      } else {
         minecraftThread.setPriority(10);
         setThreadPriority("Server thread", 5);
      }

   }

   // $FF: synthetic method
   public static boolean isTreesFancy() {
      return gameSettings.ofTrees == 0 ? gameSettings.fancyGraphics : gameSettings.ofTrees != 1;
   }

   // $FF: synthetic method
   public static int parseInt(String p_parseInt_0_, int p_parseInt_1_) {
      try {
         if (p_parseInt_0_ == null) {
            return p_parseInt_1_;
         } else {
            p_parseInt_0_ = p_parseInt_0_.trim();
            return Integer.parseInt(p_parseInt_0_);
         }
      } catch (NumberFormatException var3) {
         return p_parseInt_1_;
      }
   }

   // $FF: synthetic method
   public static boolean isAnimatedTextures() {
      return gameSettings.ofAnimatedTextures;
   }

   // $FF: synthetic method
   public static boolean isFromDefaultResourcePack(ResourceLocation p_isFromDefaultResourcePack_0_) {
      IResourcePack iresourcepack = getDefiningResourcePack(p_isFromDefaultResourcePack_0_);
      return iresourcepack == getDefaultResourcePack();
   }

   // $FF: synthetic method
   public static TextureMap getTextureMap() {
      return getMinecraft().getTextureMapBlocks();
   }

   // $FF: synthetic method
   public static byte[] readAll(InputStream p_readAll_0_) throws IOException {
      ByteArrayOutputStream bytearrayoutputstream = new ByteArrayOutputStream();
      byte[] abyte = new byte[1024];

      while(true) {
         int i = p_readAll_0_.read(abyte);
         if (i < 0) {
            p_readAll_0_.close();
            byte[] abyte1 = bytearrayoutputstream.toByteArray();
            return abyte1;
         }

         bytearrayoutputstream.write(abyte, 0, i);
      }
   }

   // $FF: synthetic method
   public static boolean isClearWater() {
      return gameSettings.ofClearWater;
   }

   // $FF: synthetic method
   public static boolean isDynamicFov() {
      return gameSettings.ofDynamicFov;
   }

   // $FF: synthetic method
   public static int[] addIntToArray(int[] p_addIntToArray_0_, int p_addIntToArray_1_) {
      return addIntsToArray(p_addIntToArray_0_, new int[]{p_addIntToArray_1_});
   }

   // $FF: synthetic method
   public static boolean isAntialiasingConfigured() {
      return getGameSettings().ofAaLevel > 0;
   }

   // $FF: synthetic method
   public static void updateTexturePackClouds() {
      texturePackClouds = 0;
      IResourceManager iresourcemanager = getResourceManager();
      if (iresourcemanager != null) {
         try {
            InputStream inputstream = iresourcemanager.getResource(new ResourceLocation("mcpatcher/color.properties")).getInputStream();
            if (inputstream == null) {
               return;
            }

            Properties properties = new Properties();
            properties.load(inputstream);
            inputstream.close();
            String s = properties.getProperty("clouds");
            if (s == null) {
               return;
            }

            dbg("Texture pack clouds: " + s);
            s = s.toLowerCase();
            if (s.equals("fast")) {
               texturePackClouds = 1;
            }

            if (s.equals("fancy")) {
               texturePackClouds = 2;
            }

            if (s.equals("off")) {
               texturePackClouds = 3;
            }
         } catch (Exception var4) {
         }
      }

   }

   // $FF: synthetic method
   public static boolean isAnimatedLava() {
      return gameSettings.ofAnimatedLava != 2;
   }

   // $FF: synthetic method
   private static String getUpdates(String p_getUpdates_0_) {
      int i = p_getUpdates_0_.indexOf(40);
      if (i < 0) {
         return "";
      } else {
         int j = p_getUpdates_0_.indexOf(32, i);
         return j < 0 ? "" : p_getUpdates_0_.substring(i + 1, j);
      }
   }

   // $FF: synthetic method
   public static int getBitsJre() {
      String[] astring = new String[]{"sun.arch.data.model", "com.ibm.vm.bitmode", "os.arch"};
      String[] var1 = astring;
      int var2 = astring.length;

      for(int var3 = 0; var3 < var2; ++var3) {
         String s = var1[var3];
         String s1 = System.getProperty(s);
         if (s1 != null && s1.contains("64")) {
            return 64;
         }
      }

      return 32;
   }

   // $FF: synthetic method
   public static boolean isCustomSky() {
      return gameSettings.ofCustomSky;
   }

   // $FF: synthetic method
   public static float parseFloat(String p_parseFloat_0_, float p_parseFloat_1_) {
      try {
         if (p_parseFloat_0_ == null) {
            return p_parseFloat_1_;
         } else {
            p_parseFloat_0_ = p_parseFloat_0_.trim();
            return Float.parseFloat(p_parseFloat_0_);
         }
      } catch (NumberFormatException var3) {
         return p_parseFloat_1_;
      }
   }

   // $FF: synthetic method
   public static boolean isBetterGrassFancy() {
      return gameSettings.ofBetterGrass == 2;
   }

   // $FF: synthetic method
   public static boolean isDynamicLightsFast() {
      return gameSettings.ofDynamicLights == 1;
   }

   // $FF: synthetic method
   public static boolean isShaders() {
      return jebac_vexiaflhnh80r1906.shaderPackLoaded;
   }

   // $FF: synthetic method
   public static boolean isBetterGrass() {
      return gameSettings.ofBetterGrass != 3;
   }

   // $FF: synthetic method
   public static InputStream getResourceStream(ResourceLocation p_getResourceStream_0_) throws IOException {
      return getResourceStream(minecraft.getResourceManager(), p_getResourceStream_0_);
   }

   // $FF: synthetic method
   public static boolean isFogOff() {
      return gameSettings.ofFogType == 3;
   }

   // $FF: synthetic method
   public static boolean isMipmaps() {
      return gameSettings.mipmapLevels > 0;
   }

   // $FF: synthetic method
   public static void initGameSettings(GameSettings p_initGameSettings_0_) {
      if (gameSettings == null) {
         gameSettings = p_initGameSettings_0_;
         desktopDisplayMode = Display.getDesktopDisplayMode();
         updateAvailableProcessors();
         jebac_vexia557mqvgv66s7.putLaunchBlackboard("optifine.ForgeSplashCompatible", Boolean.TRUE);
      }

   }
}
