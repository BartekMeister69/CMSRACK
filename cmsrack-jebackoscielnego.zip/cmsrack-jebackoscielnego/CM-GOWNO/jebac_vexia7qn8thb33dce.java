import net.minecraft.client.settings.GameSettings;

public interface jebac_vexia7qn8thb33dce {
   // $FF: synthetic method
   GameSettings.Options getOption();
}
