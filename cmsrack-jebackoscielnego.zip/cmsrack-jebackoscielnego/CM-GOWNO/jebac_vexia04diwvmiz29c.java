public class jebac_vexia04diwvmiz29c {
   // $FF: synthetic field
   private int blockId;
   // $FF: synthetic field
   private jebac_vexia2nnti3ppoopl[] matchBlocks;

   // $FF: synthetic method
   public int getBlockId() {
      return this.blockId;
   }

   // $FF: synthetic method
   int[] getMatchBlockIds() {
      int[] aint = new int[this.matchBlocks.length];

      for(int i = 0; i < aint.length; ++i) {
         aint[i] = this.matchBlocks[i].getBlockId();
      }

      return aint;
   }

   // $FF: synthetic method
   public boolean matches(int id, int metadata) {
      jebac_vexia2nnti3ppoopl[] var3 = this.matchBlocks;
      int var4 = var3.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         jebac_vexia2nnti3ppoopl matchblock = var3[var5];
         if (matchblock.matches(id, metadata)) {
            return true;
         }
      }

      return false;
   }

   // $FF: synthetic method
   jebac_vexia04diwvmiz29c(int blockId, jebac_vexia2nnti3ppoopl[] matchBlocks) {
      this.blockId = blockId;
      this.matchBlocks = matchBlocks;
   }
}
