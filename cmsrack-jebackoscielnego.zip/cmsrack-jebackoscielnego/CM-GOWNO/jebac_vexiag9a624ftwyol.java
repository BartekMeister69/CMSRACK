import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.renderer.ViewFrustum;
import net.minecraft.entity.Entity;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;

public class jebac_vexiag9a624ftwyol {
   // $FF: synthetic method
   public static Iterator makeShadowChunkIterator(WorldClient world, double partialTicks, Entity viewEntity, int renderDistanceChunks, ViewFrustum viewFrustum) {
      float f = jebac_vexiaflhnh80r1906.getShadowRenderDistance();
      if (f > 0.0F && f < (float)((renderDistanceChunks - 1) * 16)) {
         int i = MathHelper.ceiling_float_int(f / 16.0F) + 1;
         float f6 = world.getCelestialAngleRadians((float)partialTicks);
         float f1 = jebac_vexiaflhnh80r1906.sunPathRotation * 0.017453292F;
         float f2 = f6 > 1.5707964F && f6 < 4.712389F ? f6 + 3.1415927F : f6;
         float f3 = -MathHelper.sin(f2);
         float f4 = MathHelper.cos(f2) * MathHelper.cos(f1);
         float f5 = -MathHelper.cos(f2) * MathHelper.sin(f1);
         BlockPos blockpos = new BlockPos(MathHelper.floor_double(viewEntity.posX) >> 4, MathHelper.floor_double(viewEntity.posY) >> 4, MathHelper.floor_double(viewEntity.posZ) >> 4);
         BlockPos blockpos1 = blockpos.add((double)(-f3 * (float)i), (double)(-f4 * (float)i), (double)(-f5 * (float)i));
         BlockPos blockpos2 = blockpos.add((double)(f3 * (float)renderDistanceChunks), (double)(f4 * (float)renderDistanceChunks), (double)(f5 * (float)renderDistanceChunks));
         return new jebac_vexia0w4pevwbujuf(viewFrustum, blockpos1, blockpos2, i, i);
      } else {
         List list = Arrays.asList(viewFrustum.renderChunks);
         return list.iterator();
      }
   }
}
