import java.nio.charset.StandardCharsets;
import java.util.Base64;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.util.ResourceLocation;

public class jebac_vexia9eukixeuyh3g extends ServerData {
   private static final String[]  ch;
   private static final int[]  cg;
   public final ResourceLocation  cf;

   // $FF: synthetic method
   public jebac_vexia9eukixeuyh3g(String var1, String var2, boolean var3) {
      super(var1, var2, var3);
      this. cf = new ResourceLocation( ch[ cg[0]]);
   }

   // $FF: synthetic method
   private static void lIllllII() {
       ch = new String[ cg[1]];
       ch[ cg[0]] = lIlllIll(jebac_vexiaqb58506wt8o3.  ‏ ("ԎԡԅԃԇԜԝԭԑԙԣԻԆԿԬԯԋԢԑ\u0530", 1904608584), jebac_vexiaqb58506wt8o3.  ‏ ("䊇䊼䊈䊪䊤", 726156018));
   }

   // $FF: synthetic method
   private static String lIlllIll(String var0, String var1) {
      var0 = new String(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      String var2 = new StringBuilder();
      char[] var3 = var1.toCharArray();
      double var4 =  cg[0];
      boolean var5 = var0.toCharArray();
      int var6 = var5.length;
      int var7 =  cg[0];

      do {
         if (!llIIIIII(var7, var6)) {
            return String.valueOf(var2);
         }

         short var8 = var5[var7];
         var2.append((char)(var8 ^ var3[var4 % var3.length]));
         jebac_vexiaqb58506wt8o3.  ‏ ("", 1484296666).length();
         ++var4;
         ++var7;
         jebac_vexiaqb58506wt8o3.  ‏ ("", 226797807).length();
      } while(((13 + 1 - -61 + 168 ^ 34 + 36 - -11 + 110) & (48 ^ 72 ^ 155 ^ 175 ^ -jebac_vexiaqb58506wt8o3.  ‏ ("\uab6f", -1739412657).length())) < (103 + 155 - 141 + 43 ^ 19 + 97 - 40 + 88));

      return null;
   }

   // $FF: synthetic method
   private static boolean llIIIIII(int var0, int var1) {
      return var0 < var1;
   }

   static {
      lIllllll();
      lIllllII();
   }

   // $FF: synthetic method
   private static void lIllllll() {
       cg = new int[2];
       cg[0] = (66 + 133 - 160 + 159 ^ 127 + 88 - 100 + 50) & (200 ^ 144 ^ 32 ^ 27 ^ -jebac_vexiaqb58506wt8o3.  ‏ ("齦", -1672437946).length());
       cg[1] = jebac_vexiaqb58506wt8o3.  ‏ ("맸", -1658144296).length();
   }
}
