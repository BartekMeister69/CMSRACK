import net.minecraft.client.Minecraft;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.IChatComponent;

class jebac_vexia4tjvy6pwo8ll implements jebac_vexia9nzh0zm3n32z {
   // $FF: synthetic field
   private final boolean field_178665_b;
   // $FF: synthetic field
   private final int field_178666_a;

   // $FF: synthetic method
   public void func_178661_a(jebac_vexiabhmyylutxyzx menu) {
      jebac_vexiabhmyylutxyzx.access$102(menu, this.field_178666_a);
   }

   // $FF: synthetic method
   public boolean func_178662_A_() {
      return this.field_178665_b;
   }

   // $FF: synthetic method
   public IChatComponent getSpectatorName() {
      return this.field_178666_a < 0 ? new ChatComponentText("Previous Page") : new ChatComponentText("Next Page");
   }

   // $FF: synthetic method
   public jebac_vexia4tjvy6pwo8ll(int p_i45495_1_, boolean p_i45495_2_) {
      this.field_178666_a = p_i45495_1_;
      this.field_178665_b = p_i45495_2_;
   }

   // $FF: synthetic method
   public void func_178663_a(float p_178663_1_, int alpha) {
      Minecraft.getMinecraft().getTextureManager().bindTexture(jebac_vexia4ygfqd1m48f0.field_175269_a);
      if (this.field_178666_a < 0) {
         jebac_vexiabhi02xzapwrh.drawModalRectWithCustomSizedTexture(0, 0, 144.0F, 0.0F, 16, 16, 256.0F, 256.0F);
      } else {
         jebac_vexiabhi02xzapwrh.drawModalRectWithCustomSizedTexture(0, 0, 160.0F, 0.0F, 16, 16, 256.0F, 256.0F);
      }

   }
}
