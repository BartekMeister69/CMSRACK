import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class jebac_vexiaryg721x2j3kq extends jebac_vexiazrxtvwdcml9w {
   // $FF: synthetic field
   private static final Pattern PATTERN_DEFINE = Pattern.compile("^\\s*(//)?\\s*#define\\s+([A-Za-z0-9_]+)\\s*(//.*)?$");
   // $FF: synthetic field
   private static final Pattern PATTERN_IFDEF = Pattern.compile("^\\s*#if(n)?def\\s+([A-Za-z0-9_]+)(\\s*)?$");

   // $FF: synthetic method
   public jebac_vexiaryg721x2j3kq(String name, String description, String value, String path) {
      super(name, description, value, new String[]{"true", "false"}, value, path);
   }

   // $FF: synthetic method
   public boolean matchesLine(String line) {
      Matcher matcher = PATTERN_DEFINE.matcher(line);
      if (!matcher.matches()) {
         return false;
      } else {
         String s = matcher.group(2);
         return s.matches(this.getName());
      }
   }

   // $FF: synthetic method
   public String getValueColor(String val) {
      return isTrue(val) ? "§a" : "§c";
   }

   // $FF: synthetic method
   public static boolean isTrue(String val) {
      return Boolean.parseBoolean(val);
   }

   // $FF: synthetic method
   public String getSourceLine() {
      return isTrue(this.getValue()) ? "#define " + this.getName() + " // Shader option ON" : "//#define " + this.getName() + " // Shader option OFF";
   }

   // $FF: synthetic method
   public String getValueText(String val) {
      return isTrue(val) ? jebac_vexia7gzdvsc1kfyf.getOn() : jebac_vexia7gzdvsc1kfyf.getOff();
   }

   // $FF: synthetic method
   public boolean checkUsed() {
      return true;
   }

   // $FF: synthetic method
   public static jebac_vexiazrxtvwdcml9w parseOption(String line, String path) {
      Matcher matcher = PATTERN_DEFINE.matcher(line);
      if (!matcher.matches()) {
         return null;
      } else {
         String s = matcher.group(1);
         String s1 = matcher.group(2);
         String s2 = matcher.group(3);
         if (s1 != null && s1.length() > 0) {
            boolean flag = jebac_vexiakrwecfs16wve.equals(s, "//");
            boolean flag1 = !flag;
            path = jebac_vexianzkdk43wtdrt.removePrefix(path, "/shaders/");
            return new jebac_vexiaryg721x2j3kq(s1, s2, String.valueOf(flag1), path);
         } else {
            return null;
         }
      }
   }

   // $FF: synthetic method
   public boolean isUsedInLine(String line) {
      Matcher matcher = PATTERN_IFDEF.matcher(line);
      if (matcher.matches()) {
         String s = matcher.group(2);
         return s.equals(this.getName());
      } else {
         return false;
      }
   }
}
