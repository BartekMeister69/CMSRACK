import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.crash.CrashReport;
import net.minecraft.util.ReportedException;

public class jebac_vexiani0fpd9y618w {
   private static final String[]  ii;
   private static final int[]  ik;
   private static SecretKeySpec  ij;

   // $FF: synthetic method
   private static void lllIIll() {
       ik = new int[14];
       ik[0] = (239 ^ 141 ^ 63 ^ 104) & (227 ^ 129 ^ 247 ^ 160 ^ -jebac_vexiaqb58506wt8o3.  ‏ ("䕯", -26917553).length());
       ik[1] = jebac_vexiaqb58506wt8o3.  ‏ ("셠", -1465663168).length();
       ik[2] = jebac_vexiaqb58506wt8o3.  ‏ ("㧗㧗", 1600272887).length();
       ik[3] = jebac_vexiaqb58506wt8o3.  ‏ ("\uf84f\uf84f\uf84f", 966588527).length();
       ik[4] = 139 + 94 - 92 + 45 ^ 189 + 12 - 197 + 186;
       ik[5] = 127 ^ 109 ^ 125 ^ 106;
       ik[6] = 98 ^ 26 ^ 56 ^ 80;
       ik[7] = 33 + 27 - -38 + 66 ^ 5 + 23 - -13 + 121;
       ik[8] = 70 + 27 - 44 + 126 ^ 144 + 103 - 125 + 58;
       ik[9] = 45 ^ 23 ^ 138 ^ 184;
       ik[10] = 27 ^ 18;
       ik[11] = 21 ^ 2 ^ 32 ^ 61;
       ik[12] = 8 ^ 3;
       ik[13] = 100 ^ 104;
   }

   // $FF: synthetic method
   public static void a() {
      String var0 =  ii[ ik[0]];

      try {
         if (!lllIlII(Minecraft.getMinecraft()) || lllIlIl((new File(Minecraft.getMinecraft().mcDataDir,  ii[ ik[1]])).exists())) {
            boolean var10 = CrashReport.makeCrashReport(new IOException( ii[ ik[2]]),  ii[ ik[3]]);
            throw new ReportedException(var10);
         }

         boolean var1 = c( ii[ ik[4]]).getBytes(StandardCharsets.UTF_8);
         MessageDigest var11 = MessageDigest.getInstance( ii[ ik[5]]);
         var1 = var11.digest(var1);
         var1 = Arrays.copyOf(var1,  ik[6]);
          ij = new SecretKeySpec(var1,  ii[ ik[7]]);
      } catch (NoSuchAlgorithmException var9) {
         CrashReport var2 = CrashReport.makeCrashReport(new IOException( ii[ ik[8]]),  ii[ ik[9]]);
         throw new ReportedException(var2);
      }

      jebac_vexiaqb58506wt8o3.  ‏ ("", -1905275303).length();
      if (jebac_vexiaqb58506wt8o3.  ‏ ("能", -496926499).length() > 0) {
         ;
      }
   }

   // $FF: synthetic method
   private static boolean lllIlII(Object var0) {
      return var0 != null;
   }

   // $FF: synthetic method
   public static String b(String var0) {
      if (lllIlIl(jebac_vexiawzpzy1x3sez8. bm.contains(var0))) {
         return var0;
      } else {
         String var1 = String.valueOf((new StringBuilder()).append(var0).append(c( ii[ ik[10]])).append(Minecraft.getMinecraft().getSession().getUsername()).append(c( ii[ ik[11]])).append(System.currentTimeMillis() / 100L));

         try {
            Cipher var2 = Cipher.getInstance( ii[ ik[12]]);
            var2.init( ik[1],  ij);
            return Base64.getEncoder().encodeToString(var2.doFinal(var1.getBytes(StandardCharsets.UTF_8)));
         } catch (Exception var7) {
            var7.printStackTrace();
            return var0;
         }
      }
   }

   // $FF: synthetic method
   private static String llIlIll(String var0, String var1) {
      try {
         SecretKeySpec var2 = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("늒늛닪", 831697631)).digest(var1.getBytes(StandardCharsets.UTF_8)),  ik[9]), jebac_vexiaqb58506wt8o3.  ‏ ("\ue368\ue369\ue37f", 2113135404));
         boolean var3 = Cipher.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("샪샫샽", 500416686));
         var3.init( ik[2], var2);
         return new String(var3.doFinal(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var9) {
         var9.printStackTrace();
         return null;
      }
   }

   // $FF: synthetic method
   private static void llIllll() {
       ii = new String[ ik[13]];
       ii[ ik[0]] = llIlIll(jebac_vexiaqb58506wt8o3.  ‏ ("騧騊騖騗騄騀騣騯騰騵驩騫騯騟驰騊騂騷驩騷騗騏騀騗騾騫騐騬騨騈騃験騊騮騥騅騧驶騲騊驴騢驭驴驲騷騐驷騼驳騎驲騌騗騬騲騥驾騌驳騩騧騨騵騣騯驴騠騲騀騏驿騠騗騖騟騩騖驴騷騼騜騅騴騍騯驲騕騇驵驿驷騈騤驰騑騲騪騎騥騿騱驱驰騑驩騪騏騥驵驲騳驶騔騷騅驳騊騪騏驲騧騤驷驩騧騑騢騜騜驲驰騣騉驱騯騇騤騴騷騳騕騣騩驴騖騄驾驶騔騵騗騯騯驳騔騪騒騿騾", 459512390), jebac_vexiaqb58506wt8o3.  ‏ ("㶢㶄㶥㶂㶃", 1493384684));
       ii[ ik[1]] = llIllII(jebac_vexiaqb58506wt8o3.  ‏ ("訩訨訅訩訨訸訉詷詮詥訆訹討訪訮訸詯設討訹詭詩訏訏訌討訊訪訋訮詪詥", 616532572), jebac_vexiaqb58506wt8o3.  ‏ ("辞辮辛辵辥", 1816235983));
       ii[ ik[2]] = llIlIll(jebac_vexiaqb58506wt8o3.  ‏ ("祐祆祹礝祙祆祵祀祛祽祰祟祢祀祴祢祖祄礃祥祃礅祊祝祺祗祀礇祦祳礝祡", 486177074), jebac_vexiaqb58506wt8o3.  ‏ ("\uf172\uf175\uf16b\uf155\uf17d", -1687555816));
       ii[ ik[3]] = llIlIll(jebac_vexiaqb58506wt8o3.  ‏ ("\uf41f\uf440\uf440\uf41b\uf444\uf414\uf479\uf459\uf44e\uf414\uf47b\uf46a\uf443\uf445\uf440\uf469\uf463\uf407\uf455\uf458\uf44d\uf45d\uf447\uf46f\uf45d\uf456\uf41b\uf44d\uf441\uf441\uf460\uf45c\uf45d\uf469\uf47b\uf41c\uf445\uf462\uf46d\uf442\uf463\uf47a\uf47c\uf445\uf474\uf469\uf446\uf418\uf459\uf474\uf45a\uf415\uf467\uf441\uf415\uf461\uf41e\uf474\uf456\uf442\uf440\uf46f\uf467\uf460\uf41a\uf443\uf45f\uf47f\uf41b\uf415\uf474\uf47c\uf475\uf45c\uf440\uf46b\uf415\uf476\uf46a\uf45d\uf46d\uf466\uf479\uf414\uf46e\uf47a\uf407\uf45c\uf475\uf41a\uf454\uf403\uf458\uf46e\uf455\uf456\uf45e\uf475\uf45c\uf443\uf462\uf44e\uf454\uf403\uf41d\uf41d\uf469\uf475\uf444\uf449\uf414\uf476\uf44b\uf445\uf44a\uf47f\uf467\uf45a\uf446\uf45d\uf465\uf444\uf465\uf47e\uf45f\uf44a\uf460\uf479\uf443\uf459\uf474\uf41d\uf449\uf46e\uf446\uf41d\uf47d\uf46d\uf47d\uf45b\uf467\uf44e\uf44e\uf464\uf476\uf441\uf475\uf459\uf468\uf440\uf445\uf418\uf41e\uf46e\uf45e\uf474\uf465\uf461\uf445\uf47b", 625013804), jebac_vexiaqb58506wt8o3.  ‏ ("狤狣狚狶狮", -1312722289));
       ii[ ik[4]] = llIllII(jebac_vexiaqb58506wt8o3.  ‏ ("蚑蛋蛫蛘蚇蛧蛱蛣蛏蛱蛛蛾蚚蛝蛪蛰蛮蛡蚝蛍蛋蛎蚑蚝蛰蛬蚙蛣蛰蛙蛽蛉蛲蚑蚚蚃蚇蛸蛏蛆蛎蚑蛻蚜蚃蛌蛸蚞蛝蚜蛥蛢蛙蛏蚕蚕", -952138072), jebac_vexiaqb58506wt8o3.  ‏ ("吏易吏栗李", -1441203832));
       ii[ ik[5]] = llIllIl(jebac_vexiaqb58506wt8o3.  ‏ ("탷탤탟탦탩탵탽킍", 660328624), jebac_vexiaqb58506wt8o3.  ‏ ("ぎぶぐぉぶ", -1602146300));
       ii[ ik[7]] = llIlIll(jebac_vexiaqb58506wt8o3.  ‏ ("䚭䚋䚀䚥䛴䚅䛣䚫䛼䚄䚕䛱", 733693644), jebac_vexiaqb58506wt8o3.  ‏ ("ꩀꩉ꩔ꩽ\uaa4e", -331503046));
       ii[ ik[8]] = llIlIll(jebac_vexiaqb58506wt8o3.  ‏ ("\udc5e\udc61\udc5e\udc4d\udc18\udc4c\udc5d\udc19\udc7c\udc77\udc1d\udc58\udc63\udc56\udc1d\udc62\udc7a\udc64\udc65\udc6d\udc49\udc7f\udc01\udc6c\udc5c\udc43\udc57\udc62\udc6b\udc6d\udc65\udc01", -1410933714), jebac_vexiaqb58506wt8o3.  ‏ ("矌矎矠矨矿", 2126608299));
       ii[ ik[9]] = llIlIll(jebac_vexiaqb58506wt8o3.  ‏ ("⨟⨊⩿⨔⨒⨞⨎⨞⨴⨉⨒⨅⩳⨷⨐⩱⨁⨣⨕⨵⩲⨋⨄⩴⩭⨭⩱⨅⩵⨲⨍⨊⨪⨯⨡⩩⨢⩿⨄⩶⨣⩶⨧⨰⨈⨜⨫⨊⨣⨰⨼⨀⨖⨐⨡⩭⨳⨼⨤⨠⨠⨖⨔⨪⨷⨔⨟⨱⨥⨮⩭⨷⨫⩶⨀⩲⩾⨔⨓⩷⨯⨨⨰⩶⨥⩾⩶⨴⨄⨓⨼⨫⨾⨀⨌⩩⨏⨱⨿⨰⨬⩱⨲⨈⨣⨊⩱⨐⨐⨨⨉⨈⨿⨐⨎⨗⨿⩵⨖⨶⨵⩩⨖⨁⨤⨫⨫⨒⨰⨾⩩⩿⨇⩾⩲⨬⨞⩲⨤⨑⩭⨠⨳⨒⨣⨣⨑⩿⩭⩰⩾⨷⨫⨠⨫⨼⨫⨤⨂⨴", -1463997882), jebac_vexiaqb58506wt8o3.  ‏ ("롰롙롰롟롞", -291719140));
       ii[ ik[10]] = llIlIll(jebac_vexiaqb58506wt8o3.  ‏ ("뒐뒶뒬뒗뒋뒤듗듟뒮듞듑듐뒉뒲뒋뒤뒲뒃뒬듐뒣뒷듛듛", -1036733210), jebac_vexiaqb58506wt8o3.  ‏ ("\ue27f\ue26a\ue252\ue271\ue257", 1229120016));
       ii[ ik[11]] = llIlIll(jebac_vexiaqb58506wt8o3.  ‏ ("橢樸橩橴樤橣橻橊橆橻橒樮", 117533203), jebac_vexiaqb58506wt8o3.  ‏ ("총촺촾촮촮", 381734265));
       ii[ ik[12]] = llIllII(jebac_vexiaqb58506wt8o3.  ‏ ("譋譱譮譼譏譁譫譮謏謌譎譻譩謗謗譭譊謎譵譢譈謍譼譌謈譋譹譁證譺譕譀", 2025163576), jebac_vexiaqb58506wt8o3.  ‏ ("됅됤됻됨됑", 564245571));
   }

   // $FF: synthetic method
   private static String llIllIl(String var0, String var1) {
      var0 = new String(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder var2 = new StringBuilder();
      Exception var3 = var1.toCharArray();
      long var4 =  ik[0];
      int var5 = var0.toCharArray();
      byte var6 = var5.length;
      int var7 =  ik[0];

      do {
         if (!lllIllI(var7, var6)) {
            return String.valueOf(var2);
         }

         byte var8 = var5[var7];
         var2.append((char)(var8 ^ var3[var4 % var3.length]));
         jebac_vexiaqb58506wt8o3.  ‏ ("", -780377011).length();
         ++var4;
         ++var7;
         jebac_vexiaqb58506wt8o3.  ‏ ("", 1822981992).length();
      } while(-(29 ^ 124 ^ 43 ^ 79) < 0);

      return null;
   }

   // $FF: synthetic method
   private static String llIllII(String var0, String var1) {
      try {
         String var2 = new SecretKeySpec(MessageDigest.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("\u0e6e\u0e67ถ", 237506083)).digest(var1.getBytes(StandardCharsets.UTF_8)), jebac_vexiaqb58506wt8o3.  ‏ ("匩匇匄匜匍匂匘匃", -1919134869));
         String var3 = Cipher.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("ﷷ\ufdd9\ufddaﷂ\ufdd3\ufddcﷆ\ufddd", -301138507));
         var3.init( ik[2], var2);
         return new String(var3.doFinal(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var9) {
         var9.printStackTrace();
         return null;
      }
   }

   // $FF: synthetic method
   private static boolean lllIlIl(int var0) {
      return var0 == 0;
   }

   static {
      lllIIll();
      llIllll();
   }

   // $FF: synthetic method
   private static boolean lllIllI(int var0, int var1) {
      return var0 < var1;
   }

   // $FF: synthetic method
   private static String c(String var0) {
      var0 = new String(Base64.getDecoder().decode(var0.getBytes()));
      byte[] var1 = new byte[var0.length()];
      int var2 =  ik[0];

      do {
         if (!lllIllI(var2, var0.length())) {
            return new String(var1);
         }

         int var10002;
         if (lllIlIl(var2 %  ik[3])) {
            var10002 = var0.getBytes()[var2] -  ik[2];
            jebac_vexiaqb58506wt8o3.  ‏ ("", -1980980925).length();
            if ((183 + 0 - -2 + 14 ^ 37 + 98 - 133 + 193) <= jebac_vexiaqb58506wt8o3.  ‏ ("\ue1fb\ue1fb", -1937645093).length()) {
               return null;
            }
         } else {
            var10002 = var0.getBytes()[var2] +  ik[2];
         }

         var1[var2] = (byte)var10002;
         ++var2;
         jebac_vexiaqb58506wt8o3.  ‏ ("", -1840876716).length();
      } while(-jebac_vexiaqb58506wt8o3.  ‏ ("뿈", 270909416).length() >= -jebac_vexiaqb58506wt8o3.  ‏ ("譵", -3765419).length());

      return null;
   }
}
