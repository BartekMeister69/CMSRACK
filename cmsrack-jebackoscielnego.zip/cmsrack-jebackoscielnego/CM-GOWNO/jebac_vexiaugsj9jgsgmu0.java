import java.io.IOException;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.resources.I18n;
import net.minecraft.network.play.client.C00PacketKeepAlive;

public class jebac_vexiaugsj9jgsgmu0 extends jebac_vexiakl614w3uw0xg {
   // $FF: synthetic field
   private NetHandlerPlayClient netHandlerPlayClient;
   // $FF: synthetic field
   private int progress;

   // $FF: synthetic method
   public jebac_vexiaugsj9jgsgmu0(NetHandlerPlayClient netHandler) {
      this.netHandlerPlayClient = netHandler;
   }

   // $FF: synthetic method
   public void drawScreen(int mouseX, int mouseY, float partialTicks) {
      this.drawBackground();
      this.drawCenteredString(this.fontRendererObj, I18n.format("multiplayer.downloadingTerrain"), this.width / 2, this.height / 2 - 50, 16777215);
      super.drawScreen(mouseX, mouseY, partialTicks);
   }

   // $FF: synthetic method
   public void initGui() {
      this.buttonList.clear();
   }

   // $FF: synthetic method
   protected void keyTyped(char typedChar, int keyCode) throws IOException {
   }

   // $FF: synthetic method
   public boolean doesGuiPauseGame() {
      return false;
   }

   // $FF: synthetic method
   public void updateScreen() {
      ++this.progress;
      if (this.progress % 20 == 0) {
         this.netHandlerPlayClient.addToSendQueue(new C00PacketKeepAlive());
      }

   }
}
