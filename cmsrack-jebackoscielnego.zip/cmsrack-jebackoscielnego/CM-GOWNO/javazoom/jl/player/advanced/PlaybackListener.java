package javazoom.jl.player.advanced;

public abstract class PlaybackListener {
   // $FF: synthetic method
   public void playbackStarted(PlaybackEvent var1) {
   }

   // $FF: synthetic method
   public void playbackFinished(PlaybackEvent var1) {
   }
}
