package javazoom.jl.player.advanced;

public class PlaybackEvent {
   // $FF: synthetic field
   private AdvancedPlayer source;
   // $FF: synthetic field
   private int id;
   // $FF: synthetic field
   private int frame;
   // $FF: synthetic field
   public static int STARTED = 2;
   // $FF: synthetic field
   public static int STOPPED = 1;

   // $FF: synthetic method
   public int getId() {
      return this.id;
   }

   // $FF: synthetic method
   public void setSource(AdvancedPlayer var1) {
      this.source = var1;
   }

   // $FF: synthetic method
   public void setFrame(int var1) {
      this.frame = var1;
   }

   // $FF: synthetic method
   public int getFrame() {
      return this.frame;
   }

   // $FF: synthetic method
   public void setId(int var1) {
      this.id = var1;
   }

   // $FF: synthetic method
   public PlaybackEvent(AdvancedPlayer var1, int var2, int var3) {
      this.id = var2;
      this.source = var1;
      this.frame = var3;
   }

   // $FF: synthetic method
   public AdvancedPlayer getSource() {
      return this.source;
   }
}
