package javazoom.jl.player;

import java.applet.Applet;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import javazoom.jl.decoder.JavaLayerException;

public class PlayerApplet extends Applet implements Runnable {
   // $FF: synthetic field
   private String fileName = null;
   // $FF: synthetic field
   private Thread playerThread = null;
   // $FF: synthetic field
   private Player player = null;
   // $FF: synthetic field
   public static final String AUDIO_PARAMETER = "audioURL";

   // $FF: synthetic method
   public void stop() {
      try {
         this.stopPlayer();
      } catch (JavaLayerException var2) {
         System.err.println(var2);
      }

   }

   // $FF: synthetic method
   protected InputStream getAudioStream() {
      InputStream var1 = null;

      try {
         URL var2 = this.getAudioURL();
         if (var2 != null) {
            var1 = var2.openStream();
         }
      } catch (IOException var3) {
         System.err.println(var3);
      }

      return var1;
   }

   // $FF: synthetic method
   protected void play(InputStream var1, AudioDevice var2) throws JavaLayerException {
      this.stopPlayer();
      if (var1 != null && var2 != null) {
         this.player = new Player(var1, var2);
         this.playerThread = this.createPlayerThread();
         this.playerThread.start();
      }

   }

   // $FF: synthetic method
   public void start() {
      String var1 = this.getAudioFileName();

      try {
         InputStream var7 = this.getAudioStream();
         AudioDevice var3 = this.getAudioDevice();
         this.play(var7, var3);
      } catch (JavaLayerException var6) {
         JavaLayerException var2 = var6;
         synchronized(System.err) {
            System.err.println("Unable to play " + var1);
            var2.printStackTrace(System.err);
         }
      }

   }

   // $FF: synthetic method
   public String getFileName() {
      return this.fileName;
   }

   // $FF: synthetic method
   protected AudioDevice getAudioDevice() throws JavaLayerException {
      return FactoryRegistry.systemRegistry().createAudioDevice();
   }

   // $FF: synthetic method
   protected void stopPlayer() throws JavaLayerException {
      if (this.player != null) {
         this.player.close();
         this.player = null;
         this.playerThread = null;
      }

   }

   // $FF: synthetic method
   public void init() {
   }

   // $FF: synthetic method
   protected URL getAudioURL() {
      String var1 = this.getAudioFileName();
      URL var2 = null;
      if (var1 != null) {
         try {
            var2 = new URL(this.getDocumentBase(), var1);
         } catch (Exception var4) {
            System.err.println(var4);
         }
      }

      return var2;
   }

   // $FF: synthetic method
   public void setFileName(String var1) {
      this.fileName = var1;
   }

   // $FF: synthetic method
   protected Thread createPlayerThread() {
      return new Thread(this, "Audio player thread");
   }

   // $FF: synthetic method
   public void run() {
      if (this.player != null) {
         try {
            this.player.play();
         } catch (JavaLayerException var2) {
            System.err.println("Problem playing audio: " + var2);
         }
      }

   }

   // $FF: synthetic method
   protected String getAudioFileName() {
      String var1 = this.fileName;
      if (var1 == null) {
         var1 = this.getParameter("audioURL");
      }

      return var1;
   }

   // $FF: synthetic method
   public void destroy() {
   }
}
