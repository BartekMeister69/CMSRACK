package javazoom.jl.player;

import java.util.Enumeration;
import java.util.Hashtable;
import javazoom.jl.decoder.JavaLayerException;

public class FactoryRegistry extends AudioDeviceFactory {
   // $FF: synthetic field
   protected Hashtable factories = new Hashtable();
   // $FF: synthetic field
   private static FactoryRegistry instance = null;

   // $FF: synthetic method
   public void removeFactory(AudioDeviceFactory var1) {
      this.factories.remove(var1.getClass());
   }

   // $FF: synthetic method
   protected void registerDefaultFactories() {
      this.addFactory(new JavaSoundAudioDeviceFactory());
   }

   // $FF: synthetic method
   public void addFactory(AudioDeviceFactory var1) {
      this.factories.put(var1.getClass(), var1);
   }

   // $FF: synthetic method
   protected AudioDeviceFactory[] getFactoriesPriority() {
      AudioDeviceFactory[] var1 = null;
      synchronized(this.factories) {
         int var3 = this.factories.size();
         if (var3 != 0) {
            var1 = new AudioDeviceFactory[var3];
            int var4 = 0;

            AudioDeviceFactory var6;
            for(Enumeration var5 = this.factories.elements(); var5.hasMoreElements(); var1[var4++] = var6) {
               var6 = (AudioDeviceFactory)var5.nextElement();
            }
         }

         return var1;
      }
   }

   // $FF: synthetic method
   public static synchronized FactoryRegistry systemRegistry() {
      if (instance == null) {
         instance = new FactoryRegistry();
         instance.registerDefaultFactories();
      }

      return instance;
   }

   // $FF: synthetic method
   public void removeFactoryType(Class var1) {
      this.factories.remove(var1);
   }

   // $FF: synthetic method
   public AudioDevice createAudioDevice() throws JavaLayerException {
      AudioDevice var1 = null;
      AudioDeviceFactory[] var2 = this.getFactoriesPriority();
      if (var2 == null) {
         throw new JavaLayerException(this + ": no factories registered");
      } else {
         JavaLayerException var3 = null;

         for(int var4 = 0; var1 == null && var4 < var2.length; ++var4) {
            try {
               var1 = var2[var4].createAudioDevice();
            } catch (JavaLayerException var6) {
               var3 = var6;
            }
         }

         if (var1 == null && var3 != null) {
            throw new JavaLayerException("Cannot create AudioDevice", var3);
         } else {
            return var1;
         }
      }
   }
}
