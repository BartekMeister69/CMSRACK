package javazoom.jl.player;

import javazoom.jl.decoder.Decoder;
import javazoom.jl.decoder.JavaLayerException;

public interface AudioDevice {
   // $FF: synthetic method
   void write(short[] var1, int var2, int var3) throws JavaLayerException;

   // $FF: synthetic method
   void flush();

   // $FF: synthetic method
   void open(Decoder var1) throws JavaLayerException;

   // $FF: synthetic method
   void close();

   // $FF: synthetic method
   boolean isOpen();

   // $FF: synthetic method
   int getPosition();
}
