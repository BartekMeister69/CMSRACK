package javazoom.jl.player;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Line;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.SourceDataLine;
import javax.sound.sampled.DataLine.Info;
import javazoom.jl.decoder.Decoder;
import javazoom.jl.decoder.JavaLayerException;

public class JavaSoundAudioDevice extends AudioDeviceBase {
   // $FF: synthetic field
   private byte[] byteBuf = new byte[4096];
   // $FF: synthetic field
   private SourceDataLine source = null;
   static Class class$javax$sound$sampled$SourceDataLine;
   // $FF: synthetic field
   private AudioFormat fmt = null;

   // $FF: synthetic method
   protected void closeImpl() {
      if (this.source != null) {
         this.source.close();
      }

   }

   // $FF: synthetic method
   protected AudioFormat getAudioFormat() {
      if (this.fmt == null) {
         Decoder var1 = this.getDecoder();
         this.fmt = new AudioFormat((float)var1.getOutputFrequency(), 16, var1.getOutputChannels(), true, false);
      }

      return this.fmt;
   }

   // $FF: synthetic method
   public int millisecondsToBytes(AudioFormat var1, int var2) {
      return (int)((double)((float)var2 * var1.getSampleRate() * (float)var1.getChannels() * (float)var1.getSampleSizeInBits()) / 8000.0D);
   }

   // $FF: synthetic method
   protected byte[] getByteArray(int var1) {
      if (this.byteBuf.length < var1) {
         this.byteBuf = new byte[var1 + 1024];
      }

      return this.byteBuf;
   }

   // $FF: synthetic method
   protected Info getSourceLineInfo() {
      AudioFormat var1 = this.getAudioFormat();
      Info var2 = new Info(class$javax$sound$sampled$SourceDataLine == null ? (class$javax$sound$sampled$SourceDataLine = class$("javax.sound.sampled.SourceDataLine")) : class$javax$sound$sampled$SourceDataLine, var1);
      return var2;
   }

   // $FF: synthetic method
   protected void writeImpl(short[] var1, int var2, int var3) throws JavaLayerException {
      if (this.source == null) {
         this.createSource();
      }

      byte[] var4 = this.toByteArray(var1, var2, var3);
      this.source.write(var4, 0, var3 * 2);
   }

   // $FF: synthetic method
   protected void createSource() throws JavaLayerException {
      Object var1 = null;

      try {
         Line var2 = AudioSystem.getLine(this.getSourceLineInfo());
         if (var2 instanceof SourceDataLine) {
            this.source = (SourceDataLine)var2;
            this.source.open(this.fmt);
            this.source.start();
         }
      } catch (RuntimeException var3) {
         var1 = var3;
      } catch (LinkageError var4) {
         var1 = var4;
      } catch (LineUnavailableException var5) {
         var1 = var5;
      }

      if (this.source == null) {
         throw new JavaLayerException("cannot obtain source audio line", (Throwable)var1);
      }
   }

   // $FF: synthetic method
   public void open(AudioFormat var1) throws JavaLayerException {
      if (!this.isOpen()) {
         this.setAudioFormat(var1);
         this.openImpl();
         this.setOpen(true);
      }

   }

   // $FF: synthetic method
   protected byte[] toByteArray(short[] var1, int var2, int var3) {
      byte[] var4 = this.getByteArray(var3 * 2);

      short var6;
      for(int var5 = 0; var3-- > 0; var4[var5++] = (byte)(var6 >>> 8)) {
         var6 = var1[var2++];
         var4[var5++] = (byte)var6;
      }

      return var4;
   }

   // $FF: synthetic method
   protected void setAudioFormat(AudioFormat var1) {
      this.fmt = var1;
   }

   // $FF: synthetic method
   protected void openImpl() throws JavaLayerException {
   }

   // $FF: synthetic method
   public void test() throws JavaLayerException {
      try {
         this.open(new AudioFormat(22050.0F, 16, 1, true, false));
         short[] var1 = new short[2205];
         this.write(var1, 0, var1.length);
         this.flush();
         this.close();
      } catch (RuntimeException var2) {
         throw new JavaLayerException("Device test failed: " + var2);
      }
   }

   static Class class$(String var0) {
      try {
         return Class.forName(var0);
      } catch (ClassNotFoundException var2) {
         throw new NoClassDefFoundError(var2.getMessage());
      }
   }

   // $FF: synthetic method
   protected void flushImpl() {
      if (this.source != null) {
         this.source.drain();
      }

   }

   // $FF: synthetic method
   public int getPosition() {
      int var1 = 0;
      if (this.source != null) {
         var1 = (int)(this.source.getMicrosecondPosition() / 1000L);
      }

      return var1;
   }
}
