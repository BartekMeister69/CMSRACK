package javazoom.jl.player;

import javazoom.jl.decoder.Decoder;
import javazoom.jl.decoder.JavaLayerException;

public abstract class AudioDeviceBase implements AudioDevice {
   // $FF: synthetic field
   private Decoder decoder = null;
   // $FF: synthetic field
   private boolean open = false;

   // $FF: synthetic method
   protected Decoder getDecoder() {
      return this.decoder;
   }

   // $FF: synthetic method
   public synchronized boolean isOpen() {
      return this.open;
   }

   // $FF: synthetic method
   protected void flushImpl() {
   }

   // $FF: synthetic method
   public synchronized void close() {
      if (this.isOpen()) {
         this.closeImpl();
         this.setOpen(false);
         this.decoder = null;
      }

   }

   // $FF: synthetic method
   protected void openImpl() throws JavaLayerException {
   }

   // $FF: synthetic method
   protected void closeImpl() {
   }

   // $FF: synthetic method
   public void flush() {
      if (this.isOpen()) {
         this.flushImpl();
      }

   }

   // $FF: synthetic method
   protected void setOpen(boolean var1) {
      this.open = var1;
   }

   // $FF: synthetic method
   public void write(short[] var1, int var2, int var3) throws JavaLayerException {
      if (this.isOpen()) {
         this.writeImpl(var1, var2, var3);
      }

   }

   // $FF: synthetic method
   protected void writeImpl(short[] var1, int var2, int var3) throws JavaLayerException {
   }

   // $FF: synthetic method
   public synchronized void open(Decoder var1) throws JavaLayerException {
      if (!this.isOpen()) {
         this.decoder = var1;
         this.openImpl();
         this.setOpen(true);
      }

   }
}
