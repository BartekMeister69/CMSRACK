package javazoom.jl.player;

public class NullAudioDevice extends AudioDeviceBase {
   // $FF: synthetic method
   public int getPosition() {
      return 0;
   }
}
