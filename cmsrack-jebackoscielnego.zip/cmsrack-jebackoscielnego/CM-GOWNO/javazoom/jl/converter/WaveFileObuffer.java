package javazoom.jl.converter;

import javazoom.jl.decoder.Obuffer;

public class WaveFileObuffer extends Obuffer {
   // $FF: synthetic field
   private WaveFile outWave;
   // $FF: synthetic field
   private short[] bufferp;
   // $FF: synthetic field
   short[] myBuffer = new short[2];
   // $FF: synthetic field
   private int channels;
   // $FF: synthetic field
   private short[] buffer;

   // $FF: synthetic method
   public WaveFileObuffer(int var1, int var2, String var3) {
      if (var3 == null) {
         throw new NullPointerException("FileName");
      } else {
         this.buffer = new short[2304];
         this.bufferp = new short[2];
         this.channels = var1;

         for(int var4 = 0; var4 < var1; ++var4) {
            this.bufferp[var4] = (short)var4;
         }

         this.outWave = new WaveFile();
         this.outWave.OpenForWrite(var3, var2, (short)16, (short)this.channels);
      }
   }

   // $FF: synthetic method
   public void append(int var1, short var2) {
      this.buffer[this.bufferp[var1]] = var2;
      short[] var10000 = this.bufferp;
      var10000[var1] = (short)(var10000[var1] + this.channels);
   }

   // $FF: synthetic method
   public void close() {
      this.outWave.Close();
   }

   // $FF: synthetic method
   public void write_buffer(int var1) {
      boolean var2 = false;
      boolean var3 = false;
      int var5 = this.outWave.WriteData(this.buffer, this.bufferp[0]);

      for(int var4 = 0; var4 < this.channels; ++var4) {
         this.bufferp[var4] = (short)var4;
      }

   }

   // $FF: synthetic method
   public void set_stop_flag() {
   }

   // $FF: synthetic method
   public void clear_buffer() {
   }
}
