package javazoom.jl.decoder;

import java.io.IOException;
import java.io.InputStream;

public class InputStreamSource implements Source {
   // $FF: synthetic field
   private final InputStream in;

   // $FF: synthetic method
   public boolean willReadBlock() {
      return true;
   }

   // $FF: synthetic method
   public int read(byte[] var1, int var2, int var3) throws IOException {
      int var4 = this.in.read(var1, var2, var3);
      return var4;
   }

   // $FF: synthetic method
   public boolean isSeekable() {
      return false;
   }

   // $FF: synthetic method
   public long seek(long var1) {
      return -1L;
   }

   // $FF: synthetic method
   public long tell() {
      return -1L;
   }

   // $FF: synthetic method
   public long length() {
      return -1L;
   }

   // $FF: synthetic method
   public InputStreamSource(InputStream var1) {
      if (var1 == null) {
         throw new NullPointerException("in");
      } else {
         this.in = var1;
      }
   }
}
