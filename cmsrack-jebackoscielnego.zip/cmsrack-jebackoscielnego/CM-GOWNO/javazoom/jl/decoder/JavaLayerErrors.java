package javazoom.jl.decoder;

public interface JavaLayerErrors {
   // $FF: synthetic field
   int DECODER_ERROR = 512;
   // $FF: synthetic field
   int BITSTREAM_ERROR = 256;
}
