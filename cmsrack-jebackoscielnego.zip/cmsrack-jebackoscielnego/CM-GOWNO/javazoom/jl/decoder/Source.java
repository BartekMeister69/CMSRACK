package javazoom.jl.decoder;

import java.io.IOException;

public interface Source {
   // $FF: synthetic field
   long LENGTH_UNKNOWN = -1L;

   // $FF: synthetic method
   boolean isSeekable();

   // $FF: synthetic method
   long seek(long var1);

   // $FF: synthetic method
   int read(byte[] var1, int var2, int var3) throws IOException;

   // $FF: synthetic method
   long length();

   // $FF: synthetic method
   long tell();

   // $FF: synthetic method
   boolean willReadBlock();
}
