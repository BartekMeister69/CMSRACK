package javazoom.jl.decoder;

final class BitReserve {
   // $FF: synthetic field
   private final int[] buf = new int['耀'];
   // $FF: synthetic field
   private static final int BUFSIZE_MASK = 32767;
   // $FF: synthetic field
   private static final int BUFSIZE = 32768;
   // $FF: synthetic field
   private int buf_byte_idx = 0;
   // $FF: synthetic field
   private int offset = 0;
   // $FF: synthetic field
   private int buf_bit_idx;
   // $FF: synthetic field
   private int totbit = 0;

   // $FF: synthetic method
   public int hget1bit() {
      ++this.totbit;
      int var1 = this.buf[this.buf_byte_idx];
      this.buf_byte_idx = this.buf_byte_idx + 1 & 32767;
      return var1;
   }

   // $FF: synthetic method
   public int hgetbits(int var1) {
      this.totbit += var1;
      int var2 = 0;
      int var3 = this.buf_byte_idx;
      if (var3 + var1 < 32768) {
         while(var1-- > 0) {
            var2 <<= 1;
            var2 |= this.buf[var3++] != 0 ? 1 : 0;
         }
      } else {
         while(var1-- > 0) {
            var2 <<= 1;
            var2 |= this.buf[var3] != 0 ? 1 : 0;
            var3 = var3 + 1 & 32767;
         }
      }

      this.buf_byte_idx = var3;
      return var2;
   }

   // $FF: synthetic method
   public int hsstell() {
      return this.totbit;
   }

   // $FF: synthetic method
   public void hputbuf(int var1) {
      int var2 = this.offset;
      this.buf[var2++] = var1 & 128;
      this.buf[var2++] = var1 & 64;
      this.buf[var2++] = var1 & 32;
      this.buf[var2++] = var1 & 16;
      this.buf[var2++] = var1 & 8;
      this.buf[var2++] = var1 & 4;
      this.buf[var2++] = var1 & 2;
      this.buf[var2++] = var1 & 1;
      if (var2 == 32768) {
         this.offset = 0;
      } else {
         this.offset = var2;
      }

   }

   // $FF: synthetic method
   public void rewindNbytes(int var1) {
      int var2 = var1 << 3;
      this.totbit -= var2;
      this.buf_byte_idx -= var2;
      if (this.buf_byte_idx < 0) {
         this.buf_byte_idx += 32768;
      }

   }

   // $FF: synthetic method
   public void rewindNbits(int var1) {
      this.totbit -= var1;
      this.buf_byte_idx -= var1;
      if (this.buf_byte_idx < 0) {
         this.buf_byte_idx += 32768;
      }

   }
}
