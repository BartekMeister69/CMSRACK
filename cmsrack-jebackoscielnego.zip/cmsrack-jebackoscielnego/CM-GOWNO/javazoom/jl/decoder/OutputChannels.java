package javazoom.jl.decoder;

public class OutputChannels {
   // $FF: synthetic field
   public static final OutputChannels RIGHT = new OutputChannels(2);
   // $FF: synthetic field
   public static final int DOWNMIX_CHANNELS = 3;
   // $FF: synthetic field
   public static final OutputChannels LEFT = new OutputChannels(1);
   // $FF: synthetic field
   public static final int LEFT_CHANNEL = 1;
   // $FF: synthetic field
   public static final OutputChannels BOTH = new OutputChannels(0);
   // $FF: synthetic field
   public static final int RIGHT_CHANNEL = 2;
   // $FF: synthetic field
   public static final OutputChannels DOWNMIX = new OutputChannels(3);
   // $FF: synthetic field
   public static final int BOTH_CHANNELS = 0;
   // $FF: synthetic field
   private int outputChannels;

   // $FF: synthetic method
   public int getChannelCount() {
      int var1 = this.outputChannels == 0 ? 2 : 1;
      return var1;
   }

   // $FF: synthetic method
   private OutputChannels(int var1) {
      this.outputChannels = var1;
      if (var1 < 0 || var1 > 3) {
         throw new IllegalArgumentException("channels");
      }
   }

   // $FF: synthetic method
   public int hashCode() {
      return this.outputChannels;
   }

   // $FF: synthetic method
   public static OutputChannels fromInt(int var0) {
      switch(var0) {
      case 0:
         return BOTH;
      case 1:
         return LEFT;
      case 2:
         return RIGHT;
      case 3:
         return DOWNMIX;
      default:
         throw new IllegalArgumentException("Invalid channel code: " + var0);
      }
   }

   // $FF: synthetic method
   public boolean equals(Object var1) {
      boolean var2 = false;
      if (var1 instanceof OutputChannels) {
         OutputChannels var3 = (OutputChannels)var1;
         var2 = var3.outputChannels == this.outputChannels;
      }

      return var2;
   }

   // $FF: synthetic method
   public int getChannelsOutputCode() {
      return this.outputChannels;
   }
}
