package javazoom.jl.decoder;

public interface DecoderErrors extends JavaLayerErrors {
   // $FF: synthetic field
   int UNSUPPORTED_LAYER = 513;
   // $FF: synthetic field
   int UNKNOWN_ERROR = 512;
}
