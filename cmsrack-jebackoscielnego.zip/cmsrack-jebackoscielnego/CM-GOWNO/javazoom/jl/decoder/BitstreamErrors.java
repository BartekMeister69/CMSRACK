package javazoom.jl.decoder;

public interface BitstreamErrors extends JavaLayerErrors {
   // $FF: synthetic field
   int INVALIDFRAME = 261;
   // $FF: synthetic field
   int UNKNOWN_SAMPLE_RATE = 257;
   // $FF: synthetic field
   int UNEXPECTED_EOF = 259;
   // $FF: synthetic field
   int STREAM_EOF = 260;
   // $FF: synthetic field
   int UNKNOWN_ERROR = 256;
   // $FF: synthetic field
   int BITSTREAM_LAST = 511;
   // $FF: synthetic field
   int STREAM_ERROR = 258;
}
