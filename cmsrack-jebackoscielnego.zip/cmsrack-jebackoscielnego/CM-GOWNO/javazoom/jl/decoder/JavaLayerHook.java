package javazoom.jl.decoder;

import java.io.InputStream;

public interface JavaLayerHook {
   // $FF: synthetic method
   InputStream getResourceAsStream(String var1);
}
