package javazoom.jl.decoder;

public interface Control {
   // $FF: synthetic method
   void stop();

   // $FF: synthetic method
   boolean isRandomAccess();

   // $FF: synthetic method
   void start();

   // $FF: synthetic method
   boolean isPlaying();

   // $FF: synthetic method
   void setPosition(double var1);

   // $FF: synthetic method
   double getPosition();

   // $FF: synthetic method
   void pause();
}
