package javazoom.jl.decoder;

public class Manager {
   // $FF: synthetic method
   public void removeControl(Control var1) {
   }

   // $FF: synthetic method
   public void addControl(Control var1) {
   }

   // $FF: synthetic method
   public void removeAll() {
   }
}
