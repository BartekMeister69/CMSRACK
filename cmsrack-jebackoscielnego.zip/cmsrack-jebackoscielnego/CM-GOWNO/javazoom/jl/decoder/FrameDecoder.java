package javazoom.jl.decoder;

public interface FrameDecoder {
   // $FF: synthetic method
   void decodeFrame();
}
