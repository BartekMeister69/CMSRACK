package javazoom.jl.decoder;

public class JavaLayerError extends Error {
}
