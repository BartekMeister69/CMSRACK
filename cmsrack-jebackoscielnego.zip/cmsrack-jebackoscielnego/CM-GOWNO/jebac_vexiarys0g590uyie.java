import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.resources.I18n;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.world.gen.FlatLayerInfo;

class jebac_vexiarys0g590uyie extends jebac_vexiado18oeh2l9bq {
   // $FF: synthetic field
   public int field_148228_k;
   final jebac_vexia0o9cuuh5axo5 this$0;

   // $FF: synthetic method
   private void func_148225_a(int p_148225_1_, int p_148225_2_, ItemStack p_148225_3_) {
      this.func_148226_e(p_148225_1_ + 1, p_148225_2_ + 1);
      GlStateManager.enableRescaleNormal();
      if (p_148225_3_ != null && p_148225_3_.getItem() != null) {
         RenderHelper.enableGUIStandardItemLighting();
         this.this$0.itemRender.renderItemIntoGUI(p_148225_3_, p_148225_1_ + 2, p_148225_2_ + 2);
         RenderHelper.disableStandardItemLighting();
      }

      GlStateManager.disableRescaleNormal();
   }

   // $FF: synthetic method
   protected boolean isSelected(int slotIndex) {
      return slotIndex == this.field_148228_k;
   }

   // $FF: synthetic method
   protected void drawSlot(int entryID, int p_180791_2_, int p_180791_3_, int p_180791_4_, int mouseXIn, int mouseYIn) {
      FlatLayerInfo flatlayerinfo = (FlatLayerInfo)jebac_vexia0o9cuuh5axo5.access$000(this.this$0).getFlatLayers().get(jebac_vexia0o9cuuh5axo5.access$000(this.this$0).getFlatLayers().size() - entryID - 1);
      IBlockState iblockstate = flatlayerinfo.func_175900_c();
      Block block = iblockstate.getBlock();
      Item item = Item.getItemFromBlock(block);
      ItemStack itemstack = block != Blocks.air && item != null ? new ItemStack(item, 1, block.getMetaFromState(iblockstate)) : null;
      String s = itemstack == null ? "Air" : item.getItemStackDisplayName(itemstack);
      if (item == null) {
         if (block != Blocks.water && block != Blocks.flowing_water) {
            if (block == Blocks.lava || block == Blocks.flowing_lava) {
               item = Items.lava_bucket;
            }
         } else {
            item = Items.water_bucket;
         }

         if (item != null) {
            itemstack = new ItemStack(item, 1, block.getMetaFromState(iblockstate));
            s = block.getLocalizedName();
         }
      }

      this.func_148225_a(p_180791_2_, p_180791_3_, itemstack);
      this.this$0.fontRendererObj.drawString(s, p_180791_2_ + 18 + 5, p_180791_3_ + 3, 16777215);
      String s1;
      if (entryID == 0) {
         s1 = I18n.format("createWorld.customize.flat.layer.top", flatlayerinfo.getLayerCount());
      } else if (entryID == jebac_vexia0o9cuuh5axo5.access$000(this.this$0).getFlatLayers().size() - 1) {
         s1 = I18n.format("createWorld.customize.flat.layer.bottom", flatlayerinfo.getLayerCount());
      } else {
         s1 = I18n.format("createWorld.customize.flat.layer", flatlayerinfo.getLayerCount());
      }

      this.this$0.fontRendererObj.drawString(s1, p_180791_2_ + 2 + 213 - this.this$0.fontRendererObj.getStringWidth(s1), p_180791_3_ + 3, 16777215);
   }

   // $FF: synthetic method
   protected void elementClicked(int slotIndex, boolean isDoubleClick, int mouseX, int mouseY) {
      this.field_148228_k = slotIndex;
      this.this$0.func_146375_g();
   }

   // $FF: synthetic method
   public jebac_vexiarys0g590uyie(jebac_vexia0o9cuuh5axo5 this$0) {
      super(this$0.mc, this$0.width, this$0.height, 43, this$0.height - 60, 24);
      this.this$0 = this$0;
      this.field_148228_k = -1;
   }

   // $FF: synthetic method
   protected void drawBackground() {
   }

   // $FF: synthetic method
   private void func_148224_c(int p_148224_1_, int p_148224_2_, int p_148224_3_, int p_148224_4_) {
      GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
      this.mc.getTextureManager().bindTexture(jebac_vexiabhi02xzapwrh.statIcons);
      Tessellator tessellator = Tessellator.getInstance();
      WorldRenderer worldrenderer = tessellator.getWorldRenderer();
      worldrenderer.begin(7, DefaultVertexFormats.POSITION_TEX);
      worldrenderer.pos((double)p_148224_1_, (double)(p_148224_2_ + 18), (double)this.this$0.zLevel).tex((double)((float)p_148224_3_ * 0.0078125F), (double)((float)(p_148224_4_ + 18) * 0.0078125F)).endVertex();
      worldrenderer.pos((double)(p_148224_1_ + 18), (double)(p_148224_2_ + 18), (double)this.this$0.zLevel).tex((double)((float)(p_148224_3_ + 18) * 0.0078125F), (double)((float)(p_148224_4_ + 18) * 0.0078125F)).endVertex();
      worldrenderer.pos((double)(p_148224_1_ + 18), (double)p_148224_2_, (double)this.this$0.zLevel).tex((double)((float)(p_148224_3_ + 18) * 0.0078125F), (double)((float)p_148224_4_ * 0.0078125F)).endVertex();
      worldrenderer.pos((double)p_148224_1_, (double)p_148224_2_, (double)this.this$0.zLevel).tex((double)((float)p_148224_3_ * 0.0078125F), (double)((float)p_148224_4_ * 0.0078125F)).endVertex();
      tessellator.draw();
   }

   // $FF: synthetic method
   private void func_148226_e(int p_148226_1_, int p_148226_2_) {
      this.func_148224_c(p_148226_1_, p_148226_2_, 0, 0);
   }

   // $FF: synthetic method
   protected int getSize() {
      return jebac_vexia0o9cuuh5axo5.access$000(this.this$0).getFlatLayers().size();
   }

   // $FF: synthetic method
   protected int getScrollBarX() {
      return this.width - 70;
   }
}
