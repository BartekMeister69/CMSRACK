import java.awt.Color;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MovingObjectPosition;
import org.lwjgl.opengl.GL11;

public class jebac_vexia7k1fepxln7md {
   private final Minecraft  m;
   public jebac_vexiabjvb6fu2xswx  k;
   public float  n;
   public Color  i;
   private static final int[]  l;
   public boolean  j;

   // $FF: synthetic method
   private void drawFilledBoundingBox(AxisAlignedBB var1, float var2, float var3, float var4, float var5) {
      Exception var6 = Tessellator.getInstance();
      WorldRenderer var7 = var6.getWorldRenderer();
      var7.begin( l[6], DefaultVertexFormats.POSITION_COLOR);
      var7.pos(var1.minX, var1.minY, var1.minZ).color(var2, var3, var4, var5).endVertex();
      var7.pos(var1.minX, var1.maxY, var1.minZ).color(var2, var3, var4, var5).endVertex();
      var7.pos(var1.maxX, var1.minY, var1.minZ).color(var2, var3, var4, var5).endVertex();
      var7.pos(var1.maxX, var1.maxY, var1.minZ).color(var2, var3, var4, var5).endVertex();
      var7.pos(var1.maxX, var1.minY, var1.maxZ).color(var2, var3, var4, var5).endVertex();
      var7.pos(var1.maxX, var1.maxY, var1.maxZ).color(var2, var3, var4, var5).endVertex();
      var7.pos(var1.minX, var1.minY, var1.maxZ).color(var2, var3, var4, var5).endVertex();
      var7.pos(var1.minX, var1.maxY, var1.maxZ).color(var2, var3, var4, var5).endVertex();
      var6.draw();
      var7.begin( l[6], DefaultVertexFormats.POSITION_COLOR);
      var7.pos(var1.maxX, var1.maxY, var1.minZ).color(var2, var3, var4, var5).endVertex();
      var7.pos(var1.maxX, var1.minY, var1.minZ).color(var2, var3, var4, var5).endVertex();
      var7.pos(var1.minX, var1.maxY, var1.minZ).color(var2, var3, var4, var5).endVertex();
      var7.pos(var1.minX, var1.minY, var1.minZ).color(var2, var3, var4, var5).endVertex();
      var7.pos(var1.minX, var1.maxY, var1.maxZ).color(var2, var3, var4, var5).endVertex();
      var7.pos(var1.minX, var1.minY, var1.maxZ).color(var2, var3, var4, var5).endVertex();
      var7.pos(var1.maxX, var1.maxY, var1.maxZ).color(var2, var3, var4, var5).endVertex();
      var7.pos(var1.maxX, var1.minY, var1.maxZ).color(var2, var3, var4, var5).endVertex();
      var6.draw();
      var7.begin( l[6], DefaultVertexFormats.POSITION_COLOR);
      var7.pos(var1.minX, var1.maxY, var1.minZ).color(var2, var3, var4, var5).endVertex();
      var7.pos(var1.maxX, var1.maxY, var1.minZ).color(var2, var3, var4, var5).endVertex();
      var7.pos(var1.maxX, var1.maxY, var1.maxZ).color(var2, var3, var4, var5).endVertex();
      var7.pos(var1.minX, var1.maxY, var1.maxZ).color(var2, var3, var4, var5).endVertex();
      var7.pos(var1.minX, var1.maxY, var1.minZ).color(var2, var3, var4, var5).endVertex();
      var7.pos(var1.minX, var1.maxY, var1.maxZ).color(var2, var3, var4, var5).endVertex();
      var7.pos(var1.maxX, var1.maxY, var1.maxZ).color(var2, var3, var4, var5).endVertex();
      var7.pos(var1.maxX, var1.maxY, var1.minZ).color(var2, var3, var4, var5).endVertex();
      var6.draw();
      var7.begin( l[6], DefaultVertexFormats.POSITION_COLOR);
      var7.pos(var1.minX, var1.minY, var1.minZ).color(var2, var3, var4, var5).endVertex();
      var7.pos(var1.maxX, var1.minY, var1.minZ).color(var2, var3, var4, var5).endVertex();
      var7.pos(var1.maxX, var1.minY, var1.maxZ).color(var2, var3, var4, var5).endVertex();
      var7.pos(var1.minX, var1.minY, var1.maxZ).color(var2, var3, var4, var5).endVertex();
      var7.pos(var1.minX, var1.minY, var1.minZ).color(var2, var3, var4, var5).endVertex();
      var7.pos(var1.minX, var1.minY, var1.maxZ).color(var2, var3, var4, var5).endVertex();
      var7.pos(var1.maxX, var1.minY, var1.maxZ).color(var2, var3, var4, var5).endVertex();
      var7.pos(var1.maxX, var1.minY, var1.minZ).color(var2, var3, var4, var5).endVertex();
      var6.draw();
      var7.begin( l[6], DefaultVertexFormats.POSITION_COLOR);
      var7.pos(var1.minX, var1.minY, var1.minZ).color(var2, var3, var4, var5).endVertex();
      var7.pos(var1.minX, var1.maxY, var1.minZ).color(var2, var3, var4, var5).endVertex();
      var7.pos(var1.minX, var1.minY, var1.maxZ).color(var2, var3, var4, var5).endVertex();
      var7.pos(var1.minX, var1.maxY, var1.maxZ).color(var2, var3, var4, var5).endVertex();
      var7.pos(var1.maxX, var1.minY, var1.maxZ).color(var2, var3, var4, var5).endVertex();
      var7.pos(var1.maxX, var1.maxY, var1.maxZ).color(var2, var3, var4, var5).endVertex();
      var7.pos(var1.maxX, var1.minY, var1.minZ).color(var2, var3, var4, var5).endVertex();
      var7.pos(var1.maxX, var1.maxY, var1.minZ).color(var2, var3, var4, var5).endVertex();
      var6.draw();
      var7.begin( l[6], DefaultVertexFormats.POSITION_COLOR);
      var7.pos(var1.minX, var1.maxY, var1.maxZ).color(var2, var3, var4, var5).endVertex();
      var7.pos(var1.minX, var1.minY, var1.maxZ).color(var2, var3, var4, var5).endVertex();
      var7.pos(var1.minX, var1.maxY, var1.minZ).color(var2, var3, var4, var5).endVertex();
      var7.pos(var1.minX, var1.minY, var1.minZ).color(var2, var3, var4, var5).endVertex();
      var7.pos(var1.maxX, var1.maxY, var1.minZ).color(var2, var3, var4, var5).endVertex();
      var7.pos(var1.maxX, var1.minY, var1.minZ).color(var2, var3, var4, var5).endVertex();
      var7.pos(var1.maxX, var1.maxY, var1.maxZ).color(var2, var3, var4, var5).endVertex();
      var7.pos(var1.maxX, var1.minY, var1.maxZ).color(var2, var3, var4, var5).endVertex();
      var6.draw();
   }

   // $FF: synthetic method
   private static void llIIlll() {
       l = new int[7];
       l[0] = jebac_vexiaqb58506wt8o3.  ‏ ("祽", 1191082333).length();
       l[1] = (200 ^ 128 ^ 101 ^ 105) & (181 ^ 156 ^ 249 ^ 148 ^ -jebac_vexiaqb58506wt8o3.  ‏ ("υ", -590937115).length());
       l[2] = -25750 & 26519;
       l[3] = -205 & 975;
       l[4] = -25 & 4024;
       l[5] = 115 + 51 - 109 + 83 ^ 85 + 92 - 134 + 88;
       l[6] = 169 ^ 162 ^ 99 ^ 111;
   }

   // $FF: synthetic method
   private static boolean llIlIIl(int var0) {
      return var0 != 0;
   }

   // $FF: synthetic method
   public jebac_vexia7k1fepxln7md(Minecraft var1) {
      this. m = var1;
      this. k = jebac_vexiabjvb6fu2xswx. jl;
      this. n = 1.0F;
      this. i = Color.BLACK;
      this. j = (boolean) l[0];
   }

   // $FF: synthetic method
   private static boolean llIlIlI(Object var0, Object var1) {
      return var0 == var1;
   }

   // $FF: synthetic method
   public void render(MovingObjectPosition var1, WorldClient var2) {
      MovingObjectPosition var3 = var1.getBlockPos();
      boolean var4 = var2.getBlockState(var3).getBlock();
      if (llIlIII(var4.getMaterial(), Material.air)) {
         GlStateManager.pushMatrix();
         GlStateManager.depthMask((boolean) l[1]);
         GlStateManager.enableBlend();
         GlStateManager.disableTexture2D();
         GlStateManager.tryBlendFuncSeparate( l[2],  l[3],  l[0],  l[1]);
         GL11.glLineWidth(this. n);
         Color var10000;
         if (llIlIIl(this. j)) {
            var10000 = jebac_vexiacs3qcki5ln4n.getRainbow( l[4],  l[5]);
            jebac_vexiaqb58506wt8o3.  ‏ ("", 48740429).length();
            if (-jebac_vexiaqb58506wt8o3.  ‏ ("沶", 1969450134).length() > (26 + 120 - 65 + 55 ^ 121 + 61 - 161 + 119)) {
               return;
            }
         } else {
            var10000 = this. i;
         }

         Color var5 = var10000;
         BlockPos var6 = (float)var5.getRed() / 255.0F;
         double var7 = (float)var5.getGreen() / 255.0F;
         char var8 = (float)var5.getBlue() / 255.0F;
         float var22;
         if (llIlIlI(this. k, jebac_vexiabjvb6fu2xswx. jg)) {
            var22 = 0.12F;
            jebac_vexiaqb58506wt8o3.  ‏ ("", 1355144793).length();
            if ((11 ^ 14) == 0) {
               return;
            }
         } else {
            var22 = 1.0F;
         }

         Block var9 = var22;
         GlStateManager.color(var6, var7, var8, 1.0F);
         boolean var10 = var4.getSelectedBoundingBox(this. m.theWorld, var1.getBlockPos()).expand(0.0020000000949949026D, 0.0020000000949949026D, 0.0020000000949949026D).offset(-this. m.getRenderManager().viewerPosX, -this. m.getRenderManager().viewerPosY, -this. m.getRenderManager().viewerPosZ);
         RenderGlobal.func_181561_a(var10);
         if (llIlIlI(this. k, jebac_vexiabjvb6fu2xswx. jg)) {
            this.drawFilledBoundingBox(var10, var6, var7, var8, var9);
         }

         GlStateManager.disableBlend();
         GlStateManager.enableTexture2D();
         GlStateManager.depthMask((boolean) l[0]);
         GlStateManager.popMatrix();
      }

   }

   static {
      llIIlll();
   }

   // $FF: synthetic method
   private static boolean llIlIII(Object var0, Object var1) {
      return var0 != var1;
   }
}
