import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public abstract class jebac_vexia56c56njkv3fc {
   // $FF: synthetic field
   private static final Logger LOGGER = LogManager.getLogger();

   // $FF: synthetic method
   public static void warning(String message) {
      LOGGER.warn("[Shaders] " + message);
   }

   // $FF: synthetic method
   public static void info(String message) {
      LOGGER.info("[Shaders] " + message);
   }

   // $FF: synthetic method
   public static void info(String format, Object... args) {
      String s = String.format(format, args);
      LOGGER.info("[Shaders] " + s);
   }

   // $FF: synthetic method
   public static void severe(String message) {
      LOGGER.error("[Shaders] " + message);
   }

   // $FF: synthetic method
   public static void warning(String format, Object... args) {
      String s = String.format(format, args);
      LOGGER.warn("[Shaders] " + s);
   }
}
