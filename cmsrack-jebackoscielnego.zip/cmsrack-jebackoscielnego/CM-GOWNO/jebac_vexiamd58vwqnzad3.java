import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import java.io.IOException;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import net.minecraft.block.BlockTallGrass;
import net.minecraft.client.resources.I18n;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.world.biome.BiomeGenBase;
import net.minecraft.world.gen.FlatGeneratorInfo;
import net.minecraft.world.gen.FlatLayerInfo;
import org.lwjgl.input.Keyboard;

public class jebac_vexiamd58vwqnzad3 extends jebac_vexiakl614w3uw0xg {
   // $FF: synthetic field
   private final jebac_vexia0o9cuuh5axo5 parentScreen;
   // $FF: synthetic field
   private jebac_vexia4oibzo50ubf0 field_146434_t;
   // $FF: synthetic field
   private String presetsTitle;
   // $FF: synthetic field
   private String field_146436_r;
   // $FF: synthetic field
   private String presetsShare;
   // $FF: synthetic field
   private static final List FLAT_WORLD_PRESETS = Lists.newArrayList();
   // $FF: synthetic field
   private jebac_vexiaa29g8ikthjc5 field_146433_u;
   // $FF: synthetic field
   private jebac_vexiaa73fwc6ycz0l field_146435_s;

   // $FF: synthetic method
   protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
      this.field_146433_u.mouseClicked(mouseX, mouseY, mouseButton);
      super.mouseClicked(mouseX, mouseY, mouseButton);
   }

   // $FF: synthetic method
   public void initGui() {
      this.buttonList.clear();
      Keyboard.enableRepeatEvents(true);
      this.presetsTitle = I18n.format("createWorld.customize.presets.title");
      this.presetsShare = I18n.format("createWorld.customize.presets.share");
      this.field_146436_r = I18n.format("createWorld.customize.presets.list");
      this.field_146433_u = new jebac_vexiaa29g8ikthjc5(2, this.fontRendererObj, 50, 40, this.width - 100, 20);
      this.field_146435_s = new jebac_vexiaa73fwc6ycz0l(this);
      this.field_146433_u.setMaxStringLength(1230);
      this.field_146433_u.setText(this.parentScreen.func_146384_e());
      this.buttonList.add(this.field_146434_t = new jebac_vexia4oibzo50ubf0(0, this.width / 2 - 155, this.height - 28, 150, 20, I18n.format("createWorld.customize.presets.select")));
      this.buttonList.add(new jebac_vexia4oibzo50ubf0(1, this.width / 2 + 5, this.height - 28, 150, 20, I18n.format("gui.cancel")));
      this.func_146426_g();
   }

   // $FF: synthetic method
   public jebac_vexiamd58vwqnzad3(jebac_vexia0o9cuuh5axo5 p_i46318_1_) {
      this.parentScreen = p_i46318_1_;
   }

   static jebac_vexiaa73fwc6ycz0l access$100(jebac_vexiamd58vwqnzad3 x0) {
      return x0.field_146435_s;
   }

   // $FF: synthetic method
   private static void func_146425_a(String p_146425_0_, Item p_146425_1_, BiomeGenBase p_146425_2_, FlatLayerInfo... p_146425_3_) {
      func_175354_a(p_146425_0_, p_146425_1_, 0, p_146425_2_, (List)null, p_146425_3_);
   }

   static jebac_vexiaa29g8ikthjc5 access$200(jebac_vexiamd58vwqnzad3 x0) {
      return x0.field_146433_u;
   }

   static {
      func_146421_a("Classic Flat", Item.getItemFromBlock(Blocks.grass), BiomeGenBase.plains, Arrays.asList("village"), new FlatLayerInfo(1, Blocks.grass), new FlatLayerInfo(2, Blocks.dirt), new FlatLayerInfo(1, Blocks.bedrock));
      func_146421_a("Tunnelers' Dream", Item.getItemFromBlock(Blocks.stone), BiomeGenBase.extremeHills, Arrays.asList("biome_1", "dungeon", "decoration", "stronghold", "mineshaft"), new FlatLayerInfo(1, Blocks.grass), new FlatLayerInfo(5, Blocks.dirt), new FlatLayerInfo(230, Blocks.stone), new FlatLayerInfo(1, Blocks.bedrock));
      func_146421_a("Water World", Items.water_bucket, BiomeGenBase.deepOcean, Arrays.asList("biome_1", "oceanmonument"), new FlatLayerInfo(90, Blocks.water), new FlatLayerInfo(5, Blocks.sand), new FlatLayerInfo(5, Blocks.dirt), new FlatLayerInfo(5, Blocks.stone), new FlatLayerInfo(1, Blocks.bedrock));
      func_175354_a("Overworld", Item.getItemFromBlock(Blocks.tallgrass), BlockTallGrass.EnumType.GRASS.getMeta(), BiomeGenBase.plains, Arrays.asList("village", "biome_1", "decoration", "stronghold", "mineshaft", "dungeon", "lake", "lava_lake"), new FlatLayerInfo(1, Blocks.grass), new FlatLayerInfo(3, Blocks.dirt), new FlatLayerInfo(59, Blocks.stone), new FlatLayerInfo(1, Blocks.bedrock));
      func_146421_a("Snowy Kingdom", Item.getItemFromBlock(Blocks.snow_layer), BiomeGenBase.icePlains, Arrays.asList("village", "biome_1"), new FlatLayerInfo(1, Blocks.snow_layer), new FlatLayerInfo(1, Blocks.grass), new FlatLayerInfo(3, Blocks.dirt), new FlatLayerInfo(59, Blocks.stone), new FlatLayerInfo(1, Blocks.bedrock));
      func_146421_a("Bottomless Pit", Items.feather, BiomeGenBase.plains, Arrays.asList("village", "biome_1"), new FlatLayerInfo(1, Blocks.grass), new FlatLayerInfo(3, Blocks.dirt), new FlatLayerInfo(2, Blocks.cobblestone));
      func_146421_a("Desert", Item.getItemFromBlock(Blocks.sand), BiomeGenBase.desert, Arrays.asList("village", "biome_1", "decoration", "stronghold", "mineshaft", "dungeon"), new FlatLayerInfo(8, Blocks.sand), new FlatLayerInfo(52, Blocks.sandstone), new FlatLayerInfo(3, Blocks.stone), new FlatLayerInfo(1, Blocks.bedrock));
      func_146425_a("Redstone Ready", Items.redstone, BiomeGenBase.desert, new FlatLayerInfo(52, Blocks.sandstone), new FlatLayerInfo(3, Blocks.stone), new FlatLayerInfo(1, Blocks.bedrock));
   }

   // $FF: synthetic method
   public void drawScreen(int mouseX, int mouseY, float partialTicks) {
      this.drawDefaultBackground();
      this.field_146435_s.drawScreen(mouseX, mouseY, partialTicks);
      this.drawCenteredString(this.fontRendererObj, this.presetsTitle, this.width / 2, 8, 16777215);
      this.drawString(this.fontRendererObj, this.presetsShare, 50, 30, 10526880);
      this.drawString(this.fontRendererObj, this.field_146436_r, 50, 70, 10526880);
      this.field_146433_u.drawTextBox();
      super.drawScreen(mouseX, mouseY, partialTicks);
   }

   // $FF: synthetic method
   private static void func_175354_a(String p_175354_0_, Item p_175354_1_, int p_175354_2_, BiomeGenBase p_175354_3_, List p_175354_4_, FlatLayerInfo... p_175354_5_) {
      FlatGeneratorInfo flatgeneratorinfo = new FlatGeneratorInfo();

      for(int i = p_175354_5_.length - 1; i >= 0; --i) {
         flatgeneratorinfo.getFlatLayers().add(p_175354_5_[i]);
      }

      flatgeneratorinfo.setBiome(p_175354_3_.biomeID);
      flatgeneratorinfo.func_82645_d();
      if (p_175354_4_ != null) {
         Iterator var9 = p_175354_4_.iterator();

         while(var9.hasNext()) {
            String s = (String)var9.next();
            flatgeneratorinfo.getWorldFeatures().put(s, Maps.newHashMap());
         }
      }

      FLAT_WORLD_PRESETS.add(new jebac_vexiaup8pelpglzd6(p_175354_1_, p_175354_2_, p_175354_0_, flatgeneratorinfo.toString()));
   }

   // $FF: synthetic method
   protected void keyTyped(char typedChar, int keyCode) throws IOException {
      if (!this.field_146433_u.textboxKeyTyped(typedChar, keyCode)) {
         super.keyTyped(typedChar, keyCode);
      }

   }

   // $FF: synthetic method
   public void func_146426_g() {
      boolean flag = this.func_146430_p();
      this.field_146434_t.enabled = flag;
   }

   // $FF: synthetic method
   public void updateScreen() {
      this.field_146433_u.updateCursorCounter();
      super.updateScreen();
   }

   static List access$000() {
      return FLAT_WORLD_PRESETS;
   }

   // $FF: synthetic method
   private boolean func_146430_p() {
      return this.field_146435_s.field_148175_k > -1 && this.field_146435_s.field_148175_k < FLAT_WORLD_PRESETS.size() || this.field_146433_u.getText().length() > 1;
   }

   // $FF: synthetic method
   public void onGuiClosed() {
      Keyboard.enableRepeatEvents(false);
   }

   // $FF: synthetic method
   protected void actionPerformed(jebac_vexia4oibzo50ubf0 button) throws IOException {
      if (button.id == 0 && this.func_146430_p()) {
         this.parentScreen.func_146383_a(this.field_146433_u.getText());
         this.mc.displayGuiScreen(this.parentScreen);
      } else if (button.id == 1) {
         this.mc.displayGuiScreen(this.parentScreen);
      }

   }

   // $FF: synthetic method
   private static void func_146421_a(String p_146421_0_, Item p_146421_1_, BiomeGenBase p_146421_2_, List p_146421_3_, FlatLayerInfo... p_146421_4_) {
      func_175354_a(p_146421_0_, p_146421_1_, 0, p_146421_2_, p_146421_3_, p_146421_4_);
   }

   // $FF: synthetic method
   public void handleMouseInput() throws IOException {
      super.handleMouseInput();
      this.field_146435_s.handleMouseInput();
   }
}
