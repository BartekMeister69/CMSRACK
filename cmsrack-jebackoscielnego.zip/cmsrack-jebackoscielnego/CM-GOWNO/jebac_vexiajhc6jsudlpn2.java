import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.client.audio.SoundCategory;
import net.minecraft.client.audio.SoundHandler;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.resources.I18n;
import net.minecraft.util.MathHelper;
import net.minecraft.util.ResourceLocation;

class jebac_vexiajhc6jsudlpn2 extends jebac_vexia4oibzo50ubf0 {
   final jebac_vexia0kvkbrbbz0rd this$0;
   // $FF: synthetic field
   public float field_146156_o;
   // $FF: synthetic field
   private final String field_146152_s;
   // $FF: synthetic field
   public boolean field_146155_p;
   // $FF: synthetic field
   private final SoundCategory field_146153_r;

   // $FF: synthetic method
   public void mouseReleased(int mouseX, int mouseY) {
      if (this.field_146155_p) {
         if (this.field_146153_r != SoundCategory.MASTER) {
            jebac_vexia0kvkbrbbz0rd.access$000(this.this$0).getSoundLevel(this.field_146153_r);
         }

         this.this$0.mc.getSoundHandler().playSound(PositionedSoundRecord.create(new ResourceLocation("gui.button.press"), 1.0F));
      }

      this.field_146155_p = false;
   }

   // $FF: synthetic method
   public boolean mousePressed(Minecraft mc, int mouseX, int mouseY) {
      if (super.mousePressed(mc, mouseX, mouseY)) {
         this.field_146156_o = (float)(mouseX - (this.xPosition + 4)) / (float)(this.width - 8);
         this.field_146156_o = MathHelper.clamp_float(this.field_146156_o, 0.0F, 1.0F);
         mc.gameSettings.setSoundLevel(this.field_146153_r, this.field_146156_o);
         mc.gameSettings.saveOptions();
         this.displayString = this.field_146152_s + ": " + this.this$0.getSoundVolume(this.field_146153_r);
         this.field_146155_p = true;
         return true;
      } else {
         return false;
      }
   }

   // $FF: synthetic method
   public void drawButton(Minecraft mc, int mouseX, int mouseY) {
      if (jebac_vexiawzpzy1x3sez8. bx) {
         GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
         this.hovered = mouseX >= this.xPosition && mouseY >= this.yPosition && mouseX < this.xPosition + this.width && mouseY < this.yPosition + this.height;
         if (System.currentTimeMillis() >= this.animationUpdateTime) {
            this.animation.update(this.hovered);
            this.animationUpdateTime = System.currentTimeMillis() + 10L;
         }

         int color = 14737632;
         this.mouseDragged(mc, mouseX, mouseY);
         super.drawCenteredString(mc.fontRendererObj, this.displayString, this.xPosition + this.width / 2, this.yPosition + 5, color);
         if (this.enabled && this.hovered) {
            jebac_vexiawqkxo5ufmdem.drawLine2D((double)(this.xPosition + this.width / 2) - this.animation.getValue() * (double)this.width / 2.0D, (double)this.yPosition, (double)(this.xPosition + this.width / 2) + this.animation.getValue() * (double)this.width / 2.0D, (double)this.yPosition, 1.0F, jebac_vexiawzpzy1x3sez8. be ? jebac_vexiacs3qcki5ln4n.getRainbow(1000, 15).getRGB() : -8355712);
            jebac_vexiawqkxo5ufmdem.drawLine2D((double)(this.xPosition + this.width / 2) - this.animation.getValue() * (double)this.width / 2.0D, (double)(this.yPosition + this.height), (double)(this.xPosition + this.width / 2) + this.animation.getValue() * (double)this.width / 2.0D, (double)(this.yPosition + this.height), 1.0F, jebac_vexiawzpzy1x3sez8. be ? jebac_vexiacs3qcki5ln4n.getRainbow(1000, 15).getRGB() : -8355712);
            jebac_vexiawqkxo5ufmdem.drawLine2D((double)(this.xPosition + this.width / 2) - this.animation.getValue() * (double)this.width / 2.0D + (double)((int)((double)this.field_146156_o * (this.animation.getValue() * (double)this.width - 8.0D))), (double)this.yPosition, (double)(this.xPosition + this.width / 2) - this.animation.getValue() * (double)this.width / 2.0D + (double)((int)((double)this.field_146156_o * (this.animation.getValue() * (double)this.width - 8.0D))) + 8.0D, (double)this.yPosition, 1.0F, jebac_vexiawzpzy1x3sez8. be ? jebac_vexiacs3qcki5ln4n.getRainbow(1000, 15).getRGB() : 14737632);
            jebac_vexiawqkxo5ufmdem.drawLine2D((double)(this.xPosition + this.width / 2) - this.animation.getValue() * (double)this.width / 2.0D + (double)((int)((double)this.field_146156_o * (this.animation.getValue() * (double)this.width - 8.0D))), (double)(this.yPosition + this.height), (double)(this.xPosition + this.width / 2) - this.animation.getValue() * (double)this.width / 2.0D + (double)((int)((double)this.field_146156_o * (this.animation.getValue() * (double)this.width - 8.0D))) + 8.0D, (double)(this.yPosition + this.height), 1.0F, jebac_vexiawzpzy1x3sez8. be ? jebac_vexiacs3qcki5ln4n.getRainbow(1000, 15).getRGB() : 14737632);
         }

         GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
      } else {
         super.drawButton(mc, mouseX, mouseY);
      }

   }

   // $FF: synthetic method
   public void playPressSound(SoundHandler soundHandlerIn) {
   }

   // $FF: synthetic method
   protected int getHoverState(boolean mouseOver) {
      return 0;
   }

   // $FF: synthetic method
   protected void mouseDragged(Minecraft mc, int mouseX, int mouseY) {
      if (this.visible) {
         if (this.field_146155_p) {
            this.field_146156_o = (float)(mouseX - (this.xPosition + 4)) / (float)(this.width - 8);
            this.field_146156_o = MathHelper.clamp_float(this.field_146156_o, 0.0F, 1.0F);
            mc.gameSettings.setSoundLevel(this.field_146153_r, this.field_146156_o);
            mc.gameSettings.saveOptions();
            this.displayString = this.field_146152_s + ": " + this.this$0.getSoundVolume(this.field_146153_r);
         }

         if (!jebac_vexiawzpzy1x3sez8. bx) {
            mc.getTextureManager().bindTexture(buttonTextures);
            GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
            this.drawTexturedModalRect(this.xPosition + (int)(this.field_146156_o * (float)(this.width - 8)), this.yPosition, 0, 66, 4, 20);
            this.drawTexturedModalRect(this.xPosition + (int)(this.field_146156_o * (float)(this.width - 8)) + 4, this.yPosition, 196, 66, 4, 20);
         }
      }

   }

   // $FF: synthetic method
   public jebac_vexiajhc6jsudlpn2(jebac_vexia0kvkbrbbz0rd this$0, int p_i45024_2_, int p_i45024_3_, int p_i45024_4_, SoundCategory p_i45024_5_, boolean p_i45024_6_) {
      super(p_i45024_2_, p_i45024_3_, p_i45024_4_, p_i45024_6_ ? 310 : 150, 20, "");
      this.this$0 = this$0;
      this.field_146153_r = p_i45024_5_;
      this.field_146152_s = I18n.format("soundCategory." + p_i45024_5_.getCategoryName());
      this.displayString = this.field_146152_s + ": " + this$0.getSoundVolume(p_i45024_5_);
      this.field_146156_o = jebac_vexia0kvkbrbbz0rd.access$000(this$0).getSoundLevel(p_i45024_5_);
   }
}
