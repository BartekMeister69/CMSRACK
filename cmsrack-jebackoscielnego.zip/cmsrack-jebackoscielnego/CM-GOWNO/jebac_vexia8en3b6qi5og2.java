import net.minecraft.client.Minecraft;
import net.minecraft.stats.StatBase;
import net.minecraft.stats.StatList;

class jebac_vexia8en3b6qi5og2 extends jebac_vexiado18oeh2l9bq {
   final jebac_vexiazwfkkk4iev4c this$0;

   // $FF: synthetic method
   protected boolean isSelected(int slotIndex) {
      return false;
   }

   // $FF: synthetic method
   public jebac_vexia8en3b6qi5og2(jebac_vexiazwfkkk4iev4c this$0, Minecraft mcIn) {
      super(mcIn, this$0.width, this$0.height, 32, this$0.height - 64, 10);
      this.this$0 = this$0;
      this.setShowSelectionBox(false);
   }

   // $FF: synthetic method
   protected void drawSlot(int entryID, int p_180791_2_, int p_180791_3_, int p_180791_4_, int mouseXIn, int mouseYIn) {
      StatBase statbase = (StatBase)StatList.generalStats.get(entryID);
      this.this$0.drawString(jebac_vexiazwfkkk4iev4c.access$1300(this.this$0), statbase.getStatName().getUnformattedText(), p_180791_2_ + 2, p_180791_3_ + 1, entryID % 2 == 0 ? 16777215 : 9474192);
      String s = statbase.format(jebac_vexiazwfkkk4iev4c.access$100(this.this$0).readStat(statbase));
      this.this$0.drawString(jebac_vexiazwfkkk4iev4c.access$1400(this.this$0), s, p_180791_2_ + 2 + 213 - jebac_vexiazwfkkk4iev4c.access$1500(this.this$0).getStringWidth(s), p_180791_3_ + 1, entryID % 2 == 0 ? 16777215 : 9474192);
   }

   // $FF: synthetic method
   protected void drawBackground() {
      this.this$0.drawDefaultBackground();
   }

   // $FF: synthetic method
   protected void elementClicked(int slotIndex, boolean isDoubleClick, int mouseX, int mouseY) {
   }

   // $FF: synthetic method
   protected int getSize() {
      return StatList.generalStats.size();
   }

   // $FF: synthetic method
   protected int getContentHeight() {
      return this.getSize() * 10;
   }
}
