import net.minecraft.util.Util;

public class jebac_vexiaxl8ykkxok474 {
   // $FF: synthetic field
   private static String PREFIX_MACRO = "MC_";
   // $FF: synthetic field
   private static String[] extensionMacros;

   // $FF: synthetic method
   public static String getVendor() {
      String s = jebac_vexiakrwecfs16wve.openGlVendor;
      if (s == null) {
         return "MC_GL_VENDOR_OTHER";
      } else {
         s = s.toLowerCase();
         return s.startsWith("ati") ? "MC_GL_VENDOR_ATI" : (s.startsWith("intel") ? "MC_GL_VENDOR_INTEL" : (s.startsWith("nvidia") ? "MC_GL_VENDOR_NVIDIA" : (s.startsWith("x.org") ? "MC_GL_VENDOR_XORG" : "MC_GL_VENDOR_OTHER")));
      }
   }

   // $FF: synthetic method
   public static String getOs() {
      Util.EnumOS util$enumos = Util.getOSType();
      switch(util$enumos) {
      case WINDOWS:
         return "MC_OS_WINDOWS";
      case OSX:
         return "MC_OS_MAC";
      case LINUX:
         return "MC_OS_LINUX";
      default:
         return "MC_OS_OTHER";
      }
   }

   // $FF: synthetic method
   public static String getRenderer() {
      String s = jebac_vexiakrwecfs16wve.openGlRenderer;
      if (s == null) {
         return "MC_GL_RENDERER_OTHER";
      } else {
         s = s.toLowerCase();
         return s.startsWith("amd") ? "MC_GL_RENDERER_RADEON" : (s.startsWith("ati") ? "MC_GL_RENDERER_RADEON" : (s.startsWith("radeon") ? "MC_GL_RENDERER_RADEON" : (s.startsWith("gallium") ? "MC_GL_RENDERER_GALLIUM" : (s.startsWith("intel") ? "MC_GL_RENDERER_INTEL" : (s.startsWith("geforce") ? "MC_GL_RENDERER_GEFORCE" : (s.startsWith("nvidia") ? "MC_GL_RENDERER_GEFORCE" : (s.startsWith("quadro") ? "MC_GL_RENDERER_QUADRO" : (s.startsWith("nvs") ? "MC_GL_RENDERER_QUADRO" : (s.startsWith("mesa") ? "MC_GL_RENDERER_MESA" : "MC_GL_RENDERER_OTHER")))))))));
      }
   }

   // $FF: synthetic method
   public static String[] getExtensions() {
      if (extensionMacros == null) {
         String[] astring = jebac_vexiakrwecfs16wve.getOpenGlExtensions();
         String[] astring1 = new String[astring.length];

         for(int i = 0; i < astring.length; ++i) {
            astring1[i] = PREFIX_MACRO + astring[i];
         }

         extensionMacros = astring1;
      }

      return extensionMacros;
   }

   // $FF: synthetic method
   public static String getPrefixMacro() {
      return PREFIX_MACRO;
   }
}
