import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.CharArrayReader;
import java.io.CharArrayWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class jebac_vexiayhrpz6ms4dh9 {
   // $FF: synthetic field
   private static final Pattern PATTERN_VERSION = Pattern.compile("^\\s*#version\\s+.*$");
   // $FF: synthetic field
   private static final Pattern PATTERN_INCLUDE = Pattern.compile("^\\s*#include\\s+\"([A-Za-z0-9_/\\.]+)\".*$");
   // $FF: synthetic field
   private static final Set setConstNames = makeSetConstNames();

   // $FF: synthetic method
   private static Set makeSetConstNames() {
      Set set = new HashSet();
      set.add("shadowMapResolution");
      set.add("shadowDistance");
      set.add("shadowIntervalSize");
      set.add("generateShadowMipmap");
      set.add("generateShadowColorMipmap");
      set.add("shadowHardwareFiltering");
      set.add("shadowHardwareFiltering0");
      set.add("shadowHardwareFiltering1");
      set.add("shadowtex0Mipmap");
      set.add("shadowtexMipmap");
      set.add("shadowtex1Mipmap");
      set.add("shadowcolor0Mipmap");
      set.add("shadowColor0Mipmap");
      set.add("shadowcolor1Mipmap");
      set.add("shadowColor1Mipmap");
      set.add("shadowtex0Nearest");
      set.add("shadowtexNearest");
      set.add("shadow0MinMagNearest");
      set.add("shadowtex1Nearest");
      set.add("shadow1MinMagNearest");
      set.add("shadowcolor0Nearest");
      set.add("shadowColor0Nearest");
      set.add("shadowColor0MinMagNearest");
      set.add("shadowcolor1Nearest");
      set.add("shadowColor1Nearest");
      set.add("shadowColor1MinMagNearest");
      set.add("wetnessHalflife");
      set.add("drynessHalflife");
      set.add("eyeBrightnessHalflife");
      set.add("centerDepthHalflife");
      set.add("sunPathRotation");
      set.add("ambientOcclusionLevel");
      set.add("superSamplingLevel");
      set.add("noiseTextureResolution");
      return set;
   }

   // $FF: synthetic method
   private static boolean parseGuiScreen(String key, Properties props, Map map, jebac_vexiai4ghla0oxuww[] shaderProfiles, jebac_vexiazrxtvwdcml9w[] shaderOptions) {
      String s = props.getProperty(key);
      if (s == null) {
         return false;
      } else {
         List list = new ArrayList();
         Set set = new HashSet();
         String[] astring = jebac_vexiakrwecfs16wve.tokenize(s, " ");
         String[] var9 = astring;
         int var10 = astring.length;

         for(int var11 = 0; var11 < var10; ++var11) {
            String s1 = var9[var11];
            if (s1.equals("<empty>")) {
               list.add((Object)null);
            } else if (set.contains(s1)) {
               jebac_vexiakrwecfs16wve.warn("[Shaders] Duplicate option: " + s1 + ", key: " + key);
            } else {
               set.add(s1);
               if (s1.equals("<profile>")) {
                  if (shaderProfiles == null) {
                     jebac_vexiakrwecfs16wve.warn("[Shaders] Option profile can not be used, no profiles defined: " + s1 + ", key: " + key);
                  } else {
                     jebac_vexiagg7zbvolgevb shaderoptionprofile = new jebac_vexiagg7zbvolgevb(shaderProfiles, shaderOptions);
                     list.add(shaderoptionprofile);
                  }
               } else if (s1.equals("*")) {
                  jebac_vexiazrxtvwdcml9w shaderoption1 = new jebac_vexiarytepjva519f("<rest>");
                  list.add(shaderoption1);
               } else if (s1.startsWith("[") && s1.endsWith("]")) {
                  String s2 = jebac_vexianzkdk43wtdrt.removePrefixSuffix(s1, "[", "]");
                  if (!s2.matches("^[a-zA-Z0-9_]+$")) {
                     jebac_vexiakrwecfs16wve.warn("[Shaders] Invalid screen: " + s1 + ", key: " + key);
                  } else if (!parseGuiScreen("screen." + s2, props, map, shaderProfiles, shaderOptions)) {
                     jebac_vexiakrwecfs16wve.warn("[Shaders] Invalid screen: " + s1 + ", key: " + key);
                  } else {
                     jebac_vexia49jpdgvgic0p shaderoptionscreen = new jebac_vexia49jpdgvgic0p(s2);
                     list.add(shaderoptionscreen);
                  }
               } else {
                  jebac_vexiazrxtvwdcml9w shaderoption = jebac_vexiao69nzag0tqzs.getShaderOption(s1, shaderOptions);
                  if (shaderoption == null) {
                     jebac_vexiakrwecfs16wve.warn("[Shaders] Invalid option: " + s1 + ", key: " + key);
                     list.add((Object)null);
                  } else {
                     shaderoption.setVisible(true);
                     list.add(shaderoption);
                  }
               }
            }
         }

         jebac_vexiazrxtvwdcml9w[] ashaderoption = (jebac_vexiazrxtvwdcml9w[])list.toArray(new jebac_vexiazrxtvwdcml9w[0]);
         map.put(key, ashaderoption);
         return true;
      }
   }

   // $FF: synthetic method
   public static jebac_vexiazrxtvwdcml9w[] parseShaderPackOptions(jebac_vexiab8fgirhwov0i shaderPack, String[] programNames, List listDimensions) {
      if (shaderPack == null) {
         return new jebac_vexiazrxtvwdcml9w[0];
      } else {
         Map map = new HashMap();
         collectShaderOptions(shaderPack, "/shaders", programNames, map);
         Iterator iterator = listDimensions.iterator();

         while(iterator.hasNext()) {
            int i = (Integer)iterator.next();
            String s = "/shaders/world" + i;
            collectShaderOptions(shaderPack, s, programNames, map);
         }

         Collection collection = map.values();
         jebac_vexiazrxtvwdcml9w[] ashaderoption = (jebac_vexiazrxtvwdcml9w[])collection.toArray(new jebac_vexiazrxtvwdcml9w[0]);
         Comparator comparator = new Comparator() {
            // $FF: synthetic method
            public int compare(jebac_vexiazrxtvwdcml9w o1, jebac_vexiazrxtvwdcml9w o2) {
               return o1.getName().compareToIgnoreCase(o2.getName());
            }
         };
         Arrays.sort(ashaderoption, comparator);
         return ashaderoption;
      }
   }

   // $FF: synthetic method
   public static BufferedReader resolveIncludes(BufferedReader reader, String filePath, jebac_vexiab8fgirhwov0i shaderPack, int fileIndex, List listFiles, int includeLevel) throws IOException {
      String s = "/";
      int i = filePath.lastIndexOf("/");
      if (i >= 0) {
         s = filePath.substring(0, i);
      }

      CharArrayWriter chararraywriter = new CharArrayWriter();
      int j = -1;
      Set set = new LinkedHashSet();
      int k = 1;

      while(true) {
         String s1 = reader.readLine();
         String s3;
         String s8;
         if (s1 == null) {
            char[] achar = chararraywriter.toCharArray();
            if (j >= 0 && set.size() > 0) {
               StringBuilder stringbuilder = new StringBuilder();
               Iterator var23 = set.iterator();

               while(var23.hasNext()) {
                  s8 = (String)var23.next();
                  stringbuilder.append("#define ");
                  stringbuilder.append(s8);
                  stringbuilder.append("\n");
               }

               s3 = stringbuilder.toString();
               StringBuilder stringbuilder1 = new StringBuilder(new String(achar));
               stringbuilder1.insert(j, s3);
               String s10 = stringbuilder1.toString();
               achar = s10.toCharArray();
            }

            CharArrayReader chararrayreader = new CharArrayReader(achar);
            return new BufferedReader(chararrayreader);
         }

         Matcher matcher1;
         String s5;
         if (j < 0) {
            matcher1 = PATTERN_VERSION.matcher(s1);
            if (matcher1.matches()) {
               s5 = "#define MC_VERSION " + jebac_vexiakrwecfs16wve.getMinecraftVersionInt() + "\n#define MC_GL_VERSION " + jebac_vexiakrwecfs16wve.getGlVersion().toInt() + "\n#define MC_GLSL_VERSION " + jebac_vexiakrwecfs16wve.getGlslVersion().toInt() + "\n#define " + jebac_vexiaxl8ykkxok474.getOs() + "\n#define " + jebac_vexiaxl8ykkxok474.getVendor() + "\n#define " + jebac_vexiaxl8ykkxok474.getRenderer() + "\n";
               s3 = s1 + "\n" + s5;
               s8 = "#line " + (k + 1) + " " + fileIndex;
               s1 = s3 + s8;
               j = chararraywriter.size() + s3.length();
            }
         }

         matcher1 = PATTERN_INCLUDE.matcher(s1);
         if (matcher1.matches()) {
            s5 = matcher1.group(1);
            boolean flag = s5.startsWith("/");
            s8 = flag ? "/shaders" + s5 : s + "/" + s5;
            if (!listFiles.contains(s8)) {
               listFiles.add(s8);
            }

            int l = listFiles.indexOf(s8) + 1;
            s1 = loadFile(s8, shaderPack, l, listFiles, includeLevel);
            if (s1 == null) {
               throw new IOException("Included file not found: " + filePath);
            }

            if (s1.endsWith("\n")) {
               s1 = s1.substring(0, s1.length() - 1);
            }

            s1 = "#line 1 " + l + "\n" + s1 + "\n#line " + (k + 1) + " " + fileIndex;
         }

         if (j >= 0 && s1.contains(jebac_vexiaxl8ykkxok474.getPrefixMacro())) {
            String[] astring = findExtensions(s1, jebac_vexiaxl8ykkxok474.getExtensions());
            Collections.addAll(set, astring);
         }

         chararraywriter.write(s1);
         chararraywriter.write("\n");
         ++k;
      }
   }

   // $FF: synthetic method
   private static String[] getLines(jebac_vexiab8fgirhwov0i sp, String path) {
      try {
         List list = new ArrayList();
         String s = loadFile(path, sp, 0, list, 0);
         if (s == null) {
            return new String[0];
         } else {
            ByteArrayInputStream bytearrayinputstream = new ByteArrayInputStream(s.getBytes());
            return jebac_vexiakrwecfs16wve.readLines(bytearrayinputstream);
         }
      } catch (IOException var5) {
         jebac_vexiakrwecfs16wve.dbg(var5.getClass().getName() + ": " + var5.getMessage());
         return new String[0];
      }
   }

   // $FF: synthetic method
   public static jebac_vexiai4ghla0oxuww[] parseProfiles(Properties props, jebac_vexiazrxtvwdcml9w[] shaderOptions) {
      String s = "profile.";
      List list = new ArrayList();
      Iterator var4 = props.keySet().iterator();

      while(var4.hasNext()) {
         Object s10 = var4.next();
         String s1 = (String)s10;
         if (s1.startsWith(s)) {
            String s2 = s1.substring(s.length());
            props.getProperty(s1);
            Set set = new HashSet();
            jebac_vexiai4ghla0oxuww shaderprofile = parseProfile(s2, props, set, shaderOptions);
            if (shaderprofile != null) {
               list.add(shaderprofile);
            }
         }
      }

      if (list.size() <= 0) {
         return null;
      } else {
         return (jebac_vexiai4ghla0oxuww[])list.toArray(new jebac_vexiai4ghla0oxuww[0]);
      }
   }

   // $FF: synthetic method
   public static Map parseGuiScreens(Properties props, jebac_vexiai4ghla0oxuww[] shaderProfiles, jebac_vexiazrxtvwdcml9w[] shaderOptions) {
      Map map = new HashMap();
      parseGuiScreen("screen", props, map, shaderProfiles, shaderOptions);
      return map.isEmpty() ? null : map;
   }

   // $FF: synthetic method
   private static boolean isOptionUsed(jebac_vexiazrxtvwdcml9w so, String[] lines) {
      String[] var2 = lines;
      int var3 = lines.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         String s = var2[var4];
         if (so.isUsedInLine(s)) {
            return true;
         }
      }

      return false;
   }

   // $FF: synthetic method
   private static jebac_vexiai4ghla0oxuww parseProfile(String name, Properties props, Set parsedProfiles, jebac_vexiazrxtvwdcml9w[] shaderOptions) {
      String s = "profile.";
      String s1 = s + name;
      if (parsedProfiles.contains(s1)) {
         jebac_vexiakrwecfs16wve.warn("[Shaders] Profile already parsed: " + name);
         return null;
      } else {
         parsedProfiles.add(name);
         jebac_vexiai4ghla0oxuww shaderprofile = new jebac_vexiai4ghla0oxuww(name);
         String s2 = props.getProperty(s1);
         String[] astring = jebac_vexiakrwecfs16wve.tokenize(s2, " ");
         String[] var9 = astring;
         int var10 = astring.length;

         for(int var11 = 0; var11 < var10; ++var11) {
            String s3 = var9[var11];
            if (s3.startsWith(s)) {
               String s6 = s3.substring(s.length());
               jebac_vexiai4ghla0oxuww shaderprofile1 = parseProfile(s6, props, parsedProfiles, shaderOptions);
               shaderprofile.addOptionValues(shaderprofile1);
               shaderprofile.addDisabledPrograms(shaderprofile1.getDisabledPrograms());
            } else {
               String[] astring1 = jebac_vexiakrwecfs16wve.tokenize(s3, ":=");
               String s4;
               if (astring1.length == 1) {
                  s4 = astring1[0];
                  boolean flag = true;
                  if (s4.startsWith("!")) {
                     flag = false;
                     s4 = s4.substring(1);
                  }

                  String s8 = "program.";
                  if (!flag && s4.startsWith("program.")) {
                     String s9 = s4.substring(s8.length());
                     if (!jebac_vexiaflhnh80r1906.isProgramPath(s9)) {
                        jebac_vexiakrwecfs16wve.warn("Invalid program: " + s9 + " in profile: " + shaderprofile.getName());
                     } else {
                        shaderprofile.addDisabledProgram(s9);
                     }
                  } else {
                     jebac_vexiazrxtvwdcml9w shaderoption1 = jebac_vexiao69nzag0tqzs.getShaderOption(s4, shaderOptions);
                     if (!(shaderoption1 instanceof jebac_vexiaryg721x2j3kq)) {
                        jebac_vexiakrwecfs16wve.warn("[Shaders] Invalid option: " + s4);
                     } else {
                        shaderprofile.addOptionValue(s4, String.valueOf(flag));
                        shaderoption1.setVisible(true);
                     }
                  }
               } else if (astring1.length != 2) {
                  jebac_vexiakrwecfs16wve.warn("[Shaders] Invalid option value: " + s3);
               } else {
                  s4 = astring1[0];
                  String s5 = astring1[1];
                  jebac_vexiazrxtvwdcml9w shaderoption = jebac_vexiao69nzag0tqzs.getShaderOption(s4, shaderOptions);
                  if (shaderoption == null) {
                     jebac_vexiakrwecfs16wve.warn("[Shaders] Invalid option: " + s3);
                  } else if (!shaderoption.isValidValue(s5)) {
                     jebac_vexiakrwecfs16wve.warn("[Shaders] Invalid value: " + s3);
                  } else {
                     shaderoption.setVisible(true);
                     shaderprofile.addOptionValue(s4, s5);
                  }
               }
            }
         }

         return shaderprofile;
      }
   }

   // $FF: synthetic method
   private static jebac_vexiazrxtvwdcml9w getShaderOption(String line, String path) {
      jebac_vexiazrxtvwdcml9w shaderoption = null;
      shaderoption = jebac_vexiaryg721x2j3kq.parseOption(line, path);
      if (shaderoption == null) {
         shaderoption = jebac_vexiah4vtayrpt2ii.parseOption(line, path);
      }

      if (shaderoption != null) {
         return shaderoption;
      } else {
         shaderoption = jebac_vexiaglxaspvnw245.parseOption(line, path);
         if (shaderoption == null) {
            shaderoption = jebac_vexiaragmklxkf97f.parseOption(line, path);
         }

         return shaderoption != null && setConstNames.contains(shaderoption.getName()) ? shaderoption : null;
      }
   }

   // $FF: synthetic method
   private static String loadFile(String filePath, jebac_vexiab8fgirhwov0i shaderPack, int fileIndex, List listFiles, int includeLevel) throws IOException {
      if (includeLevel >= 10) {
         throw new IOException("#include depth exceeded: " + includeLevel + ", file: " + filePath);
      } else {
         ++includeLevel;
         InputStream inputstream = shaderPack.getResourceAsStream(filePath);
         if (inputstream == null) {
            return null;
         } else {
            InputStreamReader inputstreamreader = new InputStreamReader(inputstream, StandardCharsets.US_ASCII);
            BufferedReader bufferedreader = new BufferedReader(inputstreamreader);
            bufferedreader = resolveIncludes(bufferedreader, filePath, shaderPack, fileIndex, listFiles, includeLevel);
            CharArrayWriter chararraywriter = new CharArrayWriter();

            while(true) {
               String s = bufferedreader.readLine();
               if (s == null) {
                  return chararraywriter.toString();
               }

               chararraywriter.write(s);
               chararraywriter.write("\n");
            }
         }
      }
   }

   // $FF: synthetic method
   private static String[] findExtensions(String line, String[] extensions) {
      List list = new ArrayList();
      String[] var3 = extensions;
      int var4 = extensions.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         String s = var3[var5];
         if (line.contains(s)) {
            list.add(s);
         }
      }

      return (String[])list.toArray(new String[0]);
   }

   // $FF: synthetic method
   private static void collectShaderOptions(jebac_vexiab8fgirhwov0i sp, String path, Map mapOptions) {
      String[] astring = getLines(sp, path);
      String[] var4 = astring;
      int var5 = astring.length;

      for(int var6 = 0; var6 < var5; ++var6) {
         String s = var4[var6];
         jebac_vexiazrxtvwdcml9w shaderoption = getShaderOption(s, path);
         if (shaderoption != null && !shaderoption.getName().startsWith(jebac_vexiaxl8ykkxok474.getPrefixMacro()) && (!shaderoption.checkUsed() || isOptionUsed(shaderoption, astring))) {
            String s1 = shaderoption.getName();
            jebac_vexiazrxtvwdcml9w shaderoption1 = (jebac_vexiazrxtvwdcml9w)mapOptions.get(s1);
            if (shaderoption1 != null) {
               if (!jebac_vexiakrwecfs16wve.equals(shaderoption1.getValueDefault(), shaderoption.getValueDefault())) {
                  jebac_vexiakrwecfs16wve.warn("Ambiguous shader option: " + shaderoption.getName());
                  jebac_vexiakrwecfs16wve.warn(" - in " + jebac_vexiakrwecfs16wve.arrayToString((Object[])shaderoption1.getPaths()) + ": " + shaderoption1.getValueDefault());
                  jebac_vexiakrwecfs16wve.warn(" - in " + jebac_vexiakrwecfs16wve.arrayToString((Object[])shaderoption.getPaths()) + ": " + shaderoption.getValueDefault());
                  shaderoption1.setEnabled(false);
               }

               if (shaderoption1.getDescription() == null || shaderoption1.getDescription().length() <= 0) {
                  shaderoption1.setDescription(shaderoption.getDescription());
               }

               shaderoption1.addPaths(shaderoption.getPaths());
            } else {
               mapOptions.put(s1, shaderoption);
            }
         }
      }

   }

   // $FF: synthetic method
   private static void collectShaderOptions(jebac_vexiab8fgirhwov0i shaderPack, String dir, String[] programNames, Map mapOptions) {
      String[] var4 = programNames;
      int var5 = programNames.length;

      for(int var6 = 0; var6 < var5; ++var6) {
         String s = var4[var6];
         if (!s.equals("")) {
            String s1 = dir + "/" + s + ".vsh";
            String s2 = dir + "/" + s + ".fsh";
            collectShaderOptions(shaderPack, s1, mapOptions);
            collectShaderOptions(shaderPack, s2, mapOptions);
         }
      }

   }
}
