import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.crash.CrashReport;
import net.minecraft.crash.CrashReportCategory;

public class jebac_vexiaco2cph7bpv3h {
   // $FF: synthetic method
   public static void onCrashReport(CrashReport p_onCrashReport_0_, CrashReportCategory p_onCrashReport_1_) {
      try {
         GameSettings gamesettings = jebac_vexiakrwecfs16wve.getGameSettings();
         if (gamesettings == null) {
            return;
         }

         if (!gamesettings.snooperEnabled) {
            return;
         }

         Throwable throwable = p_onCrashReport_0_.getCrashCause();
         if (throwable == null) {
            return;
         }

         if (throwable.getClass() == Throwable.class) {
            return;
         }

         if (throwable.getClass().getName().contains(".fml.client.SplashProgress")) {
            return;
         }

         extendCrashReport(p_onCrashReport_1_);
         String s = "http://optifine.net/crashReport";
         String s1 = makeReport(p_onCrashReport_0_);
         byte[] abyte = s1.getBytes("ASCII");
         jebac_vexia502135ofxi6e ifileuploadlistener = new jebac_vexia502135ofxi6e() {
            // $FF: synthetic method
            public void fileUploadFinished(String p_fileUploadFinished_1_, byte[] p_fileUploadFinished_2_, Throwable p_fileUploadFinished_3_) {
            }
         };
         Map map = new HashMap();
         map.put("OF-Version", jebac_vexiakrwecfs16wve.getVersion());
         map.put("OF-Summary", makeSummary(p_onCrashReport_0_));
         jebac_vexia6rl5eemnpv2i fileuploadthread = new jebac_vexia6rl5eemnpv2i(s, map, abyte, ifileuploadlistener);
         fileuploadthread.setPriority(10);
         fileuploadthread.start();
         Thread.sleep(1000L);
      } catch (Exception var10) {
         jebac_vexiakrwecfs16wve.dbg(var10.getClass().getName() + ": " + var10.getMessage());
      }

   }

   // $FF: synthetic method
   private static String makeSummary(CrashReport p_makeSummary_0_) {
      Throwable throwable = p_makeSummary_0_.getCrashCause();
      if (throwable == null) {
         return "Unknown";
      } else {
         StackTraceElement[] astacktraceelement = throwable.getStackTrace();
         String s = "unknown";
         if (astacktraceelement.length > 0) {
            s = astacktraceelement[0].toString().trim();
         }

         return throwable.getClass().getName() + ": " + throwable.getMessage() + " (" + p_makeSummary_0_.getDescription() + ") [" + s + "]";
      }
   }

   // $FF: synthetic method
   public static void extendCrashReport(CrashReportCategory p_extendCrashReport_0_) {
      p_extendCrashReport_0_.addCrashSection("OptiFine Version", jebac_vexiakrwecfs16wve.getVersion());
      if (jebac_vexiakrwecfs16wve.getGameSettings() != null) {
         p_extendCrashReport_0_.addCrashSection("Render Distance Chunks", "" + jebac_vexiakrwecfs16wve.getChunkViewDistance());
         p_extendCrashReport_0_.addCrashSection("Mipmaps", "" + jebac_vexiakrwecfs16wve.getMipmapLevels());
         p_extendCrashReport_0_.addCrashSection("Anisotropic Filtering", "" + jebac_vexiakrwecfs16wve.getAnisotropicFilterLevel());
         p_extendCrashReport_0_.addCrashSection("Antialiasing", "" + jebac_vexiakrwecfs16wve.getAntialiasingLevel());
         p_extendCrashReport_0_.addCrashSection("Multitexture", "" + jebac_vexiakrwecfs16wve.isMultiTexture());
      }

      p_extendCrashReport_0_.addCrashSection("Shaders", "" + jebac_vexiaflhnh80r1906.getShaderPackName());
      p_extendCrashReport_0_.addCrashSection("OpenGlVersion", "" + jebac_vexiakrwecfs16wve.openGlVersion);
      p_extendCrashReport_0_.addCrashSection("OpenGlRenderer", "" + jebac_vexiakrwecfs16wve.openGlRenderer);
      p_extendCrashReport_0_.addCrashSection("OpenGlVendor", "" + jebac_vexiakrwecfs16wve.openGlVendor);
      p_extendCrashReport_0_.addCrashSection("CpuCount", "" + jebac_vexiakrwecfs16wve.getAvailableProcessors());
   }

   // $FF: synthetic method
   private static String makeReport(CrashReport p_makeReport_0_) {
      StringBuffer stringbuffer = new StringBuffer();
      stringbuffer.append("OptiFineVersion: " + jebac_vexiakrwecfs16wve.getVersion() + "\n");
      stringbuffer.append("Summary: " + makeSummary(p_makeReport_0_) + "\n");
      stringbuffer.append("\n");
      stringbuffer.append(p_makeReport_0_.getCompleteReport());
      stringbuffer.append("\n");
      return stringbuffer.toString();
   }
}
