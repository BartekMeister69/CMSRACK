import java.util.Map;

public class jebac_vexia6rl5eemnpv2i extends Thread {
   // $FF: synthetic field
   private Map headers;
   // $FF: synthetic field
   private jebac_vexia502135ofxi6e listener;
   // $FF: synthetic field
   private byte[] content;
   // $FF: synthetic field
   private String urlString;

   // $FF: synthetic method
   public void run() {
      try {
         jebac_vexiapkue855sna5m.post(this.urlString, this.headers, this.content);
         this.listener.fileUploadFinished(this.urlString, this.content, (Throwable)null);
      } catch (Exception var2) {
         this.listener.fileUploadFinished(this.urlString, this.content, var2);
      }

   }

   // $FF: synthetic method
   public jebac_vexia502135ofxi6e getListener() {
      return this.listener;
   }

   // $FF: synthetic method
   public jebac_vexia6rl5eemnpv2i(String p_i42_1_, Map p_i42_2_, byte[] p_i42_3_, jebac_vexia502135ofxi6e p_i42_4_) {
      this.urlString = p_i42_1_;
      this.headers = p_i42_2_;
      this.content = p_i42_3_;
      this.listener = p_i42_4_;
   }
}
