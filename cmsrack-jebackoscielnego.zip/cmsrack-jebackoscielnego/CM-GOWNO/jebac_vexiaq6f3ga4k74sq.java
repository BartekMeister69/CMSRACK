public class jebac_vexiaq6f3ga4k74sq extends jebac_vexiat51dq4htxchd {
   // $FF: synthetic method
   public jebac_vexiaq6f3ga4k74sq() {
      this.isChild = false;
   }
}
