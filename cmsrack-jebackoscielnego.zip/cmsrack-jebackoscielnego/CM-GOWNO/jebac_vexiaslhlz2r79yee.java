import java.util.Comparator;

public class jebac_vexiaslhlz2r79yee implements Comparator {
   // $FF: synthetic method
   public int compare(Object p_compare_1_, Object p_compare_2_) {
      jebac_vexial4zrpld9z8lm customitemproperties = (jebac_vexial4zrpld9z8lm)p_compare_1_;
      jebac_vexial4zrpld9z8lm customitemproperties1 = (jebac_vexial4zrpld9z8lm)p_compare_2_;
      return customitemproperties.weight != customitemproperties1.weight ? customitemproperties1.weight - customitemproperties.weight : (!jebac_vexiakrwecfs16wve.equals(customitemproperties.basePath, customitemproperties1.basePath) ? customitemproperties.basePath.compareTo(customitemproperties1.basePath) : customitemproperties.name.compareTo(customitemproperties1.name));
   }
}
