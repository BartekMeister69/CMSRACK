import com.google.common.collect.Lists;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ServerList;
import net.minecraft.client.network.LanServerDetector;

public class jebac_vexiacazjnru2p17q extends jebac_vexiadrxrz0b4x3gp {
   // $FF: synthetic field
   private final jebac_vexiaqgfx58baqzsf owner;
   // $FF: synthetic field
   private int selectedSlotIndex = -1;
   // $FF: synthetic field
   private final List field_148199_m = Lists.newArrayList();
   // $FF: synthetic field
   private final jebac_vexia68uke90d57nv lanScanEntry = new jebac_vexiak2i3dxmko7eq();
   // $FF: synthetic field
   private final List field_148198_l = Lists.newArrayList();

   // $FF: synthetic method
   public void func_148194_a(List p_148194_1_) {
      this.field_148199_m.clear();
      Iterator var2 = p_148194_1_.iterator();

      while(var2.hasNext()) {
         LanServerDetector.LanServer lanserverdetector$lanserver = (LanServerDetector.LanServer)var2.next();
         this.field_148199_m.add(new jebac_vexia1bfiy64cklkl(this.owner, lanserverdetector$lanserver));
      }

   }

   // $FF: synthetic method
   public jebac_vexia68uke90d57nv getListEntry(int index) {
      if (index < this.field_148198_l.size()) {
         return (jebac_vexia68uke90d57nv)this.field_148198_l.get(index);
      } else {
         index -= this.field_148198_l.size();
         if (index == 0) {
            return this.lanScanEntry;
         } else {
            --index;
            return (jebac_vexia68uke90d57nv)this.field_148199_m.get(index);
         }
      }
   }

   // $FF: synthetic method
   protected boolean isSelected(int slotIndex) {
      return slotIndex == this.selectedSlotIndex;
   }

   // $FF: synthetic method
   public int func_148193_k() {
      return this.selectedSlotIndex;
   }

   // $FF: synthetic method
   public jebac_vexiacazjnru2p17q(jebac_vexiaqgfx58baqzsf ownerIn, Minecraft mcIn, int widthIn, int heightIn, int topIn, int bottomIn, int slotHeightIn) {
      super(mcIn, widthIn, heightIn, topIn, bottomIn, slotHeightIn);
      this.owner = ownerIn;
   }

   // $FF: synthetic method
   protected int getSize() {
      return this.field_148198_l.size() + 1 + this.field_148199_m.size();
   }

   // $FF: synthetic method
   protected int getScrollBarX() {
      return super.getScrollBarX() + 30;
   }

   // $FF: synthetic method
   public void func_148195_a(ServerList p_148195_1_) {
      this.field_148198_l.clear();

      for(int i = 0; i < p_148195_1_.countServers(); ++i) {
         this.field_148198_l.add(new jebac_vexiac1q8698jepny(this.owner, p_148195_1_.getServerData(i)));
      }

   }

   // $FF: synthetic method
   public int getListWidth() {
      return super.getListWidth() + 85;
   }

   // $FF: synthetic method
   public void setSelectedSlotIndex(int selectedSlotIndexIn) {
      this.selectedSlotIndex = selectedSlotIndexIn;
   }
}
