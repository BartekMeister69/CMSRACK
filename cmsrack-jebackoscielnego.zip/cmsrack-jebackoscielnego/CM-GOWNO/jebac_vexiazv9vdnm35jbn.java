import java.lang.reflect.Constructor;

public class jebac_vexiazv9vdnm35jbn {
   // $FF: synthetic field
   private boolean checked = false;
   // $FF: synthetic field
   private Class[] parameterTypes = null;
   // $FF: synthetic field
   private Constructor targetConstructor = null;
   // $FF: synthetic field
   private jebac_vexiajs8ej2dllnvc reflectorClass = null;

   // $FF: synthetic method
   public jebac_vexiazv9vdnm35jbn(jebac_vexiajs8ej2dllnvc p_i84_1_, Class[] p_i84_2_) {
      this.reflectorClass = p_i84_1_;
      this.parameterTypes = p_i84_2_;
      Constructor constructor = this.getTargetConstructor();
   }

   // $FF: synthetic method
   public boolean exists() {
      return this.checked ? this.targetConstructor != null : this.getTargetConstructor() != null;
   }

   // $FF: synthetic method
   public void deactivate() {
      this.checked = true;
      this.targetConstructor = null;
   }

   // $FF: synthetic method
   public Constructor getTargetConstructor() {
      if (this.checked) {
         return this.targetConstructor;
      } else {
         this.checked = true;
         Class oclass = this.reflectorClass.getTargetClass();
         if (oclass == null) {
            return null;
         } else {
            try {
               this.targetConstructor = findConstructor(oclass, this.parameterTypes);
               if (this.targetConstructor == null) {
                  jebac_vexiakrwecfs16wve.dbg("(Reflector) Constructor not present: " + oclass.getName() + ", params: " + jebac_vexiakrwecfs16wve.arrayToString((Object[])this.parameterTypes));
               }

               if (this.targetConstructor != null) {
                  this.targetConstructor.setAccessible(true);
               }
            } catch (Throwable var3) {
               var3.printStackTrace();
            }

            return this.targetConstructor;
         }
      }
   }

   // $FF: synthetic method
   private static Constructor findConstructor(Class p_findConstructor_0_, Class[] p_findConstructor_1_) {
      Constructor[] aconstructor = p_findConstructor_0_.getDeclaredConstructors();

      for(int i = 0; i < aconstructor.length; ++i) {
         Constructor constructor = aconstructor[i];
         Class[] aclass = constructor.getParameterTypes();
         if (jebac_vexiawp5rpzl0e6ma.matchesTypes(p_findConstructor_1_, aclass)) {
            return constructor;
         }
      }

      return null;
   }
}
