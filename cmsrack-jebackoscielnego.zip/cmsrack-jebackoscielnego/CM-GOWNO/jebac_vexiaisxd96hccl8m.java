import com.google.common.collect.AbstractIterator;
import java.util.Iterator;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;

public class jebac_vexiaisxd96hccl8m extends BlockPos {
   // $FF: synthetic field
   private int mz;
   // $FF: synthetic field
   private int mx;
   // $FF: synthetic field
   private int my;
   // $FF: synthetic field
   private jebac_vexiaisxd96hccl8m[] facings;
   // $FF: synthetic field
   private int level;
   // $FF: synthetic field
   private boolean needsUpdate;

   // $FF: synthetic method
   public void setXyz(int p_setXyz_1_, int p_setXyz_2_, int p_setXyz_3_) {
      this.mx = p_setXyz_1_;
      this.my = p_setXyz_2_;
      this.mz = p_setXyz_3_;
      this.needsUpdate = true;
   }

   // $FF: synthetic method
   public jebac_vexiaisxd96hccl8m(int p_i24_1_, int p_i24_2_, int p_i24_3_, int p_i24_4_) {
      super(0, 0, 0);
      this.mx = p_i24_1_;
      this.my = p_i24_2_;
      this.mz = p_i24_3_;
      this.level = p_i24_4_;
   }

   // $FF: synthetic method
   public jebac_vexiaisxd96hccl8m(int p_i22_1_, int p_i22_2_, int p_i22_3_) {
      this(p_i22_1_, p_i22_2_, p_i22_3_, 0);
   }

   // $FF: synthetic method
   public jebac_vexiaisxd96hccl8m(double p_i23_1_, double p_i23_3_, double p_i23_5_) {
      this(MathHelper.floor_double(p_i23_1_), MathHelper.floor_double(p_i23_3_), MathHelper.floor_double(p_i23_5_));
   }

   // $FF: synthetic method
   public static Iterable getAllInBoxMutable(BlockPos p_getAllInBoxMutable_0_, BlockPos p_getAllInBoxMutable_1_) {
      BlockPos blockpos = new BlockPos(Math.min(p_getAllInBoxMutable_0_.getX(), p_getAllInBoxMutable_1_.getX()), Math.min(p_getAllInBoxMutable_0_.getY(), p_getAllInBoxMutable_1_.getY()), Math.min(p_getAllInBoxMutable_0_.getZ(), p_getAllInBoxMutable_1_.getZ()));
      BlockPos blockpos1 = new BlockPos(Math.max(p_getAllInBoxMutable_0_.getX(), p_getAllInBoxMutable_1_.getX()), Math.max(p_getAllInBoxMutable_0_.getY(), p_getAllInBoxMutable_1_.getY()), Math.max(p_getAllInBoxMutable_0_.getZ(), p_getAllInBoxMutable_1_.getZ()));
      return new Iterable(blockpos, blockpos1) {
         final BlockPos val$blockpos1;
         final BlockPos val$blockpos;

         // $FF: synthetic method
         public Iterator iterator() {
            return new AbstractIterator(this) {
               final <undefinedtype> this$0;
               // $FF: synthetic field
               private jebac_vexiaisxd96hccl8m theBlockPosM;

               // $FF: synthetic method
               jebac_vexiaisxd96hccl8m computeNext0() {
                  if (this.theBlockPosM == null) {
                     this.theBlockPosM = new jebac_vexiaisxd96hccl8m(this.this$0.val$blockpos.getX(), this.this$0.val$blockpos.getY(), this.this$0.val$blockpos.getZ(), 3);
                     return this.theBlockPosM;
                  } else if (this.theBlockPosM.equals(this.this$0.val$blockpos1)) {
                     return (jebac_vexiaisxd96hccl8m)this.endOfData();
                  } else {
                     int i = this.theBlockPosM.getX();
                     int j = this.theBlockPosM.getY();
                     int k = this.theBlockPosM.getZ();
                     if (i < this.this$0.val$blockpos1.getX()) {
                        ++i;
                     } else if (j < this.this$0.val$blockpos1.getY()) {
                        i = this.this$0.val$blockpos.getX();
                        ++j;
                     } else if (k < this.this$0.val$blockpos1.getZ()) {
                        i = this.this$0.val$blockpos.getX();
                        j = this.this$0.val$blockpos.getY();
                        ++k;
                     }

                     this.theBlockPosM.setXyz(i, j, k);
                     return this.theBlockPosM;
                  }
               }

               // $FF: synthetic method
               protected Object computeNext() {
                  return this.computeNext0();
               }

               // $FF: synthetic method
               {
                  this.this$0 = this$0;
                  this.theBlockPosM = null;
               }
            };
         }

         // $FF: synthetic method
         {
            this.val$blockpos = var1;
            this.val$blockpos1 = var2;
         }
      };
   }

   // $FF: synthetic method
   public int getZ() {
      return this.mz;
   }

   // $FF: synthetic method
   public int getX() {
      return this.mx;
   }

   // $FF: synthetic method
   public void setXyz(double p_setXyz_1_, double p_setXyz_3_, double p_setXyz_5_) {
      this.setXyz(MathHelper.floor_double(p_setXyz_1_), MathHelper.floor_double(p_setXyz_3_), MathHelper.floor_double(p_setXyz_5_));
   }

   // $FF: synthetic method
   public BlockPos offset(EnumFacing facing, int n) {
      return n == 1 ? this.offset(facing) : super.offset(facing, n);
   }

   // $FF: synthetic method
   private void update() {
      for(int i = 0; i < 6; ++i) {
         jebac_vexiaisxd96hccl8m blockposm = this.facings[i];
         if (blockposm != null) {
            EnumFacing enumfacing = EnumFacing.VALUES[i];
            int j = this.mx + enumfacing.getFrontOffsetX();
            int k = this.my + enumfacing.getFrontOffsetY();
            int l = this.mz + enumfacing.getFrontOffsetZ();
            blockposm.setXyz(j, k, l);
         }
      }

      this.needsUpdate = false;
   }

   // $FF: synthetic method
   public int getY() {
      return this.my;
   }

   // $FF: synthetic method
   public BlockPos offset(EnumFacing facing) {
      if (this.level <= 0) {
         return super.offset(facing, 1);
      } else {
         if (this.facings == null) {
            this.facings = new jebac_vexiaisxd96hccl8m[EnumFacing.VALUES.length];
         }

         if (this.needsUpdate) {
            this.update();
         }

         int i = facing.getIndex();
         jebac_vexiaisxd96hccl8m blockposm = this.facings[i];
         if (blockposm == null) {
            int j = this.mx + facing.getFrontOffsetX();
            int k = this.my + facing.getFrontOffsetY();
            int l = this.mz + facing.getFrontOffsetZ();
            blockposm = new jebac_vexiaisxd96hccl8m(j, k, l, this.level - 1);
            this.facings[i] = blockposm;
         }

         return blockposm;
      }
   }
}
