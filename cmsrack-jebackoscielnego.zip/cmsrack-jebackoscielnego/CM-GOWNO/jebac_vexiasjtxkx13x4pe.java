public class jebac_vexiasjtxkx13x4pe {
   // $FF: synthetic method
   public static int getAverage(int[] p_getAverage_0_) {
      if (p_getAverage_0_.length <= 0) {
         return 0;
      } else {
         int i = 0;
         int[] var2 = p_getAverage_0_;
         int var3 = p_getAverage_0_.length;

         for(int var4 = 0; var4 < var3; ++var4) {
            int k = var2[var4];
            i += k;
         }

         return i / p_getAverage_0_.length;
      }
   }
}
