import java.util.HashSet;
import java.util.Set;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.block.model.ItemModelGenerator;
import net.minecraft.client.renderer.entity.RenderItem;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.client.resources.model.IBakedModel;
import net.minecraft.client.resources.model.ModelResourceLocation;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.ResourceLocation;

public class jebac_vexiaogziwpl765tn {
   // $FF: synthetic field
   private static ItemModelGenerator itemModelGenerator = new ItemModelGenerator();
   // $FF: synthetic field
   private static jebac_vexial4zrpld9z8lm[][] itemProperties = (jebac_vexial4zrpld9z8lm[][])null;
   // $FF: synthetic field
   private static final int[][] EMPTY_INT2_ARRAY = new int[0][];
   // $FF: synthetic field
   private static jebac_vexial4zrpld9z8lm[][] enchantmentProperties = (jebac_vexial4zrpld9z8lm[][])null;

   // $FF: synthetic method
   public static boolean isUseGlint() {
      return true;
   }

   // $FF: synthetic method
   public static boolean bindCustomArmorTexture(ItemStack p_bindCustomArmorTexture_0_, int p_bindCustomArmorTexture_1_, String p_bindCustomArmorTexture_2_) {
      if (itemProperties == null) {
         return false;
      } else {
         ResourceLocation resourcelocation = getCustomArmorLocation(p_bindCustomArmorTexture_0_, p_bindCustomArmorTexture_1_, p_bindCustomArmorTexture_2_);
         if (resourcelocation == null) {
            return false;
         } else {
            jebac_vexiakrwecfs16wve.getTextureManager().bindTexture(resourcelocation);
            return true;
         }
      }
   }

   // $FF: synthetic method
   public static IBakedModel getCustomItemModel(ItemStack p_getCustomItemModel_0_, IBakedModel p_getCustomItemModel_1_, ModelResourceLocation p_getCustomItemModel_2_) {
      if (p_getCustomItemModel_1_.isGui3d()) {
         return p_getCustomItemModel_1_;
      } else if (itemProperties == null) {
         return p_getCustomItemModel_1_;
      } else {
         jebac_vexial4zrpld9z8lm customitemproperties = getCustomItemProperties(p_getCustomItemModel_0_, 1);
         return customitemproperties == null ? p_getCustomItemModel_1_ : customitemproperties.getModel(p_getCustomItemModel_2_);
      }
   }

   // $FF: synthetic method
   public static boolean renderCustomArmorEffect(EntityLivingBase p_renderCustomArmorEffect_0_, ItemStack p_renderCustomArmorEffect_1_, jebac_vexiat51dq4htxchd p_renderCustomArmorEffect_2_, float p_renderCustomArmorEffect_3_, float p_renderCustomArmorEffect_4_, float p_renderCustomArmorEffect_5_, float p_renderCustomArmorEffect_6_, float p_renderCustomArmorEffect_7_, float p_renderCustomArmorEffect_8_, float p_renderCustomArmorEffect_9_) {
      if (enchantmentProperties == null) {
         return false;
      } else if (jebac_vexiakrwecfs16wve.isShaders() && jebac_vexiaflhnh80r1906.isShadowPass) {
         return false;
      } else if (p_renderCustomArmorEffect_1_ == null) {
         return false;
      } else {
         int[][] aint = getEnchantmentIdLevels(p_renderCustomArmorEffect_1_);
         if (aint.length <= 0) {
            return false;
         } else {
            Set set = null;
            boolean flag = false;
            TextureManager texturemanager = jebac_vexiakrwecfs16wve.getTextureManager();
            int[][] var14 = aint;
            int var15 = aint.length;

            for(int var16 = 0; var16 < var15; ++var16) {
               int[] ints = var14[var16];
               int j = ints[0];
               if (j >= 0 && j < enchantmentProperties.length) {
                  jebac_vexial4zrpld9z8lm[] acustomitemproperties = enchantmentProperties[j];
                  if (acustomitemproperties != null) {
                     jebac_vexial4zrpld9z8lm[] var20 = acustomitemproperties;
                     int var21 = acustomitemproperties.length;

                     for(int var22 = 0; var22 < var21; ++var22) {
                        jebac_vexial4zrpld9z8lm customitemproperties = var20[var22];
                        if (set == null) {
                           set = new HashSet();
                        }

                        if (set.add(j) && matchesProperties(customitemproperties, p_renderCustomArmorEffect_1_, aint) && customitemproperties.textureLocation != null) {
                           texturemanager.bindTexture(customitemproperties.textureLocation);
                           float f = customitemproperties.getTextureWidth(texturemanager);
                           if (!flag) {
                              flag = true;
                              if (jebac_vexiakrwecfs16wve.isShaders()) {
                                 jebac_vexiajx44ap1bcm0b.renderEnchantedGlintBegin();
                              }

                              GlStateManager.enableBlend();
                              GlStateManager.depthFunc(514);
                              GlStateManager.depthMask(false);
                           }

                           jebac_vexiau5kgy2fm1nlm.setupBlend(customitemproperties.blend, 1.0F);
                           GlStateManager.disableLighting();
                           GlStateManager.matrixMode(5890);
                           GlStateManager.loadIdentity();
                           GlStateManager.rotate(customitemproperties.rotation, 0.0F, 0.0F, 1.0F);
                           float f1 = f / 8.0F;
                           GlStateManager.scale(f1, f1 / 2.0F, f1);
                           float f2 = customitemproperties.speed * (float)(Minecraft.getSystemTime() % 3000L) / 3000.0F / 8.0F;
                           GlStateManager.translate(0.0F, f2, 0.0F);
                           GlStateManager.matrixMode(5888);
                           p_renderCustomArmorEffect_2_.render(p_renderCustomArmorEffect_0_, p_renderCustomArmorEffect_3_, p_renderCustomArmorEffect_4_, p_renderCustomArmorEffect_6_, p_renderCustomArmorEffect_7_, p_renderCustomArmorEffect_8_, p_renderCustomArmorEffect_9_);
                        }
                     }
                  }
               }
            }

            if (flag) {
               GlStateManager.enableAlpha();
               GlStateManager.enableBlend();
               GlStateManager.blendFunc(770, 771);
               GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
               GlStateManager.matrixMode(5890);
               GlStateManager.loadIdentity();
               GlStateManager.matrixMode(5888);
               GlStateManager.enableLighting();
               GlStateManager.depthMask(true);
               GlStateManager.depthFunc(515);
               GlStateManager.disableBlend();
               if (jebac_vexiakrwecfs16wve.isShaders()) {
                  jebac_vexiajx44ap1bcm0b.renderEnchantedGlintEnd();
               }
            }

            return flag;
         }
      }
   }

   // $FF: synthetic method
   private static boolean matchesProperties(jebac_vexial4zrpld9z8lm p_matchesProperties_0_, ItemStack p_matchesProperties_1_, int[][] p_matchesProperties_2_) {
      Item item = p_matchesProperties_1_.getItem();
      if (p_matchesProperties_0_.damage != null) {
         int i = p_matchesProperties_1_.getItemDamage();
         if (p_matchesProperties_0_.damageMask != 0) {
            i &= p_matchesProperties_0_.damageMask;
         }

         if (p_matchesProperties_0_.damagePercent) {
            int j = item.getMaxDamage();
            i = (int)((double)(i * 100) / (double)j);
         }

         if (!p_matchesProperties_0_.damage.isInRange(i)) {
            return false;
         }
      }

      if (p_matchesProperties_0_.stackSize != null && !p_matchesProperties_0_.stackSize.isInRange(p_matchesProperties_1_.stackSize)) {
         return false;
      } else {
         int[][] aint = p_matchesProperties_2_;
         int[][] var6;
         int var7;
         int var8;
         int[] ints;
         int k1;
         boolean flag1;
         if (p_matchesProperties_0_.enchantmentIds != null) {
            if (p_matchesProperties_2_ == null) {
               aint = getEnchantmentIdLevels(p_matchesProperties_1_);
            }

            flag1 = false;
            var6 = aint;
            var7 = aint.length;

            for(var8 = 0; var8 < var7; ++var8) {
               ints = var6[var8];
               k1 = ints[0];
               if (p_matchesProperties_0_.enchantmentIds.isInRange(k1)) {
                  flag1 = true;
                  break;
               }
            }

            if (!flag1) {
               return false;
            }
         }

         if (p_matchesProperties_0_.enchantmentLevels != null) {
            if (aint == null) {
               aint = getEnchantmentIdLevels(p_matchesProperties_1_);
            }

            flag1 = false;
            var6 = aint;
            var7 = aint.length;

            for(var8 = 0; var8 < var7; ++var8) {
               ints = var6[var8];
               k1 = ints[1];
               if (p_matchesProperties_0_.enchantmentLevels.isInRange(k1)) {
                  flag1 = true;
                  break;
               }
            }

            if (!flag1) {
               return false;
            }
         }

         if (p_matchesProperties_0_.nbtTagValues != null) {
            NBTTagCompound nbttagcompound = p_matchesProperties_1_.getTagCompound();

            for(int j1 = 0; j1 < p_matchesProperties_0_.nbtTagValues.length; ++j1) {
               jebac_vexial45d4ramrjot nbttagvalue = p_matchesProperties_0_.nbtTagValues[j1];
               if (!nbttagvalue.matches(nbttagcompound)) {
                  return false;
               }
            }
         }

         return true;
      }
   }

   // $FF: synthetic method
   public static void updateModels() {
      if (itemProperties != null) {
         jebac_vexial4zrpld9z8lm[][] var0 = itemProperties;
         int var1 = var0.length;

         for(int var2 = 0; var2 < var1; ++var2) {
            jebac_vexial4zrpld9z8lm[] acustomitemproperties = var0[var2];
            if (acustomitemproperties != null) {
               jebac_vexial4zrpld9z8lm[] var4 = acustomitemproperties;
               int var5 = acustomitemproperties.length;

               for(int var6 = 0; var6 < var5; ++var6) {
                  jebac_vexial4zrpld9z8lm customitemproperties = var4[var6];
                  if (customitemproperties != null && customitemproperties.type == 1) {
                     TextureMap texturemap = Minecraft.getMinecraft().getTextureMapBlocks();
                     customitemproperties.updateModel(texturemap, itemModelGenerator);
                  }
               }
            }
         }
      }

   }

   // $FF: synthetic method
   public static boolean renderCustomEffect(RenderItem p_renderCustomEffect_0_, ItemStack p_renderCustomEffect_1_, IBakedModel p_renderCustomEffect_2_) {
      if (enchantmentProperties == null) {
         return false;
      } else if (p_renderCustomEffect_1_ == null) {
         return false;
      } else {
         int[][] aint = getEnchantmentIdLevels(p_renderCustomEffect_1_);
         if (aint.length <= 0) {
            return false;
         } else {
            Set set = null;
            boolean flag = false;
            TextureManager texturemanager = jebac_vexiakrwecfs16wve.getTextureManager();
            int[][] var7 = aint;
            int var8 = aint.length;

            for(int var9 = 0; var9 < var8; ++var9) {
               int[] ints = var7[var9];
               int j = ints[0];
               if (j >= 0 && j < enchantmentProperties.length) {
                  jebac_vexial4zrpld9z8lm[] acustomitemproperties = enchantmentProperties[j];
                  if (acustomitemproperties != null) {
                     jebac_vexial4zrpld9z8lm[] var13 = acustomitemproperties;
                     int var14 = acustomitemproperties.length;

                     for(int var15 = 0; var15 < var14; ++var15) {
                        jebac_vexial4zrpld9z8lm customitemproperties = var13[var15];
                        if (set == null) {
                           set = new HashSet();
                        }

                        if (set.add(j) && matchesProperties(customitemproperties, p_renderCustomEffect_1_, aint) && customitemproperties.textureLocation != null) {
                           texturemanager.bindTexture(customitemproperties.textureLocation);
                           float f = customitemproperties.getTextureWidth(texturemanager);
                           if (!flag) {
                              flag = true;
                              GlStateManager.depthMask(false);
                              GlStateManager.depthFunc(514);
                              GlStateManager.disableLighting();
                              GlStateManager.matrixMode(5890);
                           }

                           jebac_vexiau5kgy2fm1nlm.setupBlend(customitemproperties.blend, 1.0F);
                           GlStateManager.pushMatrix();
                           GlStateManager.scale(f / 2.0F, f / 2.0F, f / 2.0F);
                           float f1 = customitemproperties.speed * (float)(Minecraft.getSystemTime() % 3000L) / 3000.0F / 8.0F;
                           GlStateManager.translate(f1, 0.0F, 0.0F);
                           GlStateManager.rotate(customitemproperties.rotation, 0.0F, 0.0F, 1.0F);
                           p_renderCustomEffect_0_.renderModel(p_renderCustomEffect_2_, -1);
                           GlStateManager.popMatrix();
                        }
                     }
                  }
               }
            }

            if (flag) {
               GlStateManager.enableAlpha();
               GlStateManager.enableBlend();
               GlStateManager.blendFunc(770, 771);
               GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
               GlStateManager.matrixMode(5888);
               GlStateManager.enableLighting();
               GlStateManager.depthFunc(515);
               GlStateManager.depthMask(true);
               texturemanager.bindTexture(TextureMap.locationBlocksTexture);
            }

            return flag;
         }
      }
   }

   // $FF: synthetic method
   private static jebac_vexial4zrpld9z8lm getCustomItemProperties(ItemStack p_getCustomItemProperties_0_, int p_getCustomItemProperties_1_) {
      if (itemProperties == null) {
         return null;
      } else if (p_getCustomItemProperties_0_ == null) {
         return null;
      } else {
         Item item = p_getCustomItemProperties_0_.getItem();
         int i = Item.getIdFromItem(item);
         if (i >= 0 && i < itemProperties.length) {
            jebac_vexial4zrpld9z8lm[] acustomitemproperties = itemProperties[i];
            if (acustomitemproperties != null) {
               jebac_vexial4zrpld9z8lm[] var5 = acustomitemproperties;
               int var6 = acustomitemproperties.length;

               for(int var7 = 0; var7 < var6; ++var7) {
                  jebac_vexial4zrpld9z8lm customitemproperties = var5[var7];
                  if (customitemproperties.type == p_getCustomItemProperties_1_ && matchesProperties(customitemproperties, p_getCustomItemProperties_0_, (int[][])((int[][])null))) {
                     return customitemproperties;
                  }
               }
            }
         }

         return null;
      }
   }

   // $FF: synthetic method
   private static ResourceLocation getCustomArmorLocation(ItemStack p_getCustomArmorLocation_0_, int p_getCustomArmorLocation_1_, String p_getCustomArmorLocation_2_) {
      jebac_vexial4zrpld9z8lm customitemproperties = getCustomItemProperties(p_getCustomArmorLocation_0_, 3);
      if (customitemproperties == null) {
         return null;
      } else if (customitemproperties.mapTextureLocations == null) {
         return null;
      } else {
         Item item = p_getCustomArmorLocation_0_.getItem();
         if (!(item instanceof ItemArmor)) {
            return null;
         } else {
            ItemArmor itemarmor = (ItemArmor)item;
            String s = itemarmor.getArmorMaterial().getName();
            StringBuffer stringbuffer = new StringBuffer();
            stringbuffer.append("texture.");
            stringbuffer.append(s);
            stringbuffer.append("_layer_");
            stringbuffer.append(p_getCustomArmorLocation_1_);
            if (p_getCustomArmorLocation_2_ != null) {
               stringbuffer.append("_");
               stringbuffer.append(p_getCustomArmorLocation_2_);
            }

            String s1 = stringbuffer.toString();
            ResourceLocation resourcelocation = (ResourceLocation)customitemproperties.mapTextureLocations.get(s1);
            return resourcelocation;
         }
      }
   }

   // $FF: synthetic method
   private static int[][] getEnchantmentIdLevels(ItemStack p_getEnchantmentIdLevels_0_) {
      Item item = p_getEnchantmentIdLevels_0_.getItem();
      NBTTagList nbttaglist = item == Items.enchanted_book ? Items.enchanted_book.getEnchantments(p_getEnchantmentIdLevels_0_) : p_getEnchantmentIdLevels_0_.getEnchantmentTagList();
      if (nbttaglist != null && nbttaglist.tagCount() > 0) {
         int[][] aint = new int[nbttaglist.tagCount()][2];

         for(int i = 0; i < nbttaglist.tagCount(); ++i) {
            NBTTagCompound nbttagcompound = nbttaglist.getCompoundTagAt(i);
            int j = nbttagcompound.getShort("id");
            int k = nbttagcompound.getShort("lvl");
            aint[i][0] = j;
            aint[i][1] = k;
         }

         return aint;
      } else {
         return EMPTY_INT2_ARRAY;
      }
   }
}
