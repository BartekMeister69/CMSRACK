public class jebac_vexia49jpdgvgic0p extends jebac_vexiazrxtvwdcml9w {
   // $FF: synthetic method
   public String getDescriptionText() {
      return jebac_vexiaflhnh80r1906.translate("screen." + this.getName() + ".comment", (String)null);
   }

   // $FF: synthetic method
   public String getNameText() {
      return jebac_vexiaflhnh80r1906.translate("screen." + this.getName(), this.getName());
   }

   // $FF: synthetic method
   public jebac_vexia49jpdgvgic0p(String name) {
      super(name, (String)null, (String)null, new String[]{null}, (String)null, (String)null);
   }
}
