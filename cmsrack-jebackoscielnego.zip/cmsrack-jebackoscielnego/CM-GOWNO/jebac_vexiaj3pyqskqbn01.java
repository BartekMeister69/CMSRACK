import net.minecraft.client.renderer.texture.ITextureObject;

public class jebac_vexiaj3pyqskqbn01 {
   // $FF: synthetic field
   private int textureUnit;
   // $FF: synthetic field
   private String path;
   // $FF: synthetic field
   private ITextureObject texture;

   // $FF: synthetic method
   public String toString() {
      return "textureUnit: " + this.textureUnit + ", path: " + this.path + ", glTextureId: " + this.texture.getGlTextureId();
   }

   // $FF: synthetic method
   public ITextureObject getTexture() {
      return this.texture;
   }

   // $FF: synthetic method
   public String getPath() {
      return this.path;
   }

   // $FF: synthetic method
   jebac_vexiaj3pyqskqbn01(int textureUnit, String path, ITextureObject texture) {
      this.textureUnit = textureUnit;
      this.path = path;
      this.texture = texture;
   }

   // $FF: synthetic method
   int getTextureUnit() {
      return this.textureUnit;
   }
}
