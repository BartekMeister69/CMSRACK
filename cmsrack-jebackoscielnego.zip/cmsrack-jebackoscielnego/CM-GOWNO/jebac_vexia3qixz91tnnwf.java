import java.io.IOException;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.resources.LanguageManager;
import net.minecraft.client.settings.GameSettings;

public class jebac_vexia3qixz91tnnwf extends jebac_vexiakl614w3uw0xg {
   // $FF: synthetic field
   private jebac_vexiatgc7sxy17ln0 confirmSettingsBtn;
   // $FF: synthetic field
   private jebac_vexiatgc7sxy17ln0 forceUnicodeFontBtn;
   // $FF: synthetic field
   protected jebac_vexiakl614w3uw0xg parentScreen;
   // $FF: synthetic field
   private final LanguageManager languageManager;
   // $FF: synthetic field
   private jebac_vexiaoorgt2w16a1c list;
   // $FF: synthetic field
   private final GameSettings game_settings_3;

   static jebac_vexiatgc7sxy17ln0 access$200(jebac_vexia3qixz91tnnwf x0) {
      return x0.confirmSettingsBtn;
   }

   // $FF: synthetic method
   public void initGui() {
      this.buttonList.add(this.forceUnicodeFontBtn = new jebac_vexiatgc7sxy17ln0(100, this.width / 2 - 155, this.height - 38, GameSettings.Options.FORCE_UNICODE_FONT, this.game_settings_3.getKeyBinding(GameSettings.Options.FORCE_UNICODE_FONT)));
      this.buttonList.add(this.confirmSettingsBtn = new jebac_vexiatgc7sxy17ln0(6, this.width / 2 - 155 + 160, this.height - 38, I18n.format("gui.done")));
      this.list = new jebac_vexiaoorgt2w16a1c(this, this.mc);
      this.list.registerScrollButtons(7, 8);
   }

   static jebac_vexiatgc7sxy17ln0 access$300(jebac_vexia3qixz91tnnwf x0) {
      return x0.forceUnicodeFontBtn;
   }

   // $FF: synthetic method
   public void drawScreen(int mouseX, int mouseY, float partialTicks) {
      this.list.drawScreen(mouseX, mouseY, partialTicks);
      this.drawCenteredString(this.fontRendererObj, I18n.format("options.language"), this.width / 2, 16, 16777215);
      this.drawCenteredString(this.fontRendererObj, "(" + I18n.format("options.languageWarning") + ")", this.width / 2, this.height - 56, 8421504);
      super.drawScreen(mouseX, mouseY, partialTicks);
   }

   // $FF: synthetic method
   public jebac_vexia3qixz91tnnwf(jebac_vexiakl614w3uw0xg screen, GameSettings gameSettingsObj, LanguageManager manager) {
      this.parentScreen = screen;
      this.game_settings_3 = gameSettingsObj;
      this.languageManager = manager;
   }

   // $FF: synthetic method
   protected void actionPerformed(jebac_vexia4oibzo50ubf0 button) throws IOException {
      if (button.enabled) {
         switch(button.id) {
         case 5:
            break;
         case 6:
            this.mc.displayGuiScreen(this.parentScreen);
            break;
         case 100:
            if (button instanceof jebac_vexiatgc7sxy17ln0) {
               this.game_settings_3.setOptionValue(((jebac_vexiatgc7sxy17ln0)button).returnEnumOptions(), 1);
               button.displayString = this.game_settings_3.getKeyBinding(GameSettings.Options.FORCE_UNICODE_FONT);
               jebac_vexiakl8zv2fyoaq8 scaledresolution = new jebac_vexiakl8zv2fyoaq8(this.mc);
               int i = scaledresolution.getScaledWidth();
               int j = scaledresolution.getScaledHeight();
               this.setWorldAndResolution(this.mc, i, j);
            }
            break;
         default:
            this.list.actionPerformed(button);
         }
      }

   }

   // $FF: synthetic method
   public void handleMouseInput() throws IOException {
      super.handleMouseInput();
      this.list.handleMouseInput();
   }

   static GameSettings access$100(jebac_vexia3qixz91tnnwf x0) {
      return x0.game_settings_3;
   }

   static LanguageManager access$000(jebac_vexia3qixz91tnnwf x0) {
      return x0.languageManager;
   }
}
