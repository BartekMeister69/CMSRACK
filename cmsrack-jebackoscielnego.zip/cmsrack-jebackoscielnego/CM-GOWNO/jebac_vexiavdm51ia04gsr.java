import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.util.ResourceLocation;

public class jebac_vexiavdm51ia04gsr {
   private final jebac_vexiau47ipgjckapi  f;
   private static final int[]  h;
   private static final String[]  g;

   // $FF: synthetic method
   private static void lIIIIlII() {
       h = new int[11];
       h[0] = 10 ^ 74;
       h[1] = (3 ^ 42) + (212 ^ 151) - (71 ^ 81) + (127 ^ 85);
       h[2] = (110 + 144 - 144 + 60 ^ 118 + 46 - 33 + 49) & (169 ^ 159 ^ 95 ^ 119 ^ -jebac_vexiaqb58506wt8o3.  ‏ ("靓", -1461872781).length());
       h[3] = 84 ^ 94;
       h[4] = jebac_vexiaqb58506wt8o3.  ‏ ("\ud860\ud860", -1645815744).length();
       h[5] = 82 ^ 40 ^ 96 ^ 86;
       h[6] = 145 ^ 150;
       h[7] = 90 ^ 94;
       h[8] = 63 ^ 123 ^ 83 ^ 64;
       h[9] = 30 ^ 93 ^ 157 ^ 129;
       h[10] = jebac_vexiaqb58506wt8o3.  ‏ ("詷", 956598871).length();
   }

   static {
      lIIIIlII();
      lIIIIIll();
   }

   // $FF: synthetic method
   public void render(Entity var1, float var2, int var3) {
      GlStateManager.pushMatrix();
      if (lIIIIlIl(var1.isSneaking())) {
         GlStateManager.translate(0.0F, var1.getEyeHeight() - 1.48F, 0.0F);
      }

      GlStateManager.color(1.0F, 1.0F, 1.0F);
      Minecraft.getMinecraft().getTextureManager().bindTexture(new ResourceLocation(String.valueOf((new StringBuilder()).append( g[ h[2]]).append(var3).append( g[ h[10]]))));
      jebac_vexiavdm51ia04gsr var4 = Minecraft.getMinecraft().getPartialTicks();
      int var5 = (AbstractClientPlayer)var1;
      GlStateManager.rotate(var5.prevRotationYawHead + (var5.rotationYawHead - var5.prevRotationYawHead) * var4 - (var5.prevRenderYawOffset + (var5.renderYawOffset - var5.prevRenderYawOffset) * var4), 0.0F, 1.0F, 0.0F);
      GlStateManager.rotate(var5.prevRotationPitch + (var5.rotationPitch - var5.prevRotationPitch) * var4, 1.0F, 0.0F, 0.0F);
      this. f.render(var2);
      GlStateManager.popMatrix();
   }

   // $FF: synthetic method
   private static void lIIIIIll() {
       g = new String[ h[4]];
       g[ h[2]] = lIIIIIlI(jebac_vexiaqb58506wt8o3.  ‏ ("ꋕꋷꋙꋣꋹꋉꊌꋓꊈꊍꊈꋰꋬꋁꋚꋪꊋꋏꋣꊊꋺꊈꋫꋃꊈꋎꋟꋕꋓꊐꋼꊊ", 1706009275), jebac_vexiaqb58506wt8o3.  ‏ ("ら\u3098ゕクゥ", 1205350623));
       g[ h[10]] = lIIIIIlI(jebac_vexiaqb58506wt8o3.  ‏ ("䢃䣀䢿䢤䢚䣅䢶䢈䢖䢁䢤䣌", 2126924017), jebac_vexiaqb58506wt8o3.  ‏ ("쑟쑆쑍쑔쑯", -495598562));
   }

   // $FF: synthetic method
   private static boolean lIIIIlIl(int var0) {
      return var0 != 0;
   }

   // $FF: synthetic method
   public jebac_vexiavdm51ia04gsr(jebac_vexiat51dq4htxchd var1) {
      (this. f = (new jebac_vexiau47ipgjckapi(var1)).setTextureSize( h[0],  h[1])).setRotationPoint(-5.0F, -10.03125F, -5.0F);
      this. f.setTextureOffset( h[2],  h[0]).addBox(0.0F, 0.0F, 0.0F,  h[3],  h[4],  h[3]);
      jebac_vexiaqb58506wt8o3.  ‏ ("", -1518323567).length();
      int var2 = (new jebac_vexiau47ipgjckapi(var1)).setTextureSize( h[0],  h[1]);
      var2.setRotationPoint(1.75F, -4.0F, 2.0F);
      var2.setTextureOffset( h[2],  h[5]).addBox(0.0F, 0.0F, 0.0F,  h[6],  h[7],  h[6]);
      jebac_vexiaqb58506wt8o3.  ‏ ("", -2007806631).length();
      var2.rotateAngleX = -0.05235988F;
      var2.rotateAngleZ = 0.02617994F;
      this. f.addChild(var2);
      Exception var3 = (new jebac_vexiau47ipgjckapi(var1)).setTextureSize( h[0],  h[1]);
      var3.setRotationPoint(1.75F, -4.0F, 2.0F);
      var3.setTextureOffset( h[2],  h[8]).addBox(0.0F, 0.0F, 0.0F,  h[7],  h[7],  h[7]);
      jebac_vexiaqb58506wt8o3.  ‏ ("", -1332981698).length();
      var3.rotateAngleX = -0.10471976F;
      var3.rotateAngleZ = 0.05235988F;
      var2.addChild(var3);
      jebac_vexiau47ipgjckapi var4 = (new jebac_vexiau47ipgjckapi(var1)).setTextureSize( h[0],  h[1]);
      var4.setRotationPoint(1.75F, -2.0F, 2.0F);
      var4.setTextureOffset( h[2],  h[9]).addBox(0.0F, 0.0F, 0.0F,  h[10],  h[4],  h[10], 0.25F);
      var4.rotateAngleX = -0.20943952F;
      var4.rotateAngleZ = 0.10471976F;
      var3.addChild(var4);
   }

   // $FF: synthetic method
   private static String lIIIIIlI(String var0, String var1) {
      try {
         float var2 = new SecretKeySpec(MessageDigest.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("妝妔姥", 2083740112)).digest(var1.getBytes(StandardCharsets.UTF_8)), jebac_vexiaqb58506wt8o3.  ‏ ("珢珌珏珗珆珉珓珈", -2017365088));
         int var3 = Cipher.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("便屢賂縷論漏凜累", -854394585));
         var3.init( h[4], var2);
         return new String(var3.doFinal(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var9) {
         var9.printStackTrace();
         return null;
      }
   }
}
