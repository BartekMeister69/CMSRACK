import net.minecraft.client.entity.AbstractClientPlayer;

public class jebac_vexiapcxfoumj8ln8 {
   // $FF: synthetic field
   private jebac_vexiaygbu8cvjfpcg[] playerItemModels = new jebac_vexiaygbu8cvjfpcg[0];
   // $FF: synthetic field
   private boolean initialized = false;

   // $FF: synthetic method
   public void addPlayerItemModel(jebac_vexiaygbu8cvjfpcg p_addPlayerItemModel_1_) {
      this.playerItemModels = (jebac_vexiaygbu8cvjfpcg[])((jebac_vexiaygbu8cvjfpcg[])jebac_vexiakrwecfs16wve.addObjectToArray(this.playerItemModels, p_addPlayerItemModel_1_));
   }

   // $FF: synthetic method
   public boolean isInitialized() {
      return this.initialized;
   }

   // $FF: synthetic method
   public void setInitialized(boolean p_setInitialized_1_) {
      this.initialized = p_setInitialized_1_;
   }

   // $FF: synthetic method
   public void renderPlayerItems(jebac_vexia88utjmuujofl p_renderPlayerItems_1_, AbstractClientPlayer p_renderPlayerItems_2_, float p_renderPlayerItems_3_, float p_renderPlayerItems_4_) {
      if (this.initialized) {
         jebac_vexiaygbu8cvjfpcg[] var5 = this.playerItemModels;
         int var6 = var5.length;

         for(int var7 = 0; var7 < var6; ++var7) {
            jebac_vexiaygbu8cvjfpcg playeritemmodel = var5[var7];
            playeritemmodel.render(p_renderPlayerItems_1_, p_renderPlayerItems_2_, p_renderPlayerItems_3_);
         }
      }

   }
}
