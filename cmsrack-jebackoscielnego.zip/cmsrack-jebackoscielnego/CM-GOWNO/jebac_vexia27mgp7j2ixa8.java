import java.awt.Color;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

public class jebac_vexia27mgp7j2ixa8 {
   private final String[]  df;
   private static final int[]  dg;
   private final int  dd;
   private final int  da;
   private double  dj;
   private long  de;
   private final ArrayDeque  dh;
   private boolean  db;
   private final int  cz;
   private int  dc;
   private static final String[]  di;

   // $FF: synthetic method
   private int getCPS() {
      jebac_vexia27mgp7j2ixa8 var1 = System.currentTimeMillis();
      long var3 = var1 - 1000L;
      long var5 = var1 + 1000L;

      while(lIIllIlI(this. dh.isEmpty())) {
         long var7 = (Long)this. dh.peek();
         if (lIIllIll(lIIllIIl(var7, var3)) && !lIIlllII(lIIllIIl(var7, var5))) {
            break;
         }

         this. dh.poll();
         jebac_vexiaqb58506wt8o3.  ‏ ("", -902881243).length();
         jebac_vexiaqb58506wt8o3.  ‏ ("", 586215099).length();
         if (jebac_vexiaqb58506wt8o3.  ‏ ("䒏䒏䒏", 1797670063).length() == 0) {
            return (125 + 70 - 166 + 102 ^ 120 + 48 - 140 + 134) & (161 + 131 - 140 + 10 ^ 76 + 75 - 26 + 6 ^ -jebac_vexiaqb58506wt8o3.  ‏ ("鶁", 484941217).length());
         }
      }

      return this. dh.size();
   }

   // $FF: synthetic method
   public void render(int var1, int var2, Color var3) {
      byte var4 = Mouse.isButtonDown(this. dd);
      int var5 = this. df[this. dd];
      if (lIIlllIl(var4, this. db)) {
         this. db = (boolean)var4;
         this. de = System.currentTimeMillis();
         if (lIIllllI(var4)) {
            this. dh.add(this. de);
            jebac_vexiaqb58506wt8o3.  ‏ ("", -1511894024).length();
         }
      }

      if (lIIllllI(var4)) {
         this. dc = Math.min( dg[3], (int)(2L * (System.currentTimeMillis() - this. de)));
         this. dj = Math.max(0.0D, 1.0D - (double)(System.currentTimeMillis() - this. de) / 20.0D);
         jebac_vexiaqb58506wt8o3.  ‏ ("", 1352668287).length();
         if (((94 ^ 3) & ~(7 ^ 90)) != 0) {
            return;
         }
      } else {
         this. dc = Math.max( dg[1],  dg[3] - (int)(2L * (System.currentTimeMillis() - this. de)));
         this. dj = Math.min(1.0D, (double)(System.currentTimeMillis() - this. de) / 20.0D);
      }

      int var10000 = var1 + this. cz;
      int var10001 = var2 + this. da;
      int var10002 = var1 + this. cz +  dg[4];
      int var10003 = var2 + this. da;
      int var10004;
      if (lIIllllI(jebac_vexiaau3mg1q92fzj. dy. jp)) {
         var10004 =  dg[5];
         jebac_vexiaqb58506wt8o3.  ‏ ("", -2062747060).length();
         if (jebac_vexiaqb58506wt8o3.  ‏ ("톪", 858116490).length() < -jebac_vexiaqb58506wt8o3.  ‏ ("\ueaf9", -1210651943).length()) {
            return;
         }
      } else {
         var10004 =  dg[6];
      }

      jebac_vexiabhi02xzapwrh.drawRect(var10000, var10001, var10002, var10003 + var10004,  dg[7] + (this. dc <<  dg[6]) + (this. dc <<  dg[8]) + this. dc);
      String var6 = var3.getRed();
      String var7 = var3.getGreen();
      jebac_vexia27mgp7j2ixa8 var8 = var3.getBlue();
      var10002 = var1 + this. cz +  dg[8];
      var10003 = var2 + this. da +  dg[9];
      var10004 =  dg[10] + ((int)((double)var6 * this. dj) <<  dg[6]) + ((int)((double)var7 * this. dj) <<  dg[8]);
      int var10005 = (int)((double)var8 * this. dj);
      Minecraft.getMinecraft().fontRendererObj.drawString(var5, var10002, var10003, var10004 + var10005);
      jebac_vexiaqb58506wt8o3.  ‏ ("", -133974591).length();
      String var9 = String.valueOf((new StringBuilder()).append(this.getCPS()).append( di[ dg[0]]));
      float var10 = Minecraft.getMinecraft().fontRendererObj.getStringWidth(var9);
      GL11.glScalef(0.5F, 0.5F, 0.5F);
      if (lIIllllI(jebac_vexiaau3mg1q92fzj. dy. jp)) {
         var10002 = (var1 + this. cz +  dg[11]) *  dg[0] - var10 /  dg[0];
         var10003 = (var2 + this. da +  dg[12]) *  dg[0];
         var10004 =  dg[10] + ((int)(255.0D * this. dj) <<  dg[6]) + ((int)(255.0D * this. dj) <<  dg[8]);
         Minecraft.getMinecraft().fontRendererObj.drawString(var9, var10002, var10003, var10004 + (int)(255.0D * this. dj));
         jebac_vexiaqb58506wt8o3.  ‏ ("", -685543620).length();
      }

      GL11.glScalef(2.0F, 2.0F, 2.0F);
   }

   // $FF: synthetic method
   private static void lIIllIII() {
       dg = new int[14];
       dg[0] = jebac_vexiaqb58506wt8o3.  ‏ ("썰썰", 645907280).length();
       dg[1] = (180 ^ 138 ^ 235 ^ 133) & (24 ^ 73 ^ jebac_vexiaqb58506wt8o3.  ‏ ("궟", 632729023).length() ^ -jebac_vexiaqb58506wt8o3.  ‏ ("ｂ", -475267230).length());
       dg[2] = jebac_vexiaqb58506wt8o3.  ‏ ("쐥", -1944730619).length();
       dg[3] = (114 ^ 25) + 108 + 108 - 94 + 16 - (200 ^ 176) + 44 + 77 - 107 + 116;
       dg[4] = 7 ^ 37;
       dg[5] = 59 + 46 - 101 + 138 ^ 1 + 104 - -22 + 25;
       dg[6] = 96 + 211 - 277 + 185 ^ 4 + 132 - 42 + 105;
       dg[7] = -6540 & 2013272459;
       dg[8] = 197 ^ 128 ^ 49 ^ 124;
       dg[9] = 21 ^ 17;
       dg[10] = -(-14018 & 16791233);
       dg[11] = 45 ^ 76 ^ 98 ^ 18;
       dg[12] = (204 ^ 193) & ~(75 ^ 70) ^ 141 ^ 131;
       dg[13] = jebac_vexiaqb58506wt8o3.  ‏ ("ᡆᡆᡆ", -1310451610).length();
   }

   // $FF: synthetic method
   private static boolean lIIllIlI(int var0) {
      return var0 == 0;
   }

   // $FF: synthetic method
   private static String lIIlIlIl(String var0, String var1) {
      try {
         SecretKeySpec var2 = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("辀辉迸", 71143373)).digest(var1.getBytes(StandardCharsets.UTF_8)),  dg[8]), jebac_vexiaqb58506wt8o3.  ‏ ("䵀䵁䵗", -628142844));
         float var3 = Cipher.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("噍噌噚", 1905350153));
         var3.init( dg[0], var2);
         return new String(var3.doFinal(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var9) {
         var9.printStackTrace();
         return null;
      }
   }

   // $FF: synthetic method
   private static boolean lIIllllI(int var0) {
      return var0 != 0;
   }

   // $FF: synthetic method
   private static boolean lIIlllII(int var0) {
      return var0 > 0;
   }

   // $FF: synthetic method
   private static void lIIlIlll() {
       di = new String[ dg[13]];
       di[ dg[1]] = lIIlIlII(jebac_vexiaqb58506wt8o3.  ‏ ("\uf415\uf430\uf41a\uf42b\uf40d\uf46f\uf40c\uf40b\uf40c\uf40e\uf408\uf464", -596315047), jebac_vexiaqb58506wt8o3.  ‏ ("鄈鄀鄕鄐鄶", 987861370));
       di[ dg[2]] = lIIlIlIl(jebac_vexiaqb58506wt8o3.  ‏ ("뇻놭놂농놇놾놃뇽놚놌놥뇷", 990425546), jebac_vexiaqb58506wt8o3.  ‏ ("扬扥扞扴扈", -1631690177));
       di[ dg[0]] = lIIlIllI(jebac_vexiaqb58506wt8o3.  ‏ ("鑿鑷鑷鑡鑠鑁鐛鐛", 1792578598), jebac_vexiaqb58506wt8o3.  ‏ ("\uf7ff\uf7f9\uf7e8\uf7fb\uf7f2", 971110334));
   }

   // $FF: synthetic method
   private static boolean lIIllIll(int var0) {
      return var0 >= 0;
   }

   static {
      lIIllIII();
      lIIlIlll();
   }

   // $FF: synthetic method
   private static boolean lIIlllll(int var0, int var1) {
      return var0 < var1;
   }

   // $FF: synthetic method
   jebac_vexia27mgp7j2ixa8(int var1, int var2, int var3) {
      String[] var10001 = new String[ dg[0]];
      var10001[ dg[1]] =  di[ dg[1]];
      var10001[ dg[2]] =  di[ dg[2]];
      this. df = var10001;
      this. dd = var1;
      this. cz = var2;
      this. da = var3;
      this. dh = new ArrayDeque();
      this. db = (boolean) dg[2];
      this. de = 0L;
      this. dc =  dg[3];
      this. dj = 1.0D;
   }

   // $FF: synthetic method
   private static boolean lIIlllIl(int var0, int var1) {
      return var0 != var1;
   }

   // $FF: synthetic method
   private static int lIIllIIl(long var0, long var2) {
      long var4;
      return (var4 = var0 - var2) == 0L ? 0 : (var4 < 0L ? -1 : 1);
   }

   // $FF: synthetic method
   private static String lIIlIllI(String var0, String var1) {
      var0 = new String(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      byte var2 = new StringBuilder();
      long var3 = var1.toCharArray();
      byte var4 =  dg[1];
      Exception var5 = var0.toCharArray();
      byte var6 = var5.length;
      int var7 =  dg[1];

      do {
         if (!lIIlllll(var7, var6)) {
            return String.valueOf(var2);
         }

         int var8 = var5[var7];
         var2.append((char)(var8 ^ var3[var4 % var3.length]));
         jebac_vexiaqb58506wt8o3.  ‏ ("", -2006370361).length();
         ++var4;
         ++var7;
         jebac_vexiaqb58506wt8o3.  ‏ ("", 678948870).length();
      } while(((250 ^ 188 ^ 225 ^ 159) & (198 + 4 - 143 + 189 ^ 17 + 113 - 64 + 126 ^ -jebac_vexiaqb58506wt8o3.  ‏ ("⾄", 230764452).length())) == 0);

      return null;
   }

   // $FF: synthetic method
   private static String lIIlIlII(String var0, String var1) {
      try {
         String var2 = new SecretKeySpec(MessageDigest.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("\udad8\udad1\udaa0", 195418773)).digest(var1.getBytes(StandardCharsets.UTF_8)), jebac_vexiaqb58506wt8o3.  ‏ ("㤟㤱㤲㤪㤻㤴㤮㤵", 1064843613));
         SecretKeySpec var3 = Cipher.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("샫샅샆샞샏샀샚상", 1352450217));
         var3.init( dg[0], var2);
         return new String(var3.doFinal(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var9) {
         var9.printStackTrace();
         return null;
      }
   }
}
