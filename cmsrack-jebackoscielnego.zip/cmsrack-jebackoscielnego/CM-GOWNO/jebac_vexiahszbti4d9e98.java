import net.minecraft.client.Minecraft;

public class jebac_vexiahszbti4d9e98 extends Thread {
   // $FF: synthetic field
   private jebac_vexiae21v1yzd8ma8 listener = null;
   // $FF: synthetic field
   private String urlString = null;

   // $FF: synthetic method
   public jebac_vexiae21v1yzd8ma8 getListener() {
      return this.listener;
   }

   // $FF: synthetic method
   public jebac_vexiahszbti4d9e98(String p_i41_1_, jebac_vexiae21v1yzd8ma8 p_i41_2_) {
      this.urlString = p_i41_1_;
      this.listener = p_i41_2_;
   }

   // $FF: synthetic method
   public void run() {
      try {
         byte[] abyte = jebac_vexia7dtg4ljk048p.get(this.urlString, Minecraft.getMinecraft().getProxy());
         this.listener.fileDownloadFinished(this.urlString, abyte, (Throwable)null);
      } catch (Exception var2) {
         this.listener.fileDownloadFinished(this.urlString, (byte[])null, var2);
      }

   }
}
