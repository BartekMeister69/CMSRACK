import java.io.IOException;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.resources.I18n;

public class jebac_vexia4dh8b3zbbuiq extends jebac_vexiakl614w3uw0xg {
   // $FF: synthetic field
   private int field_146444_f;
   // $FF: synthetic field
   private int field_146445_a;

   // $FF: synthetic method
   protected void actionPerformed(jebac_vexia4oibzo50ubf0 button) throws IOException {
      switch(button.id) {
      case 0:
         this.mc.displayGuiScreen(new jebac_vexiap2nws6jqswjc(this, this.mc.gameSettings));
         break;
      case 1:
         boolean flag = this.mc.isIntegratedServerRunning();
         button.enabled = false;
         this.mc.theWorld.sendQuittingDisconnectingPacket();
         this.mc.loadWorld((WorldClient)null);
         if (flag) {
            this.mc.displayGuiScreen(new jebac_vexiajsj9h47ef5xh());
         } else {
            this.mc.displayGuiScreen(new jebac_vexiaqgfx58baqzsf(new jebac_vexiajsj9h47ef5xh()));
         }
      case 2:
      case 3:
      default:
         break;
      case 4:
         this.mc.displayGuiScreen((jebac_vexiakl614w3uw0xg)null);
         this.mc.setIngameFocus();
         break;
      case 5:
         this.mc.displayGuiScreen(new jebac_vexiamzwb6k9tn3vk(this, this.mc.thePlayer.getStatFileWriter()));
         break;
      case 6:
         this.mc.displayGuiScreen(new jebac_vexiazwfkkk4iev4c(this, this.mc.thePlayer.getStatFileWriter()));
         break;
      case 7:
         this.mc.displayGuiScreen(new jebac_vexia6qud5d4vka5c(this));
      }

   }

   // $FF: synthetic method
   public void drawScreen(int mouseX, int mouseY, float partialTicks) {
      this.drawDefaultBackground();
      this.drawCenteredString(this.fontRendererObj, I18n.format("menu.game"), this.width / 2, 40, 16777215);
      super.drawScreen(mouseX, mouseY, partialTicks);
   }

   // $FF: synthetic method
   public void initGui() {
      this.field_146445_a = 0;
      this.buttonList.clear();
      int i = -16;
      int j = true;
      this.buttonList.add(new jebac_vexia4oibzo50ubf0(1, this.width / 2 - 100, this.height / 4 + 120 + i, I18n.format("menu.returnToMenu")));
      if (!this.mc.isIntegratedServerRunning()) {
         ((jebac_vexia4oibzo50ubf0)this.buttonList.get(0)).displayString = I18n.format("menu.disconnect");
      }

      this.buttonList.add(new jebac_vexia4oibzo50ubf0(4, this.width / 2 - 100, this.height / 4 + 24 + i, I18n.format("menu.returnToGame")));
      this.buttonList.add(new jebac_vexia4oibzo50ubf0(0, this.width / 2 - 100, this.height / 4 + 96 + i, 98, 20, I18n.format("menu.options")));
      jebac_vexia4oibzo50ubf0 guibutton;
      this.buttonList.add(guibutton = new jebac_vexia4oibzo50ubf0(7, this.width / 2 + 2, this.height / 4 + 96 + i, 98, 20, I18n.format("menu.shareToLan")));
      this.buttonList.add(new jebac_vexia4oibzo50ubf0(5, this.width / 2 - 100, this.height / 4 + 48 + i, 98, 20, I18n.format("gui.achievements")));
      this.buttonList.add(new jebac_vexia4oibzo50ubf0(6, this.width / 2 + 2, this.height / 4 + 48 + i, 98, 20, I18n.format("gui.stats")));
      guibutton.enabled = this.mc.isSingleplayer() && !this.mc.getIntegratedServer().getPublic();
   }

   // $FF: synthetic method
   public void updateScreen() {
      super.updateScreen();
      ++this.field_146444_f;
   }
}
