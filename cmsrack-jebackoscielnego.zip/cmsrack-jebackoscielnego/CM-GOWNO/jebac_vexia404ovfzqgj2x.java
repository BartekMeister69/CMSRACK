import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;

public class jebac_vexia404ovfzqgj2x implements jebac_vexia68uke90d57nv {
   private final jebac_vexiakl614w3uw0xg  cl;
   private final jebac_vexia4oibzo50ubf0  cj;
   private static final String[]  ck;
   private final jebac_vexia4oibzo50ubf0  ci;
   private static final int[]  cm;
   private final Minecraft  cn;

   // $FF: synthetic method
   private static void lIIIIllII() {
       cm = new int[9];
       cm[0] = (199 ^ 132 ^ 247 ^ 172) & (94 + 10 - -8 + 44 ^ 16 + 104 - 73 + 85 ^ -jebac_vexiaqb58506wt8o3.  ‏ ("噗", -1081846153).length());
       cm[1] = jebac_vexiaqb58506wt8o3.  ‏ ("吝", 1332433981).length();
       cm[2] = jebac_vexiaqb58506wt8o3.  ‏ ("璱璱", 574583953).length();
       cm[3] = jebac_vexiaqb58506wt8o3.  ‏ ("ຑຑຑ", -796258639).length();
       cm[4] = 5 ^ 1;
       cm[5] = 168 ^ 149 ^ 151 ^ 175;
       cm[6] = 40 ^ 46;
       cm[7] = 115 ^ 116;
       cm[8] = 232 ^ 168 ^ 23 ^ 95;
   }

   // $FF: synthetic method
   jebac_vexia404ovfzqgj2x(Minecraft var1, jebac_vexiakl614w3uw0xg var2, jebac_vexia4oibzo50ubf0 var3, jebac_vexia4oibzo50ubf0 var4) {
      this. cn = var1;
      this. cl = var2;
      this. ci = var3;
      this. cj = var4;
   }

   // $FF: synthetic method
   private static boolean lIIIIlllI(int var0) {
      return var0 != 0;
   }

   // $FF: synthetic method
   public void setSelected(int var1, int var2, int var3) {
   }

   // $FF: synthetic method
   public void drawEntry(int var1, int var2, int var3, int var4, int var5, int var6, int var7, boolean var8) {
      if (lIIIIllIl(this. ci)) {
         this. ci.yPosition = var3;
         this. ci.drawButton(this. cn, var6, var7);
      }

      if (lIIIIllIl(this. cj)) {
         this. cj.yPosition = var3;
         this. cj.drawButton(this. cn, var6, var7);
      }

   }

   // $FF: synthetic method
   private static boolean lIIIIllll(Object var0, Object var1) {
      return var0 == var1;
   }

   // $FF: synthetic method
   private static String lllllIll(String var0, String var1) {
      try {
         SecretKeySpec var2 = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("\uf2b4\uf2bd\uf2cc", -1669074183)).digest(var1.getBytes(StandardCharsets.UTF_8)),  cm[8]), jebac_vexiaqb58506wt8o3.  ‏ ("쵹쵸쵮", -1863463619));
         String var3 = Cipher.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("\ue989\ue988\ue99e", 1349577165));
         var3.init( cm[2], var2);
         return new String(var3.doFinal(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var9) {
         var9.printStackTrace();
         return null;
      }
   }

   // $FF: synthetic method
   private static String lllllIII(String var0, String var1) {
      try {
         SecretKeySpec var2 = new SecretKeySpec(MessageDigest.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("꯭ꯤꮕ", -1880904800)).digest(var1.getBytes(StandardCharsets.UTF_8)), jebac_vexiaqb58506wt8o3.  ‏ ("헝헳헰헨헹헶헬헷", -880814689));
         int var3 = Cipher.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("䌓䌽䌾䌦䌷䌸䌢䌹", 1714307921));
         var3.init( cm[2], var2);
         return new String(var3.doFinal(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var9) {
         var9.printStackTrace();
         return null;
      }
   }

   // $FF: synthetic method
   private void actionPerformed(jebac_vexia4oibzo50ubf0 var1) {
      short var2 = (jebac_vexia3mso3ea3nx6y)var1;
      jebac_vexiatj0yt8p6od53 var3 = var2.getEnum();
      if (lIIIIlllI(var3.isBoolean())) {
         jebac_vexiaagw19xxuzm2q.setValue(var3);
         jebac_vexiaqb58506wt8o3.  ‏ ("", 400005662).length();
         if (((84 + 207 - 145 + 81 ^ 96 + 95 - 184 + 177) & (65 + 105 - -41 + 36 ^ 0 + 49 - 24 + 147 ^ -jebac_vexiaqb58506wt8o3.  ‏ ("玑", 161575857).length())) != 0) {
            return;
         }
      } else {
         jebac_vexiaagw19xxuzm2q.performAction(this. cn, this. cl, var3);
      }

      StringBuilder var10001 = (new StringBuilder()).append(var3.getName());
      String var10002;
      if (lIIIIlllI(var3.isBoolean())) {
         if (lIIIIlllI(jebac_vexiaagw19xxuzm2q.getValue(var3))) {
            var10002 =  ck[ cm[0]];
            jebac_vexiaqb58506wt8o3.  ‏ ("", -1279786325).length();
            if (jebac_vexiaqb58506wt8o3.  ‏ ("鮁鮁鮁", -1684235359).length() < jebac_vexiaqb58506wt8o3.  ‏ ("逜逜", -410611652).length()) {
               return;
            }
         } else {
            var10002 =  ck[ cm[1]];
            jebac_vexiaqb58506wt8o3.  ‏ ("", -1739917291).length();
            if (-jebac_vexiaqb58506wt8o3.  ‏ ("燯燯", 943354319).length() >= 0) {
               return;
            }
         }
      } else if (lIIIIllll(var3, jebac_vexiatj0yt8p6od53. hb)) {
         if (lIIIIlllI(jebac_vexiawzpzy1x3sez8. bj.equals( ck[ cm[2]]))) {
            var10002 =  ck[ cm[3]];
            jebac_vexiaqb58506wt8o3.  ‏ ("", -689212319).length();
            if (null != null) {
               return;
            }
         } else {
            var10002 =  ck[ cm[4]];
            jebac_vexiaqb58506wt8o3.  ‏ ("", 297304306).length();
            if (((6 ^ 80) & ~(207 ^ 153)) != 0) {
               return;
            }
         }
      } else if (lIIIIllll(var3, jebac_vexiatj0yt8p6od53. gz)) {
         if (lIIIIlllI(jebac_vexiaagw19xxuzm2q.getValue(var3))) {
            var10002 =  ck[ cm[5]];
            jebac_vexiaqb58506wt8o3.  ‏ ("", 4460638).length();
            if (null != null) {
               return;
            }
         } else {
            var10002 =  ck[ cm[6]];
            jebac_vexiaqb58506wt8o3.  ‏ ("", 1032755775).length();
            if (-jebac_vexiaqb58506wt8o3.  ‏ ("䟩䟩䟩", 383731657).length() > 0) {
               return;
            }
         }
      } else {
         var10002 =  ck[ cm[7]];
      }

      var1.displayString = String.valueOf(var10001.append(var10002));
      var1.playPressSound(this. cn.getSoundHandler());
   }

   // $FF: synthetic method
   private static boolean lIIIlIIII(int var0, int var1) {
      return var0 < var1;
   }

   // $FF: synthetic method
   public boolean mousePressed(int var1, int var2, int var3, int var4, int var5, int var6) {
      if (lIIIIlllI(this. ci.mousePressed(this. cn, var2, var3))) {
         this.actionPerformed(this. ci);
         return (boolean) cm[1];
      } else if (lIIIIllIl(this. cj) && lIIIIlllI(this. cj.mousePressed(this. cn, var2, var3))) {
         this.actionPerformed(this. cj);
         return (boolean) cm[1];
      } else {
         return (boolean) cm[0];
      }
   }

   // $FF: synthetic method
   private static boolean lIIIIllIl(Object var0) {
      return var0 != null;
   }

   static {
      lIIIIllII();
      llllllll();
   }

   // $FF: synthetic method
   private static String lllllIlI(String var0, String var1) {
      var0 = new String(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      String var2 = new StringBuilder();
      char[] var3 = var1.toCharArray();
      Exception var4 =  cm[0];
      char[] var5 = var0.toCharArray();
      char[] var6 = var5.length;
      int var7 =  cm[0];

      do {
         if (!lIIIlIIII(var7, var6)) {
            return String.valueOf(var2);
         }

         double var8 = var5[var7];
         var2.append((char)(var8 ^ var3[var4 % var3.length]));
         jebac_vexiaqb58506wt8o3.  ‏ ("", -1602664994).length();
         ++var4;
         ++var7;
         jebac_vexiaqb58506wt8o3.  ‏ ("", -1044767163).length();
      } while(jebac_vexiaqb58506wt8o3.  ‏ ("ꠁ", 159098913).length() < jebac_vexiaqb58506wt8o3.  ‏ ("\ue17f\ue17f\ue17f", -925703841).length());

      return null;
   }

   // $FF: synthetic method
   public void mouseReleased(int var1, int var2, int var3, int var4, int var5, int var6) {
      if (lIIIIllIl(this. ci)) {
         this. ci.mouseReleased(var2, var3);
      }

      if (lIIIIllIl(this. cj)) {
         this. cj.mouseReleased(var2, var3);
      }

   }

   // $FF: synthetic method
   private static void llllllll() {
       ck = new String[ cm[8]];
       ck[ cm[0]] = lllllIII(jebac_vexiaqb58506wt8o3.  ‏ ("ᾯᾑᾺᾅᾊᾄᾇᾪᾨᾬᾄῖ", 1524703211), jebac_vexiaqb58506wt8o3.  ‏ ("̸̧̘̓̔", -403111042));
       ck[ cm[1]] = lllllIlI(jebac_vexiaqb58506wt8o3.  ‏ ("\ue3d0\ue393\ue3d0\ue3d7\ue3f7\ue3e4\ue3c8\ue3cd", 925295527), jebac_vexiaqb58506wt8o3.  ‏ ("ⰽⰜⰤⰵⰰ", 329919574));
       ck[ cm[2]] = lllllIll(jebac_vexiaqb58506wt8o3.  ‏ ("纜绨纝绘绑纟绀续绁绂绳绲织纀绤绪绘绦绦绁绁绂练纚给绂绬结绠绣绠绝终绲绑给绁纟绌纘绦织络纖", 367361707), jebac_vexiaqb58506wt8o3.  ‏ ("眚省眗眜眰", -328894607));
       ck[ cm[3]] = lllllIll(jebac_vexiaqb58506wt8o3.  ‏ ("딠딿딸딤땑땣땳땪땥땨땆딶", -1458522869), jebac_vexiaqb58506wt8o3.  ‏ ("ﴅﴺﴯﴐﴧ", 637205865));
       ck[ cm[4]] = lllllIII(jebac_vexiaqb58506wt8o3.  ‏ ("鮕鮴鮟鮁鮾鮳鮌鮶鯫鮈鮂鮽鮊鯷鮵鯯鮻鮻鮝鮲鮮鮯鯥鯥", -1136485416), jebac_vexiaqb58506wt8o3.  ‏ ("蟷蟃蟡蟽蟘", -433944684));
       ck[ cm[5]] = lllllIII(jebac_vexiaqb58506wt8o3.  ‏ ("\uf5b8\uf5bb\uf5bd\uf586\uf58b\uf5b9\uf59a\uf59a\uf5b8\uf5b4\uf5bd\uf5c1", 2082600444), jebac_vexiaqb58506wt8o3.  ‏ ("虧虁虵虎虢", -467237338));
       ck[ cm[6]] = lllllIll(jebac_vexiaqb58506wt8o3.  ‏ ("軨軭軪躝軧軆軾軡軈軓軮躖", 1908903595), jebac_vexiaqb58506wt8o3.  ‏ ("螘螵螄螘螓", 1552123874));
       ck[ cm[7]] = lllllIll(jebac_vexiaqb58506wt8o3.  ‏ ("캁캆컦캀커캚캚캅캪캝컧컮", -1106260269), jebac_vexiaqb58506wt8o3.  ‏ ("ᱽᱝᱝᱏ᱄", 897457182));
   }
}
