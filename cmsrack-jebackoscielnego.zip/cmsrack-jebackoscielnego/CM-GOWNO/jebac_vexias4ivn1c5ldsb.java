public class jebac_vexias4ivn1c5ldsb {
   // $FF: synthetic field
   private int min;
   // $FF: synthetic field
   private int max;

   // $FF: synthetic method
   public int getMin() {
      return this.min;
   }

   // $FF: synthetic method
   public jebac_vexias4ivn1c5ldsb(int p_i80_1_, int p_i80_2_) {
      this.min = Math.min(p_i80_1_, p_i80_2_);
      this.max = Math.max(p_i80_1_, p_i80_2_);
   }

   // $FF: synthetic method
   public String toString() {
      return "min: " + this.min + ", max: " + this.max;
   }

   // $FF: synthetic method
   public boolean isInRange(int p_isInRange_1_) {
      return p_isInRange_1_ >= this.min && p_isInRange_1_ <= this.max;
   }

   // $FF: synthetic method
   public int getMax() {
      return this.max;
   }
}
