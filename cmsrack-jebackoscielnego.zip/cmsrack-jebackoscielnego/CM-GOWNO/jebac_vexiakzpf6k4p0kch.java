public class jebac_vexiakzpf6k4p0kch {
   // $FF: synthetic field
   private jebac_vexiaknlf2gexq698 httpListener = null;
   // $FF: synthetic field
   private jebac_vexiahtrnwedo9ob6 httpRequest = null;
   // $FF: synthetic field
   private boolean closed = false;

   // $FF: synthetic method
   public void setClosed(boolean p_setClosed_1_) {
      this.closed = p_setClosed_1_;
   }

   // $FF: synthetic method
   public boolean isClosed() {
      return this.closed;
   }

   // $FF: synthetic method
   public jebac_vexiakzpf6k4p0kch(jebac_vexiahtrnwedo9ob6 p_i58_1_, jebac_vexiaknlf2gexq698 p_i58_2_) {
      this.httpRequest = p_i58_1_;
      this.httpListener = p_i58_2_;
   }

   // $FF: synthetic method
   public jebac_vexiaknlf2gexq698 getHttpListener() {
      return this.httpListener;
   }

   // $FF: synthetic method
   public jebac_vexiahtrnwedo9ob6 getHttpRequest() {
      return this.httpRequest;
   }
}
