public enum jebac_vexiavrks9g79h9kq {
   // $FF: synthetic field
   ANTIALIASING("of.options.shaders.ANTIALIASING", "antialiasingLevel", "0"),
   // $FF: synthetic field
   NORMAL_MAP("of.options.shaders.NORMAL_MAP", "normalMapEnabled", "true"),
   // $FF: synthetic field
   SPECULAR_MAP("of.options.shaders.SPECULAR_MAP", "specularMapEnabled", "true"),
   // $FF: synthetic field
   RENDER_RES_MUL("of.options.shaders.RENDER_RES_MUL", "renderResMul", "1.0"),
   // $FF: synthetic field
   SHADOW_RES_MUL("of.options.shaders.SHADOW_RES_MUL", "shadowResMul", "1.0"),
   // $FF: synthetic field
   HAND_DEPTH_MUL("of.options.shaders.HAND_DEPTH_MUL", "handDepthMul", "0.125"),
   // $FF: synthetic field
   CLOUD_SHADOW("of.options.shaders.CLOUD_SHADOW", "cloudShadow", "true"),
   // $FF: synthetic field
   OLD_HAND_LIGHT("of.options.shaders.OLD_HAND_LIGHT", "oldHandLight", "default"),
   // $FF: synthetic field
   OLD_LIGHTING("of.options.shaders.OLD_LIGHTING", "oldLighting", "default"),
   // $FF: synthetic field
   SHADER_PACK("of.options.shaders.SHADER_PACK", "shaderPack", ""),
   // $FF: synthetic field
   TWEAK_BLOCK_DAMAGE("of.options.shaders.TWEAK_BLOCK_DAMAGE", "tweakBlockDamage", "false"),
   // $FF: synthetic field
   SHADOW_CLIP_FRUSTRUM("of.options.shaders.SHADOW_CLIP_FRUSTRUM", "shadowClipFrustrum", "true"),
   // $FF: synthetic field
   TEX_MIN_FIL_B("of.options.shaders.TEX_MIN_FIL_B", "TexMinFilB", "0"),
   // $FF: synthetic field
   TEX_MIN_FIL_N("of.options.shaders.TEX_MIN_FIL_N", "TexMinFilN", "0"),
   // $FF: synthetic field
   TEX_MIN_FIL_S("of.options.shaders.TEX_MIN_FIL_S", "TexMinFilS", "0"),
   // $FF: synthetic field
   TEX_MAG_FIL_B("of.options.shaders.TEX_MAG_FIL_B", "TexMagFilB", "0"),
   // $FF: synthetic field
   TEX_MAG_FIL_N("of.options.shaders.TEX_MAG_FIL_N", "TexMagFilN", "0"),
   // $FF: synthetic field
   TEX_MAG_FIL_S("of.options.shaders.TEX_MAG_FIL_S", "TexMagFilS", "0");

   // $FF: synthetic field
   private String resourceKey;
   // $FF: synthetic field
   private String propertyKey;
   // $FF: synthetic field
   private String valueDefault;
   private static final jebac_vexiavrks9g79h9kq[] $VALUES = new jebac_vexiavrks9g79h9kq[]{ANTIALIASING, NORMAL_MAP, SPECULAR_MAP, RENDER_RES_MUL, SHADOW_RES_MUL, HAND_DEPTH_MUL, CLOUD_SHADOW, OLD_HAND_LIGHT, OLD_LIGHTING, SHADER_PACK, TWEAK_BLOCK_DAMAGE, SHADOW_CLIP_FRUSTRUM, TEX_MIN_FIL_B, TEX_MIN_FIL_N, TEX_MIN_FIL_S, TEX_MAG_FIL_B, TEX_MAG_FIL_N, TEX_MAG_FIL_S};

   // $FF: synthetic method
   private jebac_vexiavrks9g79h9kq(String resourceKey, String propertyKey, String valueDefault) {
      this.resourceKey = resourceKey;
      this.propertyKey = propertyKey;
      this.valueDefault = valueDefault;
   }

   // $FF: synthetic method
   public String getResourceKey() {
      return this.resourceKey;
   }

   // $FF: synthetic method
   public String getPropertyKey() {
      return this.propertyKey;
   }

   // $FF: synthetic method
   public String getValueDefault() {
      return this.valueDefault;
   }
}
