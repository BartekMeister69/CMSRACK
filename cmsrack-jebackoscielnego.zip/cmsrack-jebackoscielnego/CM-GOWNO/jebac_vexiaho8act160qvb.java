import java.lang.reflect.Field;

public class jebac_vexiaho8act160qvb implements jebac_vexiasxnrrk3b6ekg {
   // $FF: synthetic field
   private String targetFieldName = null;
   // $FF: synthetic field
   private jebac_vexiajs8ej2dllnvc reflectorClass = null;

   // $FF: synthetic method
   public Field getField() {
      Class oclass = this.reflectorClass.getTargetClass();
      if (oclass == null) {
         return null;
      } else {
         try {
            Field field = oclass.getDeclaredField(this.targetFieldName);
            field.setAccessible(true);
            return field;
         } catch (NoSuchFieldException var3) {
            jebac_vexiakrwecfs16wve.log("(Reflector) Field not present: " + oclass.getName() + "." + this.targetFieldName);
            return null;
         } catch (Throwable var4) {
            var4.printStackTrace();
            return null;
         }
      }
   }

   // $FF: synthetic method
   public jebac_vexiaho8act160qvb(jebac_vexiajs8ej2dllnvc p_i38_1_, String p_i38_2_) {
      this.reflectorClass = p_i38_1_;
      this.targetFieldName = p_i38_2_;
   }
}
