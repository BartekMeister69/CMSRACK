public interface jebac_vexiae21v1yzd8ma8 {
   // $FF: synthetic method
   void fileDownloadFinished(String var1, byte[] var2, Throwable var3);
}
