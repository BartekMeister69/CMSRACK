import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.entity.AbstractClientPlayer;

public class jebac_vexiara06cijtnxiy {
   // $FF: synthetic field
   private static Map mapConfigurations = null;

   // $FF: synthetic method
   private static Map getMapConfigurations() {
      if (mapConfigurations == null) {
         mapConfigurations = new HashMap();
      }

      return mapConfigurations;
   }

   // $FF: synthetic method
   public static void renderPlayerItems(jebac_vexia88utjmuujofl p_renderPlayerItems_0_, AbstractClientPlayer p_renderPlayerItems_1_, float p_renderPlayerItems_2_, float p_renderPlayerItems_3_) {
      jebac_vexiapcxfoumj8ln8 playerconfiguration = getPlayerConfiguration(p_renderPlayerItems_1_);
      if (playerconfiguration != null) {
         playerconfiguration.renderPlayerItems(p_renderPlayerItems_0_, p_renderPlayerItems_1_, p_renderPlayerItems_2_, p_renderPlayerItems_3_);
      }

   }

   // $FF: synthetic method
   public static synchronized jebac_vexiapcxfoumj8ln8 getPlayerConfiguration(AbstractClientPlayer p_getPlayerConfiguration_0_) {
      String s = p_getPlayerConfiguration_0_.getNameClear();
      if (s == null) {
         return null;
      } else {
         jebac_vexiapcxfoumj8ln8 playerconfiguration = (jebac_vexiapcxfoumj8ln8)getMapConfigurations().get(s);
         if (playerconfiguration == null) {
            playerconfiguration = new jebac_vexiapcxfoumj8ln8();
            getMapConfigurations().put(s, playerconfiguration);
            jebac_vexiaty3hns3gyjac playerconfigurationreceiver = new jebac_vexiaty3hns3gyjac(s);
            String s1 = "http://s.optifine.net/users/" + s + ".cfg";
            jebac_vexiahszbti4d9e98 filedownloadthread = new jebac_vexiahszbti4d9e98(s1, playerconfigurationreceiver);
            filedownloadthread.start();
         }

         return playerconfiguration;
      }
   }

   // $FF: synthetic method
   public static synchronized void setPlayerConfiguration(String p_setPlayerConfiguration_0_, jebac_vexiapcxfoumj8ln8 p_setPlayerConfiguration_1_) {
      getMapConfigurations().put(p_setPlayerConfiguration_0_, p_setPlayerConfiguration_1_);
   }
}
