public interface jebac_vexia2ut457nkbgny {
   // $FF: synthetic method
   void func_175257_a(jebac_vexiabhmyylutxyzx var1);
}
