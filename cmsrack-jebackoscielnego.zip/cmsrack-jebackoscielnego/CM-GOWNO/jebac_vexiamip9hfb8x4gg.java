class jebac_vexiamip9hfb8x4gg extends jebac_vexia4oibzo50ubf0 {
   // $FF: synthetic field
   private jebac_vexiazrxtvwdcml9w shaderOption;

   // $FF: synthetic method
   jebac_vexiazrxtvwdcml9w getShaderOption() {
      return this.shaderOption;
   }

   // $FF: synthetic method
   jebac_vexiamip9hfb8x4gg(int buttonId, int x, int y, int widthIn, int heightIn, jebac_vexiazrxtvwdcml9w shaderOption, String text) {
      super(buttonId, x, y, widthIn, heightIn, text);
      this.shaderOption = shaderOption;
   }
}
