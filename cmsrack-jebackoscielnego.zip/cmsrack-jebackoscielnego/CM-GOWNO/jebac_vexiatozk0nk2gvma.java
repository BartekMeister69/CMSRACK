import com.mojang.authlib.exceptions.InvalidCredentialsException;
import java.awt.Desktop;
import java.io.IOException;
import java.math.BigInteger;
import java.net.URI;
import java.util.Random;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.player.EnumPlayerModelParts;

public class jebac_vexiatozk0nk2gvma extends jebac_vexiakl614w3uw0xg {
   // $FF: synthetic field
   private String title;
   // $FF: synthetic field
   private final jebac_vexiakl614w3uw0xg parentScreen;

   // $FF: synthetic method
   public void drawScreen(int mouseX, int mouseY, float partialTicks) {
      this.drawDefaultBackground();
      this.drawCenteredString(this.fontRendererObj, this.title, this.width / 2, 20, 16777215);
      super.drawScreen(mouseX, mouseY, partialTicks);
   }

   // $FF: synthetic method
   public void initGui() {
      int i = 0;
      this.title = I18n.format("options.skinCustomisation.title");
      EnumPlayerModelParts[] var2 = EnumPlayerModelParts.values();
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         EnumPlayerModelParts enumplayermodelparts = var2[var4];
         this.buttonList.add(new jebac_vexiawc5yr2ltwc4z(this, enumplayermodelparts.getPartId(), this.width / 2 - 155 + i % 2 * 160, this.height / 6 + 24 * (i >> 1), 150, 20, enumplayermodelparts));
         ++i;
      }

      if (i % 2 == 1) {
         ++i;
      }

      this.buttonList.add(new jebac_vexia4oibzo50ubf0(200, this.width / 2 + 5, this.height / 6 + 24 * (i >> 1), 150, 20, I18n.format("gui.done")));
      this.buttonList.add(new jebac_vexia4oibzo50ubf0(210, this.width / 2 - 155, this.height / 6 + 24 * (i >> 1), 150, 20, "Peleryna OptiFine"));
   }

   // $FF: synthetic method
   public jebac_vexiatozk0nk2gvma(jebac_vexiakl614w3uw0xg parentScreenIn) {
      this.parentScreen = parentScreenIn;
   }

   // $FF: synthetic method
   private String func_175358_a(EnumPlayerModelParts playerModelParts) {
      String s;
      if (this.mc.gameSettings.getModelParts().contains(playerModelParts)) {
         s = I18n.format("options.on");
      } else {
         s = I18n.format("options.off");
      }

      return playerModelParts.func_179326_d().getFormattedText() + ": " + s;
   }

   static String access$200(jebac_vexiatozk0nk2gvma x0, EnumPlayerModelParts x1) {
      return x0.func_175358_a(x1);
   }

   // $FF: synthetic method
   protected void actionPerformed(jebac_vexia4oibzo50ubf0 button) throws IOException {
      if (button.enabled) {
         if (button.id == 200) {
            this.mc.gameSettings.saveOptions();
            this.mc.displayGuiScreen(this.parentScreen);
         } else if (button.id == 210) {
            try {
               String s = this.mc.getSession().getProfile().getName();
               String s1 = this.mc.getSession().getProfile().getId().toString().replace("-", "");
               String s2 = this.mc.getSession().getToken();
               Random random = new Random();
               Random random1 = new Random((long)System.identityHashCode(new Object()));
               BigInteger biginteger = new BigInteger(128, random);
               BigInteger biginteger1 = new BigInteger(128, random1);
               BigInteger biginteger2 = biginteger.xor(biginteger1);
               String s3 = biginteger2.toString(16);
               this.mc.getSessionService().joinServer(this.mc.getSession().getProfile(), s2, s3);
               String s4 = "https://optifine.net/capeChange?u=" + s1 + "&n=" + s + "&s=" + s3;
               Desktop.getDesktop().browse(new URI(s4));
            } catch (InvalidCredentialsException var12) {
               this.mc.displayGuiScreen(new jebac_vexia3ck4rlo2j8o0(this, "Blad! Nieprawidlowe dane logowania. (InvalidCredentialsException)"));
            } catch (Exception var13) {
               this.mc.displayGuiScreen(new jebac_vexia3ck4rlo2j8o0(this, "Nieoczekiwany blad! " + var13.getMessage()));
            }
         } else if (button instanceof jebac_vexiawc5yr2ltwc4z) {
            EnumPlayerModelParts enumplayermodelparts = jebac_vexiawc5yr2ltwc4z.access$100((jebac_vexiawc5yr2ltwc4z)button);
            this.mc.gameSettings.switchModelPartEnabled(enumplayermodelparts);
            button.displayString = this.func_175358_a(enumplayermodelparts);
         }
      }

   }
}
