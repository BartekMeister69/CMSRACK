import com.google.common.collect.Lists;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.resources.DefaultPlayerSkin;
import net.minecraft.scoreboard.ScorePlayerTeam;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.IChatComponent;
import net.minecraft.util.MathHelper;
import net.minecraft.util.ResourceLocation;

class jebac_vexiany1xa6v3zwzb implements jebac_vexia9nzh0zm3n32z {
   // $FF: synthetic field
   private final ScorePlayerTeam field_178676_b;
   final jebac_vexiazwukeefhh95d this$0;
   // $FF: synthetic field
   private final ResourceLocation field_178677_c;
   // $FF: synthetic field
   private final List field_178675_d;

   // $FF: synthetic method
   public void func_178661_a(jebac_vexiabhmyylutxyzx menu) {
      menu.func_178647_a(new jebac_vexiatfe7m6mntuj0(this.field_178675_d));
   }

   // $FF: synthetic method
   public jebac_vexiany1xa6v3zwzb(jebac_vexiazwukeefhh95d this$0, ScorePlayerTeam p_i45492_2_) {
      this.this$0 = this$0;
      this.field_178676_b = p_i45492_2_;
      this.field_178675_d = Lists.newArrayList();
      Iterator var3 = p_i45492_2_.getMembershipCollection().iterator();

      while(var3.hasNext()) {
         String s = (String)var3.next();
         NetworkPlayerInfo networkplayerinfo = Minecraft.getMinecraft().getNetHandler().getPlayerInfo(s);
         if (networkplayerinfo != null) {
            this.field_178675_d.add(networkplayerinfo);
         }
      }

      if (!this.field_178675_d.isEmpty()) {
         String s1 = ((NetworkPlayerInfo)this.field_178675_d.get((new Random()).nextInt(this.field_178675_d.size()))).getGameProfile().getName();
         this.field_178677_c = AbstractClientPlayer.getLocationSkin(s1);
         AbstractClientPlayer.getDownloadImageSkin(this.field_178677_c, s1);
      } else {
         this.field_178677_c = DefaultPlayerSkin.getDefaultSkinLegacy();
      }

   }

   // $FF: synthetic method
   public boolean func_178662_A_() {
      return !this.field_178675_d.isEmpty();
   }

   // $FF: synthetic method
   public IChatComponent getSpectatorName() {
      return new ChatComponentText(this.field_178676_b.getTeamName());
   }

   // $FF: synthetic method
   public void func_178663_a(float p_178663_1_, int alpha) {
      int i = -1;
      String s = jebac_vexiav0ttj7we8byq.getFormatFromString(this.field_178676_b.getColorPrefix());
      if (s.length() >= 2) {
         i = Minecraft.getMinecraft().fontRendererObj.getColorCode(s.charAt(1));
      }

      if (i >= 0) {
         float f = (float)(i >> 16 & 255) / 255.0F;
         float f1 = (float)(i >> 8 & 255) / 255.0F;
         float f2 = (float)(i & 255) / 255.0F;
         jebac_vexiabhi02xzapwrh.drawRect(1, 1, 15, 15, MathHelper.func_180183_b(f * p_178663_1_, f1 * p_178663_1_, f2 * p_178663_1_) | alpha << 24);
      }

      Minecraft.getMinecraft().getTextureManager().bindTexture(this.field_178677_c);
      GlStateManager.color(p_178663_1_, p_178663_1_, p_178663_1_, (float)alpha / 255.0F);
      jebac_vexiabhi02xzapwrh.drawScaledCustomSizeModalRect(2, 2, 8.0F, 8.0F, 8, 8, 12, 12, 64.0F, 64.0F);
      jebac_vexiabhi02xzapwrh.drawScaledCustomSizeModalRect(2, 2, 40.0F, 8.0F, 8, 8, 12, 12, 64.0F, 64.0F);
   }
}
