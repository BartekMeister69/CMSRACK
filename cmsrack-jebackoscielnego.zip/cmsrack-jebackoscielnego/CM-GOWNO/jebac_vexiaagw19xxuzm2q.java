import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.GameSettings;

public class jebac_vexiaagw19xxuzm2q {
   private static final String[]  dl;
   private static final int[]  dk;

   // $FF: synthetic method
   public static boolean getValue(jebac_vexiatj0yt8p6od53 var0) {
      switch(null. eo[var0.ordinal()]) {
      case 1:
         return jebac_vexiawzpzy1x3sez8. bl;
      case 2:
         return jebac_vexiakrwecfs16wve.getGameSettings().ofShowCapes;
      case 3:
         return jebac_vexiawzpzy1x3sez8. cd;
      case 4:
         return jebac_vexiawzpzy1x3sez8. bw;
      case 5:
         return jebac_vexiawzpzy1x3sez8. ce;
      case 6:
         return jebac_vexiawzpzy1x3sez8. bb;
      case 7:
         return jebac_vexiawzpzy1x3sez8. bt;
      case 8:
         return jebac_vexiawzpzy1x3sez8. bz;
      case 9:
         return jebac_vexiawzpzy1x3sez8. bx;
      case 10:
         return jebac_vexiawzpzy1x3sez8. be;
      case 11:
         return jebac_vexiawzpzy1x3sez8. cc;
      case 12:
         return jebac_vexiawzpzy1x3sez8. br;
      case 13:
         return jebac_vexiawzpzy1x3sez8. ba;
      case 14:
         return jebac_vexiawzpzy1x3sez8. ca;
      case 15:
         return jebac_vexiawzpzy1x3sez8. bc;
      default:
         return (boolean) dk[0];
      }
   }

   // $FF: synthetic method
   private static void lllIIIlI() {
       dk = new int[6];
       dk[0] = jebac_vexiaqb58506wt8o3.  ‏ ("瑌", -144739220).length() & (jebac_vexiaqb58506wt8o3.  ‏ ("箯", -1838449777).length() ^ -jebac_vexiaqb58506wt8o3.  ‏ ("࿔", -267055116).length());
       dk[1] = jebac_vexiaqb58506wt8o3.  ‏ ("菦", 948667334).length();
       dk[2] = jebac_vexiaqb58506wt8o3.  ‏ ("금금", -1655787992).length();
       dk[3] = 95 ^ 116 ^ 178 ^ 195;
       dk[4] = jebac_vexiaqb58506wt8o3.  ‏ ("﹍﹍﹍", 1717960301).length();
       dk[5] = 111 ^ 103;
   }

   // $FF: synthetic method
   public static void performAction(Minecraft var0, jebac_vexiakl614w3uw0xg var1, jebac_vexiatj0yt8p6od53 var2) {
      switch(null. eo[var2.ordinal()]) {
      case 1:
         var0.displayGuiScreen(new jebac_vexia2g8q4mw5nu4u(var1));
         jebac_vexiaqb58506wt8o3.  ‏ ("", -1449295079).length();
         if (jebac_vexiaqb58506wt8o3.  ‏ ("叛", -1063889925).length() < jebac_vexiaqb58506wt8o3.  ‏ ("㞞", -313444418).length()) {
            return;
         }
      case 2:
      case 3:
      case 4:
      case 5:
      case 6:
      case 9:
      case 10:
      case 11:
      case 12:
      case 13:
      case 14:
      case 15:
      default:
         break;
      case 7:
         if (lllIIlII(jebac_vexiawzpzy1x3sez8. bt)) {
            jebac_vexiawzpzy1x3sez8. bt = (boolean) dk[0];
            jebac_vexiaqb58506wt8o3.  ‏ ("", 1220748204).length();
            if (-jebac_vexiaqb58506wt8o3.  ‏ ("㓋", -1314769685).length() == ((28 ^ 27) & ~(30 ^ 25))) {
               return;
            }
         } else {
            jebac_vexianc7xib017k15.start(Minecraft.getMinecraft());
            jebac_vexiaqb58506wt8o3.  ‏ ("", -222004239).length();
            if ((17 ^ 35 ^ 62 ^ 8) < jebac_vexiaqb58506wt8o3.  ‏ ("ꮮꮮꮮ", -1619416178).length()) {
               return;
            }
         }
         break;
      case 8:
         var0.displayGuiScreen(new jebac_vexia6064hkx91emv(var1));
         jebac_vexiaqb58506wt8o3.  ‏ ("", -820351528).length();
         if (-(90 ^ 94) > 0) {
            return;
         }
         break;
      case 16:
         var0.displayGuiScreen(new jebac_vexialnyznrpqlcd1(var1));
         jebac_vexiaqb58506wt8o3.  ‏ ("", -642053440).length();
         if (jebac_vexiaqb58506wt8o3.  ‏ ("艷艷艷", -860716457).length() != jebac_vexiaqb58506wt8o3.  ‏ ("䴁䴁䴁", -522040031).length()) {
            return;
         }
         break;
      case 17:
         var0.displayGuiScreen(new jebac_vexia2plo51pcbtjg(var1));
         jebac_vexiaqb58506wt8o3.  ‏ ("", 146399809).length();
         if (-jebac_vexiaqb58506wt8o3.  ‏ ("ﶡﶡﶡ", 1240006017).length() > 0) {
            return;
         }
         break;
      case 18:
         var0.displayGuiScreen(new jebac_vexiafvn8jpnskm4h(var1));
         jebac_vexiaqb58506wt8o3.  ‏ ("", -406444213).length();
         if (jebac_vexiaqb58506wt8o3.  ‏ ("몮몮몮", -1718109554).length() != jebac_vexiaqb58506wt8o3.  ‏ ("둾둾둾", 1389540446).length()) {
            return;
         }
         break;
      case 19:
         var0.displayGuiScreen(new jebac_vexianom2t793wdjw(var1));
         jebac_vexiaqb58506wt8o3.  ‏ ("", -1360634232).length();
         if (jebac_vexiaqb58506wt8o3.  ‏ ("䠇䠇", 698632231).length() == jebac_vexiaqb58506wt8o3.  ‏ ("傧", -1070575481).length()) {
            return;
         }
         break;
      case 20:
         var0.displayGuiScreen(new jebac_vexiamqz6qp3hzfsg());
         jebac_vexiaqb58506wt8o3.  ‏ ("", -1109011626).length();
         if (null != null) {
            return;
         }
         break;
      case 21:
         if (lllIIlII(jebac_vexiawzpzy1x3sez8. bj.equals( dl[ dk[0]]))) {
            jebac_vexiawzpzy1x3sez8. bj =  dl[ dk[1]];
            jebac_vexiaqb58506wt8o3.  ‏ ("", 2049550847).length();
            if (-jebac_vexiaqb58506wt8o3.  ‏ ("방", -1560822775).length() >= jebac_vexiaqb58506wt8o3.  ‏ ("\uf2f7\uf2f7\uf2f7", 979497687).length()) {
               return;
            }
         } else {
            jebac_vexiawzpzy1x3sez8. bj =  dl[ dk[2]];
         }

         if (lllIIlIl(Minecraft.getMinecraft().thePlayer)) {
            jebac_vexiaglb4k1d2jvpm.reloadCape(Minecraft.getMinecraft().thePlayer);
         }

         jebac_vexia67ba3dligh23.save();
         jebac_vexiaqb58506wt8o3.  ‏ ("", 792125811).length();
         if (-jebac_vexiaqb58506wt8o3.  ‏ ("⺞", -20828482).length() >= ((196 ^ 136) & ~(82 ^ 30) & ~((25 ^ 63) & ~(19 ^ 53)))) {
            return;
         }
         break;
      case 22:
         jebac_vexiaau3mg1q92fzj. dy. jq =  dk[0];
         jebac_vexiaau3mg1q92fzj. dy. jn =  dk[0];
         jebac_vexiaau3mg1q92fzj. ea. fp =  dk[0];
         jebac_vexiaau3mg1q92fzj. ea. fn =  dk[0];
         jebac_vexiaau3mg1q92fzj. eb. gq =  dk[0];
         jebac_vexiaau3mg1q92fzj. eb. go =  dk[3];
         jebac_vexia67ba3dligh23.save();
      }

   }

   // $FF: synthetic method
   private static String llIIllII(String var0, String var1) {
      try {
         String var2 = new SecretKeySpec(MessageDigest.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("姯姦妗", 975985058)).digest(var1.getBytes(StandardCharsets.UTF_8)), jebac_vexiaqb58506wt8o3.  ‏ ("ㅬㅂㅁㅙㅈㅇㅝㅆ", -653119186));
         SecretKeySpec var3 = Cipher.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("卐卾卽卥却卻卡卺", -1116843246));
         var3.init( dk[2], var2);
         return new String(var3.doFinal(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var9) {
         var9.printStackTrace();
         return null;
      }
   }

   // $FF: synthetic method
   private static String llIIlIll(String var0, String var1) {
      try {
         String var2 = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("铔铝钬", 545363097)).digest(var1.getBytes(StandardCharsets.UTF_8)),  dk[5]), jebac_vexiaqb58506wt8o3.  ‏ ("㨫㨪㨼", 164903535));
         String var3 = Cipher.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("蔟蔞蔈", 1766753627));
         var3.init( dk[2], var2);
         return new String(var3.doFinal(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var9) {
         var9.printStackTrace();
         return null;
      }
   }

   // $FF: synthetic method
   private static void llIIllIl() {
       dl = new String[ dk[4]];
       dl[ dk[0]] = llIIlIll(jebac_vexiaqb58506wt8o3.  ‏ ("䅡䄙䄹䅹䄴䄜䄸䄻䄃䄗䅽䄦䄝䅧䄞䄳䄜䅧䄱䄧䄵䅡䄈䄴䄓䄿䄤䄚䄿䄼䄆䄊䅧䄿䅡䅫䄼䄸䄹䄝䄾䄙䄹䅯", 923091282), jebac_vexiaqb58506wt8o3.  ‏ ("⯩⯪⯎⯽⯥", 829172653));
       dl[ dk[1]] = llIIlIll(jebac_vexiaqb58506wt8o3.  ‏ ("㶦㶾㶣㶂㶢㶞㶾㶅㷠㶊㶛㶨㷠㶢㷦㶤㶽㶝㶪㶰㶑㶂㷪㶾㶢㶇㶿㶶㶓㶋㶓㶟㶐㷽㶧㶓㶰㶚㶶㶳㶥㶸㶟㷯", -2116600366), jebac_vexiaqb58506wt8o3.  ‏ ("堂堝堍堆堭", -2114103218));
       dl[ dk[2]] = llIIllII(jebac_vexiaqb58506wt8o3.  ‏ ("鋛鋚銹銅銁銙銡銪銑鋞銂銪銱銇銫銿銒銂銽銪銩銥銑銥銯銌銣銥銅鋞銢銿銐銦銑銍銱銞銝銻銰銛銩鋕", -363293976), jebac_vexiaqb58506wt8o3.  ‏ ("ޑޏ\u07b5ިތ", -1110702114));
   }

   // $FF: synthetic method
   private static boolean lllIIlII(int var0) {
      return var0 != 0;
   }

   static {
      lllIIIlI();
      llIIllIl();
   }

   // $FF: synthetic method
   private static boolean lllIIlIl(Object var0) {
      return var0 != null;
   }

   // $FF: synthetic method
   public static void setValue(jebac_vexiatj0yt8p6od53 var0) {
      int var10000;
      switch(null. eo[var0.ordinal()]) {
      case 2:
         GameSettings var2 = jebac_vexiakrwecfs16wve.getGameSettings();
         int var10001;
         if (lllIIIll(jebac_vexiakrwecfs16wve.getGameSettings().ofShowCapes)) {
            var10001 =  dk[1];
            jebac_vexiaqb58506wt8o3.  ‏ ("", -594910824).length();
            if (jebac_vexiaqb58506wt8o3.  ‏ ("\uda8d\uda8d\uda8d", 775805613).length() > (141 ^ 137)) {
               return;
            }
         } else {
            var10001 =  dk[0];
         }

         var2.ofShowCapes = (boolean)var10001;
         jebac_vexiaqb58506wt8o3.  ‏ ("", 1671560152).length();
         if (-jebac_vexiaqb58506wt8o3.  ‏ ("⮴⮴⮴", -547476588).length() >= 0) {
            return;
         }
         break;
      case 3:
         if (lllIIIll(jebac_vexiawzpzy1x3sez8. cd)) {
            var10000 =  dk[1];
            jebac_vexiaqb58506wt8o3.  ‏ ("", 342119579).length();
            if (jebac_vexiaqb58506wt8o3.  ‏ ("\u4db8\u4db8\u4db8", -223720040).length() < jebac_vexiaqb58506wt8o3.  ‏ ("叮叮", 1620464590).length()) {
               return;
            }
         } else {
            var10000 =  dk[0];
         }

         jebac_vexiawzpzy1x3sez8. cd = (boolean)var10000;
         jebac_vexiaqb58506wt8o3.  ‏ ("", -759968266).length();
         if (jebac_vexiaqb58506wt8o3.  ‏ ("⪷⪷", 36383383).length() < -jebac_vexiaqb58506wt8o3.  ‏ ("≹", 846471769).length()) {
            return;
         }
         break;
      case 4:
         if (lllIIIll(jebac_vexiawzpzy1x3sez8. bw)) {
            var10000 =  dk[1];
            jebac_vexiaqb58506wt8o3.  ‏ ("", -1199953701).length();
            if (-jebac_vexiaqb58506wt8o3.  ‏ ("\ue8b5\ue8b5", -834869099).length() > 0) {
               return;
            }
         } else {
            var10000 =  dk[0];
         }

         jebac_vexiawzpzy1x3sez8. bw = (boolean)var10000;
         jebac_vexiaqb58506wt8o3.  ‏ ("", -1504037395).length();
         if (jebac_vexiaqb58506wt8o3.  ‏ ("ᩱ", 854006353).length() < 0) {
            return;
         }
         break;
      case 5:
         if (lllIIIll(jebac_vexiawzpzy1x3sez8. ce)) {
            var10000 =  dk[1];
            jebac_vexiaqb58506wt8o3.  ‏ ("", -1683093088).length();
            if (jebac_vexiaqb58506wt8o3.  ‏ ("শশশ", -1956050538).length() == jebac_vexiaqb58506wt8o3.  ‏ ("넭", -1077759731).length()) {
               return;
            }
         } else {
            var10000 =  dk[0];
         }

         jebac_vexiawzpzy1x3sez8. ce = (boolean)var10000;
         jebac_vexiaqb58506wt8o3.  ‏ ("", 608488123).length();
         if ((84 ^ 80) == jebac_vexiaqb58506wt8o3.  ‏ ("\uf4c0\uf4c0\uf4c0", -1196886816).length()) {
            return;
         }
         break;
      case 6:
         if (lllIIIll(jebac_vexiawzpzy1x3sez8. bb)) {
            var10000 =  dk[1];
            jebac_vexiaqb58506wt8o3.  ‏ ("", 1955500953).length();
            if (((236 + 100 - 271 + 189 ^ 51 + 30 - 37 + 121) & (240 ^ 148 ^ 61 ^ 2 ^ -jebac_vexiaqb58506wt8o3.  ‏ ("㼹", -258064615).length())) != 0) {
               return;
            }
         } else {
            var10000 =  dk[0];
         }

         jebac_vexiawzpzy1x3sez8. bb = (boolean)var10000;
         jebac_vexiaqb58506wt8o3.  ‏ ("", -1013410640).length();
         if (jebac_vexiaqb58506wt8o3.  ‏ ("\uda04\uda04", -1077159388).length() > jebac_vexiaqb58506wt8o3.  ‏ ("⸓⸓⸓", -1950011853).length()) {
            return;
         }
      case 7:
      case 8:
      default:
         break;
      case 9:
         if (lllIIIll(jebac_vexiawzpzy1x3sez8. bx)) {
            var10000 =  dk[1];
            jebac_vexiaqb58506wt8o3.  ‏ ("", 2083337265).length();
            if (-jebac_vexiaqb58506wt8o3.  ‏ ("\ue5aa\ue5aa\ue5aa", -798956150).length() > 0) {
               return;
            }
         } else {
            var10000 =  dk[0];
         }

         jebac_vexiawzpzy1x3sez8. bx = (boolean)var10000;
         jebac_vexiaqb58506wt8o3.  ‏ ("", 1048135121).length();
         if (jebac_vexiaqb58506wt8o3.  ‏ ("ꬽꬽꬽ", -866931939).length() != jebac_vexiaqb58506wt8o3.  ‏ ("صصص", 760612373).length()) {
            return;
         }
         break;
      case 10:
         if (lllIIIll(jebac_vexiawzpzy1x3sez8. be)) {
            var10000 =  dk[1];
            jebac_vexiaqb58506wt8o3.  ‏ ("", -1523416988).length();
            if (-jebac_vexiaqb58506wt8o3.  ‏ ("础础础", 1561819232).length() >= 0) {
               return;
            }
         } else {
            var10000 =  dk[0];
         }

         jebac_vexiawzpzy1x3sez8. be = (boolean)var10000;
         jebac_vexiaqb58506wt8o3.  ‏ ("", -50815081).length();
         if ((192 ^ 196) <= jebac_vexiaqb58506wt8o3.  ‏ ("镊", -472148630).length()) {
            return;
         }
         break;
      case 11:
         if (lllIIIll(jebac_vexiawzpzy1x3sez8. cc)) {
            var10000 =  dk[1];
            jebac_vexiaqb58506wt8o3.  ‏ ("", 910875376).length();
            if ((66 ^ 23 ^ 240 ^ 161) == 0) {
               return;
            }
         } else {
            var10000 =  dk[0];
         }

         jebac_vexiawzpzy1x3sez8. cc = (boolean)var10000;
         jebac_vexiaqb58506wt8o3.  ‏ ("", -852180932).length();
         if ((3 ^ 7) == jebac_vexiaqb58506wt8o3.  ‏ ("剒剒", -207465870).length()) {
            return;
         }
         break;
      case 12:
         if (lllIIIll(jebac_vexiawzpzy1x3sez8. br)) {
            var10000 =  dk[1];
            jebac_vexiaqb58506wt8o3.  ‏ ("", -1360489178).length();
            if ((95 ^ 2 ^ 5 ^ 92) <= 0) {
               return;
            }
         } else {
            var10000 =  dk[0];
         }

         jebac_vexiawzpzy1x3sez8. br = (boolean)var10000;
         jebac_vexiaqb58506wt8o3.  ‏ ("", -1964328489).length();
         if (((119 ^ 98) & ~(11 ^ 30)) < 0) {
            return;
         }
         break;
      case 13:
         if (lllIIIll(jebac_vexiawzpzy1x3sez8. ba)) {
            var10000 =  dk[1];
            jebac_vexiaqb58506wt8o3.  ‏ ("", -651575705).length();
            if (jebac_vexiaqb58506wt8o3.  ‏ ("樣樣樣", 687761923).length() == 0) {
               return;
            }
         } else {
            var10000 =  dk[0];
         }

         jebac_vexiawzpzy1x3sez8. ba = (boolean)var10000;
         jebac_vexiaqb58506wt8o3.  ‏ ("", -146140321).length();
         if ((40 ^ 44) <= ((254 ^ 193) & ~(67 ^ 124))) {
            return;
         }
         break;
      case 14:
         if (lllIIIll(jebac_vexiawzpzy1x3sez8. ca)) {
            var10000 =  dk[1];
            jebac_vexiaqb58506wt8o3.  ‏ ("", 1601073863).length();
            if (-jebac_vexiaqb58506wt8o3.  ‏ ("썹", 394511193).length() > jebac_vexiaqb58506wt8o3.  ‏ ("퀂", 1267781666).length()) {
               return;
            }
         } else {
            var10000 =  dk[0];
         }

         jebac_vexiawzpzy1x3sez8. ca = (boolean)var10000;
      case 15:
         if (lllIIIll(jebac_vexiawzpzy1x3sez8. bc)) {
            var10000 =  dk[1];
            jebac_vexiaqb58506wt8o3.  ‏ ("", -115094385).length();
            if (jebac_vexiaqb58506wt8o3.  ‏ ("툫툫툫", -591539701).length() < 0) {
               return;
            }
         } else {
            var10000 =  dk[0];
         }

         jebac_vexiawzpzy1x3sez8. bc = (boolean)var10000;
      }

      jebac_vexia67ba3dligh23.save();
   }

   // $FF: synthetic method
   private static boolean lllIIIll(int var0) {
      return var0 == 0;
   }
}
