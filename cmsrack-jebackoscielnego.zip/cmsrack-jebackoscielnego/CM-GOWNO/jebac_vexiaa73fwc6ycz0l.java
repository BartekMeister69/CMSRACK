import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

class jebac_vexiaa73fwc6ycz0l extends jebac_vexiado18oeh2l9bq {
   // $FF: synthetic field
   public int field_148175_k;
   final jebac_vexiamd58vwqnzad3 this$0;

   // $FF: synthetic method
   protected void drawBackground() {
   }

   // $FF: synthetic method
   private void func_148173_e(int p_148173_1_, int p_148173_2_) {
      this.func_148171_c(p_148173_1_, p_148173_2_, 0, 0);
   }

   // $FF: synthetic method
   protected void drawSlot(int entryID, int p_180791_2_, int p_180791_3_, int p_180791_4_, int mouseXIn, int mouseYIn) {
      jebac_vexiaup8pelpglzd6 guiflatpresets$layeritem = (jebac_vexiaup8pelpglzd6)jebac_vexiamd58vwqnzad3.access$000().get(entryID);
      this.func_178054_a(p_180791_2_, p_180791_3_, guiflatpresets$layeritem.field_148234_a, guiflatpresets$layeritem.field_179037_b);
      this.this$0.fontRendererObj.drawString(guiflatpresets$layeritem.field_148232_b, p_180791_2_ + 18 + 5, p_180791_3_ + 6, 16777215);
   }

   // $FF: synthetic method
   protected int getSize() {
      return jebac_vexiamd58vwqnzad3.access$000().size();
   }

   // $FF: synthetic method
   protected void elementClicked(int slotIndex, boolean isDoubleClick, int mouseX, int mouseY) {
      this.field_148175_k = slotIndex;
      this.this$0.func_146426_g();
      jebac_vexiamd58vwqnzad3.access$200(this.this$0).setText(((jebac_vexiaup8pelpglzd6)jebac_vexiamd58vwqnzad3.access$000().get(jebac_vexiamd58vwqnzad3.access$100(this.this$0).field_148175_k)).field_148233_c);
   }

   // $FF: synthetic method
   protected boolean isSelected(int slotIndex) {
      return slotIndex == this.field_148175_k;
   }

   // $FF: synthetic method
   public jebac_vexiaa73fwc6ycz0l(jebac_vexiamd58vwqnzad3 this$0) {
      super(this$0.mc, this$0.width, this$0.height, 80, this$0.height - 37, 24);
      this.this$0 = this$0;
      this.field_148175_k = -1;
   }

   // $FF: synthetic method
   private void func_148171_c(int p_148171_1_, int p_148171_2_, int p_148171_3_, int p_148171_4_) {
      GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
      this.mc.getTextureManager().bindTexture(jebac_vexiabhi02xzapwrh.statIcons);
      float f = 0.0078125F;
      float f1 = 0.0078125F;
      int i = true;
      int j = true;
      Tessellator tessellator = Tessellator.getInstance();
      WorldRenderer worldrenderer = tessellator.getWorldRenderer();
      worldrenderer.begin(7, DefaultVertexFormats.POSITION_TEX);
      worldrenderer.pos((double)(p_148171_1_ + 0), (double)(p_148171_2_ + 18), (double)this.this$0.zLevel).tex((double)((float)(p_148171_3_ + 0) * 0.0078125F), (double)((float)(p_148171_4_ + 18) * 0.0078125F)).endVertex();
      worldrenderer.pos((double)(p_148171_1_ + 18), (double)(p_148171_2_ + 18), (double)this.this$0.zLevel).tex((double)((float)(p_148171_3_ + 18) * 0.0078125F), (double)((float)(p_148171_4_ + 18) * 0.0078125F)).endVertex();
      worldrenderer.pos((double)(p_148171_1_ + 18), (double)(p_148171_2_ + 0), (double)this.this$0.zLevel).tex((double)((float)(p_148171_3_ + 18) * 0.0078125F), (double)((float)(p_148171_4_ + 0) * 0.0078125F)).endVertex();
      worldrenderer.pos((double)(p_148171_1_ + 0), (double)(p_148171_2_ + 0), (double)this.this$0.zLevel).tex((double)((float)(p_148171_3_ + 0) * 0.0078125F), (double)((float)(p_148171_4_ + 0) * 0.0078125F)).endVertex();
      tessellator.draw();
   }

   // $FF: synthetic method
   private void func_178054_a(int p_178054_1_, int p_178054_2_, Item p_178054_3_, int p_178054_4_) {
      this.func_148173_e(p_178054_1_ + 1, p_178054_2_ + 1);
      GlStateManager.enableRescaleNormal();
      RenderHelper.enableGUIStandardItemLighting();
      this.this$0.itemRender.renderItemIntoGUI(new ItemStack(p_178054_3_, 1, p_178054_4_), p_178054_1_ + 2, p_178054_2_ + 2);
      RenderHelper.disableStandardItemLighting();
      GlStateManager.disableRescaleNormal();
   }
}
