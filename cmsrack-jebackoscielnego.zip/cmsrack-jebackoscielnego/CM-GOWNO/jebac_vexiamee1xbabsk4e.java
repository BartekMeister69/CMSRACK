public class jebac_vexiamee1xbabsk4e {
   // $FF: synthetic field
   private final String field_178937_b;
   // $FF: synthetic field
   private final boolean field_178938_c;
   // $FF: synthetic field
   private final int field_178939_a;

   // $FF: synthetic method
   public boolean func_178934_d() {
      return this.field_178938_c;
   }

   // $FF: synthetic method
   public int func_178935_b() {
      return this.field_178939_a;
   }

   // $FF: synthetic method
   public jebac_vexiamee1xbabsk4e(int p_i45531_1_, String p_i45531_2_, boolean p_i45531_3_) {
      this.field_178939_a = p_i45531_1_;
      this.field_178937_b = p_i45531_2_;
      this.field_178938_c = p_i45531_3_;
   }

   // $FF: synthetic method
   public String func_178936_c() {
      return this.field_178937_b;
   }
}
