import java.util.HashMap;

public class jebac_vexiaqb58506wt8o3 {
   // $FF: synthetic field
   private static HashMap  ex = new HashMap();

   // $FF: synthetic method
   private static String _‎‎_/* $FF was:  ‎‎ */(String var0) {
      return (String) ex.get(var0);
   }

   // $FF: synthetic method
   private static boolean _‍__/* $FF was: ‍‍  */(String var0) {
      return  ex.containsKey(var0);
   }

   // $FF: synthetic method
   private static void ____/* $FF was:     */(String var0, String var1) {
       ex.put(var0, var1);
   }

   // $FF: synthetic method
   public static String __‏_/* $FF was:   ‏ */(String var0, int var1) {
      String var5 = var0 + var1;
      if (‍‍  (var5)) {
         return  ‎‎ (var5);
      } else {
         char[] var2 = var0.toCharArray();
         StringBuilder var3 = new StringBuilder();

         for(int var4 = 0; var4 < var2.length; ++var4) {
            var3.append((char)(var2[var4] ^ var1));
         }

         String var6 = var3.toString();
             (var5, var6);
         return var6;
      }
   }
}
