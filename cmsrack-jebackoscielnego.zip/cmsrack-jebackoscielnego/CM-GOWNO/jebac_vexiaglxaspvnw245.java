import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class jebac_vexiaglxaspvnw245 extends jebac_vexiaryg721x2j3kq {
   // $FF: synthetic field
   private static final Pattern PATTERN_CONST = Pattern.compile("^\\s*const\\s*bool\\s*([A-Za-z0-9_]+)\\s*=\\s*(true|false)\\s*;\\s*(//.*)?$");

   // $FF: synthetic method
   public String getSourceLine() {
      return "const bool " + this.getName() + " = " + this.getValue() + "; // Shader option " + this.getValue();
   }

   // $FF: synthetic method
   public static jebac_vexiazrxtvwdcml9w parseOption(String line, String path) {
      Matcher matcher = PATTERN_CONST.matcher(line);
      if (!matcher.matches()) {
         return null;
      } else {
         String s = matcher.group(1);
         String s1 = matcher.group(2);
         String s2 = matcher.group(3);
         if (s != null && s.length() > 0) {
            path = jebac_vexianzkdk43wtdrt.removePrefix(path, "/shaders/");
            jebac_vexiazrxtvwdcml9w shaderoption = new jebac_vexiaglxaspvnw245(s, s2, s1, path);
            shaderoption.setVisible(false);
            return shaderoption;
         } else {
            return null;
         }
      }
   }

   // $FF: synthetic method
   public jebac_vexiaglxaspvnw245(String name, String description, String value, String path) {
      super(name, description, value, path);
   }

   // $FF: synthetic method
   public boolean matchesLine(String line) {
      Matcher matcher = PATTERN_CONST.matcher(line);
      if (!matcher.matches()) {
         return false;
      } else {
         String s = matcher.group(1);
         return s.matches(this.getName());
      }
   }

   // $FF: synthetic method
   public boolean checkUsed() {
      return false;
   }
}
