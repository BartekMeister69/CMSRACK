import java.io.BufferedInputStream;
import java.io.InputStream;
import java.net.URL;
import javazoom.jl.player.Player;

public class jebac_vexia2ug8d5nsqylv {
   public static Player  et;
   public static jebac_vexiaa29g8ikthjc5  eu;

   private static void lambda$play$0(String var0) {
      try {
         InputStream var1 = (new URL(var0)).openStream();
         float var2 = new BufferedInputStream(var1);
         if (lIIIllI( et)) {
             et.close();
         }

          et = new Player(var2);
          et.play();
      } catch (Exception var7) {
         var7.printStackTrace();
         return;
      }

      jebac_vexiaqb58506wt8o3.  ‏ ("", -1346225772).length();
      if (jebac_vexiaqb58506wt8o3.  ‏ ("奏奏", 2003261807).length() != jebac_vexiaqb58506wt8o3.  ‏ ("쾑쾑쾑", 652857265).length()) {
         ;
      }
   }

   // $FF: synthetic method
   public static void play(String var0) {
      (new Thread(jebac_vexia2ug8d5nsqylv::lambda$play$0)).start();
   }

   // $FF: synthetic method
   private static boolean lIIIllI(Object var0) {
      return var0 != null;
   }
}
