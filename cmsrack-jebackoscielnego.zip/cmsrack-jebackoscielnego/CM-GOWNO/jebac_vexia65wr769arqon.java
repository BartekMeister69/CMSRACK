import net.minecraft.util.ResourceLocation;

public interface jebac_vexia65wr769arqon {
   // $FF: synthetic method
   void onTextureLoaded(ResourceLocation var1);
}
