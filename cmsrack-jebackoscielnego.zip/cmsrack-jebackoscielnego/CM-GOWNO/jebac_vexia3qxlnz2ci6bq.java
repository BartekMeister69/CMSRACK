import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.I18n;

public class jebac_vexia3qxlnz2ci6bq extends jebac_vexia6fd2eiv9yfhn {
   // $FF: synthetic method
   public jebac_vexia3qxlnz2ci6bq(Minecraft mcIn, int p_i45056_2_, int p_i45056_3_, List p_i45056_4_) {
      super(mcIn, p_i45056_2_, p_i45056_3_, p_i45056_4_);
   }

   // $FF: synthetic method
   protected String getListHeader() {
      return I18n.format("resourcePack.selected.title");
   }
}
