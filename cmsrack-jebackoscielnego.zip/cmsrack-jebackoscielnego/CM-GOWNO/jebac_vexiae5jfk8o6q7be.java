import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.google.common.collect.UnmodifiableIterator;
import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;
import net.minecraft.block.Block;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.EnumSkyBlock;
import net.minecraft.world.WorldType;
import net.minecraft.world.chunk.Chunk;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL11;

public class jebac_vexiae5jfk8o6q7be extends jebac_vexiabhi02xzapwrh {
   // $FF: synthetic field
   private final Minecraft mc;
   // $FF: synthetic field
   private final jebac_vexiav0ttj7we8byq fontRenderer;

   // $FF: synthetic method
   private void renderDebugInfoLeft() {
      List list = this.call();

      for(int i = 0; i < list.size(); ++i) {
         String s = (String)list.get(i);
         if (!Strings.isNullOrEmpty(s)) {
            int j = this.fontRenderer.FONT_HEIGHT;
            int k = this.fontRenderer.getStringWidth(s);
            int l = 2 + j * i;
            drawRect(1, l - 1, 2 + k + 1, l + j - 1, -1873784752);
            this.fontRenderer.drawString(s, 2, l, 14737632);
         }
      }

   }

   // $FF: synthetic method
   private static long bytesToMb(long bytes) {
      return bytes / 1024L / 1024L;
   }

   // $FF: synthetic method
   protected List call() {
      BlockPos blockpos = new BlockPos(this.mc.getRenderViewEntity().posX, this.mc.getRenderViewEntity().getEntityBoundingBox().minY, this.mc.getRenderViewEntity().posZ);
      Entity entity = this.mc.getRenderViewEntity();
      EnumFacing enumfacing = entity.getHorizontalFacing();
      ArrayList arraylist = Lists.newArrayList(new String[]{"Minecraft 1.8.8 (CMPack)", this.mc.debug, "", String.format("XYZ: %.1f / %.1f / %.1f", this.mc.getRenderViewEntity().posX, this.mc.getRenderViewEntity().getEntityBoundingBox().minY, this.mc.getRenderViewEntity().posZ), "Facing: " + enumfacing});
      if (!jebac_vexiawzpzy1x3sez8. ce) {
         arraylist.add(this.mc.renderGlobal.getDebugInfoRenders());
         arraylist.add(this.mc.renderGlobal.getDebugInfoEntities());
         arraylist.add("P: " + this.mc.effectRenderer.getStatistics() + ". T: " + this.mc.theWorld.getDebugLoadedEntities());
         arraylist.add(this.mc.theWorld.getProviderName());
         arraylist.add(String.format("Block: %d %d %d", blockpos.getX(), blockpos.getY(), blockpos.getZ()));
         arraylist.add(String.format("Chunk: %d %d %d in %d %d %d", blockpos.getX() & 15, blockpos.getY() & 15, blockpos.getZ() & 15, blockpos.getX() >> 4, blockpos.getY() >> 4, blockpos.getZ() >> 4));
         if (this.mc.theWorld != null && this.mc.theWorld.isBlockLoaded(blockpos)) {
            Chunk chunk = this.mc.theWorld.getChunkFromBlockCoords(blockpos);
            arraylist.add("Biome: " + chunk.getBiome(blockpos, this.mc.theWorld.getWorldChunkManager()).biomeName);
            arraylist.add("Light: " + chunk.getLightSubtracted(blockpos, 0) + " (" + chunk.getLightFor(EnumSkyBlock.SKY, blockpos) + " sky, " + chunk.getLightFor(EnumSkyBlock.BLOCK, blockpos) + " block)");
            DifficultyInstance difficultyinstance = this.mc.theWorld.getDifficultyForLocation(blockpos);
            if (this.mc.isIntegratedServerRunning() && this.mc.getIntegratedServer() != null) {
               EntityPlayerMP entityplayermp = this.mc.getIntegratedServer().getConfigurationManager().getPlayerByUUID(this.mc.thePlayer.getUniqueID());
               if (entityplayermp != null) {
                  difficultyinstance = entityplayermp.worldObj.getDifficultyForLocation(new BlockPos(entityplayermp));
               }
            }

            arraylist.add(String.format("Local Difficulty: %.2f (Day %d)", difficultyinstance.getAdditionalDifficulty(), this.mc.theWorld.getWorldTime() / 24000L));
         }

         if (this.mc.entityRenderer != null && this.mc.entityRenderer.isShaderActive()) {
            arraylist.add("Shader: " + this.mc.entityRenderer.getShaderGroup().getShaderGroupName());
         }

         if (this.mc.objectMouseOver != null && this.mc.objectMouseOver.typeOfHit == MovingObjectPosition.MovingObjectType.BLOCK && this.mc.objectMouseOver.getBlockPos() != null) {
            BlockPos blockpos1 = this.mc.objectMouseOver.getBlockPos();
            arraylist.add(String.format("Looking at: %d %d %d", blockpos1.getX(), blockpos1.getY(), blockpos1.getZ()));
         }
      }

      return arraylist;
   }

   // $FF: synthetic method
   void renderDebugInfo(jebac_vexiakl8zv2fyoaq8 scaledResolutionIn) {
      this.mc.mcProfiler.startSection("debug");
      GlStateManager.pushMatrix();
      this.renderDebugInfoLeft();
      this.renderDebugInfoRight(scaledResolutionIn);
      GlStateManager.popMatrix();
      this.mc.mcProfiler.endSection();
   }

   // $FF: synthetic method
   private List getDebugInfoRight() {
      long i = Runtime.getRuntime().maxMemory();
      long j = Runtime.getRuntime().totalMemory();
      long k = Runtime.getRuntime().freeMemory();
      long l = j - k;
      ArrayList arraylist = Lists.newArrayList(new String[]{String.format("Java: %s %dbit", System.getProperty("java.version"), this.mc.isJava64bit() ? 64 : 32), String.format("%2d%% %03d/%03dMB", l * 100L / i, bytesToMb(l), bytesToMb(i)), String.format("%2d%% %03dMB", j * 100L / i, bytesToMb(j))});
      if (!jebac_vexiawzpzy1x3sez8. ce) {
         arraylist.add("");
         arraylist.add("CPU: " + OpenGlHelper.func_183029_j());
         arraylist.add("");
         arraylist.add(String.format("Display: %dx%d (%s)", Display.getWidth(), Display.getHeight(), GL11.glGetString(7936)));
         arraylist.add(GL11.glGetString(7936));
         arraylist.add(GL11.glGetString(7937));
         arraylist.add(GL11.glGetString(7938));
         if (this.mc.objectMouseOver != null && this.mc.objectMouseOver.typeOfHit == MovingObjectPosition.MovingObjectType.BLOCK && this.mc.objectMouseOver.getBlockPos() != null) {
            BlockPos blockpos = this.mc.objectMouseOver.getBlockPos();
            IBlockState iblockstate = this.mc.theWorld.getBlockState(blockpos);
            if (this.mc.theWorld.getWorldType() != WorldType.DEBUG_WORLD) {
               iblockstate = iblockstate.getBlock().getActualState(iblockstate, this.mc.theWorld, blockpos);
            }

            arraylist.add("");
            arraylist.add(String.valueOf(Block.blockRegistry.getNameForObject(iblockstate.getBlock())));

            Entry entry;
            String s;
            for(UnmodifiableIterator iterator = iblockstate.getProperties().entrySet().iterator(); iterator.hasNext(); arraylist.add(((IProperty)entry.getKey()).getName() + ": " + s)) {
               entry = (Entry)iterator.next();
               s = entry.getValue().toString();
               if (entry.getValue() == Boolean.TRUE) {
                  s = EnumChatFormatting.GREEN + s;
               } else if (entry.getValue() == Boolean.FALSE) {
                  s = EnumChatFormatting.RED + s;
               }
            }
         }
      }

      return arraylist;
   }

   // $FF: synthetic method
   jebac_vexiae5jfk8o6q7be(Minecraft mc) {
      this.mc = mc;
      this.fontRenderer = mc.fontRendererObj;
   }

   // $FF: synthetic method
   private void renderDebugInfoRight(jebac_vexiakl8zv2fyoaq8 p_175239_1_) {
      List list = this.getDebugInfoRight();

      for(int i = 0; i < list.size(); ++i) {
         String s = (String)list.get(i);
         if (!Strings.isNullOrEmpty(s)) {
            int j = this.fontRenderer.FONT_HEIGHT;
            int k = this.fontRenderer.getStringWidth(s);
            int l = p_175239_1_.getScaledWidth() - 2 - k;
            int i1 = 2 + j * i;
            drawRect(l - 1, i1 - 1, l + k + 1, i1 + j - 1, -1873784752);
            this.fontRenderer.drawString(s, l, i1, 14737632);
         }
      }

   }
}
