public interface jebac_vexiaa9gjo3qagx3k {
   // $FF: synthetic method
   void confirmClicked(boolean var1, int var2);
}
