import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.resources.Language;
import net.minecraft.client.settings.GameSettings;

class jebac_vexiaoorgt2w16a1c extends jebac_vexiado18oeh2l9bq {
   // $FF: synthetic field
   private final Map languageMap;
   final jebac_vexia3qixz91tnnwf this$0;
   // $FF: synthetic field
   private final List langCodeList;

   // $FF: synthetic method
   protected void drawBackground() {
      this.this$0.drawDefaultBackground();
   }

   // $FF: synthetic method
   protected int getSize() {
      return this.langCodeList.size();
   }

   // $FF: synthetic method
   protected void elementClicked(int slotIndex, boolean isDoubleClick, int mouseX, int mouseY) {
      Language language = (Language)this.languageMap.get(this.langCodeList.get(slotIndex));
      jebac_vexia3qixz91tnnwf.access$000(this.this$0).setCurrentLanguage(language);
      jebac_vexia3qixz91tnnwf.access$100(this.this$0).language = language.getLanguageCode();
      this.mc.refreshResources();
      this.this$0.fontRendererObj.setUnicodeFlag(jebac_vexia3qixz91tnnwf.access$000(this.this$0).isCurrentLocaleUnicode() || jebac_vexia3qixz91tnnwf.access$100(this.this$0).forceUnicodeFont);
      this.this$0.fontRendererObj.setBidiFlag(jebac_vexia3qixz91tnnwf.access$000(this.this$0).isCurrentLanguageBidirectional());
      jebac_vexia3qixz91tnnwf.access$200(this.this$0).displayString = I18n.format("gui.done");
      jebac_vexia3qixz91tnnwf.access$300(this.this$0).displayString = jebac_vexia3qixz91tnnwf.access$100(this.this$0).getKeyBinding(GameSettings.Options.FORCE_UNICODE_FONT);
      jebac_vexia3qixz91tnnwf.access$100(this.this$0).saveOptions();
   }

   // $FF: synthetic method
   protected void drawSlot(int entryID, int p_180791_2_, int p_180791_3_, int p_180791_4_, int mouseXIn, int mouseYIn) {
      this.this$0.fontRendererObj.setBidiFlag(true);
      this.this$0.drawCenteredString(this.this$0.fontRendererObj, ((Language)this.languageMap.get(this.langCodeList.get(entryID))).toString(), this.width / 2, p_180791_3_ + 1, 16777215);
      this.this$0.fontRendererObj.setBidiFlag(jebac_vexia3qixz91tnnwf.access$000(this.this$0).getCurrentLanguage().isBidirectional());
   }

   // $FF: synthetic method
   protected boolean isSelected(int slotIndex) {
      return ((String)this.langCodeList.get(slotIndex)).equals(jebac_vexia3qixz91tnnwf.access$000(this.this$0).getCurrentLanguage().getLanguageCode());
   }

   // $FF: synthetic method
   public jebac_vexiaoorgt2w16a1c(jebac_vexia3qixz91tnnwf this$0, Minecraft mcIn) {
      super(mcIn, this$0.width, this$0.height, 32, this$0.height - 65 + 4, 18);
      this.this$0 = this$0;
      this.langCodeList = Lists.newArrayList();
      this.languageMap = Maps.newHashMap();
      Iterator var3 = jebac_vexia3qixz91tnnwf.access$000(this$0).getLanguages().iterator();

      while(var3.hasNext()) {
         Language language = (Language)var3.next();
         this.languageMap.put(language.getLanguageCode(), language);
         this.langCodeList.add(language.getLanguageCode());
      }

   }

   // $FF: synthetic method
   protected int getContentHeight() {
      return this.getSize() * 18;
   }
}
