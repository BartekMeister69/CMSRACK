import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.ResourceLocation;

class jebac_vexiaf51wafzwysuw extends jebac_vexiado18oeh2l9bq {
   // $FF: synthetic field
   public int field_178053_u;
   final jebac_vexiai6dbk9voxk7g this$0;

   // $FF: synthetic method
   public jebac_vexiaf51wafzwysuw(jebac_vexiai6dbk9voxk7g this$0) {
      super(this$0.mc, this$0.width, this$0.height, 80, this$0.height - 32, 38);
      this.this$0 = this$0;
      this.field_178053_u = -1;
   }

   // $FF: synthetic method
   protected void elementClicked(int slotIndex, boolean isDoubleClick, int mouseX, int mouseY) {
      this.field_178053_u = slotIndex;
      this.this$0.func_175304_a();
      jebac_vexiai6dbk9voxk7g.access$200(this.this$0).setText(((jebac_vexiantqymg43wcbp)jebac_vexiai6dbk9voxk7g.access$000().get(jebac_vexiai6dbk9voxk7g.access$100(this.this$0).field_178053_u)).field_178954_c.toString());
   }

   // $FF: synthetic method
   protected void drawBackground() {
   }

   // $FF: synthetic method
   protected boolean isSelected(int slotIndex) {
      return slotIndex == this.field_178053_u;
   }

   // $FF: synthetic method
   private void func_178051_a(int p_178051_1_, int p_178051_2_, ResourceLocation p_178051_3_) {
      int i = p_178051_1_ + 5;
      this.this$0.drawHorizontalLine(i - 1, i + 32, p_178051_2_ - 1, -2039584);
      this.this$0.drawHorizontalLine(i - 1, i + 32, p_178051_2_ + 32, -6250336);
      this.this$0.drawVerticalLine(i - 1, p_178051_2_ - 1, p_178051_2_ + 32, -2039584);
      this.this$0.drawVerticalLine(i + 32, p_178051_2_ - 1, p_178051_2_ + 32, -6250336);
      GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
      this.mc.getTextureManager().bindTexture(p_178051_3_);
      int j = true;
      int k = true;
      Tessellator tessellator = Tessellator.getInstance();
      WorldRenderer worldrenderer = tessellator.getWorldRenderer();
      worldrenderer.begin(7, DefaultVertexFormats.POSITION_TEX);
      worldrenderer.pos((double)(i + 0), (double)(p_178051_2_ + 32), 0.0D).tex(0.0D, 1.0D).endVertex();
      worldrenderer.pos((double)(i + 32), (double)(p_178051_2_ + 32), 0.0D).tex(1.0D, 1.0D).endVertex();
      worldrenderer.pos((double)(i + 32), (double)(p_178051_2_ + 0), 0.0D).tex(1.0D, 0.0D).endVertex();
      worldrenderer.pos((double)(i + 0), (double)(p_178051_2_ + 0), 0.0D).tex(0.0D, 0.0D).endVertex();
      tessellator.draw();
   }

   // $FF: synthetic method
   protected int getSize() {
      return jebac_vexiai6dbk9voxk7g.access$000().size();
   }

   // $FF: synthetic method
   protected void drawSlot(int entryID, int p_180791_2_, int p_180791_3_, int p_180791_4_, int mouseXIn, int mouseYIn) {
      jebac_vexiantqymg43wcbp guiscreencustomizepresets$info = (jebac_vexiantqymg43wcbp)jebac_vexiai6dbk9voxk7g.access$000().get(entryID);
      this.func_178051_a(p_180791_2_, p_180791_3_, guiscreencustomizepresets$info.field_178953_b);
      this.this$0.fontRendererObj.drawString(guiscreencustomizepresets$info.field_178955_a, p_180791_2_ + 32 + 10, p_180791_3_ + 14, 16777215);
   }
}
