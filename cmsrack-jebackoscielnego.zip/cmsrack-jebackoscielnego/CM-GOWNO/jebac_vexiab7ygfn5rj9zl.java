import org.lwjgl.opengl.ARBShaderObjects;

public class jebac_vexiab7ygfn5rj9zl extends jebac_vexiayjlmwpsmx1qc {
   // $FF: synthetic field
   private float[] values = new float[4];

   // $FF: synthetic method
   public void setValue(float f0, float f1, float f2, float f3) {
      if (this.getLocation() >= 0 && (this.values[0] != f0 || this.values[1] != f1 || this.values[2] != f2 || this.values[3] != f3)) {
         ARBShaderObjects.glUniform4fARB(this.getLocation(), f0, f1, f2, f3);
         jebac_vexiaflhnh80r1906.checkGLError(this.getName());
         this.values[0] = f0;
         this.values[1] = f1;
         this.values[2] = f2;
         this.values[3] = f3;
      }

   }

   // $FF: synthetic method
   protected void onProgramChanged() {
      this.values[0] = 0.0F;
      this.values[1] = 0.0F;
      this.values[2] = 0.0F;
      this.values[3] = 0.0F;
   }

   // $FF: synthetic method
   public jebac_vexiab7ygfn5rj9zl(String name) {
      super(name);
   }

   // $FF: synthetic method
   public float[] getValues() {
      return this.values;
   }
}
