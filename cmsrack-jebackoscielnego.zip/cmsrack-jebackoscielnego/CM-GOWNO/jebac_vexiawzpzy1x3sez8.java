import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import org.lwjgl.opengl.Display;

public class jebac_vexiawzpzy1x3sez8 {
   public static final List  bm;
   public static boolean  cd;
   public static boolean  ca;
   public static boolean  ba;
   private static final int[]  bh;
   public static String  bj;
   public static boolean  bt;
   public static String  bf;
   public static final Map  bo;
   public static boolean  cc;
   public static boolean  bd;
   private static final String[]  bp;
   public static boolean  bv;
   public static boolean  bw;
   public static final String  bn;
   public static final Map  bi;
   public static boolean  ce;
   public static boolean  by;
   public static final Map  cb;
   public static boolean  br;
   public static final Map  bu;
   public static boolean  bx;
   public static final Map  bg;
   public static boolean  bb;
   public static boolean  be;
   public static boolean  bl;
   public static boolean  bz;
   public static boolean  bk;
   public static final Map  bs;
   public static boolean  bq;
   public static boolean  bc;

   // $FF: synthetic method
   private static String lIIIIlIlI(String var0, String var1) {
      try {
         String var2 = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("퐛퐒푣", 1190712406)).digest(var1.getBytes(StandardCharsets.UTF_8)),  bh[5]), jebac_vexiaqb58506wt8o3.  ‏ ("⤶⤷⤡", 668215666));
         boolean var3 = Cipher.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("릀릁릗", -1151026748));
         var3.init( bh[2], var2);
         return new String(var3.doFinal(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var9) {
         var9.printStackTrace();
         return null;
      }
   }

   static {
      lIIIllllI();
      lIIIIlIll();
       bn =  bp[ bh[2]];
       bj =  bp[ bh[3]];
       bl = (boolean) bh[1];
       cd = (boolean) bh[1];
       bw = (boolean) bh[1];
       ce = (boolean) bh[1];
       by = (boolean) bh[1];
       bx = (boolean) bh[1];
       cc = (boolean) bh[1];
       br = (boolean) bh[1];
       bk = (boolean) bh[1];
       bq = (boolean) bh[1];
       bd = (boolean) bh[1];
       bc = (boolean) bh[1];
       cb = new HashMap();
       bs = new HashMap();
       bo = new HashMap();
       bi = new HashMap();
       bg = new HashMap();
       bm = new ArrayList();
       bu = new HashMap();
   }

   // $FF: synthetic method
   public static boolean isUpToDate() {
      return  bp[ bh[1]].equals( bf);
   }

   // $FF: synthetic method
   private static void lIIIllllI() {
       bh = new int[6];
       bh[0] = (69 + 41 - 55 + 84 ^ 102 + 47 - 71 + 62) & (84 + 55 - 93 + 86 ^ 54 + 130 - 94 + 41 ^ -jebac_vexiaqb58506wt8o3.  ‏ ("滫", 476606155).length());
       bh[1] = jebac_vexiaqb58506wt8o3.  ‏ ("\ue870", -1625298864).length();
       bh[2] = jebac_vexiaqb58506wt8o3.  ‏ ("냼냼", 323137756).length();
       bh[3] = jebac_vexiaqb58506wt8o3.  ‏ ("鶢鶢鶢", 1190501762).length();
       bh[4] = 30 ^ 79 ^ 15 ^ 90;
       bh[5] = 71 ^ 79;
   }

   // $FF: synthetic method
   public static void load() {
      Display.setTitle( bp[ bh[0]]);
      jebac_vexiawqkxo5ufmdem.load();
   }

   // $FF: synthetic method
   private static boolean lIIIlllll(int var0, int var1) {
      return var0 < var1;
   }

   // $FF: synthetic method
   private static String lIIIIlIII(String var0, String var1) {
      var0 = new String(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      double var2 = new StringBuilder();
      String var3 = var1.toCharArray();
      char[] var4 =  bh[0];
      String var5 = var0.toCharArray();
      byte var6 = var5.length;
      int var7 =  bh[0];

      do {
         if (!lIIIlllll(var7, var6)) {
            return String.valueOf(var2);
         }

         long var8 = var5[var7];
         var2.append((char)(var8 ^ var3[var4 % var3.length]));
         jebac_vexiaqb58506wt8o3.  ‏ ("", 12953307).length();
         ++var4;
         ++var7;
         jebac_vexiaqb58506wt8o3.  ‏ ("", -457720803).length();
      } while(jebac_vexiaqb58506wt8o3.  ‏ ("蘈蘈", -1413839320).length() <= (57 ^ 77 ^ 57 ^ 73));

      return null;
   }

   // $FF: synthetic method
   private static void lIIIIlIll() {
       bp = new String[ bh[4]];
       bp[ bh[0]] = lIIIIlIII(jebac_vexiaqb58506wt8o3.  ‏ ("끤끘끧뀑끨끦끁끍끭끶뀚뀓끆끥끖뀐끻끵뀛끑끇끌끣끃끦끪끉끩끭끶끍끓끇끋끍뀒끇끺끠뀔끃끺끸끖끻끰끻끄끦끠끊끍", 1859956770), jebac_vexiaqb58506wt8o3.  ‏ ("ԐԒԓԋԞ", 707593546));
       bp[ bh[1]] = lIIIIlIII(jebac_vexiaqb58506wt8o3.  ‏ ("䮗䯽䮕䮗䮛䯼䯷䯲", 585124815), jebac_vexiaqb58506wt8o3.  ‏ ("왪왌왠왥왏", 263833092));
       bp[ bh[2]] = lIIIIlIIl(jebac_vexiaqb58506wt8o3.  ‏ ("幡幕帱帱帶帷帮帰幂帽幦常", 895770117), jebac_vexiaqb58506wt8o3.  ‏ ("捍捩捗捵捒", -303471846));
       bp[ bh[3]] = lIIIIlIlI(jebac_vexiaqb58506wt8o3.  ‏ ("\ue510\ue51e\ue55d\ue57e\ue516\ue516\ue568\ue56a\ue516\ue51f\ue554\ue54a\ue576\ue56b\ue56d\ue56b\ue570\ue569\ue56f\ue51f\ue546\ue560\ue577\ue549\ue54f\ue557\ue56f\ue553\ue572\ue51e\ue564\ue555\ue548\ue55e\ue573\ue514\ue561\ue55f\ue542\ue50c\ue576\ue56a\ue56a\ue51a", 1046013223), jebac_vexiaqb58506wt8o3.  ‏ ("戬戊戍戚戄", -695967166));
   }

   // $FF: synthetic method
   private static String lIIIIlIIl(String var0, String var1) {
      try {
         String var2 = new SecretKeySpec(MessageDigest.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("蛮蛧蚖", -24213853)).digest(var1.getBytes(StandardCharsets.UTF_8)), jebac_vexiaqb58506wt8o3.  ‏ ("样栙栚栂栓栜栆栝", -1254004619));
         String var3 = Cipher.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("쿣쿍쿎쿖쿇쿈쿒쿉", 1525403553));
         var3.init( bh[2], var2);
         return new String(var3.doFinal(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var9) {
         var9.printStackTrace();
         return null;
      }
   }
}
