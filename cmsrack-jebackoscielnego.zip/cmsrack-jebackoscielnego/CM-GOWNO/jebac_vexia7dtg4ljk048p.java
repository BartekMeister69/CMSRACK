import java.io.IOException;
import java.io.InterruptedIOException;
import java.net.Proxy;
import java.net.URL;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

public class jebac_vexia7dtg4ljk048p {
   // $FF: synthetic field
   private static Map mapConnections = new HashMap();

   // $FF: synthetic method
   public static byte[] get(String p_get_0_) throws IOException {
      return get(p_get_0_, Proxy.NO_PROXY);
   }

   // $FF: synthetic method
   private static String makeConnectionKey(String p_makeConnectionKey_0_, int p_makeConnectionKey_1_, Proxy p_makeConnectionKey_2_) {
      String s = p_makeConnectionKey_0_ + ":" + p_makeConnectionKey_1_ + "-" + p_makeConnectionKey_2_;
      return s;
   }

   // $FF: synthetic method
   public static byte[] get(String p_get_0_, Proxy p_get_1_) throws IOException {
      jebac_vexiahtrnwedo9ob6 httprequest = makeRequest(p_get_0_, p_get_1_);
      jebac_vexiahx0fynbv9rl1 httpresponse = executeRequest(httprequest);
      if (httpresponse.getStatus() / 100 != 2) {
         throw new IOException("HTTP response: " + httpresponse.getStatus());
      } else {
         return httpresponse.getBody();
      }
   }

   // $FF: synthetic method
   public static void addRequest(jebac_vexiakzpf6k4p0kch p_addRequest_0_) {
      jebac_vexiahtrnwedo9ob6 httprequest = p_addRequest_0_.getHttpRequest();

      for(jebac_vexiam5jljwh5z5qe httppipelineconnection = getConnection(httprequest.getHost(), httprequest.getPort(), httprequest.getProxy()); !httppipelineconnection.addRequest(p_addRequest_0_); httppipelineconnection = getConnection(httprequest.getHost(), httprequest.getPort(), httprequest.getProxy())) {
         removeConnection(httprequest.getHost(), httprequest.getPort(), httprequest.getProxy(), httppipelineconnection);
      }

   }

   // $FF: synthetic method
   public static jebac_vexiahtrnwedo9ob6 makeRequest(String p_makeRequest_0_, Proxy p_makeRequest_1_) throws IOException {
      URL url = new URL(p_makeRequest_0_);
      if (!url.getProtocol().equals("http")) {
         throw new IOException("Only protocol http is supported: " + url);
      } else {
         String s = url.getFile();
         String s1 = url.getHost();
         int i = url.getPort();
         if (i <= 0) {
            i = 80;
         }

         String s2 = "GET";
         String s3 = "HTTP/1.1";
         Map map = new LinkedHashMap();
         map.put("User-Agent", "Java/" + System.getProperty("java.version"));
         map.put("Host", s1);
         map.put("Accept", "text/html, image/gif, image/png");
         map.put("Connection", "keep-alive");
         byte[] abyte = new byte[0];
         return new jebac_vexiahtrnwedo9ob6(s1, i, p_makeRequest_1_, s2, s, s3, map, abyte);
      }
   }

   // $FF: synthetic method
   private static synchronized jebac_vexiam5jljwh5z5qe getConnection(String p_getConnection_0_, int p_getConnection_1_, Proxy p_getConnection_2_) {
      String s = makeConnectionKey(p_getConnection_0_, p_getConnection_1_, p_getConnection_2_);
      jebac_vexiam5jljwh5z5qe httppipelineconnection = (jebac_vexiam5jljwh5z5qe)mapConnections.get(s);
      if (httppipelineconnection == null) {
         httppipelineconnection = new jebac_vexiam5jljwh5z5qe(p_getConnection_0_, p_getConnection_1_, p_getConnection_2_);
         mapConnections.put(s, httppipelineconnection);
      }

      return httppipelineconnection;
   }

   // $FF: synthetic method
   private static synchronized void removeConnection(String p_removeConnection_0_, int p_removeConnection_1_, Proxy p_removeConnection_2_, jebac_vexiam5jljwh5z5qe p_removeConnection_3_) {
      String s = makeConnectionKey(p_removeConnection_0_, p_removeConnection_1_, p_removeConnection_2_);
      jebac_vexiam5jljwh5z5qe httppipelineconnection = (jebac_vexiam5jljwh5z5qe)mapConnections.get(s);
      if (httppipelineconnection == p_removeConnection_3_) {
         mapConnections.remove(s);
      }

   }

   // $FF: synthetic method
   public static jebac_vexiahx0fynbv9rl1 executeRequest(jebac_vexiahtrnwedo9ob6 p_executeRequest_0_) throws IOException {
      Map map = new HashMap();
      jebac_vexiaknlf2gexq698 httplistener = new jebac_vexiaknlf2gexq698(map) {
         final Map val$map;

         // $FF: synthetic method
         public void failed(jebac_vexiahtrnwedo9ob6 p_failed_1_, Exception p_failed_2_) {
            synchronized(this.val$map) {
               this.val$map.put("Exception", p_failed_2_);
               this.val$map.notifyAll();
            }
         }

         // $FF: synthetic method
         public void finished(jebac_vexiahtrnwedo9ob6 p_finished_1_, jebac_vexiahx0fynbv9rl1 p_finished_2_) {
            synchronized(this.val$map) {
               this.val$map.put("Response", p_finished_2_);
               this.val$map.notifyAll();
            }
         }

         // $FF: synthetic method
         {
            this.val$map = var1;
         }
      };
      synchronized(map) {
         jebac_vexiakzpf6k4p0kch httppipelinerequest = new jebac_vexiakzpf6k4p0kch(p_executeRequest_0_, httplistener);
         addRequest(httppipelinerequest);

         try {
            map.wait();
         } catch (InterruptedException var8) {
            throw new InterruptedIOException("Interrupted");
         }

         Exception exception = (Exception)map.get("Exception");
         if (exception != null) {
            if (exception instanceof IOException) {
               throw (IOException)exception;
            } else if (exception instanceof RuntimeException) {
               throw (RuntimeException)exception;
            } else {
               throw new RuntimeException(exception.getMessage(), exception);
            }
         } else {
            jebac_vexiahx0fynbv9rl1 httpresponse = (jebac_vexiahx0fynbv9rl1)map.get("Response");
            if (httpresponse == null) {
               throw new IOException("Response is null");
            } else {
               return httpresponse;
            }
         }
      }
   }
}
