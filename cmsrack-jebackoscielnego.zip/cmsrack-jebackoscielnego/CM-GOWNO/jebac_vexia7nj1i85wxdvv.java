import net.minecraft.client.Minecraft;

public class jebac_vexia7nj1i85wxdvv implements jebac_vexia68uke90d57nv {
   // $FF: synthetic field
   private final jebac_vexiabhi02xzapwrh field_178029_b;
   // $FF: synthetic field
   private jebac_vexiabhi02xzapwrh field_178028_d;
   // $FF: synthetic field
   private final Minecraft field_178031_a = Minecraft.getMinecraft();
   // $FF: synthetic field
   private final jebac_vexiabhi02xzapwrh field_178030_c;

   static jebac_vexiabhi02xzapwrh access$100(jebac_vexia7nj1i85wxdvv x0) {
      return x0.field_178030_c;
   }

   // $FF: synthetic method
   private void func_178019_b(jebac_vexia4oibzo50ubf0 p_178019_1_, int p_178019_2_, int p_178019_3_, int p_178019_4_) {
      p_178019_1_.mouseReleased(p_178019_2_, p_178019_3_);
   }

   // $FF: synthetic method
   public jebac_vexia7nj1i85wxdvv(jebac_vexiabhi02xzapwrh p_i45533_1_, jebac_vexiabhi02xzapwrh p_i45533_2_) {
      this.field_178029_b = p_i45533_1_;
      this.field_178030_c = p_i45533_2_;
   }

   // $FF: synthetic method
   public jebac_vexiabhi02xzapwrh func_178022_a() {
      return this.field_178029_b;
   }

   static jebac_vexiabhi02xzapwrh access$000(jebac_vexia7nj1i85wxdvv x0) {
      return x0.field_178029_b;
   }

   // $FF: synthetic method
   private void func_178025_a(jebac_vexia8klesz79u5uq p_178025_1_, int p_178025_2_, int p_178025_3_, int p_178025_4_, boolean p_178025_5_) {
      p_178025_1_.field_146174_h = p_178025_2_;
      if (!p_178025_5_) {
         p_178025_1_.drawLabel(this.field_178031_a, p_178025_3_, p_178025_4_);
      }

   }

   // $FF: synthetic method
   private void func_178017_a(jebac_vexiabhi02xzapwrh p_178017_1_, int p_178017_2_, int p_178017_3_, int p_178017_4_, boolean p_178017_5_) {
      if (p_178017_1_ != null) {
         if (p_178017_1_ instanceof jebac_vexia4oibzo50ubf0) {
            this.func_178024_a((jebac_vexia4oibzo50ubf0)p_178017_1_, p_178017_2_, p_178017_3_, p_178017_4_, p_178017_5_);
         } else if (p_178017_1_ instanceof jebac_vexiaa29g8ikthjc5) {
            this.func_178027_a((jebac_vexiaa29g8ikthjc5)p_178017_1_, p_178017_2_, p_178017_5_);
         } else if (p_178017_1_ instanceof jebac_vexia8klesz79u5uq) {
            this.func_178025_a((jebac_vexia8klesz79u5uq)p_178017_1_, p_178017_2_, p_178017_3_, p_178017_4_, p_178017_5_);
         }
      }

   }

   // $FF: synthetic method
   private boolean func_178026_a(jebac_vexiabhi02xzapwrh p_178026_1_, int p_178026_2_, int p_178026_3_, int p_178026_4_) {
      if (p_178026_1_ == null) {
         return false;
      } else if (p_178026_1_ instanceof jebac_vexia4oibzo50ubf0) {
         return this.func_178023_a((jebac_vexia4oibzo50ubf0)p_178026_1_, p_178026_2_, p_178026_3_, p_178026_4_);
      } else {
         if (p_178026_1_ instanceof jebac_vexiaa29g8ikthjc5) {
            this.func_178018_a((jebac_vexiaa29g8ikthjc5)p_178026_1_, p_178026_2_, p_178026_3_, p_178026_4_);
         }

         return false;
      }
   }

   // $FF: synthetic method
   private void func_178016_b(jebac_vexiabhi02xzapwrh p_178016_1_, int p_178016_2_, int p_178016_3_, int p_178016_4_) {
      if (p_178016_1_ != null && p_178016_1_ instanceof jebac_vexia4oibzo50ubf0) {
         this.func_178019_b((jebac_vexia4oibzo50ubf0)p_178016_1_, p_178016_2_, p_178016_3_, p_178016_4_);
      }

   }

   // $FF: synthetic method
   public jebac_vexiabhi02xzapwrh func_178021_b() {
      return this.field_178030_c;
   }

   // $FF: synthetic method
   private boolean func_178023_a(jebac_vexia4oibzo50ubf0 p_178023_1_, int p_178023_2_, int p_178023_3_, int p_178023_4_) {
      boolean flag = p_178023_1_.mousePressed(this.field_178031_a, p_178023_2_, p_178023_3_);
      if (flag) {
         this.field_178028_d = p_178023_1_;
      }

      return flag;
   }

   // $FF: synthetic method
   private void func_178024_a(jebac_vexia4oibzo50ubf0 p_178024_1_, int p_178024_2_, int p_178024_3_, int p_178024_4_, boolean p_178024_5_) {
      p_178024_1_.yPosition = p_178024_2_;
      if (!p_178024_5_) {
         p_178024_1_.drawButton(this.field_178031_a, p_178024_3_, p_178024_4_);
      }

   }

   // $FF: synthetic method
   public void mouseReleased(int slotIndex, int x, int y, int mouseEvent, int relativeX, int relativeY) {
      this.func_178016_b(this.field_178029_b, x, y, mouseEvent);
      this.func_178016_b(this.field_178030_c, x, y, mouseEvent);
   }

   static jebac_vexiabhi02xzapwrh access$200(jebac_vexia7nj1i85wxdvv x0) {
      return x0.field_178028_d;
   }

   // $FF: synthetic method
   public void drawEntry(int slotIndex, int x, int y, int listWidth, int slotHeight, int mouseX, int mouseY, boolean isSelected) {
      this.func_178017_a(this.field_178029_b, y, mouseX, mouseY, false);
      this.func_178017_a(this.field_178030_c, y, mouseX, mouseY, false);
   }

   // $FF: synthetic method
   private void func_178018_a(jebac_vexiaa29g8ikthjc5 p_178018_1_, int p_178018_2_, int p_178018_3_, int p_178018_4_) {
      p_178018_1_.mouseClicked(p_178018_2_, p_178018_3_, p_178018_4_);
      if (p_178018_1_.isFocused()) {
         this.field_178028_d = p_178018_1_;
      }

   }

   // $FF: synthetic method
   public boolean mousePressed(int slotIndex, int p_148278_2_, int p_148278_3_, int p_148278_4_, int p_148278_5_, int p_148278_6_) {
      boolean flag = this.func_178026_a(this.field_178029_b, p_148278_2_, p_148278_3_, p_148278_4_);
      boolean flag1 = this.func_178026_a(this.field_178030_c, p_148278_2_, p_148278_3_, p_148278_4_);
      return flag || flag1;
   }

   // $FF: synthetic method
   private void func_178027_a(jebac_vexiaa29g8ikthjc5 p_178027_1_, int p_178027_2_, boolean p_178027_3_) {
      p_178027_1_.yPosition = p_178027_2_;
      if (!p_178027_3_) {
         p_178027_1_.drawTextBox();
      }

   }

   // $FF: synthetic method
   public void setSelected(int p_178011_1_, int p_178011_2_, int p_178011_3_) {
      this.func_178017_a(this.field_178029_b, p_178011_3_, 0, 0, true);
      this.func_178017_a(this.field_178030_c, p_178011_3_, 0, 0, true);
   }
}
