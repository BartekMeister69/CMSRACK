public class jebac_vexiauw6xjpymnteq {
   // $FF: synthetic field
   private jebac_vexias4ivn1c5ldsb[] ranges = new jebac_vexias4ivn1c5ldsb[0];

   // $FF: synthetic method
   public int getCountRanges() {
      return this.ranges.length;
   }

   // $FF: synthetic method
   public String toString() {
      StringBuffer stringbuffer = new StringBuffer();
      stringbuffer.append("[");

      for(int i = 0; i < this.ranges.length; ++i) {
         jebac_vexias4ivn1c5ldsb rangeint = this.ranges[i];
         if (i > 0) {
            stringbuffer.append(", ");
         }

         stringbuffer.append(rangeint.toString());
      }

      stringbuffer.append("]");
      return stringbuffer.toString();
   }

   // $FF: synthetic method
   public boolean isInRange(int p_isInRange_1_) {
      for(int i = 0; i < this.ranges.length; ++i) {
         jebac_vexias4ivn1c5ldsb rangeint = this.ranges[i];
         if (rangeint.isInRange(p_isInRange_1_)) {
            return true;
         }
      }

      return false;
   }

   // $FF: synthetic method
   public jebac_vexias4ivn1c5ldsb getRange(int p_getRange_1_) {
      return this.ranges[p_getRange_1_];
   }

   // $FF: synthetic method
   public void addRange(jebac_vexias4ivn1c5ldsb p_addRange_1_) {
      this.ranges = (jebac_vexias4ivn1c5ldsb[])((jebac_vexias4ivn1c5ldsb[])jebac_vexiakrwecfs16wve.addObjectToArray(this.ranges, p_addRange_1_));
   }
}
