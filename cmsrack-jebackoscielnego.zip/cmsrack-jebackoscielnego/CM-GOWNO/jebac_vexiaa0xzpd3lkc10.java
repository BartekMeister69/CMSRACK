import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.Socket;
import java.nio.charset.Charset;
import java.util.Iterator;
import java.util.Map;

public class jebac_vexiaa0xzpd3lkc10 extends Thread {
   // $FF: synthetic field
   private jebac_vexiam5jljwh5z5qe httpPipelineConnection = null;
   // $FF: synthetic field
   private static Charset ASCII = Charset.forName("ASCII");

   // $FF: synthetic method
   public void run() {
      jebac_vexiakzpf6k4p0kch httppipelinerequest = null;

      try {
         this.connect();

         while(!Thread.interrupted()) {
            httppipelinerequest = this.httpPipelineConnection.getNextRequestSend();
            jebac_vexiahtrnwedo9ob6 httprequest = httppipelinerequest.getHttpRequest();
            OutputStream outputstream = this.httpPipelineConnection.getOutputStream();
            this.writeRequest(httprequest, outputstream);
            this.httpPipelineConnection.onRequestSent();
         }
      } catch (InterruptedException var4) {
      } catch (Exception var5) {
         this.httpPipelineConnection.onExceptionSend(var5);
      }

   }

   // $FF: synthetic method
   public jebac_vexiaa0xzpd3lkc10(jebac_vexiam5jljwh5z5qe p_i59_1_) {
      super("HttpPipelineSender");
      this.httpPipelineConnection = p_i59_1_;
   }

   // $FF: synthetic method
   private void writeRequest(jebac_vexiahtrnwedo9ob6 p_writeRequest_1_, OutputStream p_writeRequest_2_) throws IOException {
      this.write(p_writeRequest_2_, p_writeRequest_1_.getMethod() + " " + p_writeRequest_1_.getFile() + " " + p_writeRequest_1_.getHttp() + "\r\n");
      Map map = p_writeRequest_1_.getHeaders();
      Iterator var4 = map.keySet().iterator();

      while(var4.hasNext()) {
         String s = (String)var4.next();
         String s1 = (String)p_writeRequest_1_.getHeaders().get(s);
         this.write(p_writeRequest_2_, s + ": " + s1 + "\r\n");
      }

      this.write(p_writeRequest_2_, "\r\n");
   }

   // $FF: synthetic method
   private void connect() throws IOException {
      String s = this.httpPipelineConnection.getHost();
      int i = this.httpPipelineConnection.getPort();
      Proxy proxy = this.httpPipelineConnection.getProxy();
      Socket socket = new Socket(proxy);
      socket.connect(new InetSocketAddress(s, i), 5000);
      this.httpPipelineConnection.setSocket(socket);
   }

   // $FF: synthetic method
   private void write(OutputStream p_write_1_, String p_write_2_) throws IOException {
      byte[] abyte = p_write_2_.getBytes(ASCII);
      p_write_1_.write(abyte);
   }
}
