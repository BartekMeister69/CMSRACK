import com.google.common.collect.Lists;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.resources.I18n;

public class jebac_vexianjbtt6en4mmt extends jebac_vexiakl614w3uw0xg {
   // $FF: synthetic field
   protected String confirmButtonText;
   // $FF: synthetic field
   private final List field_175298_s = Lists.newArrayList();
   // $FF: synthetic field
   protected int parentButtonClickedId;
   // $FF: synthetic field
   protected String messageLine1;
   // $FF: synthetic field
   protected jebac_vexiaa9gjo3qagx3k parentScreen;
   // $FF: synthetic field
   protected String cancelButtonText;
   // $FF: synthetic field
   private String messageLine2;
   // $FF: synthetic field
   private int ticksUntilEnable;

   // $FF: synthetic method
   protected void actionPerformed(jebac_vexia4oibzo50ubf0 button) throws IOException {
      this.parentScreen.confirmClicked(button.id == 0, this.parentButtonClickedId);
   }

   // $FF: synthetic method
   public void drawScreen(int mouseX, int mouseY, float partialTicks) {
      this.drawDefaultBackground();
      this.drawCenteredString(this.fontRendererObj, this.messageLine1, this.width / 2, 70, 16777215);
      int i = 90;

      for(Iterator var5 = this.field_175298_s.iterator(); var5.hasNext(); i += this.fontRendererObj.FONT_HEIGHT) {
         String s = (String)var5.next();
         this.drawCenteredString(this.fontRendererObj, s, this.width / 2, i, 16777215);
      }

      super.drawScreen(mouseX, mouseY, partialTicks);
   }

   // $FF: synthetic method
   public jebac_vexianjbtt6en4mmt(jebac_vexiaa9gjo3qagx3k p_i1083_1_, String p_i1083_2_, String p_i1083_3_, String p_i1083_4_, String p_i1083_5_, int p_i1083_6_) {
      this.parentScreen = p_i1083_1_;
      this.messageLine1 = p_i1083_2_;
      this.messageLine2 = p_i1083_3_;
      this.confirmButtonText = p_i1083_4_;
      this.cancelButtonText = p_i1083_5_;
      this.parentButtonClickedId = p_i1083_6_;
   }

   // $FF: synthetic method
   public jebac_vexianjbtt6en4mmt(jebac_vexiaa9gjo3qagx3k p_i1082_1_, String p_i1082_2_, String p_i1082_3_, int p_i1082_4_) {
      this.parentScreen = p_i1082_1_;
      this.messageLine1 = p_i1082_2_;
      this.messageLine2 = p_i1082_3_;
      this.parentButtonClickedId = p_i1082_4_;
      this.confirmButtonText = I18n.format("gui.yes");
      this.cancelButtonText = I18n.format("gui.no");
   }

   // $FF: synthetic method
   public void setButtonDelay(int p_146350_1_) {
      this.ticksUntilEnable = p_146350_1_;

      jebac_vexia4oibzo50ubf0 guibutton;
      for(Iterator var2 = this.buttonList.iterator(); var2.hasNext(); guibutton.enabled = false) {
         guibutton = (jebac_vexia4oibzo50ubf0)var2.next();
      }

   }

   // $FF: synthetic method
   public void initGui() {
      this.buttonList.add(new jebac_vexiatgc7sxy17ln0(0, this.width / 2 - 155, this.height / 6 + 96, this.confirmButtonText));
      this.buttonList.add(new jebac_vexiatgc7sxy17ln0(1, this.width / 2 - 155 + 160, this.height / 6 + 96, this.cancelButtonText));
      this.field_175298_s.clear();
      this.field_175298_s.addAll(this.fontRendererObj.listFormattedStringToWidth(this.messageLine2, this.width - 50));
   }

   // $FF: synthetic method
   public void updateScreen() {
      super.updateScreen();
      jebac_vexia4oibzo50ubf0 guibutton;
      if (--this.ticksUntilEnable == 0) {
         for(Iterator var1 = this.buttonList.iterator(); var1.hasNext(); guibutton.enabled = true) {
            guibutton = (jebac_vexia4oibzo50ubf0)var1.next();
         }
      }

   }
}
