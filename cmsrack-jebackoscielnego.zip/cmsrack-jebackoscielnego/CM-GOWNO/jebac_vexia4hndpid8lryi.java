import net.minecraft.client.resources.I18n;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.util.EnumChatFormatting;

public class jebac_vexia4hndpid8lryi implements jebac_vexia68uke90d57nv {
   // $FF: synthetic field
   private final KeyBinding keybinding;
   // $FF: synthetic field
   private final String keyDesc;
   // $FF: synthetic field
   private final jebac_vexia4oibzo50ubf0 btnChangeKeyBinding;
   // $FF: synthetic field
   private final jebac_vexia4oibzo50ubf0 btnReset;
   final jebac_vexiac2ntje0zuqwe this$0;

   // $FF: synthetic method
   public boolean mousePressed(int slotIndex, int p_148278_2_, int p_148278_3_, int p_148278_4_, int p_148278_5_, int p_148278_6_) {
      if (this.btnChangeKeyBinding.mousePressed(jebac_vexiac2ntje0zuqwe.access$100(this.this$0), p_148278_2_, p_148278_3_)) {
         jebac_vexiac2ntje0zuqwe.access$200(this.this$0).buttonId = this.keybinding;
         return true;
      } else if (this.btnReset.mousePressed(jebac_vexiac2ntje0zuqwe.access$100(this.this$0), p_148278_2_, p_148278_3_)) {
         jebac_vexiac2ntje0zuqwe.access$100(this.this$0).gameSettings.setOptionKeyBinding(this.keybinding, this.keybinding.getKeyCodeDefault());
         KeyBinding.resetKeyBindingArrayAndHash();
         return true;
      } else {
         return false;
      }
   }

   // $FF: synthetic method
   public void setSelected(int p_178011_1_, int p_178011_2_, int p_178011_3_) {
   }

   // $FF: synthetic method
   private jebac_vexia4hndpid8lryi(jebac_vexiac2ntje0zuqwe this$0, KeyBinding p_i45029_2_) {
      this.this$0 = this$0;
      this.keybinding = p_i45029_2_;
      this.keyDesc = I18n.format(p_i45029_2_.getKeyDescription());
      this.btnChangeKeyBinding = new jebac_vexia4oibzo50ubf0(0, 0, 0, 75, 20, I18n.format(p_i45029_2_.getKeyDescription()));
      this.btnReset = new jebac_vexia4oibzo50ubf0(0, 0, 0, 50, 20, I18n.format("controls.reset"));
   }

   // $FF: synthetic method
   public void drawEntry(int slotIndex, int x, int y, int listWidth, int slotHeight, int mouseX, int mouseY, boolean isSelected) {
      boolean flag = jebac_vexiac2ntje0zuqwe.access$200(this.this$0).buttonId == this.keybinding;
      jebac_vexiac2ntje0zuqwe.access$100(this.this$0).fontRendererObj.drawString(this.keyDesc, x + 90 - jebac_vexiac2ntje0zuqwe.access$300(this.this$0), y + slotHeight / 2 - jebac_vexiac2ntje0zuqwe.access$100(this.this$0).fontRendererObj.FONT_HEIGHT / 2, 16777215);
      this.btnReset.xPosition = x + 190;
      this.btnReset.yPosition = y;
      this.btnReset.enabled = this.keybinding.getKeyCode() != this.keybinding.getKeyCodeDefault();
      this.btnReset.drawButton(jebac_vexiac2ntje0zuqwe.access$100(this.this$0), mouseX, mouseY);
      this.btnChangeKeyBinding.xPosition = x + 105;
      this.btnChangeKeyBinding.yPosition = y;
      this.btnChangeKeyBinding.displayString = GameSettings.getKeyDisplayString(this.keybinding.getKeyCode());
      boolean flag1 = false;
      if (this.keybinding.getKeyCode() != 0) {
         KeyBinding[] var11 = jebac_vexiac2ntje0zuqwe.access$100(this.this$0).gameSettings.keyBindings;
         int var12 = var11.length;

         for(int var13 = 0; var13 < var12; ++var13) {
            KeyBinding keybinding = var11[var13];
            if (keybinding != this.keybinding && keybinding.getKeyCode() == this.keybinding.getKeyCode()) {
               flag1 = true;
               break;
            }
         }
      }

      if (flag) {
         this.btnChangeKeyBinding.displayString = EnumChatFormatting.WHITE + "> " + EnumChatFormatting.YELLOW + this.btnChangeKeyBinding.displayString + EnumChatFormatting.WHITE + " <";
      } else if (flag1) {
         this.btnChangeKeyBinding.displayString = EnumChatFormatting.RED + this.btnChangeKeyBinding.displayString;
      }

      this.btnChangeKeyBinding.drawButton(jebac_vexiac2ntje0zuqwe.access$100(this.this$0), mouseX, mouseY);
   }

   // $FF: synthetic method
   public void mouseReleased(int slotIndex, int x, int y, int mouseEvent, int relativeX, int relativeY) {
      this.btnChangeKeyBinding.mouseReleased(x, y);
      this.btnReset.mouseReleased(x, y);
   }

   jebac_vexia4hndpid8lryi(jebac_vexiac2ntje0zuqwe x0, KeyBinding x1, Object x2) {
      this(x0, x1);
   }
}
