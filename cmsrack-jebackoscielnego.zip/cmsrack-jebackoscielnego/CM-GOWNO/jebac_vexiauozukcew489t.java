import com.google.common.collect.Lists;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.GameSettings;

public class jebac_vexiauozukcew489t extends jebac_vexiadrxrz0b4x3gp {
   // $FF: synthetic field
   private final List field_148184_k = Lists.newArrayList();

   // $FF: synthetic method
   public jebac_vexia4vw9pdgkxjsi getListEntry(int index) {
      return (jebac_vexia4vw9pdgkxjsi)this.field_148184_k.get(index);
   }

   // $FF: synthetic method
   protected int getScrollBarX() {
      return super.getScrollBarX() + 32;
   }

   // $FF: synthetic method
   public jebac_vexiauozukcew489t(Minecraft mcIn, int p_i45015_2_, int p_i45015_3_, int p_i45015_4_, int p_i45015_5_, int p_i45015_6_, GameSettings.Options... p_i45015_7_) {
      super(mcIn, p_i45015_2_, p_i45015_3_, p_i45015_4_, p_i45015_5_, p_i45015_6_);
      this.field_148163_i = false;

      for(int i = 0; i < p_i45015_7_.length; i += 2) {
         GameSettings.Options gamesettings$options = p_i45015_7_[i];
         GameSettings.Options gamesettings$options1 = i < p_i45015_7_.length - 1 ? p_i45015_7_[i + 1] : null;
         jebac_vexia4oibzo50ubf0 guibutton = this.func_148182_a(mcIn, p_i45015_2_ / 2 - 155, 0, gamesettings$options);
         jebac_vexia4oibzo50ubf0 guibutton1 = this.func_148182_a(mcIn, p_i45015_2_ / 2 - 155 + 160, 0, gamesettings$options1);
         this.field_148184_k.add(new jebac_vexia4vw9pdgkxjsi(guibutton, guibutton1));
      }

   }

   // $FF: synthetic method
   private jebac_vexia4oibzo50ubf0 func_148182_a(Minecraft mcIn, int p_148182_2_, int p_148182_3_, GameSettings.Options p_148182_4_) {
      if (p_148182_4_ == null) {
         return null;
      } else {
         int i = p_148182_4_.returnEnumOrdinal();
         return (jebac_vexia4oibzo50ubf0)(p_148182_4_.getEnumFloat() ? new jebac_vexiakfzkq5wmes2e(i, p_148182_2_, p_148182_3_, p_148182_4_) : new jebac_vexiatgc7sxy17ln0(i, p_148182_2_, p_148182_3_, p_148182_4_, mcIn.gameSettings.getKeyBinding(p_148182_4_)));
      }
   }

   // $FF: synthetic method
   public int getListWidth() {
      return 400;
   }

   // $FF: synthetic method
   protected int getSize() {
      return this.field_148184_k.size();
   }
}
