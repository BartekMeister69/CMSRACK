import com.google.common.base.Objects;
import java.util.List;

public class jebac_vexiam1glxj46m3t5 {
   // $FF: synthetic field
   private final jebac_vexialqxnhsad8zg7 field_178684_a;
   // $FF: synthetic field
   private final List field_178682_b;
   // $FF: synthetic field
   private final int field_178683_c;

   // $FF: synthetic method
   public jebac_vexia9nzh0zm3n32z func_178680_a(int p_178680_1_) {
      return p_178680_1_ >= 0 && p_178680_1_ < this.field_178682_b.size() ? (jebac_vexia9nzh0zm3n32z)Objects.firstNonNull(this.field_178682_b.get(p_178680_1_), jebac_vexiabhmyylutxyzx.field_178657_a) : jebac_vexiabhmyylutxyzx.field_178657_a;
   }

   // $FF: synthetic method
   public jebac_vexiam1glxj46m3t5(jebac_vexialqxnhsad8zg7 p_i45494_1_, List p_i45494_2_, int p_i45494_3_) {
      this.field_178684_a = p_i45494_1_;
      this.field_178682_b = p_i45494_2_;
      this.field_178683_c = p_i45494_3_;
   }

   // $FF: synthetic method
   public int func_178681_b() {
      return this.field_178683_c;
   }
}
