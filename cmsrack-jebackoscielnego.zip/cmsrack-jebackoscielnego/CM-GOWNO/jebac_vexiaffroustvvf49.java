import java.awt.Color;
import net.minecraft.client.Minecraft;

public class jebac_vexiaffroustvvf49 {
   public boolean  ju;
   private final jebac_vexiah20udy2hhvcs  js;
   private static final int[]  jr;
   public Color  jo;
   public int  jn;
   public boolean  jp;
   private final jebac_vexia27mgp7j2ixa8[]  jm;
   private final jebac_vexiakl0q9pjjpdbc[]  jt;
   public int  jq;

   // $FF: synthetic method
   private static boolean llIIIIll(int var0, int var1) {
      return var0 < var1;
   }

   // $FF: synthetic method
   public jebac_vexiaffroustvvf49(Minecraft var1) {
      this. jo = Color.WHITE;
      this. jp = (boolean) jr[0];
      this. jt = new jebac_vexiakl0q9pjjpdbc[ jr[1]];
      this. jt[ jr[2]] = new jebac_vexiakl0q9pjjpdbc(var1.gameSettings.keyBindForward,  jr[3],  jr[4]);
      this. jt[ jr[0]] = new jebac_vexiakl0q9pjjpdbc(var1.gameSettings.keyBindBack,  jr[3],  jr[3]);
      this. jt[ jr[4]] = new jebac_vexiakl0q9pjjpdbc(var1.gameSettings.keyBindLeft,  jr[4],  jr[3]);
      this. jt[ jr[5]] = new jebac_vexiakl0q9pjjpdbc(var1.gameSettings.keyBindRight,  jr[6],  jr[3]);
      this. js = new jebac_vexiah20udy2hhvcs(var1.gameSettings.keyBindJump,  jr[4],  jr[6]);
      this. jm = new jebac_vexia27mgp7j2ixa8[ jr[4]];
      this. jm[ jr[2]] = new jebac_vexia27mgp7j2ixa8( jr[2],  jr[4],  jr[7]);
      this. jm[ jr[0]] = new jebac_vexia27mgp7j2ixa8( jr[0],  jr[8],  jr[7]);
   }

   // $FF: synthetic method
   private static void llIIIIIl() {
       jr = new int[11];
       jr[0] = jebac_vexiaqb58506wt8o3.  ‏ ("嘵", -1520282091).length();
       jr[1] = (59 ^ 49) & ~(5 ^ 15) ^ 4 ^ 0;
       jr[2] = (182 ^ 142) & ~(166 ^ 158);
       jr[3] = 98 + 146 - 219 + 160 ^ 17 + 130 - 138 + 154;
       jr[4] = jebac_vexiaqb58506wt8o3.  ‏ ("㷵㷵", 223559125).length();
       jr[5] = jebac_vexiaqb58506wt8o3.  ‏ ("\uedc0\uedc0\uedc0", -1929712160).length();
       jr[6] = 115 ^ 47 ^ 196 ^ 170;
       jr[7] = 203 + 154 - 321 + 181 ^ 133 + 131 - 213 + 106;
       jr[8] = 1 ^ 39;
       jr[9] = -(-11787 & 15914) & -16385 & 24511;
       jr[10] = 69 + 47 - 37 + 57 ^ 71 + 59 - 98 + 103;
   }

   // $FF: synthetic method
   private static boolean llIIIIlI(int var0) {
      return var0 != 0;
   }

   static {
      llIIIIIl();
   }

   // $FF: synthetic method
   public void render() {
      int var3;
      if (llIIIIlI(this. ju)) {
         Color var1 = jebac_vexiacs3qcki5ln4n.getRainbow( jr[9],  jr[10]);
         jebac_vexiakl0q9pjjpdbc[] var2 = this. jt;
         var3 = var2.length;
         int var4 =  jr[2];

         while(llIIIIll(var4, var3)) {
            long var5 = var2[var4];
            var5.render(this. jq, this. jn, var1);
            ++var4;
            jebac_vexiaqb58506wt8o3.  ‏ ("", -1366147710).length();
            if ((jebac_vexiaqb58506wt8o3.  ‏ ("噕", 1397905013).length() & (jebac_vexiaqb58506wt8o3.  ‏ ("\ud8ed", 1877334221).length() ^ -jebac_vexiaqb58506wt8o3.  ‏ ("➼", -1945491556).length())) > jebac_vexiaqb58506wt8o3.  ‏ ("\u0fdd\u0fdd\u0fdd", 688263165).length()) {
               return;
            }
         }

         this. js.render(this. jq, this. jn, var1);
         jebac_vexia27mgp7j2ixa8[] var14 = this. jm;
         var3 = var14.length;
         var4 =  jr[2];

         while(llIIIIll(var4, var3)) {
            long var17 = var14[var4];
            var17.render(this. jq, this. jn, var1);
            ++var4;
            jebac_vexiaqb58506wt8o3.  ‏ ("", -810052281).length();
            if ((121 + 35 - 107 + 89 ^ 99 + 47 - 144 + 140) < (98 + 60 - 34 + 10 ^ 43 + 108 - 52 + 31)) {
               return;
            }
         }

         jebac_vexiaqb58506wt8o3.  ‏ ("", -1763439934).length();
         if (((131 + 149 - 237 + 114 ^ 52 + 9 - -9 + 93) & (98 ^ 20 ^ 67 ^ 11 ^ -jebac_vexiaqb58506wt8o3.  ‏ ("깰", 1586802256).length())) != 0) {
            return;
         }
      } else {
         jebac_vexiakl0q9pjjpdbc[] var12 = this. jt;
         int var15 = var12.length;
         var3 =  jr[2];

         while(llIIIIll(var3, var15)) {
            jebac_vexiaffroustvvf49 var16 = var12[var3];
            var16.render(this. jq, this. jn, this. jo);
            ++var3;
            jebac_vexiaqb58506wt8o3.  ‏ ("", 828712291).length();
            if (-jebac_vexiaqb58506wt8o3.  ‏ ("讐讐讐", 306285488).length() >= 0) {
               return;
            }
         }

         this. js.render(this. jq, this. jn, this. jo);
         jebac_vexia27mgp7j2ixa8[] var13 = this. jm;
         var15 = var13.length;
         var3 =  jr[2];

         while(llIIIIll(var3, var15)) {
            jebac_vexiaffroustvvf49 var18 = var13[var3];
            var18.render(this. jq, this. jn, this. jo);
            ++var3;
            jebac_vexiaqb58506wt8o3.  ‏ ("", 861911443).length();
            if ((33 ^ 42 ^ 48 ^ 63) != (217 ^ 160 ^ 255 ^ 130)) {
               return;
            }
         }
      }

   }
}
