import java.util.Arrays;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.settings.KeyBinding;
import org.apache.commons.lang3.ArrayUtils;

public class jebac_vexiac2ntje0zuqwe extends jebac_vexiadrxrz0b4x3gp {
   // $FF: synthetic field
   private int maxListLabelWidth = 0;
   // $FF: synthetic field
   private final Minecraft mc;
   // $FF: synthetic field
   private final jebac_vexiagvtc62j0hqov field_148191_k;
   // $FF: synthetic field
   private final jebac_vexia68uke90d57nv[] listEntries;

   static Minecraft access$100(jebac_vexiac2ntje0zuqwe x0) {
      return x0.mc;
   }

   // $FF: synthetic method
   protected int getSize() {
      return this.listEntries.length;
   }

   // $FF: synthetic method
   public jebac_vexiac2ntje0zuqwe(jebac_vexiagvtc62j0hqov controls, Minecraft mcIn) {
      super(mcIn, controls.width, controls.height, 63, controls.height - 32, 20);
      this.field_148191_k = controls;
      this.mc = mcIn;
      KeyBinding[] akeybinding = (KeyBinding[])ArrayUtils.clone(mcIn.gameSettings.keyBindings);
      this.listEntries = new jebac_vexia68uke90d57nv[akeybinding.length + KeyBinding.getKeybinds().size()];
      Arrays.sort(akeybinding);
      int i = 0;
      String s = null;
      KeyBinding[] var6 = akeybinding;
      int var7 = akeybinding.length;

      for(int var8 = 0; var8 < var7; ++var8) {
         KeyBinding keybinding = var6[var8];
         String s1 = keybinding.getKeyCategory();
         if (!s1.equals(s)) {
            s = s1;
            this.listEntries[i++] = new jebac_vexiaw7psy44d35ek(this, s1);
         }

         int j = mcIn.fontRendererObj.getStringWidth(I18n.format(keybinding.getKeyDescription()));
         if (j > this.maxListLabelWidth) {
            this.maxListLabelWidth = j;
         }

         this.listEntries[i++] = new jebac_vexia4hndpid8lryi(this, keybinding);
      }

   }

   static int access$300(jebac_vexiac2ntje0zuqwe x0) {
      return x0.maxListLabelWidth;
   }

   static jebac_vexiagvtc62j0hqov access$200(jebac_vexiac2ntje0zuqwe x0) {
      return x0.field_148191_k;
   }

   // $FF: synthetic method
   public int getListWidth() {
      return super.getListWidth() + 32;
   }

   // $FF: synthetic method
   protected int getScrollBarX() {
      return super.getScrollBarX() + 15;
   }

   // $FF: synthetic method
   public jebac_vexia68uke90d57nv getListEntry(int index) {
      return this.listEntries[index];
   }
}
