import com.jagrosh.discordipc.IPCClient;
import com.jagrosh.discordipc.IPCListener;
import com.jagrosh.discordipc.entities.RichPresence;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.OffsetDateTime;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Util;

public class jebac_vexianc7xib017k15 {
   private static final int[]  dm;

   // $FF: synthetic method
   private static boolean lIlIIlII(Object var0, Object var1) {
      return var0 == var1;
   }

   static {
      lIlIIIll();
   }

   // $FF: synthetic method
   public static void start(Minecraft var0) {
      if (lIlIIlII(Util.getOSType(), Util.EnumOS.WINDOWS)) {
         jebac_vexiawzpzy1x3sez8. bt = (boolean) dm[0];
         short var1 = new IPCClient(680342768781885440L);
         var1.setListener(new IPCListener(var0) {
            private static final int[]  cx;
            private static final String[]  cw;
            final Minecraft  cy;

            // $FF: synthetic method
            private static boolean lIlllll(int var0, int var1) {
               return var0 < var1;
            }

            // $FF: synthetic method
            private static String lIIlIII(String var0, String var1) {
               try {
                  String var2 = new SecretKeySpec(MessageDigest.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("\ue7b8\ue7b1\ue7c0", 407824373)).digest(var1.getBytes(StandardCharsets.UTF_8)), jebac_vexiaqb58506wt8o3.  ‏ ("өӇӄӜӍӂӘӃ", -716307285));
                  float var3 = Cipher.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("⍻⍕⍖⍎⍟⍐⍊⍑", 254747449));
                  var3.init( cx[2], var2);
                  return new String(var3.doFinal(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
               } catch (Exception var9) {
                  var9.printStackTrace();
                  return null;
               }
            }

            // $FF: synthetic method
            private static boolean lIlllIl(Object var0) {
               return var0 != null;
            }

            // $FF: synthetic method
            private static void lIIllIl() {
                cw = new String[ cx[6]];
                cw[ cx[0]] = lIIIlll(jebac_vexiaqb58506wt8o3.  ‏ ("\uf4e4\uf4e1\uf498\uf499\uf4e7\uf486\uf4e1\uf499\uf4bd\uf496\uf4a5\uf4ef", 1332933842), jebac_vexiaqb58506wt8o3.  ‏ ("≵≟≟≧≮", -935321050));
                cw[ cx[1]] = lIIlIII(jebac_vexiaqb58506wt8o3.  ‏ ("ᲡᲛ᳅ᲙᲱᲞᲐᲀᲞ᳁ᲇᲟᲑ\u1cbb᳇ᲖᲥᲠᲠᲜ᳁Ე\u1cce\u1cce", 813636851), jebac_vexiaqb58506wt8o3.  ‏ ("ꏗꏟꏾꏄꏷ", -2074434660));
                cw[ cx[2]] = lIIlIlI(jebac_vexiaqb58506wt8o3.  ‏ ("鬣鬟鬦鬮鬤鬌魞鬏", 1684839271), jebac_vexiaqb58506wt8o3.  ‏ ("炙遼六率紐", -1758529094));
                cw[ cx[3]] = lIIlIII(jebac_vexiaqb58506wt8o3.  ‏ ("담닯니늊늋닮늌닛늌닗단닦닙닲늈당니닧닌늋니니늂늂", -236014913), jebac_vexiaqb58506wt8o3.  ‏ ("ᤩᤂᤴᤖᤂ", -30009019));
                cw[ cx[4]] = lIIlIII(jebac_vexiaqb58506wt8o3.  ‏ ("\udb29\udb5c\udb79\udb5b\udb49\udb2f\udb66\udb7d\udb46\udb5a\udb6d\udb4b\udb69\udb7c\udb46\udb75\udb7b\udb7b\udb67\udb66\udb7c\udb4f\udb23\udb23", -226567394), jebac_vexiaqb58506wt8o3.  ‏ ("\uedd8\uedc4\uedd4\uede6\uede1", -2087522912));
                cw[ cx[5]] = lIIlIlI(jebac_vexiaqb58506wt8o3.  ‏ ("읡읺읈읎읩읇윗읷일읭읮읉읧읇읺읨읫읇윛윒", 2073741103), jebac_vexiaqb58506wt8o3.  ‏ ("ᆽᆷᆨᆬᆮ", -563998241));
            }

            // $FF: synthetic method
            private static String lIIIlll(String var0, String var1) {
               try {
                  String var2 = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("멸멱먀", 488553013)).digest(var1.getBytes(StandardCharsets.UTF_8)),  cx[7]), jebac_vexiaqb58506wt8o3.  ‏ ("환홙홏", 1069143580));
                  double var3 = Cipher.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("ⰲⰳⰥ", 525806710));
                  var3.init( cx[2], var2);
                  return new String(var3.doFinal(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
               } catch (Exception var9) {
                  var9.printStackTrace();
                  return null;
               }
            }

            // $FF: synthetic method
            private static boolean lIlllII(int var0) {
               return var0 == 0;
            }

            // $FF: synthetic method
            private static String lIIlIlI(String var0, String var1) {
               var0 = new String(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
               byte var2 = new StringBuilder();
               float var3 = var1.toCharArray();
               int var4 =  cx[0];
               String var5 = var0.toCharArray();
               char[] var6 = var5.length;
               int var7 =  cx[0];

               do {
                  if (!lIlllll(var7, var6)) {
                     return String.valueOf(var2);
                  }

                  float var8 = var5[var7];
                  var2.append((char)(var8 ^ var3[var4 % var3.length]));
                  jebac_vexiaqb58506wt8o3.  ‏ ("", 770903285).length();
                  ++var4;
                  ++var7;
                  jebac_vexiaqb58506wt8o3.  ‏ ("", -1410705595).length();
               } while((128 + 76 - 85 + 51 ^ 148 + 56 - 180 + 151) > 0);

               return null;
            }

            // $FF: synthetic method
            private static boolean lIllllI(int var0) {
               return var0 != 0;
            }

            // $FF: synthetic method
            public void onReady(IPCClient var1) {
               <undefinedtype> var2 = new RichPresence.Builder();
               var2.setStartTimestamp(OffsetDateTime.now()).setLargeImage( cw[ cx[0]],  cw[ cx[1]]);
               jebac_vexiaqb58506wt8o3.  ‏ ("", -863871573).length();
               (new Thread(<undefinedtype>::lambda$onReady$0)).start();
            }

            // $FF: synthetic method
            private static void lIllIll() {
                cx = new int[8];
                cx[0] = (47 ^ 77) & ~(194 ^ 160);
                cx[1] = jebac_vexiaqb58506wt8o3.  ‏ ("꒗", -1358715721).length();
                cx[2] = jebac_vexiaqb58506wt8o3.  ‏ ("윩윩", 1426769673).length();
                cx[3] = jebac_vexiaqb58506wt8o3.  ‏ ("笶笶笶", 535132950).length();
                cx[4] = 132 ^ 128;
                cx[5] = 85 ^ 80;
                cx[6] = 93 ^ 91;
                cx[7] = 6 ^ 14;
            }

            private static void lambda$onReady$0(IPCClient var0, RichPresence.Builder var1, Minecraft var2) {
               while(!lIlllII(jebac_vexiawzpzy1x3sez8. bt)) {
                  RichPresence.Builder var10000 = var1.setState(String.valueOf((new StringBuilder()).append( cw[ cx[2]]).append(var2.getSession().getUsername())));
                  String var10001;
                  if (lIlllIl(var2.getCurrentServerData())) {
                     var10001 = String.valueOf((new StringBuilder()).append( cw[ cx[3]]).append(var2.getCurrentServerData().serverIP));
                     jebac_vexiaqb58506wt8o3.  ‏ ("", 1997488534).length();
                     if (jebac_vexiaqb58506wt8o3.  ‏ ("鰕鰕鰕", 54631477).length() <= jebac_vexiaqb58506wt8o3.  ‏ ("鼾鼾", 289251102).length()) {
                        return;
                     }
                  } else if (lIllllI(var2.isSingleplayer())) {
                     var10001 =  cw[ cx[4]];
                     jebac_vexiaqb58506wt8o3.  ‏ ("", -1248172558).length();
                     if ((128 ^ 132 ^ (43 ^ 73) & ~(5 ^ 103)) == -jebac_vexiaqb58506wt8o3.  ‏ ("趪", -1930523254).length()) {
                        return;
                     }
                  } else {
                     var10001 =  cw[ cx[5]];
                  }

                  var10000.setDetails(var10001);
                  jebac_vexiaqb58506wt8o3.  ‏ ("", 680853235).length();
                  var0.sendRichPresence(var1.build());

                  try {
                     Thread.sleep(1000L);
                  } catch (InterruptedException var8) {
                     jebac_vexiaqb58506wt8o3.  ‏ ("", 664471776).length();
                     if (null == null) {
                        continue;
                     }

                     return;
                  }

                  jebac_vexiaqb58506wt8o3.  ‏ ("", 1544977449).length();
                  if (-jebac_vexiaqb58506wt8o3.  ‏ ("ĄĄĄ", -1308819164).length() >= 0) {
                     return;
                  }
               }

               var0.close();
               throw new ThreadDeath();
            }

            static {
               lIllIll();
               lIIllIl();
            }

            // $FF: synthetic method
            {
               this. cy = var1;
            }
         });

         try {
            var1.connect();
         } catch (Exception var6) {
            jebac_vexiawzpzy1x3sez8. bt = (boolean) dm[1];
            return;
         }

         jebac_vexiaqb58506wt8o3.  ‏ ("", 812560277).length();
         if (jebac_vexiaqb58506wt8o3.  ‏ ("ʀʀ", -1725234528).length() != jebac_vexiaqb58506wt8o3.  ‏ ("㌞㌞", -1880411330).length()) {
            return;
         }
      }

   }

   // $FF: synthetic method
   private static void lIlIIIll() {
       dm = new int[2];
       dm[0] = jebac_vexiaqb58506wt8o3.  ‏ ("\uee9e", 323874494).length();
       dm[1] = (152 + 149 - 165 + 21 ^ 19 + 84 - 27 + 61) & (16 ^ 5 ^ jebac_vexiaqb58506wt8o3.  ‏ ("ᘖ", -845867466).length() ^ -jebac_vexiaqb58506wt8o3.  ‏ ("畹", -728861351).length());
   }
}
