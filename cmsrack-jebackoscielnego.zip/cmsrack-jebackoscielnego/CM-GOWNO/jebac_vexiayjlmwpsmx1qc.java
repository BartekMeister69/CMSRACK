import org.lwjgl.opengl.ARBShaderObjects;

public abstract class jebac_vexiayjlmwpsmx1qc {
   // $FF: synthetic field
   private int program = -1;
   // $FF: synthetic field
   private String name;
   // $FF: synthetic field
   private int location = -1;

   // $FF: synthetic method
   public jebac_vexiayjlmwpsmx1qc(String name) {
      this.name = name;
   }

   // $FF: synthetic method
   public String getName() {
      return this.name;
   }

   // $FF: synthetic method
   public void setProgram(int program) {
      if (this.program != program) {
         this.program = program;
         this.location = ARBShaderObjects.glGetUniformLocationARB(program, this.name);
         this.onProgramChanged();
      }

   }

   // $FF: synthetic method
   public boolean isDefined() {
      return this.location >= 0;
   }

   // $FF: synthetic method
   protected abstract void onProgramChanged();

   // $FF: synthetic method
   public int getLocation() {
      return this.location;
   }
}
