import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.client.renderer.chunk.RenderChunk;
import net.minecraft.util.EnumFacing;

public class jebac_vexiazhnfufv0gwzu {
   // $FF: synthetic field
   private RenderGlobal.ContainerLocalRenderInformation renderInfo;
   // $FF: synthetic field
   private RenderChunk renderChunk;

   // $FF: synthetic method
   public RenderGlobal.ContainerLocalRenderInformation getRenderInfo() {
      if (this.renderInfo == null) {
         this.renderInfo = new RenderGlobal.ContainerLocalRenderInformation(this.renderChunk, (EnumFacing)null, 0);
      }

      return this.renderInfo;
   }

   // $FF: synthetic method
   public void setRenderChunk(RenderChunk p_setRenderChunk_1_) {
      this.renderChunk = p_setRenderChunk_1_;
      this.renderInfo = null;
   }
}
