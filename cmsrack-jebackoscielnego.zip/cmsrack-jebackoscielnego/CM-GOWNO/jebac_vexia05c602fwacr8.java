import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class jebac_vexia05c602fwacr8 extends jebac_vexiakl614w3uw0xg {
   private static final String[]  a;
   private static final int[]  b;
   private final float  c;

   // $FF: synthetic method
   protected void keyTyped(char var1, int var2) throws IOException {
   }

   static {
      lIIIlIlIl();
      lIIIIIIII();
   }

   // $FF: synthetic method
   private static String llllllIl(String var0, String var1) {
      try {
         SecretKeySpec var2 = new SecretKeySpec(MessageDigest.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("곣곪겛", 1742974126)).digest(var1.getBytes(StandardCharsets.UTF_8)), jebac_vexiaqb58506wt8o3.  ‏ ("Ⅲ⅌⅏⅗ⅆⅉ⅓ⅈ", 1952719136));
         long var3 = Cipher.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("\uddb4\udd9a\udd99\udd81\udd90\udd9f\udd85\udd9e", 1681907190));
         var3.init( b[1], var2);
         return new String(var3.doFinal(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var9) {
         var9.printStackTrace();
         return null;
      }
   }

   // $FF: synthetic method
   private static String lllllllI(String var0, String var1) {
      try {
         SecretKeySpec var2 = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("톸톱퇀", 1350685173)).digest(var1.getBytes(StandardCharsets.UTF_8)),  b[10]), jebac_vexiaqb58506wt8o3.  ‏ ("ᘋᘊᘜ", 213521999));
         String var3 = Cipher.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("劵労劢", -957984015));
         var3.init( b[1], var2);
         return new String(var3.doFinal(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var9) {
         var9.printStackTrace();
         return null;
      }
   }

   // $FF: synthetic method
   private static int lIIIlIllI(float var0, float var1) {
      float var2;
      return (var2 = var0 - var1) == 0.0F ? 0 : (var2 < 0.0F ? -1 : 1);
   }

   // $FF: synthetic method
   private static void lIIIlIlIl() {
       b = new int[11];
       b[0] = (103 + 28 - -1 + 0 ^ 103 + 118 - 206 + 121) & (119 ^ 92 ^ 96 ^ 71 ^ -jebac_vexiaqb58506wt8o3.  ‏ ("蛒", 1859815154).length());
       b[1] = jebac_vexiaqb58506wt8o3.  ‏ ("\uda5a\uda5a", -840312198).length();
       b[2] = 92 ^ 50;
       b[3] = -1 & 16777215;
       b[4] = jebac_vexiaqb58506wt8o3.  ‏ ("沎", 650276014).length();
       b[5] = jebac_vexiaqb58506wt8o3.  ‏ ("ᎴᎴᎴ", -1013312620).length();
       b[6] = 245 ^ 185 ^ 24 ^ 44;
       b[7] = 52 ^ 48;
       b[8] = 46 + 22 - -35 + 27;
       b[9] = 71 + 135 - 46 + 20 ^ 120 + 53 - 83 + 87;
       b[10] = 117 ^ 32 ^ 156 ^ 193;
   }

   // $FF: synthetic method
   private static boolean lIIIllIII(int var0, int var1) {
      return var0 < var1;
   }

   // $FF: synthetic method
   private static boolean lIIIlIlll(int var0) {
      return var0 == 0;
   }

   // $FF: synthetic method
   public jebac_vexia05c602fwacr8(float var1) {
      this. c = var1;
   }

   // $FF: synthetic method
   private static String llllllII(String var0, String var1) {
      var0 = new String(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder var2 = new StringBuilder();
      char[] var3 = var1.toCharArray();
      boolean var4 = jebac_vexia05c602fwacr8. b[0];
      char var5 = var0.toCharArray();
      int var6 = var5.length;
      int var7 = jebac_vexia05c602fwacr8. b[0];

      do {
         if (!lIIIllIII(var7, var6)) {
            return String.valueOf(var2);
         }

         String var8 = var5[var7];
         var2.append((char)(var8 ^ var3[var4 % var3.length]));
         jebac_vexiaqb58506wt8o3.  ‏ ("", 1782387743).length();
         ++var4;
         ++var7;
         jebac_vexiaqb58506wt8o3.  ‏ ("", -1735915151).length();
      } while(null == null);

      return null;
   }

   // $FF: synthetic method
   public void drawScreen(int var1, int var2, float var3) {
      this.drawDefaultBackground();
      this.drawCenteredString(this.fontRendererObj,  a[ b[0]], this.width /  b[1],  b[2],  b[3]);
      this.drawCenteredString(this.fontRendererObj, String.valueOf((new StringBuilder()).append( a[ b[4]]).append((new DecimalFormat( a[ b[1]])).format((double)this. c)).append( a[ b[5]])), this.width /  b[1],  b[6],  b[3]);
      if (lIIIlIlll(lIIIlIllI(this. c, 100.0F))) {
         this.drawCenteredString(this.fontRendererObj,  a[ b[7]], this.width /  b[1],  b[8],  b[3]);
      }

      super.drawScreen(var1, var2, var3);
   }

   // $FF: synthetic method
   private static void lIIIIIIII() {
       a = new String[ b[9]];
       a[ b[0]] = llllllII(jebac_vexiaqb58506wt8o3.  ‏ ("۫ہی۩۷ۑ۪۟۶ۓڋێ۵۾ڃۂۼۿ۶ېۿۑڃۚ۫ۯۺ۶۴۩ۋۖ", -1763899717), jebac_vexiaqb58506wt8o3.  ‏ ("裬裐裰裄裒", 1950058627));
       a[ b[4]] = llllllIl(jebac_vexiaqb58506wt8o3.  ‏ ("⟨⟬⟚⟠⟧⟲⟅➌⟪⟌⟶⟶⟂⟅⟌⟐⟨➛⟑⟙⟁➓⟕⟧⟴➓⟫⟊⟐⟇⟪⟊", -1442830429), jebac_vexiaqb58506wt8o3.  ‏ ("㶪㶫㶔㶴㶉", 1637498305));
       a[ b[1]] = lllllllI(jebac_vexiaqb58506wt8o3.  ‏ ("鍭錂鍥鍮鍅鍮鍁鍺錀鍚鍇錉", -599813324), jebac_vexiaqb58506wt8o3.  ‏ ("樵樵樚樕樓", -1475581316));
       a[ b[5]] = lllllllI(jebac_vexiaqb58506wt8o3.  ‏ ("㷷㷇㷗㷭㷄㷳㷉㷇㷢㶖㶛㶞", 2003254691), jebac_vexiaqb58506wt8o3.  ‏ ("蹓蹐蹓蹁蹮", -1494315495));
       a[ b[7]] = lllllllI(jebac_vexiaqb58506wt8o3.  ‏ ("ᱨᱲᱽ\u1c38\u1c38ᱩᱝᱦ᱓ᱮ᱙ᱬᰲᱰᱞ\u1c38᱂ᱡ᱆᱀᱉᱁ᱮ᱘ᱢ᱅ᱍᱬᰡᱥ᱿ᰡ", -390259702), jebac_vexiaqb58506wt8o3.  ‏ ("ꃉꃋꃏꃸꃕ", -374497124));
   }
}
