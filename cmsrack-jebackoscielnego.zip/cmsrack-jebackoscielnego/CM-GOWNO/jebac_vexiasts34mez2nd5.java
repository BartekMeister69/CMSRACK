public class jebac_vexiasts34mez2nd5 extends jebac_vexiankaoys7sjdxd {
   // $FF: synthetic field
   public static final String[] PROPERTY_VALUES = new String[]{"default", "true", "false"};
   // $FF: synthetic field
   public static final String[] USER_VALUES = new String[]{"Default", "ON", "OFF"};

   // $FF: synthetic method
   public boolean isTrue() {
      return this.getValue() == 1;
   }

   // $FF: synthetic method
   public String getUserValue() {
      return this.isDefault() ? jebac_vexia7gzdvsc1kfyf.getDefault() : (this.isTrue() ? jebac_vexia7gzdvsc1kfyf.getOn() : (this.isFalse() ? jebac_vexia7gzdvsc1kfyf.getOff() : super.getUserValue()));
   }

   // $FF: synthetic method
   public jebac_vexiasts34mez2nd5(String propertyName, String userName, int defaultValue) {
      super(propertyName, PROPERTY_VALUES, userName, USER_VALUES, defaultValue);
   }

   // $FF: synthetic method
   public boolean isFalse() {
      return this.getValue() == 2;
   }

   // $FF: synthetic method
   public boolean isDefault() {
      return this.getValue() == 0;
   }
}
