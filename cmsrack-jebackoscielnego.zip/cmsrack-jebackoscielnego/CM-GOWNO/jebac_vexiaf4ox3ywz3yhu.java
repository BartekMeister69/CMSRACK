import net.minecraft.client.resources.I18n;

class jebac_vexiaf4ox3ywz3yhu extends jebac_vexia72k5sdirsh7v {
   final jebac_vexiajrsmxgnpvxgq this$0;

   // $FF: synthetic method
   public void drawButtonForegroundLayer(int mouseX, int mouseY) {
      jebac_vexiajrsmxgnpvxgq.access$100(this.this$0, I18n.format("gui.cancel"), mouseX, mouseY);
   }

   // $FF: synthetic method
   public jebac_vexiaf4ox3ywz3yhu(jebac_vexiajrsmxgnpvxgq this$0, int p_i1074_2_, int p_i1074_3_, int p_i1074_4_) {
      super(p_i1074_2_, p_i1074_3_, p_i1074_4_, jebac_vexiajrsmxgnpvxgq.access$000(), 112, 220);
      this.this$0 = this$0;
   }
}
