import net.minecraft.util.IChatComponent;

public class jebac_vexiayl7wu3tqnekm {
   // $FF: synthetic field
   private final IChatComponent lineString;
   // $FF: synthetic field
   private final int updateCounterCreated;
   // $FF: synthetic field
   private final int chatLineID;

   // $FF: synthetic method
   public jebac_vexiayl7wu3tqnekm(int p_i45000_1_, IChatComponent p_i45000_2_, int p_i45000_3_) {
      this.lineString = p_i45000_2_;
      this.updateCounterCreated = p_i45000_1_;
      this.chatLineID = p_i45000_3_;
   }

   // $FF: synthetic method
   public int getUpdatedCounter() {
      return this.updateCounterCreated;
   }

   // $FF: synthetic method
   public IChatComponent getChatComponent() {
      return this.lineString;
   }

   // $FF: synthetic method
   public int getChatLineID() {
      return this.chatLineID;
   }
}
