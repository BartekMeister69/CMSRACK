import java.util.Iterator;
import net.minecraft.util.BlockPos;
import net.minecraft.util.Vec3;

public class jebac_vexiaofeelg9ae69d implements Iterator {
   // $FF: synthetic field
   private jebac_vexiaow5hep5yfvoy iteratorAxis;
   // $FF: synthetic field
   private int kX;
   // $FF: synthetic field
   private int kZ;
   // $FF: synthetic field
   private int axis = 0;
   // $FF: synthetic field
   private int kY;
   // $FF: synthetic field
   private jebac_vexiaisxd96hccl8m blockPos = new jebac_vexiaisxd96hccl8m(0, 0, 0);

   // $FF: synthetic method
   public jebac_vexiaofeelg9ae69d(BlockPos posStart, BlockPos posEnd, int width, int height) {
      boolean flag = posStart.getX() > posEnd.getX();
      boolean flag1 = posStart.getY() > posEnd.getY();
      boolean flag2 = posStart.getZ() > posEnd.getZ();
      posStart = this.reverseCoord(posStart, flag, flag1, flag2);
      posEnd = this.reverseCoord(posEnd, flag, flag1, flag2);
      this.kX = flag ? -1 : 1;
      this.kY = flag1 ? -1 : 1;
      this.kZ = flag2 ? -1 : 1;
      Vec3 vec3 = new Vec3((double)(posEnd.getX() - posStart.getX()), (double)(posEnd.getY() - posStart.getY()), (double)(posEnd.getZ() - posStart.getZ()));
      Vec3 vec31 = vec3.normalize();
      Vec3 vec32 = new Vec3(1.0D, 0.0D, 0.0D);
      double d0 = vec31.dotProduct(vec32);
      double d1 = Math.abs(d0);
      Vec3 vec33 = new Vec3(0.0D, 1.0D, 0.0D);
      double d2 = vec31.dotProduct(vec33);
      double d3 = Math.abs(d2);
      Vec3 vec34 = new Vec3(0.0D, 0.0D, 1.0D);
      double d4 = vec31.dotProduct(vec34);
      double d5 = Math.abs(d4);
      BlockPos blockpos;
      BlockPos blockpos1;
      int i;
      double d6;
      double d7;
      if (d5 >= d3 && d5 >= d1) {
         this.axis = 2;
         blockpos = new BlockPos(posStart.getZ(), posStart.getY() - width, posStart.getX() - height);
         blockpos1 = new BlockPos(posEnd.getZ(), posStart.getY() + width + 1, posStart.getX() + height + 1);
         i = posEnd.getZ() - posStart.getZ();
         d6 = (double)(posEnd.getY() - posStart.getY()) / (1.0D * (double)i);
         d7 = (double)(posEnd.getX() - posStart.getX()) / (1.0D * (double)i);
         this.iteratorAxis = new jebac_vexiaow5hep5yfvoy(blockpos, blockpos1, d6, d7);
      } else if (d3 >= d1 && d3 >= d5) {
         this.axis = 1;
         blockpos = new BlockPos(posStart.getY(), posStart.getX() - width, posStart.getZ() - height);
         blockpos1 = new BlockPos(posEnd.getY(), posStart.getX() + width + 1, posStart.getZ() + height + 1);
         i = posEnd.getY() - posStart.getY();
         d6 = (double)(posEnd.getX() - posStart.getX()) / (1.0D * (double)i);
         d7 = (double)(posEnd.getZ() - posStart.getZ()) / (1.0D * (double)i);
         this.iteratorAxis = new jebac_vexiaow5hep5yfvoy(blockpos, blockpos1, d6, d7);
      } else {
         this.axis = 0;
         blockpos = new BlockPos(posStart.getX(), posStart.getY() - width, posStart.getZ() - height);
         blockpos1 = new BlockPos(posEnd.getX(), posStart.getY() + width + 1, posStart.getZ() + height + 1);
         i = posEnd.getX() - posStart.getX();
         d6 = (double)(posEnd.getY() - posStart.getY()) / (1.0D * (double)i);
         d7 = (double)(posEnd.getZ() - posStart.getZ()) / (1.0D * (double)i);
         this.iteratorAxis = new jebac_vexiaow5hep5yfvoy(blockpos, blockpos1, d6, d7);
      }

   }

   // $FF: synthetic method
   public boolean hasNext() {
      return this.iteratorAxis.hasNext();
   }

   // $FF: synthetic method
   private BlockPos reverseCoord(BlockPos pos, boolean revX, boolean revY, boolean revZ) {
      if (revX) {
         pos = new BlockPos(-pos.getX(), pos.getY(), pos.getZ());
      }

      if (revY) {
         pos = new BlockPos(pos.getX(), -pos.getY(), pos.getZ());
      }

      if (revZ) {
         pos = new BlockPos(pos.getX(), pos.getY(), -pos.getZ());
      }

      return pos;
   }

   // $FF: synthetic method
   public void remove() {
      throw new RuntimeException("Not supported");
   }

   // $FF: synthetic method
   public BlockPos next() {
      BlockPos blockpos = this.iteratorAxis.next();
      switch(this.axis) {
      case 1:
         this.blockPos.setXyz(blockpos.getY() * this.kX, blockpos.getX() * this.kY, blockpos.getZ() * this.kZ);
         return this.blockPos;
      case 2:
         this.blockPos.setXyz(blockpos.getZ() * this.kX, blockpos.getY() * this.kY, blockpos.getX() * this.kZ);
         return this.blockPos;
      default:
         this.blockPos.setXyz(blockpos.getX() * this.kX, blockpos.getY() * this.kY, blockpos.getZ() * this.kZ);
         return this.blockPos;
      }
   }
}
