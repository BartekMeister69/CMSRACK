public class jebac_vexiao69nzag0tqzs {
   // $FF: synthetic method
   public static jebac_vexiazrxtvwdcml9w getShaderOption(String name, jebac_vexiazrxtvwdcml9w[] opts) {
      if (opts == null) {
         return null;
      } else {
         jebac_vexiazrxtvwdcml9w[] var2 = opts;
         int var3 = opts.length;

         for(int var4 = 0; var4 < var3; ++var4) {
            jebac_vexiazrxtvwdcml9w shaderoption = var2[var4];
            if (shaderoption.getName().equals(name)) {
               return shaderoption;
            }
         }

         return null;
      }
   }

   // $FF: synthetic method
   public static jebac_vexiai4ghla0oxuww detectProfile(jebac_vexiai4ghla0oxuww[] profs, jebac_vexiazrxtvwdcml9w[] opts, boolean def) {
      if (profs == null) {
         return null;
      } else {
         jebac_vexiai4ghla0oxuww[] var3 = profs;
         int var4 = profs.length;

         for(int var5 = 0; var5 < var4; ++var5) {
            jebac_vexiai4ghla0oxuww shaderprofile = var3[var5];
            if (matchProfile(shaderprofile, opts, def)) {
               return shaderprofile;
            }
         }

         return null;
      }
   }

   // $FF: synthetic method
   public static boolean matchProfile(jebac_vexiai4ghla0oxuww prof, jebac_vexiazrxtvwdcml9w[] opts, boolean def) {
      if (prof == null) {
         return false;
      } else if (opts == null) {
         return false;
      } else {
         String[] astring = prof.getOptions();
         String[] var4 = astring;
         int var5 = astring.length;

         for(int var6 = 0; var6 < var5; ++var6) {
            String s = var4[var6];
            jebac_vexiazrxtvwdcml9w shaderoption = getShaderOption(s, opts);
            if (shaderoption != null) {
               String s1 = def ? shaderoption.getValueDefault() : shaderoption.getValue();
               String s2 = prof.getValue(s);
               if (!jebac_vexiakrwecfs16wve.equals(s1, s2)) {
                  return false;
               }
            }
         }

         return true;
      }
   }
}
