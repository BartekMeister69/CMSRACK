import net.minecraft.client.Minecraft;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.IChatComponent;

class jebac_vexia73a0lnekw3k0 implements jebac_vexia9nzh0zm3n32z {
   jebac_vexia73a0lnekw3k0(Object x0) {
      this();
   }

   // $FF: synthetic method
   public boolean func_178662_A_() {
      return true;
   }

   // $FF: synthetic method
   private jebac_vexia73a0lnekw3k0() {
   }

   // $FF: synthetic method
   public void func_178663_a(float p_178663_1_, int alpha) {
      Minecraft.getMinecraft().getTextureManager().bindTexture(jebac_vexia4ygfqd1m48f0.field_175269_a);
      jebac_vexiabhi02xzapwrh.drawModalRectWithCustomSizedTexture(0, 0, 128.0F, 0.0F, 16, 16, 256.0F, 256.0F);
   }

   // $FF: synthetic method
   public void func_178661_a(jebac_vexiabhmyylutxyzx menu) {
      menu.func_178641_d();
   }

   // $FF: synthetic method
   public IChatComponent getSpectatorName() {
      return new ChatComponentText("Close menu");
   }
}
