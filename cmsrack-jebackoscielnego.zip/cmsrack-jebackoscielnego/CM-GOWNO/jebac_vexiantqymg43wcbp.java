import net.minecraft.util.ResourceLocation;
import net.minecraft.world.gen.ChunkProviderSettings;

class jebac_vexiantqymg43wcbp {
   // $FF: synthetic field
   public String field_178955_a;
   // $FF: synthetic field
   public ChunkProviderSettings.Factory field_178954_c;
   // $FF: synthetic field
   public ResourceLocation field_178953_b;

   // $FF: synthetic method
   public jebac_vexiantqymg43wcbp(String p_i45523_1_, ResourceLocation p_i45523_2_, ChunkProviderSettings.Factory p_i45523_3_) {
      this.field_178955_a = p_i45523_1_;
      this.field_178953_b = p_i45523_2_;
      this.field_178954_c = p_i45523_3_;
   }
}
