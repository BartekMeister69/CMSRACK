import java.util.BitSet;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.state.BlockStateBase;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.renderer.BlockModelRenderer;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.renderer.block.model.BreakingFour;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.world.IBlockAccess;

public class jebac_vexiai2kawx8j8o7a {
   // $FF: synthetic field
   private BitSet boundsFlags;
   // $FF: synthetic field
   private boolean[] borderFlags;
   // $FF: synthetic field
   private BlockModelRenderer.AmbientOcclusionFace aoFace;
   // $FF: synthetic field
   private int breakingAnimation = -1;
   // $FF: synthetic field
   private float[] quadBounds;
   // $FF: synthetic field
   private static ThreadLocal threadLocalInstance = new ThreadLocal();
   // $FF: synthetic field
   private jebac_vexiaisxd96hccl8m colorizerBlockPosM;
   // $FF: synthetic field
   private IBlockState blockState;
   // $FF: synthetic field
   private int metadata = -1;
   // $FF: synthetic field
   private int blockId = -1;

   // $FF: synthetic method
   public int getMetadata() {
      if (this.metadata < 0) {
         if (this.blockState instanceof BlockStateBase) {
            BlockStateBase blockstatebase = (BlockStateBase)this.blockState;
            this.metadata = blockstatebase.getMetadata();
         } else {
            this.metadata = this.blockState.getBlock().getMetaFromState(this.blockState);
         }
      }

      return this.metadata;
   }

   // $FF: synthetic method
   public jebac_vexiaisxd96hccl8m getColorizerBlockPosM() {
      if (this.colorizerBlockPosM == null) {
         this.colorizerBlockPosM = new jebac_vexiaisxd96hccl8m(0, 0, 0);
      }

      return this.colorizerBlockPosM;
   }

   // $FF: synthetic method
   private void reset(IBlockState p_reset_2_) {
      this.blockState = p_reset_2_;
      this.blockId = -1;
      this.metadata = -1;
      this.breakingAnimation = -1;
      this.boundsFlags.clear();
   }

   // $FF: synthetic method
   public boolean isBreakingAnimation() {
      return this.breakingAnimation == 1;
   }

   // $FF: synthetic method
   public boolean[] getBorderFlags() {
      if (this.borderFlags == null) {
         this.borderFlags = new boolean[4];
      }

      return this.borderFlags;
   }

   // $FF: synthetic method
   public BlockModelRenderer.AmbientOcclusionFace getAoFace() {
      return this.aoFace;
   }

   // $FF: synthetic method
   public boolean isBreakingAnimation(List p_isBreakingAnimation_1_) {
      if (this.breakingAnimation < 0 && p_isBreakingAnimation_1_.size() > 0) {
         if (p_isBreakingAnimation_1_.get(0) instanceof BreakingFour) {
            this.breakingAnimation = 1;
         } else {
            this.breakingAnimation = 0;
         }
      }

      return this.breakingAnimation == 1;
   }

   // $FF: synthetic method
   public float[] getQuadBounds() {
      return this.quadBounds;
   }

   // $FF: synthetic method
   public boolean isBreakingAnimation(BakedQuad p_isBreakingAnimation_1_) {
      if (this.breakingAnimation < 0) {
         if (p_isBreakingAnimation_1_ instanceof BreakingFour) {
            this.breakingAnimation = 1;
         } else {
            this.breakingAnimation = 0;
         }
      }

      return this.breakingAnimation == 1;
   }

   // $FF: synthetic method
   private jebac_vexiai2kawx8j8o7a(IBlockState p_i94_2_) {
      this.quadBounds = new float[EnumFacing.VALUES.length * 2];
      this.boundsFlags = new BitSet(3);
      this.aoFace = new BlockModelRenderer.AmbientOcclusionFace();
      this.colorizerBlockPosM = null;
      this.borderFlags = null;
      this.blockState = p_i94_2_;
   }

   // $FF: synthetic method
   public IBlockState getBlockState() {
      return this.blockState;
   }

   // $FF: synthetic method
   public static jebac_vexiai2kawx8j8o7a getInstance(IBlockAccess p_getInstance_0_, IBlockState p_getInstance_1_, BlockPos p_getInstance_2_) {
      jebac_vexiai2kawx8j8o7a renderenv = (jebac_vexiai2kawx8j8o7a)threadLocalInstance.get();
      if (renderenv == null) {
         renderenv = new jebac_vexiai2kawx8j8o7a(p_getInstance_1_);
         threadLocalInstance.set(renderenv);
         return renderenv;
      } else {
         renderenv.reset(p_getInstance_1_);
         return renderenv;
      }
   }

   // $FF: synthetic method
   public int getBlockId() {
      if (this.blockId < 0) {
         if (this.blockState instanceof BlockStateBase) {
            BlockStateBase blockstatebase = (BlockStateBase)this.blockState;
            this.blockId = blockstatebase.getBlockId();
         } else {
            this.blockId = Block.getIdFromBlock(this.blockState.getBlock());
         }
      }

      return this.blockId;
   }

   // $FF: synthetic method
   public BitSet getBoundsFlags() {
      return this.boundsFlags;
   }
}
