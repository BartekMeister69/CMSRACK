import net.minecraft.entity.player.EnumPlayerModelParts;

class jebac_vexiawc5yr2ltwc4z extends jebac_vexia4oibzo50ubf0 {
   // $FF: synthetic field
   private final EnumPlayerModelParts playerModelParts;
   final jebac_vexiatozk0nk2gvma this$0;

   jebac_vexiawc5yr2ltwc4z(jebac_vexiatozk0nk2gvma x0, int x1, int x2, int x3, int x4, int x5, EnumPlayerModelParts x6, Object x7) {
      this(x0, x1, x2, x3, x4, x5, x6);
   }

   static EnumPlayerModelParts access$100(jebac_vexiawc5yr2ltwc4z x0) {
      return x0.playerModelParts;
   }

   // $FF: synthetic method
   private jebac_vexiawc5yr2ltwc4z(jebac_vexiatozk0nk2gvma this$0, int p_i45514_2_, int p_i45514_3_, int p_i45514_4_, int p_i45514_5_, int p_i45514_6_, EnumPlayerModelParts playerModelParts) {
      super(p_i45514_2_, p_i45514_3_, p_i45514_4_, p_i45514_5_, p_i45514_6_, jebac_vexiatozk0nk2gvma.access$200(this$0, playerModelParts));
      this.this$0 = this$0;
      this.playerModelParts = playerModelParts;
   }
}
