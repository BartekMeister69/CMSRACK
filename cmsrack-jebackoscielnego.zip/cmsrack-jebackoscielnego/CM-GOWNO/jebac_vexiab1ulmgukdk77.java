import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import net.minecraft.client.renderer.texture.ITextureObject;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;

public class jebac_vexiab1ulmgukdk77 {
   // $FF: synthetic field
   private static jebac_vexia6uw791mvay6k[][] worldSkyLayers = (jebac_vexia6uw791mvay6k[][])null;

   // $FF: synthetic method
   public static void update() {
      reset();
      if (jebac_vexiakrwecfs16wve.isCustomSky()) {
         worldSkyLayers = readCustomSkies();
      }

   }

   // $FF: synthetic method
   private static jebac_vexia6uw791mvay6k[][] readCustomSkies() {
      jebac_vexia6uw791mvay6k[][] acustomskylayer = new jebac_vexia6uw791mvay6k[10][0];
      String s = "mcpatcher/sky/world";
      int i = -1;

      int j;
      for(j = 0; j < acustomskylayer.length; ++j) {
         String s1 = s + j + "/sky";
         List list = new ArrayList();

         for(int k = 1; k < 1000; ++k) {
            String s2 = s1 + k + ".properties";

            try {
               ResourceLocation resourcelocation = new ResourceLocation(s2);
               InputStream inputstream = jebac_vexiakrwecfs16wve.getResourceStream(resourcelocation);
               if (inputstream == null) {
                  break;
               }

               Properties properties = new Properties();
               properties.load(inputstream);
               inputstream.close();
               jebac_vexiakrwecfs16wve.dbg("CustomSky properties: " + s2);
               String s3 = s1 + k + ".png";
               jebac_vexia6uw791mvay6k customskylayer = new jebac_vexia6uw791mvay6k(properties, s3);
               if (customskylayer.isValid(s2)) {
                  ResourceLocation resourcelocation1 = new ResourceLocation(customskylayer.source);
                  ITextureObject itextureobject = jebac_vexiamg04e8zzk81s.getTexture(resourcelocation1);
                  if (itextureobject == null) {
                     jebac_vexiakrwecfs16wve.log("CustomSky: Texture not found: " + resourcelocation1);
                  } else {
                     customskylayer.textureId = itextureobject.getGlTextureId();
                     list.add(customskylayer);
                     inputstream.close();
                  }
               }
            } catch (FileNotFoundException var15) {
               break;
            } catch (IOException var16) {
               var16.printStackTrace();
            }
         }

         if (list.size() > 0) {
            jebac_vexia6uw791mvay6k[] acustomskylayer2 = (jebac_vexia6uw791mvay6k[])((jebac_vexia6uw791mvay6k[])list.toArray(new jebac_vexia6uw791mvay6k[0]));
            acustomskylayer[j] = acustomskylayer2;
            i = j;
         }
      }

      if (i < 0) {
         return (jebac_vexia6uw791mvay6k[][])null;
      } else {
         j = i + 1;
         jebac_vexia6uw791mvay6k[][] acustomskylayer1 = new jebac_vexia6uw791mvay6k[j][0];
         System.arraycopy(acustomskylayer, 0, acustomskylayer1, 0, acustomskylayer1.length);
         return acustomskylayer1;
      }
   }

   // $FF: synthetic method
   public static void reset() {
      worldSkyLayers = (jebac_vexia6uw791mvay6k[][])null;
   }

   // $FF: synthetic method
   public static void renderSky(World p_renderSky_0_, float p_renderSky_2_, float p_renderSky_3_) {
      if (worldSkyLayers != null && jebac_vexiakrwecfs16wve.getGameSettings().renderDistanceChunks >= 8) {
         int i = p_renderSky_0_.provider.getDimensionId();
         if (i >= 0 && i < worldSkyLayers.length) {
            jebac_vexia6uw791mvay6k[] acustomskylayer = worldSkyLayers[i];
            if (acustomskylayer != null) {
               long j = p_renderSky_0_.getWorldTime();
               int k = (int)(j % 24000L);
               jebac_vexia6uw791mvay6k[] var8 = acustomskylayer;
               int var9 = acustomskylayer.length;

               for(int var10 = 0; var10 < var9; ++var10) {
                  jebac_vexia6uw791mvay6k customskylayer = var8[var10];
                  if (customskylayer.isActive(p_renderSky_0_, k)) {
                     customskylayer.render(k, p_renderSky_2_, p_renderSky_3_);
                  }
               }

               jebac_vexiau5kgy2fm1nlm.clearBlend(p_renderSky_3_);
            }
         }
      }

   }

   // $FF: synthetic method
   public static boolean hasSkyLayers(World p_hasSkyLayers_0_) {
      if (worldSkyLayers == null) {
         return false;
      } else if (jebac_vexiakrwecfs16wve.getGameSettings().renderDistanceChunks < 8) {
         return false;
      } else {
         int i = p_hasSkyLayers_0_.provider.getDimensionId();
         if (i >= 0 && i < worldSkyLayers.length) {
            jebac_vexia6uw791mvay6k[] acustomskylayer = worldSkyLayers[i];
            return acustomskylayer != null && acustomskylayer.length > 0;
         } else {
            return false;
         }
      }
   }
}
