import net.minecraft.item.Item;

class jebac_vexiaup8pelpglzd6 {
   // $FF: synthetic field
   public Item field_148234_a;
   // $FF: synthetic field
   public int field_179037_b;
   // $FF: synthetic field
   public String field_148233_c;
   // $FF: synthetic field
   public String field_148232_b;

   // $FF: synthetic method
   public jebac_vexiaup8pelpglzd6(Item p_i45518_1_, int p_i45518_2_, String p_i45518_3_, String p_i45518_4_) {
      this.field_148234_a = p_i45518_1_;
      this.field_179037_b = p_i45518_2_;
      this.field_148232_b = p_i45518_3_;
      this.field_148233_c = p_i45518_4_;
   }
}
