public class jebac_vexiaahfk36d5geld extends jebac_vexiamee1xbabsk4e {
   // $FF: synthetic field
   private final boolean field_178941_a;

   // $FF: synthetic method
   public jebac_vexiaahfk36d5geld(int p_i45535_1_, String p_i45535_2_, boolean p_i45535_3_, boolean p_i45535_4_) {
      super(p_i45535_1_, p_i45535_2_, p_i45535_3_);
      this.field_178941_a = p_i45535_4_;
   }

   // $FF: synthetic method
   public boolean func_178940_a() {
      return this.field_178941_a;
   }
}
