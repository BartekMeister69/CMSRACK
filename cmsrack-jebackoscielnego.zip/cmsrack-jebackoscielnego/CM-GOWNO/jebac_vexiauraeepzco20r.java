class jebac_vexiauraeepzco20r extends jebac_vexiado18oeh2l9bq {
   final jebac_vexialkppcl8ymvgi this$0;

   // $FF: synthetic method
   protected int getScrollBarX() {
      return this.width - 10;
   }

   // $FF: synthetic method
   protected void drawBackground() {
   }

   // $FF: synthetic method
   protected boolean isSelected(int slotIndex) {
      return false;
   }

   // $FF: synthetic method
   protected void drawSlot(int entryID, int p_180791_2_, int p_180791_3_, int p_180791_4_, int mouseXIn, int mouseYIn) {
      this.this$0.fontRendererObj.drawString((String)jebac_vexialkppcl8ymvgi.access$000(this.this$0).get(entryID), 10, p_180791_3_, 16777215);
      this.this$0.fontRendererObj.drawString((String)jebac_vexialkppcl8ymvgi.access$100(this.this$0).get(entryID), 230, p_180791_3_, 16777215);
   }

   // $FF: synthetic method
   protected void elementClicked(int slotIndex, boolean isDoubleClick, int mouseX, int mouseY) {
   }

   // $FF: synthetic method
   public jebac_vexiauraeepzco20r(jebac_vexialkppcl8ymvgi this$0) {
      super(this$0.mc, this$0.width, this$0.height, 80, this$0.height - 40, this$0.fontRendererObj.FONT_HEIGHT + 1);
      this.this$0 = this$0;
   }

   // $FF: synthetic method
   protected int getSize() {
      return jebac_vexialkppcl8ymvgi.access$000(this.this$0).size();
   }
}
