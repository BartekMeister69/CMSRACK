public interface jebac_vexiatghjrcxoegiy {
   // $FF: synthetic method
   void func_175321_a(int var1, boolean var2);

   // $FF: synthetic method
   void onTick(int var1, float var2);

   // $FF: synthetic method
   void func_175319_a(int var1, String var2);
}
