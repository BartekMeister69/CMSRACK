import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.io.File;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.renderer.IImageBuffer;
import net.minecraft.client.renderer.ThreadDownloadImageData;
import net.minecraft.client.renderer.texture.ITextureObject;
import net.minecraft.client.renderer.texture.SimpleTexture;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.util.ResourceLocation;
import org.apache.commons.io.FilenameUtils;

public class jebac_vexiaglb4k1d2jvpm {
   // $FF: synthetic method
   public static BufferedImage parseCape(BufferedImage image) {
      int i = 64;
      int j = 32;
      int k = image.getWidth();

      for(int l = image.getHeight(); i < k || j < l; j *= 2) {
         i *= 2;
      }

      BufferedImage bufferedimage = new BufferedImage(i, j, 2);
      Graphics graphics = bufferedimage.getGraphics();
      graphics.drawImage(image, 0, 0, (ImageObserver)null);
      graphics.dispose();
      return bufferedimage;
   }

   // $FF: synthetic method
   public static void downloadCape(AbstractClientPlayer player) {
      String s = player.getNameClear();
      if (s != null && !s.isEmpty()) {
         String s1 = jebac_vexiawzpzy1x3sez8. bj + s + ".png";
         String s2 = FilenameUtils.getBaseName(s1);
         ResourceLocation resourcelocation = new ResourceLocation("capeof/" + s2);
         TextureManager texturemanager = Minecraft.getMinecraft().getTextureManager();
         ITextureObject itextureobject = texturemanager.getTexture(resourcelocation);
         if (itextureobject instanceof ThreadDownloadImageData) {
            ThreadDownloadImageData threaddownloadimagedata = (ThreadDownloadImageData)itextureobject;
            if (threaddownloadimagedata.imageFound != null) {
               if (threaddownloadimagedata.imageFound) {
                  player.setLocationOfCape(resourcelocation);
               }

               return;
            }
         }

         IImageBuffer iimagebuffer = new IImageBuffer(player, resourcelocation) {
            final ResourceLocation val$resourcelocation;
            final AbstractClientPlayer val$player;

            // $FF: synthetic method
            public BufferedImage parseUserSkin(BufferedImage image) {
               return jebac_vexiaglb4k1d2jvpm.parseCape(image);
            }

            // $FF: synthetic method
            public void skinAvailable() {
               this.val$player.setLocationOfCape(this.val$resourcelocation);
            }

            // $FF: synthetic method
            {
               this.val$player = var1;
               this.val$resourcelocation = var2;
            }
         };
         ThreadDownloadImageData thread = new ThreadDownloadImageData((File)null, s1, (ResourceLocation)null, iimagebuffer);
         thread.pipeline = true;
         texturemanager.loadTexture(resourcelocation, thread);
      }

   }

   // $FF: synthetic method
   public static void reloadCape(AbstractClientPlayer player) {
      ResourceLocation resourcelocation = new ResourceLocation("capeof/" + player.getNameClear());
      TextureManager texturemanager = Minecraft.getMinecraft().getTextureManager();
      ITextureObject texture = texturemanager.getTexture(resourcelocation);
      if (texture instanceof ThreadDownloadImageData) {
         SimpleTexture simpletex = (SimpleTexture)texture;
         simpletex.deleteGlTexture();
         texturemanager.deleteTexture(resourcelocation);
      }

      player.setLocationOfCape((ResourceLocation)null);
      downloadCape(player);
   }
}
