import com.google.common.base.Predicate;
import com.google.common.primitives.Floats;
import java.io.IOException;
import java.util.Random;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.resources.I18n;
import net.minecraft.util.MathHelper;
import net.minecraft.world.biome.BiomeGenBase;
import net.minecraft.world.gen.ChunkProviderSettings;

public class jebac_vexiapys3k7g7tk2c extends jebac_vexiakl614w3uw0xg implements jebac_vexiajena7f8xtrrr, jebac_vexiatghjrcxoegiy {
   // $FF: synthetic field
   protected String[] field_175342_h = new String[4];
   // $FF: synthetic field
   private boolean field_175338_A = false;
   // $FF: synthetic field
   private jebac_vexia4oibzo50ubf0 field_175352_x;
   // $FF: synthetic field
   private final jebac_vexiac6d627d28q0h field_175343_i;
   // $FF: synthetic field
   protected String field_175335_g = "Basic Settings";
   // $FF: synthetic field
   private final Random random = new Random();
   // $FF: synthetic field
   private jebac_vexia4oibzo50ubf0 field_175344_w;
   // $FF: synthetic field
   private boolean field_175340_C = false;
   // $FF: synthetic field
   private jebac_vexia4oibzo50ubf0 field_175350_z;
   // $FF: synthetic field
   private jebac_vexia4oibzo50ubf0 field_175347_t;
   // $FF: synthetic field
   private int field_175339_B = 0;
   // $FF: synthetic field
   private jebac_vexia4oibzo50ubf0 field_175348_s;
   // $FF: synthetic field
   private jebac_vexia4oibzo50ubf0 field_175351_y;
   // $FF: synthetic field
   private final Predicate field_175332_D = new Predicate(this) {
      final jebac_vexiapys3k7g7tk2c this$0;

      // $FF: synthetic method
      public boolean apply(String p_apply_1_) {
         Float f = Floats.tryParse(p_apply_1_);
         return p_apply_1_.length() == 0 || f != null && Floats.isFinite(f) && f >= 0.0F;
      }

      // $FF: synthetic method
      {
         this.this$0 = this$0;
      }
   };
   // $FF: synthetic field
   protected String field_175341_a = "Customize World Settings";
   // $FF: synthetic field
   protected String field_175333_f = "Page 1 of 3";
   // $FF: synthetic field
   private jebac_vexiajy6et0ec4v4z field_175349_r;
   // $FF: synthetic field
   private final ChunkProviderSettings.Factory field_175334_E = new ChunkProviderSettings.Factory();
   // $FF: synthetic field
   private jebac_vexia4oibzo50ubf0 field_175346_u;
   // $FF: synthetic field
   private jebac_vexia4oibzo50ubf0 field_175345_v;
   // $FF: synthetic field
   private ChunkProviderSettings.Factory field_175336_F;

   // $FF: synthetic method
   public void func_175321_a(int p_175321_1_, boolean p_175321_2_) {
      switch(p_175321_1_) {
      case 148:
         this.field_175336_F.useCaves = p_175321_2_;
         break;
      case 149:
         this.field_175336_F.useDungeons = p_175321_2_;
         break;
      case 150:
         this.field_175336_F.useStrongholds = p_175321_2_;
         break;
      case 151:
         this.field_175336_F.useVillages = p_175321_2_;
         break;
      case 152:
         this.field_175336_F.useMineShafts = p_175321_2_;
         break;
      case 153:
         this.field_175336_F.useTemples = p_175321_2_;
         break;
      case 154:
         this.field_175336_F.useRavines = p_175321_2_;
         break;
      case 155:
         this.field_175336_F.useWaterLakes = p_175321_2_;
         break;
      case 156:
         this.field_175336_F.useLavaLakes = p_175321_2_;
         break;
      case 161:
         this.field_175336_F.useLavaOceans = p_175321_2_;
         break;
      case 210:
         this.field_175336_F.useMonuments = p_175321_2_;
      }

      if (!this.field_175336_F.equals(this.field_175334_E)) {
         this.func_181031_a(true);
      }

   }

   // $FF: synthetic method
   private void func_175331_h() throws IOException {
      switch(this.field_175339_B) {
      case 300:
         this.actionPerformed((jebac_vexia98jsdrfcbi94)this.field_175349_r.func_178061_c(300));
         break;
      case 304:
         this.func_175326_g();
      }

      this.field_175339_B = 0;
      this.field_175340_C = true;
      this.func_175329_a(false);
   }

   // $FF: synthetic method
   public String getText(int id, String name, float value) {
      return name + ": " + this.func_175330_b(id, value);
   }

   // $FF: synthetic method
   public String func_175323_a() {
      return this.field_175336_F.toString().replace("\n", "");
   }

   // $FF: synthetic method
   public void drawScreen(int mouseX, int mouseY, float partialTicks) {
      this.drawDefaultBackground();
      this.field_175349_r.drawScreen(mouseX, mouseY, partialTicks);
      this.drawCenteredString(this.fontRendererObj, this.field_175341_a, this.width / 2, 2, 16777215);
      this.drawCenteredString(this.fontRendererObj, this.field_175333_f, this.width / 2, 12, 16777215);
      this.drawCenteredString(this.fontRendererObj, this.field_175335_g, this.width / 2, 22, 16777215);
      super.drawScreen(mouseX, mouseY, partialTicks);
      if (this.field_175339_B != 0) {
         drawRect(0, 0, this.width, this.height, Integer.MIN_VALUE);
         this.drawHorizontalLine(this.width / 2 - 91, this.width / 2 + 90, 99, -2039584);
         this.drawHorizontalLine(this.width / 2 - 91, this.width / 2 + 90, 185, -6250336);
         this.drawVerticalLine(this.width / 2 - 91, 99, 185, -2039584);
         this.drawVerticalLine(this.width / 2 + 90, 99, 185, -6250336);
         float f = 85.0F;
         float f1 = 180.0F;
         GlStateManager.disableLighting();
         GlStateManager.disableFog();
         Tessellator tessellator = Tessellator.getInstance();
         WorldRenderer worldrenderer = tessellator.getWorldRenderer();
         this.mc.getTextureManager().bindTexture(optionsBackground);
         GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
         float f2 = 32.0F;
         worldrenderer.begin(7, DefaultVertexFormats.POSITION_TEX_COLOR);
         worldrenderer.pos((double)(this.width / 2 - 90), 185.0D, 0.0D).tex(0.0D, 2.65625D).color(64, 64, 64, 64).endVertex();
         worldrenderer.pos((double)(this.width / 2 + 90), 185.0D, 0.0D).tex(5.625D, 2.65625D).color(64, 64, 64, 64).endVertex();
         worldrenderer.pos((double)(this.width / 2 + 90), 100.0D, 0.0D).tex(5.625D, 0.0D).color(64, 64, 64, 64).endVertex();
         worldrenderer.pos((double)(this.width / 2 - 90), 100.0D, 0.0D).tex(0.0D, 0.0D).color(64, 64, 64, 64).endVertex();
         tessellator.draw();
         this.drawCenteredString(this.fontRendererObj, I18n.format("createWorld.customize.custom.confirmTitle"), this.width / 2, 105, 16777215);
         this.drawCenteredString(this.fontRendererObj, I18n.format("createWorld.customize.custom.confirm1"), this.width / 2, 125, 16777215);
         this.drawCenteredString(this.fontRendererObj, I18n.format("createWorld.customize.custom.confirm2"), this.width / 2, 135, 16777215);
         this.field_175352_x.drawButton(this.mc, mouseX, mouseY);
         this.field_175351_y.drawButton(this.mc, mouseX, mouseY);
      }

   }

   // $FF: synthetic method
   private String func_175330_b(int p_175330_1_, float p_175330_2_) {
      switch(p_175330_1_) {
      case 100:
      case 101:
      case 102:
      case 103:
      case 104:
      case 107:
      case 108:
      case 110:
      case 111:
      case 132:
      case 133:
      case 134:
      case 135:
      case 136:
      case 139:
      case 140:
      case 142:
      case 143:
         return String.format("%5.3f", p_175330_2_);
      case 105:
      case 106:
      case 109:
      case 112:
      case 113:
      case 114:
      case 115:
      case 137:
      case 138:
      case 141:
      case 144:
      case 145:
      case 146:
      case 147:
         return String.format("%2.3f", p_175330_2_);
      case 116:
      case 117:
      case 118:
      case 119:
      case 120:
      case 121:
      case 122:
      case 123:
      case 124:
      case 125:
      case 126:
      case 127:
      case 128:
      case 129:
      case 130:
      case 131:
      case 148:
      case 149:
      case 150:
      case 151:
      case 152:
      case 153:
      case 154:
      case 155:
      case 156:
      case 157:
      case 158:
      case 159:
      case 160:
      case 161:
      default:
         return String.format("%d", (int)p_175330_2_);
      case 162:
         if (p_175330_2_ < 0.0F) {
            return I18n.format("gui.all");
         } else {
            BiomeGenBase biomegenbase;
            if ((int)p_175330_2_ >= BiomeGenBase.hell.biomeID) {
               biomegenbase = BiomeGenBase.getBiomeGenArray()[(int)p_175330_2_ + 2];
               return biomegenbase != null ? biomegenbase.biomeName : "?";
            } else {
               biomegenbase = BiomeGenBase.getBiomeGenArray()[(int)p_175330_2_];
               return biomegenbase != null ? biomegenbase.biomeName : "?";
            }
         }
      }
   }

   // $FF: synthetic method
   private void func_175328_i() {
      this.field_175345_v.enabled = this.field_175349_r.func_178059_e() != 0;
      this.field_175344_w.enabled = this.field_175349_r.func_178059_e() != this.field_175349_r.func_178057_f() - 1;
      this.field_175333_f = I18n.format("book.pageIndicator", this.field_175349_r.func_178059_e() + 1, this.field_175349_r.func_178057_f());
      this.field_175335_g = this.field_175342_h[this.field_175349_r.func_178059_e()];
      this.field_175347_t.enabled = this.field_175349_r.func_178059_e() != this.field_175349_r.func_178057_f() - 1;
   }

   // $FF: synthetic method
   private void func_175322_b(int p_175322_1_) {
      this.field_175339_B = p_175322_1_;
      this.func_175329_a(true);
   }

   // $FF: synthetic method
   public jebac_vexiapys3k7g7tk2c(jebac_vexiakl614w3uw0xg p_i45521_1_, String p_i45521_2_) {
      this.field_175343_i = (jebac_vexiac6d627d28q0h)p_i45521_1_;
      this.func_175324_a(p_i45521_2_);
   }

   // $FF: synthetic method
   private void func_181031_a(boolean p_181031_1_) {
      this.field_175338_A = p_181031_1_;
      this.field_175346_u.enabled = p_181031_1_;
   }

   // $FF: synthetic method
   private void func_175329_a(boolean p_175329_1_) {
      this.field_175352_x.visible = p_175329_1_;
      this.field_175351_y.visible = p_175329_1_;
      this.field_175347_t.enabled = !p_175329_1_;
      this.field_175348_s.enabled = !p_175329_1_;
      this.field_175345_v.enabled = !p_175329_1_;
      this.field_175344_w.enabled = !p_175329_1_;
      this.field_175346_u.enabled = this.field_175338_A && !p_175329_1_;
      this.field_175350_z.enabled = !p_175329_1_;
      this.field_175349_r.func_181155_a(!p_175329_1_);
   }

   // $FF: synthetic method
   protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
      super.mouseClicked(mouseX, mouseY, mouseButton);
      if (this.field_175339_B == 0 && !this.field_175340_C) {
         this.field_175349_r.mouseClicked(mouseX, mouseY, mouseButton);
      }

   }

   // $FF: synthetic method
   public void func_175324_a(String p_175324_1_) {
      if (p_175324_1_ != null && p_175324_1_.length() != 0) {
         this.field_175336_F = ChunkProviderSettings.Factory.jsonToFactory(p_175324_1_);
      } else {
         this.field_175336_F = new ChunkProviderSettings.Factory();
      }

   }

   // $FF: synthetic method
   protected void mouseReleased(int mouseX, int mouseY, int state) {
      super.mouseReleased(mouseX, mouseY, state);
      if (this.field_175340_C) {
         this.field_175340_C = false;
      } else if (this.field_175339_B == 0) {
         this.field_175349_r.mouseReleased(mouseX, mouseY, state);
      }

   }

   // $FF: synthetic method
   protected void keyTyped(char typedChar, int keyCode) throws IOException {
      super.keyTyped(typedChar, keyCode);
      if (this.field_175339_B == 0) {
         switch(keyCode) {
         case 200:
            this.func_175327_a(1.0F);
            break;
         case 208:
            this.func_175327_a(-1.0F);
            break;
         default:
            this.field_175349_r.func_178062_a(typedChar, keyCode);
         }
      }

   }

   // $FF: synthetic method
   public void initGui() {
      int i = 0;
      int j = 0;
      if (this.field_175349_r != null) {
         i = this.field_175349_r.func_178059_e();
         j = this.field_175349_r.getAmountScrolled();
      }

      this.field_175341_a = I18n.format("options.customizeTitle");
      this.buttonList.clear();
      this.buttonList.add(this.field_175345_v = new jebac_vexia4oibzo50ubf0(302, 20, 5, 80, 20, I18n.format("createWorld.customize.custom.prev")));
      this.buttonList.add(this.field_175344_w = new jebac_vexia4oibzo50ubf0(303, this.width - 100, 5, 80, 20, I18n.format("createWorld.customize.custom.next")));
      this.buttonList.add(this.field_175346_u = new jebac_vexia4oibzo50ubf0(304, this.width / 2 - 187, this.height - 27, 90, 20, I18n.format("createWorld.customize.custom.defaults")));
      this.buttonList.add(this.field_175347_t = new jebac_vexia4oibzo50ubf0(301, this.width / 2 - 92, this.height - 27, 90, 20, I18n.format("createWorld.customize.custom.randomize")));
      this.buttonList.add(this.field_175350_z = new jebac_vexia4oibzo50ubf0(305, this.width / 2 + 3, this.height - 27, 90, 20, I18n.format("createWorld.customize.custom.presets")));
      this.buttonList.add(this.field_175348_s = new jebac_vexia4oibzo50ubf0(300, this.width / 2 + 98, this.height - 27, 90, 20, I18n.format("gui.done")));
      this.field_175346_u.enabled = this.field_175338_A;
      this.field_175352_x = new jebac_vexia4oibzo50ubf0(306, this.width / 2 - 55, 160, 50, 20, I18n.format("gui.yes"));
      this.field_175352_x.visible = false;
      this.buttonList.add(this.field_175352_x);
      this.field_175351_y = new jebac_vexia4oibzo50ubf0(307, this.width / 2 + 5, 160, 50, 20, I18n.format("gui.no"));
      this.field_175351_y.visible = false;
      this.buttonList.add(this.field_175351_y);
      if (this.field_175339_B != 0) {
         this.field_175352_x.visible = true;
         this.field_175351_y.visible = true;
      }

      this.func_175325_f();
      if (i != 0) {
         this.field_175349_r.func_181156_c(i);
         this.field_175349_r.scrollBy(j);
         this.func_175328_i();
      }

   }

   // $FF: synthetic method
   public void onTick(int id, float value) {
      switch(id) {
      case 100:
         this.field_175336_F.mainNoiseScaleX = value;
         break;
      case 101:
         this.field_175336_F.mainNoiseScaleY = value;
         break;
      case 102:
         this.field_175336_F.mainNoiseScaleZ = value;
         break;
      case 103:
         this.field_175336_F.depthNoiseScaleX = value;
         break;
      case 104:
         this.field_175336_F.depthNoiseScaleZ = value;
         break;
      case 105:
         this.field_175336_F.depthNoiseScaleExponent = value;
         break;
      case 106:
         this.field_175336_F.baseSize = value;
         break;
      case 107:
         this.field_175336_F.coordinateScale = value;
         break;
      case 108:
         this.field_175336_F.heightScale = value;
         break;
      case 109:
         this.field_175336_F.stretchY = value;
         break;
      case 110:
         this.field_175336_F.upperLimitScale = value;
         break;
      case 111:
         this.field_175336_F.lowerLimitScale = value;
         break;
      case 112:
         this.field_175336_F.biomeDepthWeight = value;
         break;
      case 113:
         this.field_175336_F.biomeDepthOffset = value;
         break;
      case 114:
         this.field_175336_F.biomeScaleWeight = value;
         break;
      case 115:
         this.field_175336_F.biomeScaleOffset = value;
      case 116:
      case 117:
      case 118:
      case 119:
      case 120:
      case 121:
      case 122:
      case 123:
      case 124:
      case 125:
      case 126:
      case 127:
      case 128:
      case 129:
      case 130:
      case 131:
      case 132:
      case 133:
      case 134:
      case 135:
      case 136:
      case 137:
      case 138:
      case 139:
      case 140:
      case 141:
      case 142:
      case 143:
      case 144:
      case 145:
      case 146:
      case 147:
      case 148:
      case 149:
      case 150:
      case 151:
      case 152:
      case 153:
      case 154:
      case 155:
      case 156:
      case 161:
      case 188:
      default:
         break;
      case 157:
         this.field_175336_F.dungeonChance = (int)value;
         break;
      case 158:
         this.field_175336_F.waterLakeChance = (int)value;
         break;
      case 159:
         this.field_175336_F.lavaLakeChance = (int)value;
         break;
      case 160:
         this.field_175336_F.seaLevel = (int)value;
         break;
      case 162:
         this.field_175336_F.fixedBiome = (int)value;
         break;
      case 163:
         this.field_175336_F.biomeSize = (int)value;
         break;
      case 164:
         this.field_175336_F.riverSize = (int)value;
         break;
      case 165:
         this.field_175336_F.dirtSize = (int)value;
         break;
      case 166:
         this.field_175336_F.dirtCount = (int)value;
         break;
      case 167:
         this.field_175336_F.dirtMinHeight = (int)value;
         break;
      case 168:
         this.field_175336_F.dirtMaxHeight = (int)value;
         break;
      case 169:
         this.field_175336_F.gravelSize = (int)value;
         break;
      case 170:
         this.field_175336_F.gravelCount = (int)value;
         break;
      case 171:
         this.field_175336_F.gravelMinHeight = (int)value;
         break;
      case 172:
         this.field_175336_F.gravelMaxHeight = (int)value;
         break;
      case 173:
         this.field_175336_F.graniteSize = (int)value;
         break;
      case 174:
         this.field_175336_F.graniteCount = (int)value;
         break;
      case 175:
         this.field_175336_F.graniteMinHeight = (int)value;
         break;
      case 176:
         this.field_175336_F.graniteMaxHeight = (int)value;
         break;
      case 177:
         this.field_175336_F.dioriteSize = (int)value;
         break;
      case 178:
         this.field_175336_F.dioriteCount = (int)value;
         break;
      case 179:
         this.field_175336_F.dioriteMinHeight = (int)value;
         break;
      case 180:
         this.field_175336_F.dioriteMaxHeight = (int)value;
         break;
      case 181:
         this.field_175336_F.andesiteSize = (int)value;
         break;
      case 182:
         this.field_175336_F.andesiteCount = (int)value;
         break;
      case 183:
         this.field_175336_F.andesiteMinHeight = (int)value;
         break;
      case 184:
         this.field_175336_F.andesiteMaxHeight = (int)value;
         break;
      case 185:
         this.field_175336_F.coalSize = (int)value;
         break;
      case 186:
         this.field_175336_F.coalCount = (int)value;
         break;
      case 187:
         this.field_175336_F.coalMinHeight = (int)value;
         break;
      case 189:
         this.field_175336_F.coalMaxHeight = (int)value;
         break;
      case 190:
         this.field_175336_F.ironSize = (int)value;
         break;
      case 191:
         this.field_175336_F.ironCount = (int)value;
         break;
      case 192:
         this.field_175336_F.ironMinHeight = (int)value;
         break;
      case 193:
         this.field_175336_F.ironMaxHeight = (int)value;
         break;
      case 194:
         this.field_175336_F.goldSize = (int)value;
         break;
      case 195:
         this.field_175336_F.goldCount = (int)value;
         break;
      case 196:
         this.field_175336_F.goldMinHeight = (int)value;
         break;
      case 197:
         this.field_175336_F.goldMaxHeight = (int)value;
         break;
      case 198:
         this.field_175336_F.redstoneSize = (int)value;
         break;
      case 199:
         this.field_175336_F.redstoneCount = (int)value;
         break;
      case 200:
         this.field_175336_F.redstoneMinHeight = (int)value;
         break;
      case 201:
         this.field_175336_F.redstoneMaxHeight = (int)value;
         break;
      case 202:
         this.field_175336_F.diamondSize = (int)value;
         break;
      case 203:
         this.field_175336_F.diamondCount = (int)value;
         break;
      case 204:
         this.field_175336_F.diamondMinHeight = (int)value;
         break;
      case 205:
         this.field_175336_F.diamondMaxHeight = (int)value;
         break;
      case 206:
         this.field_175336_F.lapisSize = (int)value;
         break;
      case 207:
         this.field_175336_F.lapisCount = (int)value;
         break;
      case 208:
         this.field_175336_F.lapisCenterHeight = (int)value;
         break;
      case 209:
         this.field_175336_F.lapisSpread = (int)value;
      }

      if (id >= 100 && id < 116) {
         jebac_vexiabhi02xzapwrh gui = this.field_175349_r.func_178061_c(id - 100 + 132);
         if (gui != null) {
            ((jebac_vexiaa29g8ikthjc5)gui).setText(this.func_175330_b(id, value));
         }
      }

      if (!this.field_175336_F.equals(this.field_175334_E)) {
         this.func_181031_a(true);
      }

   }

   // $FF: synthetic method
   private void func_175325_f() {
      jebac_vexiamee1xbabsk4e[] aguipagebuttonlist$guilistentry = new jebac_vexiamee1xbabsk4e[]{new jebac_vexiawvw4ko3v0xar(160, I18n.format("createWorld.customize.custom.seaLevel"), true, this, 1.0F, 255.0F, (float)this.field_175336_F.seaLevel), new jebac_vexiaahfk36d5geld(148, I18n.format("createWorld.customize.custom.useCaves"), true, this.field_175336_F.useCaves), new jebac_vexiaahfk36d5geld(150, I18n.format("createWorld.customize.custom.useStrongholds"), true, this.field_175336_F.useStrongholds), new jebac_vexiaahfk36d5geld(151, I18n.format("createWorld.customize.custom.useVillages"), true, this.field_175336_F.useVillages), new jebac_vexiaahfk36d5geld(152, I18n.format("createWorld.customize.custom.useMineShafts"), true, this.field_175336_F.useMineShafts), new jebac_vexiaahfk36d5geld(153, I18n.format("createWorld.customize.custom.useTemples"), true, this.field_175336_F.useTemples), new jebac_vexiaahfk36d5geld(210, I18n.format("createWorld.customize.custom.useMonuments"), true, this.field_175336_F.useMonuments), new jebac_vexiaahfk36d5geld(154, I18n.format("createWorld.customize.custom.useRavines"), true, this.field_175336_F.useRavines), new jebac_vexiaahfk36d5geld(149, I18n.format("createWorld.customize.custom.useDungeons"), true, this.field_175336_F.useDungeons), new jebac_vexiawvw4ko3v0xar(157, I18n.format("createWorld.customize.custom.dungeonChance"), true, this, 1.0F, 100.0F, (float)this.field_175336_F.dungeonChance), new jebac_vexiaahfk36d5geld(155, I18n.format("createWorld.customize.custom.useWaterLakes"), true, this.field_175336_F.useWaterLakes), new jebac_vexiawvw4ko3v0xar(158, I18n.format("createWorld.customize.custom.waterLakeChance"), true, this, 1.0F, 100.0F, (float)this.field_175336_F.waterLakeChance), new jebac_vexiaahfk36d5geld(156, I18n.format("createWorld.customize.custom.useLavaLakes"), true, this.field_175336_F.useLavaLakes), new jebac_vexiawvw4ko3v0xar(159, I18n.format("createWorld.customize.custom.lavaLakeChance"), true, this, 10.0F, 100.0F, (float)this.field_175336_F.lavaLakeChance), new jebac_vexiaahfk36d5geld(161, I18n.format("createWorld.customize.custom.useLavaOceans"), true, this.field_175336_F.useLavaOceans), new jebac_vexiawvw4ko3v0xar(162, I18n.format("createWorld.customize.custom.fixedBiome"), true, this, -1.0F, 37.0F, (float)this.field_175336_F.fixedBiome), new jebac_vexiawvw4ko3v0xar(163, I18n.format("createWorld.customize.custom.biomeSize"), true, this, 1.0F, 8.0F, (float)this.field_175336_F.biomeSize), new jebac_vexiawvw4ko3v0xar(164, I18n.format("createWorld.customize.custom.riverSize"), true, this, 1.0F, 5.0F, (float)this.field_175336_F.riverSize)};
      jebac_vexiamee1xbabsk4e[] aguipagebuttonlist$guilistentry1 = new jebac_vexiamee1xbabsk4e[]{new jebac_vexiaqjl6i4rxan1x(416, I18n.format("tile.dirt.name"), false), null, new jebac_vexiawvw4ko3v0xar(165, I18n.format("createWorld.customize.custom.size"), false, this, 1.0F, 50.0F, (float)this.field_175336_F.dirtSize), new jebac_vexiawvw4ko3v0xar(166, I18n.format("createWorld.customize.custom.count"), false, this, 0.0F, 40.0F, (float)this.field_175336_F.dirtCount), new jebac_vexiawvw4ko3v0xar(167, I18n.format("createWorld.customize.custom.minHeight"), false, this, 0.0F, 255.0F, (float)this.field_175336_F.dirtMinHeight), new jebac_vexiawvw4ko3v0xar(168, I18n.format("createWorld.customize.custom.maxHeight"), false, this, 0.0F, 255.0F, (float)this.field_175336_F.dirtMaxHeight), new jebac_vexiaqjl6i4rxan1x(417, I18n.format("tile.gravel.name"), false), null, new jebac_vexiawvw4ko3v0xar(169, I18n.format("createWorld.customize.custom.size"), false, this, 1.0F, 50.0F, (float)this.field_175336_F.gravelSize), new jebac_vexiawvw4ko3v0xar(170, I18n.format("createWorld.customize.custom.count"), false, this, 0.0F, 40.0F, (float)this.field_175336_F.gravelCount), new jebac_vexiawvw4ko3v0xar(171, I18n.format("createWorld.customize.custom.minHeight"), false, this, 0.0F, 255.0F, (float)this.field_175336_F.gravelMinHeight), new jebac_vexiawvw4ko3v0xar(172, I18n.format("createWorld.customize.custom.maxHeight"), false, this, 0.0F, 255.0F, (float)this.field_175336_F.gravelMaxHeight), new jebac_vexiaqjl6i4rxan1x(418, I18n.format("tile.stone.granite.name"), false), null, new jebac_vexiawvw4ko3v0xar(173, I18n.format("createWorld.customize.custom.size"), false, this, 1.0F, 50.0F, (float)this.field_175336_F.graniteSize), new jebac_vexiawvw4ko3v0xar(174, I18n.format("createWorld.customize.custom.count"), false, this, 0.0F, 40.0F, (float)this.field_175336_F.graniteCount), new jebac_vexiawvw4ko3v0xar(175, I18n.format("createWorld.customize.custom.minHeight"), false, this, 0.0F, 255.0F, (float)this.field_175336_F.graniteMinHeight), new jebac_vexiawvw4ko3v0xar(176, I18n.format("createWorld.customize.custom.maxHeight"), false, this, 0.0F, 255.0F, (float)this.field_175336_F.graniteMaxHeight), new jebac_vexiaqjl6i4rxan1x(419, I18n.format("tile.stone.diorite.name"), false), null, new jebac_vexiawvw4ko3v0xar(177, I18n.format("createWorld.customize.custom.size"), false, this, 1.0F, 50.0F, (float)this.field_175336_F.dioriteSize), new jebac_vexiawvw4ko3v0xar(178, I18n.format("createWorld.customize.custom.count"), false, this, 0.0F, 40.0F, (float)this.field_175336_F.dioriteCount), new jebac_vexiawvw4ko3v0xar(179, I18n.format("createWorld.customize.custom.minHeight"), false, this, 0.0F, 255.0F, (float)this.field_175336_F.dioriteMinHeight), new jebac_vexiawvw4ko3v0xar(180, I18n.format("createWorld.customize.custom.maxHeight"), false, this, 0.0F, 255.0F, (float)this.field_175336_F.dioriteMaxHeight), new jebac_vexiaqjl6i4rxan1x(420, I18n.format("tile.stone.andesite.name"), false), null, new jebac_vexiawvw4ko3v0xar(181, I18n.format("createWorld.customize.custom.size"), false, this, 1.0F, 50.0F, (float)this.field_175336_F.andesiteSize), new jebac_vexiawvw4ko3v0xar(182, I18n.format("createWorld.customize.custom.count"), false, this, 0.0F, 40.0F, (float)this.field_175336_F.andesiteCount), new jebac_vexiawvw4ko3v0xar(183, I18n.format("createWorld.customize.custom.minHeight"), false, this, 0.0F, 255.0F, (float)this.field_175336_F.andesiteMinHeight), new jebac_vexiawvw4ko3v0xar(184, I18n.format("createWorld.customize.custom.maxHeight"), false, this, 0.0F, 255.0F, (float)this.field_175336_F.andesiteMaxHeight), new jebac_vexiaqjl6i4rxan1x(421, I18n.format("tile.oreCoal.name"), false), null, new jebac_vexiawvw4ko3v0xar(185, I18n.format("createWorld.customize.custom.size"), false, this, 1.0F, 50.0F, (float)this.field_175336_F.coalSize), new jebac_vexiawvw4ko3v0xar(186, I18n.format("createWorld.customize.custom.count"), false, this, 0.0F, 40.0F, (float)this.field_175336_F.coalCount), new jebac_vexiawvw4ko3v0xar(187, I18n.format("createWorld.customize.custom.minHeight"), false, this, 0.0F, 255.0F, (float)this.field_175336_F.coalMinHeight), new jebac_vexiawvw4ko3v0xar(189, I18n.format("createWorld.customize.custom.maxHeight"), false, this, 0.0F, 255.0F, (float)this.field_175336_F.coalMaxHeight), new jebac_vexiaqjl6i4rxan1x(422, I18n.format("tile.oreIron.name"), false), null, new jebac_vexiawvw4ko3v0xar(190, I18n.format("createWorld.customize.custom.size"), false, this, 1.0F, 50.0F, (float)this.field_175336_F.ironSize), new jebac_vexiawvw4ko3v0xar(191, I18n.format("createWorld.customize.custom.count"), false, this, 0.0F, 40.0F, (float)this.field_175336_F.ironCount), new jebac_vexiawvw4ko3v0xar(192, I18n.format("createWorld.customize.custom.minHeight"), false, this, 0.0F, 255.0F, (float)this.field_175336_F.ironMinHeight), new jebac_vexiawvw4ko3v0xar(193, I18n.format("createWorld.customize.custom.maxHeight"), false, this, 0.0F, 255.0F, (float)this.field_175336_F.ironMaxHeight), new jebac_vexiaqjl6i4rxan1x(423, I18n.format("tile.oreGold.name"), false), null, new jebac_vexiawvw4ko3v0xar(194, I18n.format("createWorld.customize.custom.size"), false, this, 1.0F, 50.0F, (float)this.field_175336_F.goldSize), new jebac_vexiawvw4ko3v0xar(195, I18n.format("createWorld.customize.custom.count"), false, this, 0.0F, 40.0F, (float)this.field_175336_F.goldCount), new jebac_vexiawvw4ko3v0xar(196, I18n.format("createWorld.customize.custom.minHeight"), false, this, 0.0F, 255.0F, (float)this.field_175336_F.goldMinHeight), new jebac_vexiawvw4ko3v0xar(197, I18n.format("createWorld.customize.custom.maxHeight"), false, this, 0.0F, 255.0F, (float)this.field_175336_F.goldMaxHeight), new jebac_vexiaqjl6i4rxan1x(424, I18n.format("tile.oreRedstone.name"), false), null, new jebac_vexiawvw4ko3v0xar(198, I18n.format("createWorld.customize.custom.size"), false, this, 1.0F, 50.0F, (float)this.field_175336_F.redstoneSize), new jebac_vexiawvw4ko3v0xar(199, I18n.format("createWorld.customize.custom.count"), false, this, 0.0F, 40.0F, (float)this.field_175336_F.redstoneCount), new jebac_vexiawvw4ko3v0xar(200, I18n.format("createWorld.customize.custom.minHeight"), false, this, 0.0F, 255.0F, (float)this.field_175336_F.redstoneMinHeight), new jebac_vexiawvw4ko3v0xar(201, I18n.format("createWorld.customize.custom.maxHeight"), false, this, 0.0F, 255.0F, (float)this.field_175336_F.redstoneMaxHeight), new jebac_vexiaqjl6i4rxan1x(425, I18n.format("tile.oreDiamond.name"), false), null, new jebac_vexiawvw4ko3v0xar(202, I18n.format("createWorld.customize.custom.size"), false, this, 1.0F, 50.0F, (float)this.field_175336_F.diamondSize), new jebac_vexiawvw4ko3v0xar(203, I18n.format("createWorld.customize.custom.count"), false, this, 0.0F, 40.0F, (float)this.field_175336_F.diamondCount), new jebac_vexiawvw4ko3v0xar(204, I18n.format("createWorld.customize.custom.minHeight"), false, this, 0.0F, 255.0F, (float)this.field_175336_F.diamondMinHeight), new jebac_vexiawvw4ko3v0xar(205, I18n.format("createWorld.customize.custom.maxHeight"), false, this, 0.0F, 255.0F, (float)this.field_175336_F.diamondMaxHeight), new jebac_vexiaqjl6i4rxan1x(426, I18n.format("tile.oreLapis.name"), false), null, new jebac_vexiawvw4ko3v0xar(206, I18n.format("createWorld.customize.custom.size"), false, this, 1.0F, 50.0F, (float)this.field_175336_F.lapisSize), new jebac_vexiawvw4ko3v0xar(207, I18n.format("createWorld.customize.custom.count"), false, this, 0.0F, 40.0F, (float)this.field_175336_F.lapisCount), new jebac_vexiawvw4ko3v0xar(208, I18n.format("createWorld.customize.custom.center"), false, this, 0.0F, 255.0F, (float)this.field_175336_F.lapisCenterHeight), new jebac_vexiawvw4ko3v0xar(209, I18n.format("createWorld.customize.custom.spread"), false, this, 0.0F, 255.0F, (float)this.field_175336_F.lapisSpread)};
      jebac_vexiamee1xbabsk4e[] aguipagebuttonlist$guilistentry2 = new jebac_vexiamee1xbabsk4e[]{new jebac_vexiawvw4ko3v0xar(100, I18n.format("createWorld.customize.custom.mainNoiseScaleX"), false, this, 1.0F, 5000.0F, this.field_175336_F.mainNoiseScaleX), new jebac_vexiawvw4ko3v0xar(101, I18n.format("createWorld.customize.custom.mainNoiseScaleY"), false, this, 1.0F, 5000.0F, this.field_175336_F.mainNoiseScaleY), new jebac_vexiawvw4ko3v0xar(102, I18n.format("createWorld.customize.custom.mainNoiseScaleZ"), false, this, 1.0F, 5000.0F, this.field_175336_F.mainNoiseScaleZ), new jebac_vexiawvw4ko3v0xar(103, I18n.format("createWorld.customize.custom.depthNoiseScaleX"), false, this, 1.0F, 2000.0F, this.field_175336_F.depthNoiseScaleX), new jebac_vexiawvw4ko3v0xar(104, I18n.format("createWorld.customize.custom.depthNoiseScaleZ"), false, this, 1.0F, 2000.0F, this.field_175336_F.depthNoiseScaleZ), new jebac_vexiawvw4ko3v0xar(105, I18n.format("createWorld.customize.custom.depthNoiseScaleExponent"), false, this, 0.01F, 20.0F, this.field_175336_F.depthNoiseScaleExponent), new jebac_vexiawvw4ko3v0xar(106, I18n.format("createWorld.customize.custom.baseSize"), false, this, 1.0F, 25.0F, this.field_175336_F.baseSize), new jebac_vexiawvw4ko3v0xar(107, I18n.format("createWorld.customize.custom.coordinateScale"), false, this, 1.0F, 6000.0F, this.field_175336_F.coordinateScale), new jebac_vexiawvw4ko3v0xar(108, I18n.format("createWorld.customize.custom.heightScale"), false, this, 1.0F, 6000.0F, this.field_175336_F.heightScale), new jebac_vexiawvw4ko3v0xar(109, I18n.format("createWorld.customize.custom.stretchY"), false, this, 0.01F, 50.0F, this.field_175336_F.stretchY), new jebac_vexiawvw4ko3v0xar(110, I18n.format("createWorld.customize.custom.upperLimitScale"), false, this, 1.0F, 5000.0F, this.field_175336_F.upperLimitScale), new jebac_vexiawvw4ko3v0xar(111, I18n.format("createWorld.customize.custom.lowerLimitScale"), false, this, 1.0F, 5000.0F, this.field_175336_F.lowerLimitScale), new jebac_vexiawvw4ko3v0xar(112, I18n.format("createWorld.customize.custom.biomeDepthWeight"), false, this, 1.0F, 20.0F, this.field_175336_F.biomeDepthWeight), new jebac_vexiawvw4ko3v0xar(113, I18n.format("createWorld.customize.custom.biomeDepthOffset"), false, this, 0.0F, 20.0F, this.field_175336_F.biomeDepthOffset), new jebac_vexiawvw4ko3v0xar(114, I18n.format("createWorld.customize.custom.biomeScaleWeight"), false, this, 1.0F, 20.0F, this.field_175336_F.biomeScaleWeight), new jebac_vexiawvw4ko3v0xar(115, I18n.format("createWorld.customize.custom.biomeScaleOffset"), false, this, 0.0F, 20.0F, this.field_175336_F.biomeScaleOffset)};
      jebac_vexiamee1xbabsk4e[] aguipagebuttonlist$guilistentry3 = new jebac_vexiamee1xbabsk4e[]{new jebac_vexiaqjl6i4rxan1x(400, I18n.format("createWorld.customize.custom.mainNoiseScaleX") + ":", false), new jebac_vexiay4ml4av3j3n0(132, String.format("%5.3f", this.field_175336_F.mainNoiseScaleX), false, this.field_175332_D), new jebac_vexiaqjl6i4rxan1x(401, I18n.format("createWorld.customize.custom.mainNoiseScaleY") + ":", false), new jebac_vexiay4ml4av3j3n0(133, String.format("%5.3f", this.field_175336_F.mainNoiseScaleY), false, this.field_175332_D), new jebac_vexiaqjl6i4rxan1x(402, I18n.format("createWorld.customize.custom.mainNoiseScaleZ") + ":", false), new jebac_vexiay4ml4av3j3n0(134, String.format("%5.3f", this.field_175336_F.mainNoiseScaleZ), false, this.field_175332_D), new jebac_vexiaqjl6i4rxan1x(403, I18n.format("createWorld.customize.custom.depthNoiseScaleX") + ":", false), new jebac_vexiay4ml4av3j3n0(135, String.format("%5.3f", this.field_175336_F.depthNoiseScaleX), false, this.field_175332_D), new jebac_vexiaqjl6i4rxan1x(404, I18n.format("createWorld.customize.custom.depthNoiseScaleZ") + ":", false), new jebac_vexiay4ml4av3j3n0(136, String.format("%5.3f", this.field_175336_F.depthNoiseScaleZ), false, this.field_175332_D), new jebac_vexiaqjl6i4rxan1x(405, I18n.format("createWorld.customize.custom.depthNoiseScaleExponent") + ":", false), new jebac_vexiay4ml4av3j3n0(137, String.format("%2.3f", this.field_175336_F.depthNoiseScaleExponent), false, this.field_175332_D), new jebac_vexiaqjl6i4rxan1x(406, I18n.format("createWorld.customize.custom.baseSize") + ":", false), new jebac_vexiay4ml4av3j3n0(138, String.format("%2.3f", this.field_175336_F.baseSize), false, this.field_175332_D), new jebac_vexiaqjl6i4rxan1x(407, I18n.format("createWorld.customize.custom.coordinateScale") + ":", false), new jebac_vexiay4ml4av3j3n0(139, String.format("%5.3f", this.field_175336_F.coordinateScale), false, this.field_175332_D), new jebac_vexiaqjl6i4rxan1x(408, I18n.format("createWorld.customize.custom.heightScale") + ":", false), new jebac_vexiay4ml4av3j3n0(140, String.format("%5.3f", this.field_175336_F.heightScale), false, this.field_175332_D), new jebac_vexiaqjl6i4rxan1x(409, I18n.format("createWorld.customize.custom.stretchY") + ":", false), new jebac_vexiay4ml4av3j3n0(141, String.format("%2.3f", this.field_175336_F.stretchY), false, this.field_175332_D), new jebac_vexiaqjl6i4rxan1x(410, I18n.format("createWorld.customize.custom.upperLimitScale") + ":", false), new jebac_vexiay4ml4av3j3n0(142, String.format("%5.3f", this.field_175336_F.upperLimitScale), false, this.field_175332_D), new jebac_vexiaqjl6i4rxan1x(411, I18n.format("createWorld.customize.custom.lowerLimitScale") + ":", false), new jebac_vexiay4ml4av3j3n0(143, String.format("%5.3f", this.field_175336_F.lowerLimitScale), false, this.field_175332_D), new jebac_vexiaqjl6i4rxan1x(412, I18n.format("createWorld.customize.custom.biomeDepthWeight") + ":", false), new jebac_vexiay4ml4av3j3n0(144, String.format("%2.3f", this.field_175336_F.biomeDepthWeight), false, this.field_175332_D), new jebac_vexiaqjl6i4rxan1x(413, I18n.format("createWorld.customize.custom.biomeDepthOffset") + ":", false), new jebac_vexiay4ml4av3j3n0(145, String.format("%2.3f", this.field_175336_F.biomeDepthOffset), false, this.field_175332_D), new jebac_vexiaqjl6i4rxan1x(414, I18n.format("createWorld.customize.custom.biomeScaleWeight") + ":", false), new jebac_vexiay4ml4av3j3n0(146, String.format("%2.3f", this.field_175336_F.biomeScaleWeight), false, this.field_175332_D), new jebac_vexiaqjl6i4rxan1x(415, I18n.format("createWorld.customize.custom.biomeScaleOffset") + ":", false), new jebac_vexiay4ml4av3j3n0(147, String.format("%2.3f", this.field_175336_F.biomeScaleOffset), false, this.field_175332_D)};
      this.field_175349_r = new jebac_vexiajy6et0ec4v4z(this.mc, this.width, this.height, 32, this.height - 32, 25, this, new jebac_vexiamee1xbabsk4e[][]{aguipagebuttonlist$guilistentry, aguipagebuttonlist$guilistentry1, aguipagebuttonlist$guilistentry2, aguipagebuttonlist$guilistentry3});

      for(int i = 0; i < 4; ++i) {
         this.field_175342_h[i] = I18n.format("createWorld.customize.custom.page" + i);
      }

      this.func_175328_i();
   }

   // $FF: synthetic method
   public void func_175319_a(int p_175319_1_, String p_175319_2_) {
      float f = 0.0F;

      try {
         f = Float.parseFloat(p_175319_2_);
      } catch (NumberFormatException var5) {
      }

      float f1 = 0.0F;
      switch(p_175319_1_) {
      case 132:
         f1 = this.field_175336_F.mainNoiseScaleX = MathHelper.clamp_float(f, 1.0F, 5000.0F);
         break;
      case 133:
         f1 = this.field_175336_F.mainNoiseScaleY = MathHelper.clamp_float(f, 1.0F, 5000.0F);
         break;
      case 134:
         f1 = this.field_175336_F.mainNoiseScaleZ = MathHelper.clamp_float(f, 1.0F, 5000.0F);
         break;
      case 135:
         f1 = this.field_175336_F.depthNoiseScaleX = MathHelper.clamp_float(f, 1.0F, 2000.0F);
         break;
      case 136:
         f1 = this.field_175336_F.depthNoiseScaleZ = MathHelper.clamp_float(f, 1.0F, 2000.0F);
         break;
      case 137:
         f1 = this.field_175336_F.depthNoiseScaleExponent = MathHelper.clamp_float(f, 0.01F, 20.0F);
         break;
      case 138:
         f1 = this.field_175336_F.baseSize = MathHelper.clamp_float(f, 1.0F, 25.0F);
         break;
      case 139:
         f1 = this.field_175336_F.coordinateScale = MathHelper.clamp_float(f, 1.0F, 6000.0F);
         break;
      case 140:
         f1 = this.field_175336_F.heightScale = MathHelper.clamp_float(f, 1.0F, 6000.0F);
         break;
      case 141:
         f1 = this.field_175336_F.stretchY = MathHelper.clamp_float(f, 0.01F, 50.0F);
         break;
      case 142:
         f1 = this.field_175336_F.upperLimitScale = MathHelper.clamp_float(f, 1.0F, 5000.0F);
         break;
      case 143:
         f1 = this.field_175336_F.lowerLimitScale = MathHelper.clamp_float(f, 1.0F, 5000.0F);
         break;
      case 144:
         f1 = this.field_175336_F.biomeDepthWeight = MathHelper.clamp_float(f, 1.0F, 20.0F);
         break;
      case 145:
         f1 = this.field_175336_F.biomeDepthOffset = MathHelper.clamp_float(f, 0.0F, 20.0F);
         break;
      case 146:
         f1 = this.field_175336_F.biomeScaleWeight = MathHelper.clamp_float(f, 1.0F, 20.0F);
         break;
      case 147:
         f1 = this.field_175336_F.biomeScaleOffset = MathHelper.clamp_float(f, 0.0F, 20.0F);
      }

      if (f1 != f && f != 0.0F) {
         ((jebac_vexiaa29g8ikthjc5)this.field_175349_r.func_178061_c(p_175319_1_)).setText(this.func_175330_b(p_175319_1_, f1));
      }

      ((jebac_vexiaiui810ba7biw)this.field_175349_r.func_178061_c(p_175319_1_ - 132 + 100)).func_175218_a(f1, false);
      if (!this.field_175336_F.equals(this.field_175334_E)) {
         this.func_181031_a(true);
      }

   }

   // $FF: synthetic method
   private void func_175326_g() {
      this.field_175336_F.func_177863_a();
      this.func_175325_f();
      this.func_181031_a(false);
   }

   // $FF: synthetic method
   private void func_175327_a(float p_175327_1_) {
      jebac_vexiabhi02xzapwrh gui = this.field_175349_r.func_178056_g();
      if (gui instanceof jebac_vexiaa29g8ikthjc5) {
         float f = p_175327_1_;
         if (jebac_vexiakl614w3uw0xg.isShiftKeyDown()) {
            f = p_175327_1_ * 0.1F;
            if (jebac_vexiakl614w3uw0xg.isCtrlKeyDown()) {
               f *= 0.1F;
            }
         } else if (jebac_vexiakl614w3uw0xg.isCtrlKeyDown()) {
            f = p_175327_1_ * 10.0F;
            if (jebac_vexiakl614w3uw0xg.isAltKeyDown()) {
               f *= 10.0F;
            }
         }

         jebac_vexiaa29g8ikthjc5 guitextfield = (jebac_vexiaa29g8ikthjc5)gui;
         Float f1 = Floats.tryParse(guitextfield.getText());
         if (f1 != null) {
            f1 = f1 + f;
            int i = guitextfield.getId();
            String s = this.func_175330_b(guitextfield.getId(), f1);
            guitextfield.setText(s);
            this.func_175319_a(i, s);
         }
      }

   }

   // $FF: synthetic method
   public void handleMouseInput() throws IOException {
      super.handleMouseInput();
      this.field_175349_r.handleMouseInput();
   }

   // $FF: synthetic method
   protected void actionPerformed(jebac_vexia4oibzo50ubf0 button) throws IOException {
      if (button.enabled) {
         switch(button.id) {
         case 300:
            this.field_175343_i.chunkProviderSettingsJson = this.field_175336_F.toString();
            this.mc.displayGuiScreen(this.field_175343_i);
            break;
         case 301:
            for(int i = 0; i < this.field_175349_r.getSize(); ++i) {
               jebac_vexia7nj1i85wxdvv guipagebuttonlist$guientry = this.field_175349_r.getListEntry(i);
               jebac_vexiabhi02xzapwrh gui = guipagebuttonlist$guientry.func_178022_a();
               if (gui instanceof jebac_vexia4oibzo50ubf0) {
                  jebac_vexia4oibzo50ubf0 guibutton = (jebac_vexia4oibzo50ubf0)gui;
                  if (guibutton instanceof jebac_vexiaiui810ba7biw) {
                     float f = ((jebac_vexiaiui810ba7biw)guibutton).func_175217_d() * (0.75F + this.random.nextFloat() * 0.5F) + (this.random.nextFloat() * 0.1F - 0.05F);
                     ((jebac_vexiaiui810ba7biw)guibutton).func_175219_a(MathHelper.clamp_float(f, 0.0F, 1.0F));
                  } else if (guibutton instanceof jebac_vexia98jsdrfcbi94) {
                     ((jebac_vexia98jsdrfcbi94)guibutton).func_175212_b(this.random.nextBoolean());
                  }
               }

               jebac_vexiabhi02xzapwrh gui1 = guipagebuttonlist$guientry.func_178021_b();
               if (gui1 instanceof jebac_vexia4oibzo50ubf0) {
                  jebac_vexia4oibzo50ubf0 guibutton1 = (jebac_vexia4oibzo50ubf0)gui1;
                  if (guibutton1 instanceof jebac_vexiaiui810ba7biw) {
                     float f1 = ((jebac_vexiaiui810ba7biw)guibutton1).func_175217_d() * (0.75F + this.random.nextFloat() * 0.5F) + (this.random.nextFloat() * 0.1F - 0.05F);
                     ((jebac_vexiaiui810ba7biw)guibutton1).func_175219_a(MathHelper.clamp_float(f1, 0.0F, 1.0F));
                  } else if (guibutton1 instanceof jebac_vexia98jsdrfcbi94) {
                     ((jebac_vexia98jsdrfcbi94)guibutton1).func_175212_b(this.random.nextBoolean());
                  }
               }
            }

            return;
         case 302:
            this.field_175349_r.func_178071_h();
            this.func_175328_i();
            break;
         case 303:
            this.field_175349_r.func_178064_i();
            this.func_175328_i();
            break;
         case 304:
            if (this.field_175338_A) {
               this.func_175322_b(304);
            }
            break;
         case 305:
            this.mc.displayGuiScreen(new jebac_vexiai6dbk9voxk7g(this));
            break;
         case 306:
            this.func_175331_h();
            break;
         case 307:
            this.field_175339_B = 0;
            this.func_175331_h();
         }
      }

   }
}
