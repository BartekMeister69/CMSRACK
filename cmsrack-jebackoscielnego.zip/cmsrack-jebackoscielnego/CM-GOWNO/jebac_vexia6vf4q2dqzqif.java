import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.world.chunk.Chunk;

public class jebac_vexia6vf4q2dqzqif {
   // $FF: synthetic field
   private static Field fieldHasEntities = null;
   // $FF: synthetic field
   private static boolean fieldHasEntitiesMissing = false;

   // $FF: synthetic method
   public static boolean hasEntities(Chunk p_hasEntities_0_) {
      if (fieldHasEntities == null) {
         if (fieldHasEntitiesMissing) {
            return true;
         }

         fieldHasEntities = findFieldHasEntities(p_hasEntities_0_);
         if (fieldHasEntities == null) {
            fieldHasEntitiesMissing = true;
            return true;
         }
      }

      try {
         return fieldHasEntities.getBoolean(p_hasEntities_0_);
      } catch (Exception var2) {
         jebac_vexiakrwecfs16wve.warn("Error calling Chunk.hasEntities");
         jebac_vexiakrwecfs16wve.warn(var2.getClass().getName() + " " + var2.getMessage());
         fieldHasEntitiesMissing = true;
         return true;
      }
   }

   // $FF: synthetic method
   private static Field findFieldHasEntities(Chunk p_findFieldHasEntities_0_) {
      try {
         List list = new ArrayList();
         List list1 = new ArrayList();
         Field[] afield = Chunk.class.getDeclaredFields();
         Field[] var4 = afield;
         int var5 = afield.length;

         Field field4;
         for(int var6 = 0; var6 < var5; ++var6) {
            field4 = var4[var6];
            if (field4.getType() == Boolean.TYPE) {
               field4.setAccessible(true);
               list.add(field4);
               list1.add(field4.get(p_findFieldHasEntities_0_));
            }
         }

         p_findFieldHasEntities_0_.setHasEntities(false);
         List list2 = new ArrayList();
         Iterator var14 = list.iterator();

         while(var14.hasNext()) {
            Object field1 = var14.next();
            list2.add(((Field)field1).get(p_findFieldHasEntities_0_));
         }

         p_findFieldHasEntities_0_.setHasEntities(true);
         List list3 = new ArrayList();
         Iterator var17 = list.iterator();

         while(var17.hasNext()) {
            Object field2 = var17.next();
            list3.add(((Field)field2).get(p_findFieldHasEntities_0_));
         }

         List list4 = new ArrayList();

         for(int j = 0; j < list.size(); ++j) {
            Field field3 = (Field)list.get(j);
            Boolean obool = (Boolean)list2.get(j);
            Boolean obool1 = (Boolean)list3.get(j);
            if (!obool && obool1) {
               list4.add(field3);
               Boolean obool2 = (Boolean)list1.get(j);
               field3.set(p_findFieldHasEntities_0_, obool2);
            }
         }

         if (list4.size() == 1) {
            field4 = (Field)list4.get(0);
            return field4;
         }
      } catch (Exception var12) {
         jebac_vexiakrwecfs16wve.warn(var12.getClass().getName() + " " + var12.getMessage());
      }

      jebac_vexiakrwecfs16wve.warn("Error finding Chunk.hasEntities");
      return null;
   }
}
