import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.util.MathHelper;

public class jebac_vexiakfzkq5wmes2e extends jebac_vexia4oibzo50ubf0 {
   // $FF: synthetic field
   private final GameSettings.Options options;
   // $FF: synthetic field
   public boolean dragging;
   // $FF: synthetic field
   private float sliderValue;

   // $FF: synthetic method
   protected void mouseDragged(Minecraft mc, int mouseX, int mouseY) {
      if (this.visible) {
         if (this.dragging) {
            this.sliderValue = (float)(mouseX - (this.xPosition + 4)) / (float)(this.width - 8);
            this.sliderValue = MathHelper.clamp_float(this.sliderValue, 0.0F, 1.0F);
            float var4 = this.options.denormalizeValue(this.sliderValue);
            mc.gameSettings.setOptionFloatValue(this.options, var4);
            this.sliderValue = this.options.normalizeValue(var4);
            this.displayString = mc.gameSettings.getKeyBinding(this.options);
         }

         if (!jebac_vexiawzpzy1x3sez8. bx) {
            mc.getTextureManager().bindTexture(buttonTextures);
            GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
            this.drawTexturedModalRect(this.xPosition + (int)(this.sliderValue * (float)(this.width - 8)), this.yPosition, 0, 66, 4, 20);
            this.drawTexturedModalRect(this.xPosition + (int)(this.sliderValue * (float)(this.width - 8)) + 4, this.yPosition, 196, 66, 4, 20);
         }
      }

   }

   // $FF: synthetic method
   public jebac_vexiakfzkq5wmes2e(int p_i45016_1_, int p_i45016_2_, int p_i45016_3_, GameSettings.Options p_i45016_4_) {
      this(p_i45016_1_, p_i45016_2_, p_i45016_3_, p_i45016_4_, 0.0F, 1.0F);
   }

   // $FF: synthetic method
   public void mouseReleased(int mouseX, int mouseY) {
      this.dragging = false;
   }

   // $FF: synthetic method
   public jebac_vexiakfzkq5wmes2e(int p_i45017_1_, int p_i45017_2_, int p_i45017_3_, GameSettings.Options p_i45017_4_, float p_i45017_5_, float p_i45017_6_) {
      super(p_i45017_1_, p_i45017_2_, p_i45017_3_, 150, 20, "");
      this.sliderValue = 1.0F;
      this.options = p_i45017_4_;
      Minecraft minecraft = Minecraft.getMinecraft();
      this.sliderValue = p_i45017_4_.normalizeValue(minecraft.gameSettings.getOptionFloatValue(p_i45017_4_));
      this.displayString = minecraft.gameSettings.getKeyBinding(p_i45017_4_);
   }

   // $FF: synthetic method
   public void drawButton(Minecraft mc, int mouseX, int mouseY) {
      if (jebac_vexiawzpzy1x3sez8. bx) {
         GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
         this.hovered = mouseX >= this.xPosition && mouseY >= this.yPosition && mouseX < this.xPosition + this.width && mouseY < this.yPosition + this.height;
         if (System.currentTimeMillis() >= this.animationUpdateTime) {
            this.animation.update(this.hovered);
            this.animationUpdateTime = System.currentTimeMillis() + 10L;
         }

         int color = 14737632;
         this.mouseDragged(mc, mouseX, mouseY);
         super.drawCenteredString(mc.fontRendererObj, this.displayString, this.xPosition + this.width / 2, this.yPosition + 5, color);
         if (this.enabled && this.hovered) {
            jebac_vexiawqkxo5ufmdem.drawLine2D((double)(this.xPosition + this.width / 2) - this.animation.getValue() * (double)this.width / 2.0D, (double)this.yPosition, (double)(this.xPosition + this.width / 2) + this.animation.getValue() * (double)this.width / 2.0D, (double)this.yPosition, 1.0F, jebac_vexiawzpzy1x3sez8. be ? jebac_vexiacs3qcki5ln4n.getRainbow(1000, 15).getRGB() : -8355712);
            jebac_vexiawqkxo5ufmdem.drawLine2D((double)(this.xPosition + this.width / 2) - this.animation.getValue() * (double)this.width / 2.0D, (double)(this.yPosition + this.height), (double)(this.xPosition + this.width / 2) + this.animation.getValue() * (double)this.width / 2.0D, (double)(this.yPosition + this.height), 1.0F, jebac_vexiawzpzy1x3sez8. be ? jebac_vexiacs3qcki5ln4n.getRainbow(1000, 15).getRGB() : -8355712);
            jebac_vexiawqkxo5ufmdem.drawLine2D((double)(this.xPosition + this.width / 2) - this.animation.getValue() * (double)this.width / 2.0D + (double)((int)((double)this.sliderValue * (this.animation.getValue() * (double)this.width - 8.0D))), (double)this.yPosition, (double)(this.xPosition + this.width / 2) - this.animation.getValue() * (double)this.width / 2.0D + (double)((int)((double)this.sliderValue * (this.animation.getValue() * (double)this.width - 8.0D))) + 8.0D, (double)this.yPosition, 1.0F, jebac_vexiawzpzy1x3sez8. be ? jebac_vexiacs3qcki5ln4n.getRainbow(1000, 15).getRGB() : 14737632);
            jebac_vexiawqkxo5ufmdem.drawLine2D((double)(this.xPosition + this.width / 2) - this.animation.getValue() * (double)this.width / 2.0D + (double)((int)((double)this.sliderValue * (this.animation.getValue() * (double)this.width - 8.0D))), (double)(this.yPosition + this.height), (double)(this.xPosition + this.width / 2) - this.animation.getValue() * (double)this.width / 2.0D + (double)((int)((double)this.sliderValue * (this.animation.getValue() * (double)this.width - 8.0D))) + 8.0D, (double)(this.yPosition + this.height), 1.0F, jebac_vexiawzpzy1x3sez8. be ? jebac_vexiacs3qcki5ln4n.getRainbow(1000, 15).getRGB() : 14737632);
         }

         GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
      } else {
         super.drawButton(mc, mouseX, mouseY);
      }

   }

   // $FF: synthetic method
   protected int getHoverState(boolean mouseOver) {
      return 0;
   }

   // $FF: synthetic method
   public boolean mousePressed(Minecraft mc, int mouseX, int mouseY) {
      if (super.mousePressed(mc, mouseX, mouseY)) {
         this.sliderValue = (float)(mouseX - (this.xPosition + 4)) / (float)(this.width - 8);
         this.sliderValue = MathHelper.clamp_float(this.sliderValue, 0.0F, 1.0F);
         mc.gameSettings.setOptionFloatValue(this.options, this.options.denormalizeValue(this.sliderValue));
         this.displayString = mc.gameSettings.getKeyBinding(this.options);
         return this.dragging = true;
      } else {
         return false;
      }
   }
}
