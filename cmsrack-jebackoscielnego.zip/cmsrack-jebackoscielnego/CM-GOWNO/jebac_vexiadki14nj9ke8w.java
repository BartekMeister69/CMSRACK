import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderPlayer;
import net.minecraft.client.renderer.entity.layers.LayerRenderer;
import net.minecraft.entity.EntityLivingBase;

public class jebac_vexiadki14nj9ke8w implements LayerRenderer {
   // $FF: synthetic field
   private RenderPlayer renderPlayer = null;

   // $FF: synthetic method
   public jebac_vexiadki14nj9ke8w(RenderPlayer p_i76_1_) {
      this.renderPlayer = p_i76_1_;
   }

   // $FF: synthetic method
   public void doRenderLayer(EntityLivingBase entitylivingbaseIn, float p_177141_2_, float p_177141_3_, float partialTicks, float p_177141_5_, float p_177141_6_, float p_177141_7_, float scale) {
      this.renderEquippedItems(entitylivingbaseIn, scale, partialTicks);
   }

   // $FF: synthetic method
   protected void renderEquippedItems(EntityLivingBase p_renderEquippedItems_1_, float p_renderEquippedItems_2_, float p_renderEquippedItems_3_) {
      if (jebac_vexiakrwecfs16wve.isShowCapes() && p_renderEquippedItems_1_ instanceof AbstractClientPlayer) {
         AbstractClientPlayer abstractclientplayer = (AbstractClientPlayer)p_renderEquippedItems_1_;
         GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
         GlStateManager.disableRescaleNormal();
         GlStateManager.enableCull();
         jebac_vexia88utjmuujofl modelbiped = this.renderPlayer.getMainModel();
         jebac_vexiara06cijtnxiy.renderPlayerItems(modelbiped, abstractclientplayer, p_renderEquippedItems_2_, p_renderEquippedItems_3_);
         GlStateManager.disableCull();
      }

   }

   // $FF: synthetic method
   public boolean shouldCombineTextures() {
      return false;
   }

   // $FF: synthetic method
   public static void register(Map p_register_0_) {
      Set set = p_register_0_.keySet();
      boolean flag = false;
      Iterator var3 = set.iterator();

      while(var3.hasNext()) {
         Object object = var3.next();
         Object object1 = p_register_0_.get(object);
         if (object1 instanceof RenderPlayer) {
            RenderPlayer renderplayer = (RenderPlayer)object1;
            renderplayer.addLayer(new jebac_vexiadki14nj9ke8w(renderplayer));
            flag = true;
         }
      }

      if (!flag) {
         jebac_vexiakrwecfs16wve.warn("PlayerItemsLayer not registered");
      }

   }
}
