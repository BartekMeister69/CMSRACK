public class jebac_vexiarytepjva519f extends jebac_vexiazrxtvwdcml9w {
   // $FF: synthetic method
   public jebac_vexiarytepjva519f(String name) {
      super(name, name, (String)null, new String[]{null}, (String)null, (String)null);
   }
}
