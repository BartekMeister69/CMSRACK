import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.resources.I18n;
import net.minecraft.util.IChatComponent;

public class jebac_vexiays9i8bhkczr3 extends jebac_vexiakl614w3uw0xg {
   // $FF: synthetic field
   private List multilineMessage;
   // $FF: synthetic field
   private final jebac_vexiakl614w3uw0xg parentScreen;
   // $FF: synthetic field
   private String reason;
   // $FF: synthetic field
   private int field_175353_i;
   // $FF: synthetic field
   private IChatComponent message;

   // $FF: synthetic method
   public void drawScreen(int mouseX, int mouseY, float partialTicks) {
      this.drawDefaultBackground();
      this.drawCenteredString(this.fontRendererObj, this.reason, this.width / 2, this.height / 2 - this.field_175353_i / 2 - this.fontRendererObj.FONT_HEIGHT * 2, 11184810);
      int i = this.height / 2 - this.field_175353_i / 2;
      if (this.multilineMessage != null) {
         for(Iterator var5 = this.multilineMessage.iterator(); var5.hasNext(); i += this.fontRendererObj.FONT_HEIGHT) {
            String s = (String)var5.next();
            this.drawCenteredString(this.fontRendererObj, s, this.width / 2, i, 16777215);
         }
      }

      super.drawScreen(mouseX, mouseY, partialTicks);
   }

   // $FF: synthetic method
   protected void keyTyped(char typedChar, int keyCode) throws IOException {
   }

   // $FF: synthetic method
   public jebac_vexiays9i8bhkczr3(jebac_vexiakl614w3uw0xg screen, String reasonLocalizationKey, IChatComponent chatComp) {
      this.parentScreen = screen;
      this.reason = I18n.format(reasonLocalizationKey);
      this.message = chatComp;
   }

   // $FF: synthetic method
   protected void actionPerformed(jebac_vexia4oibzo50ubf0 button) throws IOException {
      if (button.id == 0) {
         this.mc.displayGuiScreen(this.parentScreen);
      }

   }

   // $FF: synthetic method
   public void initGui() {
      this.buttonList.clear();
      this.multilineMessage = this.fontRendererObj.listFormattedStringToWidth(this.message.getFormattedText(), this.width - 50);
      this.field_175353_i = this.multilineMessage.size() * this.fontRendererObj.FONT_HEIGHT;
      this.buttonList.add(new jebac_vexia4oibzo50ubf0(0, this.width / 2 - 100, this.height / 2 + this.field_175353_i / 2 + this.fontRendererObj.FONT_HEIGHT, I18n.format("gui.toMenu")));
   }
}
