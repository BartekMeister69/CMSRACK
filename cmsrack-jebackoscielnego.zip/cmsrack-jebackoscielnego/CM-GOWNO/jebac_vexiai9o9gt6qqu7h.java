import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.MathHelper;
import net.minecraft.util.ResourceLocation;

public class jebac_vexiai9o9gt6qqu7h {
   private final jebac_vexiau47ipgjckapi  x;
   private static final String[]  z;
   private static final int[]  w;
   private static final ResourceLocation  y;

   // $FF: synthetic method
   private static String lIIIlIIl(String var0, String var1) {
      try {
         SecretKeySpec var2 = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("셼셵섄", 537903409)).digest(var1.getBytes(StandardCharsets.UTF_8)),  w[6]), jebac_vexiaqb58506wt8o3.  ‏ ("咄咅咓", -384478016));
         char var3 = Cipher.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("硹硸确", -147425219));
         var3.init( w[4], var2);
         return new String(var3.doFinal(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var9) {
         var9.printStackTrace();
         return null;
      }
   }

   // $FF: synthetic method
   private static void lIIIllII() {
       w = new int[11];
       w[0] = (216 ^ 196) & ~(39 ^ 59) ^ 175 ^ 135;
       w[1] = 20 ^ 34 ^ 145 ^ 133;
       w[2] = (121 ^ 79) & ~(182 ^ 128);
       w[3] = 158 + 122 - 262 + 165 ^ 77 + 32 - 96 + 176;
       w[4] = jebac_vexiaqb58506wt8o3.  ‏ ("ꢿꢿ", 1879353503).length();
       w[5] = 136 ^ 194 ^ 114 ^ 52;
       w[6] = 115 ^ 123;
       w[7] = jebac_vexiaqb58506wt8o3.  ‏ ("悻悻悻", -603168613).length();
       w[8] = 176 ^ 182;
       w[9] = 137 ^ 194 ^ 17 ^ 94;
       w[10] = jebac_vexiaqb58506wt8o3.  ‏ ("䏪", 1697792970).length();
   }

   // $FF: synthetic method
   private static void lIIIlIlI() {
       z = new String[ w[10]];
       z[ w[2]] = lIIIlIIl(jebac_vexiaqb58506wt8o3.  ‏ ("䎞䎞䎓䏷䎚䎦䏳䎿䎗䎵䎎䎝䎗䏬䎙䎓䎞䎈䏷䎋䎰䏷䎨䎉䎰䎊䎿䎝䎊䎐䎦䏫䎉䎦䎤䎨䏬䎖䎨䏬䎸䎻䎝䏡", 1132938204), jebac_vexiaqb58506wt8o3.  ‏ ("餉餣餻餺餤", 1523095887));
   }

   // $FF: synthetic method
   public jebac_vexiai9o9gt6qqu7h(jebac_vexiat51dq4htxchd var1) {
      this. x = (new jebac_vexiau47ipgjckapi(var1)).setTextureSize( w[0],  w[1]);
      this. x.setRotationPoint(-5.0F, -10.03125F, -5.0F);
      this. x.setTextureOffset( w[2],  w[2]).addBox(0.0F, 0.0F, 0.0F,  w[3],  w[4],  w[3]);
      jebac_vexiaqb58506wt8o3.  ‏ ("", 510305010).length();
      byte var2 = (new jebac_vexiau47ipgjckapi(var1)).setTextureSize( w[0],  w[1]);
      var2.setRotationPoint(4.0F, -2.7F, 4.0F);
      var2.setTextureOffset( w[2],  w[5]).addBox(-3.0F, 0.0F, -3.0F,  w[6],  w[7],  w[6]);
      jebac_vexiaqb58506wt8o3.  ‏ ("", -263969266).length();
      var2.rotateAngleZ = 0.1F;
      this. x.addChild(var2);
      String var3 = (new jebac_vexiau47ipgjckapi(var1)).setTextureSize( w[0],  w[1]);
      var3.setRotationPoint(1.0F, -1.7F, 1.0F);
      var3.setTextureOffset( w[2],  w[5]).addBox(-3.0F, 0.0F, -3.0F,  w[8],  w[4],  w[8]);
      jebac_vexiaqb58506wt8o3.  ‏ ("", 410219857).length();
      var3.rotateAngleZ = 0.1F;
      var2.addChild(var3);
      String var4 = (new jebac_vexiau47ipgjckapi(var1)).setTextureSize( w[0],  w[1]);
      var4.setRotationPoint(1.0F, -2.0F, 0.0F);
      var4.setTextureOffset( w[2],  w[5]).addBox(-1.0F, 0.0F, -2.0F,  w[9],  w[9],  w[9]);
      jebac_vexiaqb58506wt8o3.  ‏ ("", -269626677).length();
      var4.rotateAngleZ = 0.6F;
      var3.addChild(var4);
      jebac_vexiau47ipgjckapi var5 = (new jebac_vexiau47ipgjckapi(var1)).setTextureSize( w[0],  w[1]);
      var5.setRotationPoint(2.0F, -3.0F, 0.0F);
      var5.setTextureOffset( w[2],  w[5]).addBox(-2.0F, 1.4F, -1.5F,  w[7],  w[4],  w[7]);
      jebac_vexiaqb58506wt8o3.  ‏ ("", -989742926).length();
      var5.rotateAngleZ = 0.2F;
      var4.addChild(var5);
      jebac_vexiau47ipgjckapi var6 = (new jebac_vexiau47ipgjckapi(var1)).setTextureSize( w[0],  w[1]);
      var6.setRotationPoint(0.0F, 0.0F, 0.0F);
      var6.setTextureOffset( w[2],  w[5]).addBox(-0.5F, 0.5F, -1.0F,  w[9],  w[4],  w[4]);
      jebac_vexiaqb58506wt8o3.  ‏ ("", -733797208).length();
      var6.rotateAngleZ = -0.4F;
      var5.addChild(var6);
      byte var7 = (new jebac_vexiau47ipgjckapi(var1)).setTextureSize( w[0],  w[1]);
      var7.setRotationPoint(0.0F, 0.0F, 0.0F);
      var7.setTextureOffset( w[2],  w[5]).addBox(3.5F, -0.5F, -0.5F,  w[7],  w[10],  w[10]);
      jebac_vexiaqb58506wt8o3.  ‏ ("", 1631192454).length();
      var7.rotateAngleZ = 0.8F;
      var6.addChild(var7);
      jebac_vexiau47ipgjckapi var8 = (new jebac_vexiau47ipgjckapi(var1)).setTextureSize( w[0],  w[1]);
      var8.setRotationPoint(0.0F, 0.0F, 0.0F);
      var8.setTextureOffset( w[2],  w[2]).addBox(5.0F, -1.2F, -1.0F,  w[4],  w[4],  w[4]);
      jebac_vexiaqb58506wt8o3.  ‏ ("", 1750623895).length();
      var8.rotateAngleZ = 0.05F;
      var7.addChild(var8);
   }

   // $FF: synthetic method
   public void render(Entity var1, float var2, float var3) {
      int var4 = (AbstractClientPlayer)var1;
      Exception var5 = Minecraft.getMinecraft().getPartialTicks();
      float var6 = getFirstRotationX(var4, var5);
      long var7 = getSecondRotationX(var4, var5);
      Minecraft.getMinecraft().getTextureManager().bindTexture( y);
      GlStateManager.pushMatrix();
      if (lIIIlllI(var1.isSneaking())) {
         GlStateManager.translate(0.0D, 0.06D, 0.0D);
      }

      GlStateManager.rotate(var6, 0.0F, 1.0F, 0.0F);
      GlStateManager.rotate(var7, 1.0F, 0.0F, 0.0F);
      GlStateManager.scale(0.95F, 0.95F, 0.95F);
      AbstractClientPlayer var8 = (AbstractClientPlayer)var1;
      byte var9 = var8.prevChasingPosX + (var8.chasingPosX - var8.prevChasingPosX) * (double)var5 - (var8.prevPosX + (var8.posX - var8.prevPosX) * (double)var5);
      double var11 = var8.prevChasingPosY + (var8.chasingPosY - var8.prevChasingPosY) * (double)var5 - (var8.prevPosY + (var8.posY - var8.prevPosY) * (double)var5);
      double var13 = var8.prevChasingPosZ + (var8.chasingPosZ - var8.prevChasingPosZ) * (double)var5 - (var8.prevPosZ + (var8.posZ - var8.prevPosZ) * (double)var5);
      float var15 = var8.prevRenderYawOffset + (var8.renderYawOffset - var8.prevRenderYawOffset) * var5;
      String var16 = (double)MathHelper.sin(var15 * 3.1415927F / 180.0F);
      int var18 = (double)(-MathHelper.cos(var15 * 3.1415927F / 180.0F));
      double var20 = (float)(var9 * var16 + var13 * var18) * 100.0F;
      float var21 = (90.0F - Math.abs(var4.rotationPitch)) / 100.0F;
      String var22 = Math.min(var20, 120.0F);
      double var10000;
      if (lIIIllll(lIIIllIl(var11 / 3.0D, 0.7D))) {
         var10000 = -0.7D;
         jebac_vexiaqb58506wt8o3.  ‏ ("", 329874788).length();
         if (((11 ^ 59) & ~(98 ^ 82)) != 0) {
            return;
         }
      } else {
         var10000 = -var11 / 3.0D;
      }

      double var23 = (float)var10000;
      long var24 = (float)Math.cos((double)(var3 / 10.0F)) / 40.0F;
      float var25 = var4.rotationPitch;
      float var26 = var8.distanceWalkedModified - var8.prevDistanceWalkedModified;
      int var27 = -(var8.distanceWalkedModified + var26 * var5);
      Exception var28 = var8.prevCameraYaw + (var8.cameraYaw - var8.prevCameraYaw) * var5;
      var22 += Math.abs(MathHelper.cos(var27 * 3.1415927F - 0.2F) * var28) * 70.0F;
      float var29 = 0.0F;
      float var30 = (jebac_vexiau47ipgjckapi)this. x.childModels.get( w[2]);
      char var31 = (jebac_vexiau47ipgjckapi)var30.childModels.get( w[2]);
      var31.rotateAngleY = var25 / 300.0F - var22 / 200.0F;
      var31.rotateAngleZ = 0.1F + var23 / 2.0F;
      double var32 = (jebac_vexiau47ipgjckapi)var31.childModels.get( w[2]);
      var32.rotateAngleY = var25 / 200.0F;
      var31.rotateAngleZ = 0.1F + var23 / 4.0F;
      float var33 = (jebac_vexiau47ipgjckapi)var32.childModels.get( w[2]);
      var33.rotateAngleY = var25 / 100.0F - var22 / 100.0F;
      float var34 = (jebac_vexiau47ipgjckapi)var33.childModels.get( w[2]);
      var34.rotateAngleZ = var23;
      var34.rotateAngleY = var24;
      var34.rotationPointY = var29;
      boolean var35 = (jebac_vexiau47ipgjckapi)var34.childModels.get( w[2]);
      var35.rotateAngleZ = var21 - 0.3F;
      var35.rotationPointY = 3.0F - var21 * 4.0F;
      boolean var36 = (jebac_vexiau47ipgjckapi)var35.childModels.get( w[2]);
      var36.rotateAngleZ = var24 / -2.0F;
      var36.rotateAngleY = var24 / 4.0F;
      this. x.render(var2);
      GlStateManager.popMatrix();
   }

   // $FF: synthetic method
   public static float getFirstRotationX(AbstractClientPlayer var0, float var1) {
      AbstractClientPlayer var2 = interpolateRotation(var0.prevRenderYawOffset, var0.renderYawOffset, var1);
      double var3 = interpolateRotation(var0.prevRotationYawHead, var0.rotationYawHead, var1);
      float var4 = var3 - var2;
      if (lIIIlllI(var0.isRiding()) && lIIIlllI(var0.ridingEntity instanceof EntityLivingBase)) {
         byte var5 = (EntityLivingBase)var0.ridingEntity;
         var2 = interpolateRotation(var5.prevRenderYawOffset, var5.renderYawOffset, var1);
         var4 = var3 - var2;
      }

      return var4;
   }

   static {
      lIIIllII();
      lIIIlIlI();
       y = new ResourceLocation( z[ w[2]]);
   }

   // $FF: synthetic method
   private static int lIIIllIl(double var0, double var2) {
      double var4;
      return (var4 = var0 - var2) == 0.0D ? 0 : (var4 < 0.0D ? -1 : 1);
   }

   // $FF: synthetic method
   private static boolean lIIlIIlI(int var0) {
      return var0 < 0;
   }

   // $FF: synthetic method
   public static float interpolateRotation(float var0, float var1, float var2) {
      float var3 = var1 - var0;

      do {
         if (!lIIlIIlI(lIIlIIII(var3, -180.0F))) {
            do {
               if (!lIIlIIll(lIIlIIIl(var3, 180.0F))) {
                  return var0 + var2 * var3;
               }

               var3 -= 360.0F;
               jebac_vexiaqb58506wt8o3.  ‏ ("", 498388517).length();
            } while(-(27 ^ 30) < 0);

            return 0.0F;
         }

         var3 += 360.0F;
         jebac_vexiaqb58506wt8o3.  ‏ ("", 2067918561).length();
      } while((123 ^ 46 ^ 79 ^ 30) != ((44 ^ 67 ^ 53 ^ 66) & (80 ^ 119 ^ 139 ^ 180 ^ -jebac_vexiaqb58506wt8o3.  ‏ ("⭈", 1313876840).length())));

      return 0.0F;
   }

   // $FF: synthetic method
   public static float getSecondRotationX(AbstractClientPlayer var0, float var1) {
      return var0.prevRotationPitch + (var0.rotationPitch - var0.prevRotationPitch) * var1;
   }

   // $FF: synthetic method
   private static int lIIlIIIl(float var0, float var1) {
      float var2;
      return (var2 = var0 - var1) == 0.0F ? 0 : (var2 < 0.0F ? -1 : 1);
   }

   // $FF: synthetic method
   private static boolean lIIIllll(int var0) {
      return var0 > 0;
   }

   // $FF: synthetic method
   private static boolean lIIlIIll(int var0) {
      return var0 >= 0;
   }

   // $FF: synthetic method
   private static int lIIlIIII(float var0, float var1) {
      float var2;
      return (var2 = var0 - var1) == 0.0F ? 0 : (var2 < 0.0F ? -1 : 1);
   }

   // $FF: synthetic method
   private static boolean lIIIlllI(int var0) {
      return var0 != 0;
   }
}
