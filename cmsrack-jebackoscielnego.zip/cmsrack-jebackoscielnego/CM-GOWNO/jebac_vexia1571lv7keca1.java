import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;

public class jebac_vexia1571lv7keca1 extends jebac_vexia4oibzo50ubf0 {
   private final double  ig;
   private double  ic;
   private final String  if;
   private static final int[]  ie;
   private boolean  id;
   private final double  ih;

   // $FF: synthetic method
   public void mouseReleased(int var1, int var2) {
      this. id = (boolean) ie[0];
   }

   // $FF: synthetic method
   private static boolean lIIllll(int var0) {
      return var0 != 0;
   }

   // $FF: synthetic method
   private static boolean lIlIlII(int var0) {
      return var0 > 0;
   }

   // $FF: synthetic method
   int getValueInt() {
      return (int)Math.round(this. ic * (this. ig - this. ih) + this. ih);
   }

   // $FF: synthetic method
   public void drawButton(Minecraft var1, int var2, int var3) {
      if (lIIllll(jebac_vexiawzpzy1x3sez8. bx)) {
         GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
         int var10001;
         if (llIIlII(var2, this.xPosition) && llIIlII(var3, this.yPosition) && llIIlIl(var2, this.xPosition + this.width) && llIIlIl(var3, this.yPosition + this.height)) {
            var10001 =  ie[6];
            jebac_vexiaqb58506wt8o3.  ‏ ("", -1114293574).length();
            if (((209 ^ 196 ^ 197 ^ 128) & (70 ^ 65 ^ 205 ^ 154 ^ -jebac_vexiaqb58506wt8o3.  ‏ ("屁", 1622170721).length())) > jebac_vexiaqb58506wt8o3.  ‏ ("穴", -1939506604).length()) {
               return;
            }
         } else {
            var10001 =  ie[0];
         }

         this.hovered = (boolean)var10001;
         if (llIIllI(llIIIll(System.currentTimeMillis(), this.animationUpdateTime))) {
            this.animation.update(this.hovered);
            this.animationUpdateTime = System.currentTimeMillis() + 10L;
         }

         int var10000;
         if (lIIllll(this.enabled)) {
            var10000 =  ie[7];
            jebac_vexiaqb58506wt8o3.  ‏ ("", 667900436).length();
            if (-jebac_vexiaqb58506wt8o3.  ‏ ("蕸蕸", 881493336).length() > 0) {
               return;
            }
         } else {
            var10000 =  ie[8];
         }

         int var4 = var10000;
         this.mouseDragged(var1, var2, var3);
         super.drawCenteredString(var1.fontRendererObj, this.displayString, this.xPosition + this.width /  ie[9], this.yPosition +  ie[10], var4);
         if (lIIllll(this.enabled) && lIIllll(this.hovered)) {
            double var10 = (double)(this.xPosition + this.width /  ie[9]) - this.animation.getValue() * (double)this.width / 2.0D;
            double var11 = (double)this.yPosition;
            double var10002 = (double)(this.xPosition + this.width /  ie[9]) + this.animation.getValue() * (double)this.width / 2.0D;
            double var10003 = (double)this.yPosition;
            int var10005;
            if (lIIllll(jebac_vexiawzpzy1x3sez8. be)) {
               var10005 = jebac_vexiacs3qcki5ln4n.getRainbow( ie[11],  ie[12]).getRGB();
               jebac_vexiaqb58506wt8o3.  ‏ ("", 179045510).length();
               if (null != null) {
                  return;
               }
            } else {
               var10005 =  ie[13];
            }

            jebac_vexiawqkxo5ufmdem.drawLine2D(var10, var11, var10002, var10003, 1.0F, var10005);
            var10 = (double)(this.xPosition + this.width /  ie[9]) - this.animation.getValue() * (double)this.width / 2.0D;
            var11 = (double)(this.yPosition + this.height);
            var10002 = (double)(this.xPosition + this.width /  ie[9]) + this.animation.getValue() * (double)this.width / 2.0D;
            var10003 = (double)(this.yPosition + this.height);
            if (lIIllll(jebac_vexiawzpzy1x3sez8. be)) {
               var10005 = jebac_vexiacs3qcki5ln4n.getRainbow( ie[11],  ie[12]).getRGB();
               jebac_vexiaqb58506wt8o3.  ‏ ("", -1350560841).length();
               if (jebac_vexiaqb58506wt8o3.  ‏ ("糫糫糫", -2069726005).length() <= 0) {
                  return;
               }
            } else {
               var10005 =  ie[13];
            }

            jebac_vexiawqkxo5ufmdem.drawLine2D(var10, var11, var10002, var10003, 1.0F, var10005);
            var10 = (double)(this.xPosition + this.width /  ie[9]) - this.animation.getValue() * (double)this.width / 2.0D + (double)((int)(this. ic * (this.animation.getValue() * (double)this.width - 8.0D)));
            var11 = (double)this.yPosition;
            var10002 = (double)(this.xPosition + this.width /  ie[9]) - this.animation.getValue() * (double)this.width / 2.0D + (double)((int)(this. ic * (this.animation.getValue() * (double)this.width - 8.0D))) + 8.0D;
            var10003 = (double)this.yPosition;
            if (lIIllll(jebac_vexiawzpzy1x3sez8. be)) {
               var10005 = jebac_vexiacs3qcki5ln4n.getRainbow( ie[11],  ie[12]).getRGB();
               jebac_vexiaqb58506wt8o3.  ‏ ("", -297943663).length();
               if (-(24 ^ 87 ^ 245 ^ 190) >= 0) {
                  return;
               }
            } else {
               var10005 =  ie[7];
            }

            jebac_vexiawqkxo5ufmdem.drawLine2D(var10, var11, var10002, var10003, 1.0F, var10005);
            var10 = (double)(this.xPosition + this.width /  ie[9]) - this.animation.getValue() * (double)this.width / 2.0D + (double)((int)(this. ic * (this.animation.getValue() * (double)this.width - 8.0D)));
            var11 = (double)(this.yPosition + this.height);
            var10002 = (double)(this.xPosition + this.width /  ie[9]) - this.animation.getValue() * (double)this.width / 2.0D + (double)((int)(this. ic * (this.animation.getValue() * (double)this.width - 8.0D))) + 8.0D;
            var10003 = (double)(this.yPosition + this.height);
            if (lIIllll(jebac_vexiawzpzy1x3sez8. be)) {
               var10005 = jebac_vexiacs3qcki5ln4n.getRainbow( ie[11],  ie[12]).getRGB();
               jebac_vexiaqb58506wt8o3.  ‏ ("", 1922636666).length();
               if (((15 ^ 45) & ~(39 ^ 5)) != 0) {
                  return;
               }
            } else {
               var10005 =  ie[7];
            }

            jebac_vexiawqkxo5ufmdem.drawLine2D(var10, var11, var10002, var10003, 1.0F, var10005);
         }

         GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
         jebac_vexiaqb58506wt8o3.  ‏ ("", -1149391896).length();
         if ((23 ^ 19) <= 0) {
            return;
         }
      } else {
         super.drawButton(var1, var2, var3);
      }

   }

   // $FF: synthetic method
   private void updateSlider() {
      if (lIlIIll(lIlIIIl(this. ic, 0.0D))) {
         this. ic = 0.0D;
      }

      if (lIlIlII(lIlIIlI(this. ic, 1.0D))) {
         this. ic = 1.0D;
      }

      short var1 = Integer.toString((int)Math.round(this. ic * (this. ig - this. ih) + this. ih));
      this.displayString = String.valueOf((new StringBuilder()).append(this. if).append(var1));
   }

   // $FF: synthetic method
   public double getValue() {
      return this. ic * (this. ig - this. ih) + this. ih;
   }

   // $FF: synthetic method
   public int getHoverState(boolean var1) {
      return  ie[0];
   }

   // $FF: synthetic method
   jebac_vexia1571lv7keca1(int var1, int var2, int var3, int var4, int var5, String var6, double var7, double var9, double var11) {
      super(var1, var2, var3, var4, var5, var6);
      this. ih = var7;
      this. ig = var9;
      this. ic = (var11 - this. ih) / (this. ig - this. ih);
      this. if = var6;
      jebac_vexia1571lv7keca1 var13 = Integer.toString((int)Math.round(this. ic * (this. ig - this. ih) + this. ih));
      this.displayString = String.valueOf((new StringBuilder()).append(this. if).append(var13));
   }

   // $FF: synthetic method
   private static void lIIlllI() {
       ie = new int[14];
       ie[0] = (33 ^ 28) & ~(143 ^ 178);
       ie[1] = 193 ^ 197;
       ie[2] = 106 + 129 - 84 + 2 ^ 17 + 33 - -87 + 8;
       ie[3] = 53 + 1 - -42 + 140 ^ 73 + 68 - 128 + 161;
       ie[4] = 154 ^ 175 ^ 23 ^ 54;
       ie[5] = 13 + 106 - -23 + 54;
       ie[6] = jebac_vexiaqb58506wt8o3.  ‏ ("臖", 1163624950).length();
       ie[7] = -271 & 14737902;
       ie[8] = -(-10374 & 27551) & -7173 & 10551229;
       ie[9] = jebac_vexiaqb58506wt8o3.  ‏ ("䱔䱔", -1096266636).length();
       ie[10] = 195 ^ 198;
       ie[11] = -3076 & 4075;
       ie[12] = 98 ^ 109;
       ie[13] = -(-(78 ^ 127) & -11 & 8355770);
   }

   // $FF: synthetic method
   private static int llIIIll(long var0, long var2) {
      long var4;
      return (var4 = var0 - var2) == 0L ? 0 : (var4 < 0L ? -1 : 1);
   }

   // $FF: synthetic method
   public void setValue(double var1) {
      this. ic = (var1 - this. ih) / (this. ig - this. ih);
   }

   // $FF: synthetic method
   protected void mouseDragged(Minecraft var1, int var2, int var3) {
      if (lIIllll(this.visible)) {
         if (lIIllll(this. id)) {
            this. ic = (double)((float)(var2 - (this.xPosition +  ie[1])) / (float)(this.width -  ie[2]));
            this.updateSlider();
         }

         if (lIlIIII(jebac_vexiawzpzy1x3sez8. bx)) {
            var1.getTextureManager().bindTexture(buttonTextures);
            GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
            this.drawTexturedModalRect(this.xPosition + (int)(this. ic * (double)((float)(this.width -  ie[2]))), this.yPosition,  ie[0],  ie[3],  ie[1],  ie[4]);
            this.drawTexturedModalRect(this.xPosition + (int)(this. ic * (double)((float)(this.width -  ie[2]))) +  ie[1], this.yPosition,  ie[5],  ie[3],  ie[1],  ie[4]);
         }
      }

   }

   // $FF: synthetic method
   private static boolean lIlIIII(int var0) {
      return var0 == 0;
   }

   // $FF: synthetic method
   private static int lIlIIIl(double var0, double var2) {
      double var4;
      return (var4 = var0 - var2) == 0.0D ? 0 : (var4 < 0.0D ? -1 : 1);
   }

   // $FF: synthetic method
   private static boolean llIIllI(int var0) {
      return var0 >= 0;
   }

   // $FF: synthetic method
   private static boolean llIIlII(int var0, int var1) {
      return var0 >= var1;
   }

   // $FF: synthetic method
   private static boolean lIlIIll(int var0) {
      return var0 < 0;
   }

   // $FF: synthetic method
   public boolean mousePressed(Minecraft var1, int var2, int var3) {
      if (lIIllll(super.mousePressed(var1, var2, var3))) {
         this. ic = (double)((float)(var2 - (this.xPosition +  ie[1])) / (float)(this.width -  ie[2]));
         this.updateSlider();
         this. id = (boolean) ie[6];
         return (boolean) ie[6];
      } else {
         return (boolean) ie[0];
      }
   }

   // $FF: synthetic method
   private static boolean llIIlIl(int var0, int var1) {
      return var0 < var1;
   }

   static {
      lIIlllI();
   }

   // $FF: synthetic method
   private static int lIlIIlI(double var0, double var2) {
      double var4;
      return (var4 = var0 - var2) == 0.0D ? 0 : (var4 < 0.0D ? -1 : 1);
   }
}
