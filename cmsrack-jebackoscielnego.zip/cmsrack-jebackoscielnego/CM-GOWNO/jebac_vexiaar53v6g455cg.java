import com.google.common.collect.Lists;
import java.util.List;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.IChatComponent;

public class jebac_vexiaar53v6g455cg implements jebac_vexialqxnhsad8zg7 {
   // $FF: synthetic field
   private final List field_178671_a = Lists.newArrayList();

   // $FF: synthetic method
   public List func_178669_a() {
      return this.field_178671_a;
   }

   // $FF: synthetic method
   public jebac_vexiaar53v6g455cg() {
      this.field_178671_a.add(new jebac_vexiatfe7m6mntuj0());
      this.field_178671_a.add(new jebac_vexiazwukeefhh95d());
   }

   // $FF: synthetic method
   public IChatComponent func_178670_b() {
      return new ChatComponentText("Press a key to select a command, and again to use it.");
   }
}
