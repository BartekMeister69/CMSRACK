import java.awt.image.BufferedImage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.util.ResourceLocation;

public class jebac_vexiaygbu8cvjfpcg {
   // $FF: synthetic field
   private ResourceLocation textureLocation = null;
   // $FF: synthetic field
   private DynamicTexture texture = null;
   // $FF: synthetic field
   private BufferedImage textureImage = null;
   // $FF: synthetic field
   private jebac_vexianytr9dqjsedo[] modelRenderers;
   // $FF: synthetic field
   private ResourceLocation locationMissing = new ResourceLocation("textures/blocks/wool_colored_red.png");
   // $FF: synthetic field
   private boolean usePlayerTexture;

   // $FF: synthetic method
   public static jebac_vexiau47ipgjckapi getAttachModel(jebac_vexia88utjmuujofl p_getAttachModel_0_, int p_getAttachModel_1_) {
      switch(p_getAttachModel_1_) {
      case 0:
         return p_getAttachModel_0_.bipedBody;
      case 1:
         return p_getAttachModel_0_.bipedHead;
      case 2:
         return p_getAttachModel_0_.bipedLeftArm;
      case 3:
         return p_getAttachModel_0_.bipedRightArm;
      case 4:
         return p_getAttachModel_0_.bipedLeftLeg;
      case 5:
         return p_getAttachModel_0_.bipedRightLeg;
      default:
         return null;
      }
   }

   // $FF: synthetic method
   public void render(jebac_vexia88utjmuujofl p_render_1_, AbstractClientPlayer p_render_2_, float p_render_3_) {
      TextureManager texturemanager = jebac_vexiakrwecfs16wve.getTextureManager();
      if (this.usePlayerTexture) {
         texturemanager.bindTexture(p_render_2_.getLocationSkin());
      } else if (this.textureLocation != null) {
         if (this.texture == null && this.textureImage != null) {
            this.texture = new DynamicTexture(this.textureImage);
            Minecraft.getMinecraft().getTextureManager().loadTexture(this.textureLocation, this.texture);
         }

         texturemanager.bindTexture(this.textureLocation);
      } else {
         texturemanager.bindTexture(this.locationMissing);
      }

      jebac_vexianytr9dqjsedo[] var5 = this.modelRenderers;
      int var6 = var5.length;

      for(int var7 = 0; var7 < var6; ++var7) {
         jebac_vexianytr9dqjsedo playeritemrenderer = var5[var7];
         GlStateManager.pushMatrix();
         if (p_render_2_.isSneaking()) {
            GlStateManager.translate(0.0F, 0.2F, 0.0F);
         }

         playeritemrenderer.render(p_render_1_, p_render_3_);
         GlStateManager.popMatrix();
      }

   }

   // $FF: synthetic method
   public DynamicTexture getTexture() {
      return this.texture;
   }

   // $FF: synthetic method
   public void setTextureImage(BufferedImage p_setTextureImage_1_) {
      this.textureImage = p_setTextureImage_1_;
   }

   // $FF: synthetic method
   public boolean isUsePlayerTexture() {
      return this.usePlayerTexture;
   }

   // $FF: synthetic method
   public jebac_vexiaygbu8cvjfpcg(boolean p_i74_2_, jebac_vexianytr9dqjsedo[] p_i74_3_) {
      this.usePlayerTexture = p_i74_2_;
      this.modelRenderers = p_i74_3_;
   }

   // $FF: synthetic method
   public void setTextureLocation(ResourceLocation p_setTextureLocation_1_) {
      this.textureLocation = p_setTextureLocation_1_;
   }
}
