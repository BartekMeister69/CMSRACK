import java.lang.reflect.Field;

public class jebac_vexia061cdu2llyx7 {
   // $FF: synthetic field
   private boolean checked;
   // $FF: synthetic field
   private jebac_vexiasxnrrk3b6ekg fieldLocator;
   // $FF: synthetic field
   private Field targetField;

   // $FF: synthetic method
   public boolean exists() {
      return this.getTargetField() != null;
   }

   // $FF: synthetic method
   public void setValue(Object p_setValue_1_, Object p_setValue_2_) {
      jebac_vexiawp5rpzl0e6ma.setFieldValue(p_setValue_1_, this, p_setValue_2_);
   }

   // $FF: synthetic method
   public jebac_vexia061cdu2llyx7(jebac_vexiajs8ej2dllnvc p_i87_1_, Class p_i87_2_, int p_i87_3_) {
      this(new jebac_vexiab2s3j88xnwyz(p_i87_1_, p_i87_2_, p_i87_3_));
   }

   // $FF: synthetic method
   public Field getTargetField() {
      if (this.checked) {
         return this.targetField;
      } else {
         this.checked = true;
         this.targetField = this.fieldLocator.getField();
         if (this.targetField != null) {
            this.targetField.setAccessible(true);
         }

         return this.targetField;
      }
   }

   // $FF: synthetic method
   public jebac_vexia061cdu2llyx7(jebac_vexiajs8ej2dllnvc p_i86_1_, Class p_i86_2_) {
      this(p_i86_1_, p_i86_2_, 0);
   }

   // $FF: synthetic method
   public Object getValue() {
      return jebac_vexiawp5rpzl0e6ma.getFieldValue((Object)null, this);
   }

   // $FF: synthetic method
   public void setValue(Object p_setValue_1_) {
      jebac_vexiawp5rpzl0e6ma.setFieldValue((Object)null, this, p_setValue_1_);
   }

   // $FF: synthetic method
   public jebac_vexia061cdu2llyx7(jebac_vexiasxnrrk3b6ekg p_i89_1_) {
      this.fieldLocator = null;
      this.checked = false;
      this.targetField = null;
      this.fieldLocator = p_i89_1_;
      this.getTargetField();
   }

   // $FF: synthetic method
   public jebac_vexia061cdu2llyx7(jebac_vexiajs8ej2dllnvc p_i85_1_, String p_i85_2_) {
      this(new jebac_vexiaho8act160qvb(p_i85_1_, p_i85_2_));
   }
}
