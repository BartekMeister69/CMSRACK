import java.awt.Color;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.resources.I18n;

public class jebac_vexia2g8q4mw5nu4u extends jebac_vexiakl614w3uw0xg {
   private static final int[]  es;
   private static final String[]  er;
   private final jebac_vexiakl614w3uw0xg  eq;

   // $FF: synthetic method
   private static boolean lIllIIl(int var0, int var1) {
      return var0 == var1;
   }

   // $FF: synthetic method
   protected void actionPerformed(jebac_vexia4oibzo50ubf0 var1) throws IOException {
      if (lIlIlll(var1.enabled)) {
         if (lIllIII(var1.id)) {
            int var10000;
            if (lIllIII(jebac_vexiawzpzy1x3sez8. bl)) {
               var10000 =  es[6];
               jebac_vexiaqb58506wt8o3.  ‏ ("", -1463031697).length();
               if (jebac_vexiaqb58506wt8o3.  ‏ ("ݔ", 739051380).length() > jebac_vexiaqb58506wt8o3.  ‏ ("܍܍܍", 754386733).length()) {
                  return;
               }
            } else {
               var10000 =  es[0];
            }

            jebac_vexiawzpzy1x3sez8. bl = (boolean)var10000;
            this.mc.displayGuiScreen(this);
            jebac_vexiaqb58506wt8o3.  ‏ ("", 1781934057).length();
            if (jebac_vexiaqb58506wt8o3.  ‏ ("㉅", 28979813).length() >= (51 ^ 40 ^ 59 ^ 36)) {
               return;
            }
         } else if (lIllIIl(var1.id,  es[6])) {
            if (lIlIlll(var1.displayString.contains( er[ es[13]]))) {
               jebac_vexiaau3mg1q92fzj. dy. jo = Color.BLUE;
               jebac_vexiaqb58506wt8o3.  ‏ ("", -1475930095).length();
               if (-(231 ^ 191 ^ 255 ^ 162) >= 0) {
                  return;
               }
            } else if (lIlIlll(var1.displayString.contains( er[ es[14]]))) {
               jebac_vexiaau3mg1q92fzj. dy. jo = Color.GREEN;
               jebac_vexiaqb58506wt8o3.  ‏ ("", 1814640141).length();
               if ((27 ^ 74 ^ 65 ^ 20) < jebac_vexiaqb58506wt8o3.  ‏ ("ᓏ", 181736687).length()) {
                  return;
               }
            } else if (lIlIlll(var1.displayString.contains( er[ es[15]]))) {
               jebac_vexiaau3mg1q92fzj. dy. jo = Color.MAGENTA;
               jebac_vexiaqb58506wt8o3.  ‏ ("", -1808961818).length();
               if (jebac_vexiaqb58506wt8o3.  ‏ ("삠삠", -2015313792).length() != jebac_vexiaqb58506wt8o3.  ‏ ("昔昔", 249259572).length()) {
                  return;
               }
            } else if (lIlIlll(var1.displayString.contains( er[ es[16]]))) {
               jebac_vexiaau3mg1q92fzj. dy. jo = Color.RED;
               jebac_vexiaqb58506wt8o3.  ‏ ("", 266526521).length();
               if (jebac_vexiaqb58506wt8o3.  ‏ ("▇", -1118755417).length() == -jebac_vexiaqb58506wt8o3.  ‏ ("붚", 792772026).length()) {
                  return;
               }
            } else if (lIlIlll(var1.displayString.contains( er[ es[17]]))) {
               jebac_vexiaau3mg1q92fzj. dy. jo = Color.YELLOW;
               jebac_vexiaqb58506wt8o3.  ‏ ("", 130119237).length();
               if (jebac_vexiaqb58506wt8o3.  ‏ ("悠", -2069995392).length() > jebac_vexiaqb58506wt8o3.  ‏ ("潉潉", -799510679).length()) {
                  return;
               }
            } else if (lIlIlll(var1.displayString.contains( er[ es[18]]))) {
               jebac_vexiaau3mg1q92fzj. dy. jo = Color.CYAN;
               jebac_vexiaqb58506wt8o3.  ‏ ("", 986959177).length();
               if (jebac_vexiaqb58506wt8o3.  ‏ ("ꐔꐔ", -422534092).length() <= jebac_vexiaqb58506wt8o3.  ‏ ("醐", 1794347440).length()) {
                  return;
               }
            } else if (lIlIlll(var1.displayString.contains( er[ es[19]]))) {
               jebac_vexiaau3mg1q92fzj. dy. jo = Color.GRAY;
               jebac_vexiaqb58506wt8o3.  ‏ ("", -873139542).length();
               if (jebac_vexiaqb58506wt8o3.  ‏ ("善善", 1481528740).length() < jebac_vexiaqb58506wt8o3.  ‏ ("헒", -508504590).length()) {
                  return;
               }
            } else if (lIlIlll(var1.displayString.contains( er[ es[20]]))) {
               jebac_vexiaau3mg1q92fzj. dy. jo = Color.ORANGE;
               jebac_vexiaqb58506wt8o3.  ‏ ("", 1756971660).length();
               if (-jebac_vexiaqb58506wt8o3.  ‏ ("\uea70", 119794256).length() > jebac_vexiaqb58506wt8o3.  ‏ ("焞焞", -1197379266).length()) {
                  return;
               }
            } else if (lIlIlll(var1.displayString.contains( er[ es[21]]))) {
               jebac_vexiaau3mg1q92fzj. dy. jo = Color.PINK;
               jebac_vexiaqb58506wt8o3.  ‏ ("", -1258212328).length();
               if (-jebac_vexiaqb58506wt8o3.  ‏ ("淅", -645894683).length() >= ((67 ^ 3 ^ 77 ^ 65) & (93 ^ 2 ^ 57 ^ 42 ^ -jebac_vexiaqb58506wt8o3.  ‏ ("囇", 356996839).length()))) {
                  return;
               }
            } else if (lIlIlll(var1.displayString.contains( er[ es[22]]))) {
               jebac_vexiaau3mg1q92fzj. dy. ju = (boolean) es[6];
               jebac_vexiaqb58506wt8o3.  ‏ ("", 1324233555).length();
               if (-jebac_vexiaqb58506wt8o3.  ‏ ("⤺", -592565990).length() == ((152 ^ 174) & ~(179 ^ 133))) {
                  return;
               }
            } else {
               jebac_vexiaau3mg1q92fzj. dy. jo = Color.WHITE;
               jebac_vexiaau3mg1q92fzj. dy. ju = (boolean) es[0];
            }

            this.mc.displayGuiScreen(this);
            jebac_vexiaqb58506wt8o3.  ‏ ("", -933923462).length();
            if (-jebac_vexiaqb58506wt8o3.  ‏ ("⪣⪣⪣", -1510856061).length() > 0) {
               return;
            }
         } else if (lIllIIl(var1.id,  es[1])) {
            jebac_vexiaffroustvvf49 var4 = jebac_vexiaau3mg1q92fzj. dy;
            int var10001;
            if (lIllIII(jebac_vexiaau3mg1q92fzj. dy. jp)) {
               var10001 =  es[6];
               jebac_vexiaqb58506wt8o3.  ‏ ("", 1373082758).length();
               if (-(53 ^ 49 ^ jebac_vexiaqb58506wt8o3.  ‏ ("숽", -1482112483).length()) >= 0) {
                  return;
               }
            } else {
               var10001 =  es[0];
            }

            var4. jp = (boolean)var10001;
            this.mc.displayGuiScreen(this);
            jebac_vexiaqb58506wt8o3.  ‏ ("", -969201746).length();
            if (((133 ^ 188) & ~(144 ^ 169)) > 0) {
               return;
            }
         } else if (lIllIIl(var1.id,  es[8])) {
            this.mc.displayGuiScreen(this. eq);
         }

         jebac_vexia67ba3dligh23.save();
      }

   }

   // $FF: synthetic method
   private static boolean lIllIlI(int var0, int var1) {
      return var0 < var1;
   }

   // $FF: synthetic method
   public jebac_vexia2g8q4mw5nu4u(jebac_vexiakl614w3uw0xg var1) {
      this. eq = var1;
   }

   // $FF: synthetic method
   private static void lIlIllI() {
       es = new int[26];
       es[0] = (11 + 3 - -134 + 0 ^ 10 + 39 - -58 + 81) & (192 ^ 137 ^ 245 ^ 148 ^ -jebac_vexiaqb58506wt8o3.  ‏ ("ﻛ", 794951419).length());
       es[1] = jebac_vexiaqb58506wt8o3.  ‏ ("쩍쩍", -1391605139).length();
       es[2] = 141 + 45 - 172 + 141;
       es[3] = 8 ^ 127 ^ 125 ^ 12;
       es[4] = 1 + 21 - -14 + 114;
       es[5] = 220 ^ 179 ^ 120 ^ 3;
       es[6] = jebac_vexiaqb58506wt8o3.  ‏ ("漆", 758935334).length();
       es[7] = 21 ^ 37 ^ 163 ^ 150;
       es[8] = jebac_vexiaqb58506wt8o3.  ‏ ("ﭙﭙﭙ", -1522205831).length();
       es[9] = 75 + 141 - 204 + 157 ^ 132 + 63 - 84 + 66;
       es[10] = 194 ^ 171 ^ 248 ^ 149;
       es[11] = 195 ^ 167;
       es[12] = 39 + 153 - 62 + 38;
       es[13] = 14 ^ 9;
       es[14] = 48 ^ 56;
       es[15] = 69 ^ 76;
       es[16] = 84 ^ 94;
       es[17] = 1 + 129 - 21 + 34 ^ 34 + 1 - -26 + 71;
       es[18] = 160 ^ 172;
       es[19] = 83 ^ 119 ^ 166 ^ 143;
       es[20] = 85 ^ 91;
       es[21] = 23 ^ 24;
       es[22] = 156 ^ 140;
       es[23] = 34 ^ 51;
       es[24] = -1 & 16777215;
       es[25] = 130 ^ 144;
   }

   // $FF: synthetic method
   public void initGui() {
      List var10000 = this.buttonList;
      jebac_vexia4oibzo50ubf0 var10001 = new jebac_vexia4oibzo50ubf0;
      int var10003 =  es[0];
      int var10004 = this.width /  es[1] -  es[2];
      int var10005 = this.height /  es[3] -  es[3];
      int var10006 =  es[4];
      int var10007 =  es[5];
      String var10008;
      if (lIlIlll(jebac_vexiawzpzy1x3sez8. bl)) {
         var10008 =  er[ es[0]];
         jebac_vexiaqb58506wt8o3.  ‏ ("", 1504106051).length();
         if (null != null) {
            return;
         }
      } else {
         var10008 =  er[ es[6]];
      }

      var10001.<init>(var10003, var10004, var10005, var10006, var10007, var10008);
      var10000.add(var10001);
      jebac_vexiaqb58506wt8o3.  ‏ ("", 1393675842).length();
      var10000 = this.buttonList;
      var10001 = new jebac_vexia4oibzo50ubf0;
      var10003 =  es[6];
      var10004 = this.width /  es[1] +  es[7];
      var10005 = this.height /  es[3] -  es[3];
      var10006 =  es[4];
      var10007 =  es[5];
      StringBuilder var2 = (new StringBuilder()).append( er[ es[1]]);
      String var10009;
      if (lIlIlll(jebac_vexiaau3mg1q92fzj. dy. ju)) {
         var10009 =  er[ es[8]];
         jebac_vexiaqb58506wt8o3.  ‏ ("", -2112817310).length();
         if (jebac_vexiaqb58506wt8o3.  ‏ ("憔憔憔", -1603051084).length() < 0) {
            return;
         }
      } else {
         var10009 = jebac_vexiacs3qcki5ln4n.toString(jebac_vexiaau3mg1q92fzj. dy. jo);
      }

      var10001.<init>(var10003, var10004, var10005, var10006, var10007, String.valueOf(var2.append(var10009)));
      var10000.add(var10001);
      jebac_vexiaqb58506wt8o3.  ‏ ("", -1366995802).length();
      var10000 = this.buttonList;
      var10001 = new jebac_vexia4oibzo50ubf0;
      var10003 =  es[1];
      var10004 = this.width /  es[1] -  es[2];
      var10005 = this.height /  es[3] +  es[9] -  es[3];
      var10006 =  es[4];
      var10007 =  es[5];
      if (lIlIlll(jebac_vexiaau3mg1q92fzj. dy. jp)) {
         var10008 =  er[ es[10]];
         jebac_vexiaqb58506wt8o3.  ‏ ("", -448006289).length();
         if (-(150 ^ 184 ^ 101 ^ 79) > 0) {
            return;
         }
      } else {
         var10008 =  er[ es[7]];
      }

      var10001.<init>(var10003, var10004, var10005, var10006, var10007, var10008);
      var10000.add(var10001);
      jebac_vexiaqb58506wt8o3.  ‏ ("", 887365620).length();
      this.buttonList.add(new jebac_vexia4oibzo50ubf0( es[8], this.width /  es[1] -  es[11], this.height /  es[3] +  es[12], I18n.format( er[ es[3]])));
      jebac_vexiaqb58506wt8o3.  ‏ ("", -463194542).length();
      if (lIllIII(jebac_vexiawzpzy1x3sez8. bl)) {
         ((jebac_vexia4oibzo50ubf0)this.buttonList.get( es[6])).enabled = (boolean) es[0];
         ((jebac_vexia4oibzo50ubf0)this.buttonList.get( es[1])).enabled = (boolean) es[0];
      }

   }

   // $FF: synthetic method
   private static boolean lIllIII(int var0) {
      return var0 == 0;
   }

   // $FF: synthetic method
   private static String lIIllII(String var0, String var1) {
      try {
         char var2 = new SecretKeySpec(MessageDigest.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("験騚驫", -307127714)).digest(var1.getBytes(StandardCharsets.UTF_8)), jebac_vexiaqb58506wt8o3.  ‏ ("涥涋消涐涁涎涔涏", 1806986727));
         int var3 = Cipher.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("\udd78\udd56\udd55\udd4d\udd5c\udd53\udd49\udd52", 1855839546));
         var3.init( es[1], var2);
         return new String(var3.doFinal(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var9) {
         var9.printStackTrace();
         return null;
      }
   }

   // $FF: synthetic method
   private static void lIlIlIl() {
       er = new String[ es[25]];
       er[ es[0]] = lIIlIIl(jebac_vexiaqb58506wt8o3.  ‏ ("蕃蕯蕠蕱蔆蕔蔅蕁蕴蕅蕶蕌蕘蕳蕞蕜蕟蕗蕣蕆蕹蔌蕗蕻蕖蕱蕀蕁蕃蕚蕒蕂蕞蕡蕝蕲蕯蔞蕺蕴蕡蔂蕼蔈", 1401324853), jebac_vexiaqb58506wt8o3.  ‏ ("謲謼謥謻謈", 2125695856));
       er[ es[6]] = lIIlIll(jebac_vexiaqb58506wt8o3.  ‏ ("ᐟᐚᐮᑬᐟᐋᐜᐴᐐᐊ᐀ᐝᐟᐰᐶᐮᐸᐾᐲᐽᐖᐰ᐀ᑲᐜᐛᐺᐶᐔᐝᐵ᐀ᐎᐔᐖᐲᐗᐾᐈᐫᐉᐈᑤᑤ", 1097995353), jebac_vexiaqb58506wt8o3.  ‏ ("檄檒檍檥檿", -1300337977));
       er[ es[1]] = lIIlIll(jebac_vexiaqb58506wt8o3.  ‏ ("왺왍왝왬왩와왨왼왩왫왝왉왧왻왯외왨왍옞완왨왆왆왠", 386647594), jebac_vexiaqb58506wt8o3.  ‏ ("㺜㺊㺀㺌㺫", -829079831));
       er[ es[8]] = lIIllII(jebac_vexiaqb58506wt8o3.  ‏ ("\udbf0\udbd7\udbc5\udbdc\udbf1\udbc4\udb81\udbf9\udbd9\udbfa\udbf5\udb89", -1333404748), jebac_vexiaqb58506wt8o3.  ‏ ("➫➅➦➒➧", 2074159042));
       er[ es[10]] = lIIlIll(jebac_vexiaqb58506wt8o3.  ‏ ("䔶䔽䕁䔈䔶䔨䔴䔝䔶䔔䔼䔛䔲䔭䔍䔈䔠䔚䔶䕖䔾䔽䔎䔫䔺䔞䕄䕄", 672220537), jebac_vexiaqb58506wt8o3.  ‏ ("ᏥᏝᏌᏕᏴ", -1600187507));
       er[ es[7]] = lIIlIll(jebac_vexiaqb58506wt8o3.  ‏ ("ꂔꂅꂁꂽꂂꂀꂷꂞꂆꂌꂯꃶꂁꂐꃽꂑꂡꂧꂋꂗꂍꂭꂍꂪꂌꂅꃹꃹ", 1901764804), jebac_vexiaqb58506wt8o3.  ‏ ("튻특튎튢튖", -180366633));
       er[ es[3]] = lIIllII(jebac_vexiaqb58506wt8o3.  ‏ ("ڔڒڹڱڏڦۯڥۼڭړڠۣڤڠڰۥڀڭڔھچ۪۪", 194512599), jebac_vexiaqb58506wt8o3.  ‏ ("\uda13\uda3d\uda05\uda16\uda1a", 749853266));
       er[ es[13]] = lIIlIll(jebac_vexiaqb58506wt8o3.  ‏ ("ᴠᴋᵒᵕᴪᴕᴫᵟ", -458678942), jebac_vexiaqb58506wt8o3.  ‏ ("龥龑龆龿龳", 206348276));
       er[ es[14]] = lIIlIll(jebac_vexiaqb58506wt8o3.  ‏ ("⼩⼲⽗⽈⼳⼲⽞⽞", 1460875107), jebac_vexiaqb58506wt8o3.  ‏ ("㜏㜪㜃㜐㜱", 1171273576));
       er[ es[15]] = lIIllII(jebac_vexiaqb58506wt8o3.  ‏ ("懬懙懰憨懽懯懞懯懈憢憪憧", -314744422), jebac_vexiaqb58506wt8o3.  ‏ ("ᾱᾓᾒ᾽ᾨ", 187310053));
       er[ es[16]] = lIIlIIl(jebac_vexiaqb58506wt8o3.  ‏ ("ⵧⴖⴾⴈⴴⴑⵦ\u2d6e\u2d6eⴛⴰⵢ", 1613835615), jebac_vexiaqb58506wt8o3.  ‏ ("殒殘段殏殷", 1347578841));
       er[ es[17]] = lIIllII(jebac_vexiaqb58506wt8o3.  ‏ ("佈佁佺伐伟伜佤佳佢佭佼伔", 2037206825), jebac_vexiaqb58506wt8o3.  ‏ ("䭣䭘䭇䭄䭙", 280972064));
       er[ es[18]] = lIIlIll(jebac_vexiaqb58506wt8o3.  ‏ ("㘡㘟㘭㘅㘫㘐㘏㘜", 618149480), jebac_vexiaqb58506wt8o3.  ‏ ("\u0bba\u0b84பஇ\u0b97", 938740672));
       er[ es[19]] = lIIllII(jebac_vexiaqb58506wt8o3.  ‏ ("\ua62dꘆ\ua632ꘊ\ua63e꘏\ua62f\ua636\ua634\ua633꘢Ꙛ", 44541543), jebac_vexiaqb58506wt8o3.  ‏ ("⢭⢇⢶⢗⢮", 1144137924));
       er[ es[20]] = lIIllII(jebac_vexiaqb58506wt8o3.  ‏ ("輥輟輁輟輟載輬輟輚輁輟轷", 603361098), jebac_vexiaqb58506wt8o3.  ‏ ("\udb97\udb92\udba9\udb90\udb91", -1682646056));
       er[ es[21]] = lIIlIll(jebac_vexiaqb58506wt8o3.  ‏ ("邔邮邽邥邒還郦邘", -1772580650), jebac_vexiaqb58506wt8o3.  ‏ ("亚亙亿云予", -100577582));
       er[ es[22]] = lIIllII(jebac_vexiaqb58506wt8o3.  ‏ ("䏦䎚䏛䎑䏈䎘䏠䏯䎝䏢䏬䎔", -603962455), jebac_vexiaqb58506wt8o3.  ‏ ("謉謆謻謱謱", 421235536));
       er[ es[23]] = lIIlIll(jebac_vexiaqb58506wt8o3.  ‏ ("䉎䉋䉌䉓䉄䉱䉦䉢䉋䉾䉄䈾䉍䉎䈹䉃䉊䉊䉺䉬䉆䉛䉈䉊䉆䉘䉮䈢", -1053212151), jebac_vexiaqb58506wt8o3.  ‏ ("༑༾༱༎༱", 1627459420));
   }

   // $FF: synthetic method
   public void drawScreen(int var1, int var2, float var3) {
      this.drawDefaultBackground();
      this.drawCenteredString(this.fontRendererObj,  er[ es[23]], this.width /  es[1],  es[21],  es[24]);
      super.drawScreen(var1, var2, var3);
   }

   // $FF: synthetic method
   private static String lIIlIIl(String var0, String var1) {
      try {
         boolean var2 = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("\ue0bc\ue0b5\ue0c4", 862052593)).digest(var1.getBytes(StandardCharsets.UTF_8)),  es[14]), jebac_vexiaqb58506wt8o3.  ‏ ("뾘뾙뾏", -1498955812));
         SecretKeySpec var3 = Cipher.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("৾\u09ff৩", -1112274502));
         var3.init( es[1], var2);
         return new String(var3.doFinal(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var9) {
         var9.printStackTrace();
         return null;
      }
   }

   // $FF: synthetic method
   private static String lIIlIll(String var0, String var1) {
      var0 = new String(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      String var2 = new StringBuilder();
      String var3 = var1.toCharArray();
      long var4 =  es[0];
      StringBuilder var5 = var0.toCharArray();
      char[] var6 = var5.length;
      int var7 =  es[0];

      do {
         if (!lIllIlI(var7, var6)) {
            return String.valueOf(var2);
         }

         String var8 = var5[var7];
         var2.append((char)(var8 ^ var3[var4 % var3.length]));
         jebac_vexiaqb58506wt8o3.  ‏ ("", 57649445).length();
         ++var4;
         ++var7;
         jebac_vexiaqb58506wt8o3.  ‏ ("", 661966612).length();
      } while(jebac_vexiaqb58506wt8o3.  ‏ ("\uf55b\uf55b\uf55b", -1551174277).length() > jebac_vexiaqb58506wt8o3.  ‏ ("郴", -1362652972).length());

      return null;
   }

   static {
      lIlIllI();
      lIlIlIl();
   }

   // $FF: synthetic method
   private static boolean lIlIlll(int var0) {
      return var0 != 0;
   }
}
