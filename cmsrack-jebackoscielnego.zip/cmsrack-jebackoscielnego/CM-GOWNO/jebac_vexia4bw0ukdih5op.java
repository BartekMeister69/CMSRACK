import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

public class jebac_vexia4bw0ukdih5op {
   private static final int[]  ej;
   private static final String[]  ek;
   private final jebac_vexiau47ipgjckapi  el;
   private final jebac_vexiau47ipgjckapi  en;
   private static final ResourceLocation  em;

   // $FF: synthetic method
   private static int llIIll(float var0, float var1) {
      float var2;
      return (var2 = var0 - var1) == 0.0F ? 0 : (var2 < 0.0F ? -1 : 1);
   }

   // $FF: synthetic method
   private static String llIIl(String var0, String var1) {
      try {
         String var2 = new SecretKeySpec(MessageDigest.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("宁守对", -1872864308)).digest(var1.getBytes(StandardCharsets.UTF_8)), jebac_vexiaqb58506wt8o3.  ‏ ("論諸諻諣諲諽諧諼", -1805284716));
         String var3 = Cipher.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("◙◷◴◬◽◲◨◳", 961750427));
         var3.init( ej[5], var2);
         return new String(var3.doFinal(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var9) {
         var9.printStackTrace();
         return null;
      }
   }

   // $FF: synthetic method
   private static void lIllIl() {
       ej = new int[11];
       ej[0] = (12 ^ 77) & ~(229 ^ 164);
       ej[1] = 127 ^ 86 ^ 19 ^ 44;
       ej[2] = 87 ^ 114 ^ 27 ^ 57;
       ej[3] = 94 ^ 90;
       ej[4] = 30 ^ 22;
       ej[5] = jebac_vexiaqb58506wt8o3.  ‏ ("랗랗", -898058313).length();
       ej[6] = jebac_vexiaqb58506wt8o3.  ‏ ("\uebbf", 779742111).length();
       ej[7] = 105 ^ 108;
       ej[8] = jebac_vexiaqb58506wt8o3.  ‏ ("悲悲悲", -1862770542).length();
       ej[9] = 125 ^ 88 ^ 89 ^ 112;
       ej[10] = 84 ^ 21 ^ 77 ^ 86;
   }

   // $FF: synthetic method
   private static boolean llIllI(int var0) {
      return var0 >= 0;
   }

   // $FF: synthetic method
   public float getSecondRotationX(AbstractClientPlayer var1, float var2) {
      return var1.prevRotationPitch + (var1.rotationPitch - var1.prevRotationPitch) * var2;
   }

   static {
      lIllIl();
      llIlI();
       em = new ResourceLocation( ek[ ej[0]]);
   }

   // $FF: synthetic method
   public void render(Entity var1) {
      AbstractClientPlayer var2 = (AbstractClientPlayer)var1;
      float var3 = Minecraft.getMinecraft().getPartialTicks();
      float var4 = this.getFirstRotationX(var2, var3);
      float var5 = this.getSecondRotationX(var2, var3);
      int var6 =  ej[0];

      do {
         if (!lIllll(var6,  ej[3])) {
            return;
         }

         GlStateManager.pushMatrix();
         GlStateManager.color(1.0F, 1.0F, 1.0F);
         GlStateManager.rotate(var4, 0.0F, 1.0F, 0.0F);
         GlStateManager.rotate(var5, 1.0F, 0.0F, 0.0F);
         char var7 = 1.085F;
         GlStateManager.scale(var7, var7, var7);
         float var8;
         if (llIIII(var1.isSneaking())) {
            var8 = var1.rotationPitch * -7.0E-4F;
            GlStateManager.translate(0.0D, (double)(0.06F - Math.abs(var8)) + 0.02D, (double)var8);
         }

         GlStateManager.rotate((float)( ej[10] * var6), 0.0F, 1.0F, 0.0F);
         GlStateManager.translate(0.0D, -0.4753D, 0.0D);
         Minecraft.getMinecraft().getTextureManager().bindTexture( em);
         this. en.render(0.0571F);
         this. el.rotateAngleZ = 0.8F;
         this. el.rotationPointZ = 0.6F;
         this. el.rotationPointX = 0.4F;
         GlStateManager.translate(-0.22F, 0.0F, 0.0F);
         GlStateManager.color(1.0F, 1.0F, 1.0F);
         var8 = 1.0F;
         GL11.glColor4f(0.01F, 0.01F, 0.01F, 0.5F);
         int var9 =  ej[0];

         while(lIllll(var9,  ej[8])) {
            this. el.render(0.0561F);
            GlStateManager.translate(0.218F, 0.0F, 0.0F);
            ++var9;
            jebac_vexiaqb58506wt8o3.  ‏ ("", -1504463715).length();
            if ((249 ^ 162 ^ 98 ^ 61) < (97 ^ 20 ^ 193 ^ 176)) {
               return;
            }
         }

         GL11.glColor3d(1.0D, 1.0D, 1.0D);
         GlStateManager.color(1.0F, 1.0F, 1.0F);
         GlStateManager.popMatrix();
         ++var6;
         jebac_vexiaqb58506wt8o3.  ‏ ("", 559624473).length();
      } while(jebac_vexiaqb58506wt8o3.  ‏ ("兣兣兣", -1335406269).length() <= jebac_vexiaqb58506wt8o3.  ‏ ("゙゙゙", 234565817).length());

   }

   // $FF: synthetic method
   private static int llIlII(float var0, float var1) {
      float var2;
      return (var2 = var0 - var1) == 0.0F ? 0 : (var2 < 0.0F ? -1 : 1);
   }

   // $FF: synthetic method
   private static boolean llIIII(int var0) {
      return var0 != 0;
   }

   // $FF: synthetic method
   public jebac_vexia4bw0ukdih5op(jebac_vexiat51dq4htxchd var1) {
      this. en = (new jebac_vexiau47ipgjckapi(var1,  ej[0],  ej[0])).setTextureSize( ej[1],  ej[2]);
      this. en.setTextureOffset( ej[3],  ej[0]).addBox(-4.0F, 0.0F, -5.0F,  ej[4],  ej[5],  ej[6], 0.2F);
      this. en.setTextureOffset( ej[0],  ej[0]).addBox(-5.0F, -2.0F, -5.0F,  ej[6],  ej[3],  ej[6], 0.2F);
      this. en.setTextureOffset( ej[0],  ej[7]).addBox(-4.0F, -1.0F, -5.0F,  ej[6],  ej[6],  ej[6], 0.2F);
      this. en.setTextureOffset( ej[0],  ej[7]).addBox(3.0F, -1.0F, -5.0F,  ej[6],  ej[6],  ej[6], 0.2F);
      this. en.setTextureOffset( ej[3],  ej[7]).addBox(-1.5F, -1.0F, -5.0F,  ej[8],  ej[6],  ej[6], 0.2F);
      this. en.setTextureOffset( ej[0],  ej[7]).addBox(-0.5F, -2.0F, -5.0F,  ej[6],  ej[6],  ej[6], 0.2F);
      this. el = (new jebac_vexiau47ipgjckapi(var1,  ej[9],  ej[7])).setTextureSize( ej[1],  ej[2]);
      this. el.addBox(-0.5F, -0.0F, -6.0F,  ej[6],  ej[6],  ej[6], 0.2F);
      this. el.rotateAngleZ = 0.8F;
      this. el.rotationPointZ = 0.5F;
      this. el.rotationPointX = 0.4F;
   }

   // $FF: synthetic method
   public float interpolateRotation(float var1, float var2, float var3) {
      float var4 = var2 - var1;

      do {
         if (!llIlIl(llIIll(var4, -180.0F))) {
            do {
               if (!llIllI(llIlII(var4, 180.0F))) {
                  return var1 + var3 * var4;
               }

               var4 -= 360.0F;
               jebac_vexiaqb58506wt8o3.  ‏ ("", -48365824).length();
            } while(((82 ^ 78) & ~(61 ^ 33)) <= 0);

            return 0.0F;
         }

         var4 += 360.0F;
         jebac_vexiaqb58506wt8o3.  ‏ ("", -765419862).length();
      } while(((136 ^ 165) & ~(58 ^ 23)) <= 0);

      return 0.0F;
   }

   // $FF: synthetic method
   private static void llIlI() {
       ek = new String[ ej[6]];
       ek[ ej[0]] = llIIl(jebac_vexiaqb58506wt8o3.  ‏ ("▉▆█▟▜▎▸◟▒◚▇▲◘▹▆◓△◚▚▉▬▹▹▨▭◄▤▭▽▌▣▆▼▙▍▓▙▲◞▆▛▧▲◖", 334439915), jebac_vexiaqb58506wt8o3.  ‏ ("ﴛﴁﴖﴲ﴾", -301597355));
   }

   // $FF: synthetic method
   private static boolean llIlIl(int var0) {
      return var0 < 0;
   }

   // $FF: synthetic method
   public float getFirstRotationX(AbstractClientPlayer var1, float var2) {
      float var3 = this.interpolateRotation(var1.prevRenderYawOffset, var1.renderYawOffset, var2);
      byte var4 = this.interpolateRotation(var1.prevRotationYawHead, var1.rotationYawHead, var2);
      float var5 = var4 - var3;
      if (llIIII(var1.isRiding()) && llIIII(var1.ridingEntity instanceof EntityLivingBase)) {
         Exception var6 = (EntityLivingBase)var1.ridingEntity;
         var3 = this.interpolateRotation(var6.prevRenderYawOffset, var6.renderYawOffset, var2);
         var5 = var4 - var3;
      }

      return var5;
   }

   // $FF: synthetic method
   private static boolean lIllll(int var0, int var1) {
      return var0 < var1;
   }
}
