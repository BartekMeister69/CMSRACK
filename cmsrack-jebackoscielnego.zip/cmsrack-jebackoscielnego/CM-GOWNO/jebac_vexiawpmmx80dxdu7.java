import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

public class jebac_vexiawpmmx80dxdu7 implements jebac_vexiab8fgirhwov0i {
   // $FF: synthetic field
   protected ZipFile packZipFile;
   // $FF: synthetic field
   protected File packFile;

   // $FF: synthetic method
   public boolean hasDirectory(String resName) {
      try {
         if (this.packZipFile == null) {
            this.packZipFile = new ZipFile(this.packFile);
         }

         String s = jebac_vexianzkdk43wtdrt.removePrefix(resName, "/");
         ZipEntry zipentry = this.packZipFile.getEntry(s);
         return zipentry != null;
      } catch (IOException var4) {
         return false;
      }
   }

   // $FF: synthetic method
   public jebac_vexiawpmmx80dxdu7(String name, File file) {
      this.packFile = file;
      this.packZipFile = null;
   }

   // $FF: synthetic method
   public void close() {
      if (this.packZipFile != null) {
         try {
            this.packZipFile.close();
         } catch (Exception var2) {
         }

         this.packZipFile = null;
      }

   }

   // $FF: synthetic method
   public InputStream getResourceAsStream(String resName) {
      try {
         if (this.packZipFile == null) {
            this.packZipFile = new ZipFile(this.packFile);
         }

         String s = jebac_vexianzkdk43wtdrt.removePrefix(resName, "/");
         ZipEntry zipentry = this.packZipFile.getEntry(s);
         return zipentry == null ? null : this.packZipFile.getInputStream(zipentry);
      } catch (Exception var4) {
         return null;
      }
   }

   // $FF: synthetic method
   public String getName() {
      return this.packFile.getName();
   }
}
