import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.resources.I18n;

public class jebac_vexialnyznrpqlcd1 extends jebac_vexiakl614w3uw0xg {
   private static final int[]  dr;
   private final jebac_vexiakl614w3uw0xg  ds;
   private static final String[]  dt;

   // $FF: synthetic method
   private static boolean lIlII(Object var0) {
      return var0 != null;
   }

   // $FF: synthetic method
   private static String lIlI(String var0, String var1) {
      var0 = new String(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      char var2 = new StringBuilder();
      String var3 = var1.toCharArray();
      Exception var4 =  dr[0];
      Exception var5 = var0.toCharArray();
      StringBuilder var6 = var5.length;
      int var7 =  dr[0];

      do {
         if (!llIII(var7, var6)) {
            return String.valueOf(var2);
         }

         float var8 = var5[var7];
         var2.append((char)(var8 ^ var3[var4 % var3.length]));
         jebac_vexiaqb58506wt8o3.  ‏ ("", -1648110273).length();
         ++var4;
         ++var7;
         jebac_vexiaqb58506wt8o3.  ‏ ("", -970084457).length();
      } while(((117 ^ 126) & ~(125 ^ 118)) > -jebac_vexiaqb58506wt8o3.  ‏ ("益", 1737357879).length());

      return null;
   }

   // $FF: synthetic method
   protected void actionPerformed(jebac_vexia4oibzo50ubf0 var1) throws IOException {
      if (lIIlI(var1.enabled)) {
         if (lIIll(var1.id)) {
            if (lIIlI(jebac_vexiawzpzy1x3sez8. bv)) {
               jebac_vexiawzpzy1x3sez8. bv = (boolean) dr[0];
               if (lIlII(jebac_vexia2ug8d5nsqylv. et)) {
                  jebac_vexia2ug8d5nsqylv. et.close();
                  jebac_vexiaqb58506wt8o3.  ‏ ("", -671993536).length();
                  if (jebac_vexiaqb58506wt8o3.  ‏ ("轨轨", -207581368).length() > (145 ^ 149)) {
                     return;
                  }
               }
            } else {
               jebac_vexiawzpzy1x3sez8. bv = (boolean) dr[6];
            }

            this.mc.displayGuiScreen(this);
            jebac_vexiaqb58506wt8o3.  ‏ ("", 185626972).length();
            if ((4 ^ 1) <= 0) {
               return;
            }
         } else if (lIlIl(var1.id,  dr[6])) {
            if (lIIlI(jebac_vexiawzpzy1x3sez8. bv) && lIllI(jebac_vexia2ug8d5nsqylv. eu.getText().length(),  dr[6])) {
               jebac_vexia2ug8d5nsqylv.play(jebac_vexia2ug8d5nsqylv. eu.getText());
            }

            this.mc.displayGuiScreen(this. ds);
         }

         jebac_vexia67ba3dligh23.save();
      }

   }

   // $FF: synthetic method
   public void updateScreen() {
      jebac_vexia2ug8d5nsqylv. eu.updateCursorCounter();
   }

   // $FF: synthetic method
   public void initGui() {
      if (lIIIl(jebac_vexia2ug8d5nsqylv. eu)) {
         jebac_vexia2ug8d5nsqylv. eu = new jebac_vexiaa29g8ikthjc5( dr[0], this.fontRendererObj, this.width /  dr[1] -  dr[2],  dr[3],  dr[4],  dr[5]);
         jebac_vexia2ug8d5nsqylv. eu.setFocused((boolean) dr[6]);
         jebac_vexia2ug8d5nsqylv. eu.setText( dt[ dr[0]]);
         jebac_vexia2ug8d5nsqylv. eu.setMaxStringLength( dr[7]);
      }

      List var10000 = this.buttonList;
      jebac_vexia4oibzo50ubf0 var10001 = new jebac_vexia4oibzo50ubf0;
      int var10003 =  dr[0];
      int var10004 = this.width /  dr[1] -  dr[2];
      int var10005 = this.height /  dr[1] -  dr[8];
      String var10006;
      if (lIIlI(jebac_vexiawzpzy1x3sez8. bv)) {
         var10006 =  dt[ dr[6]];
         jebac_vexiaqb58506wt8o3.  ‏ ("", -1937708364).length();
         if (jebac_vexiaqb58506wt8o3.  ‏ ("\u1771\u1771", 1907562321).length() < ((145 ^ 199 ^ 218 ^ 132) & (115 ^ 85 ^ 13 ^ 35 ^ -jebac_vexiaqb58506wt8o3.  ‏ ("罁", 111968097).length()))) {
            return;
         }
      } else {
         var10006 =  dt[ dr[1]];
      }

      var10001.<init>(var10003, var10004, var10005, var10006);
      var10000.add(var10001);
      jebac_vexiaqb58506wt8o3.  ‏ ("", 512031541).length();
      this.buttonList.add(new jebac_vexia4oibzo50ubf0( dr[6], this.width /  dr[1] -  dr[2], this.height /  dr[9] +  dr[10], I18n.format( dt[ dr[11]])));
      jebac_vexiaqb58506wt8o3.  ‏ ("", 296630453).length();
   }

   // $FF: synthetic method
   public jebac_vexialnyznrpqlcd1(jebac_vexiakl614w3uw0xg var1) {
      this. ds = var1;
   }

   // $FF: synthetic method
   private static boolean lIllI(int var0, int var1) {
      return var0 > var1;
   }

   // $FF: synthetic method
   private static boolean lIlIl(int var0, int var1) {
      return var0 == var1;
   }

   // $FF: synthetic method
   private static String l(String var0, String var1) {
      try {
         SecretKeySpec var2 = new SecretKeySpec(MessageDigest.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("\ue3dd\ue3d4\ue3a5", -750722160)).digest(var1.getBytes(StandardCharsets.UTF_8)), jebac_vexiaqb58506wt8o3.  ‏ ("䯱䯟䯜䯄䯕䯚䯀䯛", -560968781));
         Cipher var3 = Cipher.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("巸巖巕巍巜巓巉巒", 335240634));
         var3.init( dr[1], var2);
         return new String(var3.doFinal(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var9) {
         var9.printStackTrace();
         return null;
      }
   }

   // $FF: synthetic method
   private static boolean llIII(int var0, int var1) {
      return var0 < var1;
   }

   // $FF: synthetic method
   public void drawScreen(int var1, int var2, float var3) {
      this.drawDefaultBackground();
      this.drawCenteredString(this.fontRendererObj,  dt[ dr[13]], this.width /  dr[1],  dr[12],  dr[14]);
      this.drawString(this.fontRendererObj, I18n.format( dt[ dr[15]]), this.width /  dr[1] -  dr[2],  dr[16],  dr[17]);
      jebac_vexia2ug8d5nsqylv. eu.drawTextBox();
      super.drawScreen(var1, var2, var3);
   }

   static {
      lIIII();
      llll();
   }

   // $FF: synthetic method
   private static boolean lIIll(int var0) {
      return var0 == 0;
   }

   // $FF: synthetic method
   private static void llll() {
       dt = new String[ dr[9]];
       dt[ dr[0]] = l(jebac_vexiaqb58506wt8o3.  ‏ ("\ue0ec\ue0e3\ue0c1\ue0d5\ue0f8\ue0e0\ue0ca\ue0fc\ue0b6\ue0c7\ue0ce\ue0b2", -1697587057), jebac_vexiaqb58506wt8o3.  ‏ ("HKVUO", 1543176229));
       dt[ dr[6]] = lIlI(jebac_vexiaqb58506wt8o3.  ‏ ("戼戶戥扇戱戃扅戁戵戞扌或戵戠戥戕戤戦才戭或戇戻戧戹戝所戞戶戥扉扉", 1367892596), jebac_vexiaqb58506wt8o3.  ‏ ("ᱹ᱂ᱤᱍ᱕", 496049207));
       dt[ dr[1]] = lIll(jebac_vexiaqb58506wt8o3.  ‏ ("킃킈킾킠킏탶킇탱탯킜킜킯킂킅킽킉킮킶킓킠킮킀킠킏킧킕킑킳킌킃킀탳", -1163276092), jebac_vexiaqb58506wt8o3.  ‏ ("ↅↆ↧↣↰", -202038827));
       dt[ dr[11]] = l(jebac_vexiaqb58506wt8o3.  ‏ ("쿲쿫쿫쿹쿗쾂쾋쿋쿈쿎쿕쿈쿴쾋쾃쿑쿘쿕쾌쿩쿙쿻쾇쾇", 928239546), jebac_vexiaqb58506wt8o3.  ‏ ("螈螜螻螐螱", 460228574));
       dt[ dr[13]] = lIll(jebac_vexiaqb58506wt8o3.  ‏ ("餲餮餥餔餤餴餑餢餰餖餔餍餥饐餌餮餉餡餦餾餎餂餳餮餿餫餑饗餫餠餂饟", -43148953), jebac_vexiaqb58506wt8o3.  ‏ ("\uf270\uf256\uf24b\uf277\uf240", 1275785762));
       dt[ dr[15]] = l(jebac_vexiaqb58506wt8o3.  ‏ ("\ue47d\ue46f\ue459\ue452\ue45a\ue47c\ue447\ue458\ue454\ue40e\ue441\ue475\ue479\ue470\ue402\ue474\ue472\ue476\ue445\ue442\ue418\ue466\ue40a\ue40a", 226944055), jebac_vexiaqb58506wt8o3.  ‏ ("鳟鳤鳄鳥鳴", -1717134162));
   }

   // $FF: synthetic method
   private static void lIIII() {
       dr = new int[19];
       dr[0] = (185 ^ 141) & ~(71 ^ 115);
       dr[1] = jebac_vexiaqb58506wt8o3.  ‏ ("俑俑", 148000753).length();
       dr[2] = 100 ^ 72 ^ 62 ^ 118;
       dr[3] = 68 ^ 6;
       dr[4] = 15 + 111 - 27 + 101;
       dr[5] = 169 ^ 189;
       dr[6] = jebac_vexiaqb58506wt8o3.  ‏ ("刡", 741298689).length();
       dr[7] = -(-257 & 32702) & -65 & 32765;
       dr[8] = 44 ^ 53;
       dr[9] = 254 ^ 170 ^ 232 ^ 186;
       dr[10] = (153 ^ 147) + (34 ^ 83) - -(91 ^ 95) + (145 ^ 184);
       dr[11] = jebac_vexiaqb58506wt8o3.  ‏ ("硤硤硤", -1839105980).length();
       dr[12] = 202 ^ 197;
       dr[13] = 168 + 63 - 121 + 71 ^ 38 + 164 - 89 + 64;
       dr[14] = -1 & 16777215;
       dr[15] = 157 ^ 152;
       dr[16] = 8 ^ 97 ^ 238 ^ 178;
       dr[17] = -17241 & 10544120;
       dr[18] = 116 + 17 - 113 + 142 ^ 155 + 164 - 185 + 36;
   }

   // $FF: synthetic method
   private static String lIll(String var0, String var1) {
      try {
         String var2 = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("娇娎婿", -1528866230)).digest(var1.getBytes(StandardCharsets.UTF_8)),  dr[18]), jebac_vexiaqb58506wt8o3.  ‏ ("⒣⒢⒴", -244243225));
         String var3 = Cipher.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("ÎÏÙ", 803078282));
         var3.init( dr[1], var2);
         return new String(var3.doFinal(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var9) {
         var9.printStackTrace();
         return null;
      }
   }

   // $FF: synthetic method
   private static boolean lIIlI(int var0) {
      return var0 != 0;
   }

   // $FF: synthetic method
   private static boolean lIIIl(Object var0) {
      return var0 == null;
   }

   // $FF: synthetic method
   protected void keyTyped(char var1, int var2) throws IOException {
      jebac_vexia2ug8d5nsqylv. eu.textboxKeyTyped(var1, var2);
      jebac_vexiaqb58506wt8o3.  ‏ ("", -375026456).length();
      if (lIlIl(var2,  dr[12])) {
         jebac_vexiaa29g8ikthjc5 var10000 = jebac_vexia2ug8d5nsqylv. eu;
         int var10001;
         if (lIIll(jebac_vexia2ug8d5nsqylv. eu.isFocused())) {
            var10001 =  dr[6];
            jebac_vexiaqb58506wt8o3.  ‏ ("", 1575992999).length();
            if (jebac_vexiaqb58506wt8o3.  ‏ ("옓", 1017366067).length() <= -jebac_vexiaqb58506wt8o3.  ‏ ("찾", -74789858).length()) {
               return;
            }
         } else {
            var10001 =  dr[0];
         }

         var10000.setFocused((boolean)var10001);
      }

   }
}
