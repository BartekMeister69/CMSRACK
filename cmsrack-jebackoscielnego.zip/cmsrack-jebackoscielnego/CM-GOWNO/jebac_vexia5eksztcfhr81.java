import java.util.Collections;
import java.util.Enumeration;
import java.util.LinkedHashSet;
import java.util.Properties;
import java.util.Set;

public class jebac_vexia5eksztcfhr81 extends Properties {
   // $FF: synthetic field
   private Set keysOrdered = new LinkedHashSet();

   // $FF: synthetic method
   public synchronized Enumeration keys() {
      return Collections.enumeration(this.keySet());
   }

   // $FF: synthetic method
   public Set keySet() {
      Set set = super.keySet();
      this.keysOrdered.retainAll(set);
      return Collections.unmodifiableSet(this.keysOrdered);
   }

   // $FF: synthetic method
   public synchronized Object put(Object p_put_1_, Object p_put_2_) {
      this.keysOrdered.add(p_put_1_);
      return super.put(p_put_1_, p_put_2_);
   }
}
