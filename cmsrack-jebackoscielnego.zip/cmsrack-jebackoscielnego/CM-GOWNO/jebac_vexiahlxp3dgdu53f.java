import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.resources.I18n;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.stats.StatBase;
import net.minecraft.stats.StatCrafting;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Mouse;

abstract class jebac_vexiahlxp3dgdu53f extends jebac_vexiado18oeh2l9bq {
   // $FF: synthetic field
   protected int field_148215_p;
   // $FF: synthetic field
   protected Comparator statSorter;
   // $FF: synthetic field
   protected int field_148218_l;
   // $FF: synthetic field
   protected int field_148217_o;
   final jebac_vexiazwfkkk4iev4c this$0;
   // $FF: synthetic field
   protected List statsHolder;

   // $FF: synthetic method
   protected abstract String func_148210_b(int var1);

   // $FF: synthetic method
   protected final int getSize() {
      return this.statsHolder.size();
   }

   // $FF: synthetic method
   protected void func_148209_a(StatBase p_148209_1_, int p_148209_2_, int p_148209_3_, boolean p_148209_4_) {
      String s;
      if (p_148209_1_ != null) {
         s = p_148209_1_.format(jebac_vexiazwfkkk4iev4c.access$100(this.this$0).readStat(p_148209_1_));
         this.this$0.drawString(jebac_vexiazwfkkk4iev4c.access$200(this.this$0), s, p_148209_2_ - jebac_vexiazwfkkk4iev4c.access$300(this.this$0).getStringWidth(s), p_148209_3_ + 5, p_148209_4_ ? 16777215 : 9474192);
      } else {
         s = "-";
         this.this$0.drawString(jebac_vexiazwfkkk4iev4c.access$400(this.this$0), s, p_148209_2_ - jebac_vexiazwfkkk4iev4c.access$500(this.this$0).getStringWidth(s), p_148209_3_ + 5, p_148209_4_ ? 16777215 : 9474192);
      }

   }

   // $FF: synthetic method
   protected boolean isSelected(int slotIndex) {
      return false;
   }

   // $FF: synthetic method
   protected void elementClicked(int slotIndex, boolean isDoubleClick, int mouseX, int mouseY) {
   }

   // $FF: synthetic method
   protected final StatCrafting func_148211_c(int p_148211_1_) {
      return (StatCrafting)this.statsHolder.get(p_148211_1_);
   }

   // $FF: synthetic method
   protected void drawListHeader(int p_148129_1_, int p_148129_2_, Tessellator p_148129_3_) {
      if (!Mouse.isButtonDown(0)) {
         this.field_148218_l = -1;
      }

      if (this.field_148218_l == 0) {
         jebac_vexiazwfkkk4iev4c.access$000(this.this$0, p_148129_1_ + 115 - 18, p_148129_2_ + 1, 0, 0);
      } else {
         jebac_vexiazwfkkk4iev4c.access$000(this.this$0, p_148129_1_ + 115 - 18, p_148129_2_ + 1, 0, 18);
      }

      if (this.field_148218_l == 1) {
         jebac_vexiazwfkkk4iev4c.access$000(this.this$0, p_148129_1_ + 165 - 18, p_148129_2_ + 1, 0, 0);
      } else {
         jebac_vexiazwfkkk4iev4c.access$000(this.this$0, p_148129_1_ + 165 - 18, p_148129_2_ + 1, 0, 18);
      }

      if (this.field_148218_l == 2) {
         jebac_vexiazwfkkk4iev4c.access$000(this.this$0, p_148129_1_ + 215 - 18, p_148129_2_ + 1, 0, 0);
      } else {
         jebac_vexiazwfkkk4iev4c.access$000(this.this$0, p_148129_1_ + 215 - 18, p_148129_2_ + 1, 0, 18);
      }

      if (this.field_148217_o != -1) {
         int i = 79;
         int j = 18;
         if (this.field_148217_o == 1) {
            i = 129;
         } else if (this.field_148217_o == 2) {
            i = 179;
         }

         if (this.field_148215_p == 1) {
            j = 36;
         }

         jebac_vexiazwfkkk4iev4c.access$000(this.this$0, p_148129_1_ + i, p_148129_2_ + 1, j, 0);
      }

   }

   // $FF: synthetic method
   protected void func_148213_a(StatCrafting p_148213_1_, int p_148213_2_, int p_148213_3_) {
      if (p_148213_1_ != null) {
         Item item = p_148213_1_.func_150959_a();
         ItemStack itemstack = new ItemStack(item);
         String s = itemstack.getUnlocalizedName();
         String s1 = ("" + I18n.format(s + ".name")).trim();
         if (s1.length() > 0) {
            int i = p_148213_2_ + 12;
            int j = p_148213_3_ - 12;
            int k = jebac_vexiazwfkkk4iev4c.access$900(this.this$0).getStringWidth(s1);
            jebac_vexiazwfkkk4iev4c.access$1000(this.this$0, i - 3, j - 3, i + k + 3, j + 8 + 3, -1073741824, -1073741824);
            jebac_vexiazwfkkk4iev4c.access$1100(this.this$0).drawStringWithShadow(s1, (float)i, (float)j, -1);
         }
      }

   }

   // $FF: synthetic method
   protected void func_148142_b(int p_148142_1_, int p_148142_2_) {
      if (p_148142_2_ >= this.top && p_148142_2_ <= this.bottom) {
         int i = this.getSlotIndexFromScreenCoords(p_148142_1_, p_148142_2_);
         int j = this.width / 2 - 92 - 16;
         if (i >= 0) {
            if (p_148142_1_ < j + 40 || p_148142_1_ > j + 40 + 20) {
               return;
            }

            StatCrafting statcrafting = this.func_148211_c(i);
            this.func_148213_a(statcrafting, p_148142_1_, p_148142_2_);
         } else {
            String s;
            if (p_148142_1_ >= j + 115 - 18 && p_148142_1_ <= j + 115) {
               s = this.func_148210_b(0);
            } else if (p_148142_1_ >= j + 165 - 18 && p_148142_1_ <= j + 165) {
               s = this.func_148210_b(1);
            } else {
               if (p_148142_1_ < j + 215 - 18 || p_148142_1_ > j + 215) {
                  return;
               }

               s = this.func_148210_b(2);
            }

            s = ("" + I18n.format(s)).trim();
            if (s.length() > 0) {
               int k = p_148142_1_ + 12;
               int l = p_148142_2_ - 12;
               int i1 = jebac_vexiazwfkkk4iev4c.access$600(this.this$0).getStringWidth(s);
               jebac_vexiazwfkkk4iev4c.access$700(this.this$0, k - 3, l - 3, k + i1 + 3, l + 8 + 3, -1073741824, -1073741824);
               jebac_vexiazwfkkk4iev4c.access$800(this.this$0).drawStringWithShadow(s, (float)k, (float)l, -1);
            }
         }
      }

   }

   // $FF: synthetic method
   protected void func_148132_a(int p_148132_1_, int p_148132_2_) {
      this.field_148218_l = -1;
      if (p_148132_1_ >= 79 && p_148132_1_ < 115) {
         this.field_148218_l = 0;
      } else if (p_148132_1_ >= 129 && p_148132_1_ < 165) {
         this.field_148218_l = 1;
      } else if (p_148132_1_ >= 179 && p_148132_1_ < 215) {
         this.field_148218_l = 2;
      }

      if (this.field_148218_l >= 0) {
         this.func_148212_h(this.field_148218_l);
         this.mc.getSoundHandler().playSound(PositionedSoundRecord.create(new ResourceLocation("gui.button.press"), 1.0F));
      }

   }

   // $FF: synthetic method
   protected void func_148212_h(int p_148212_1_) {
      if (p_148212_1_ != this.field_148217_o) {
         this.field_148217_o = p_148212_1_;
         this.field_148215_p = -1;
      } else if (this.field_148215_p == -1) {
         this.field_148215_p = 1;
      } else {
         this.field_148217_o = -1;
         this.field_148215_p = 0;
      }

      Collections.sort(this.statsHolder, this.statSorter);
   }

   // $FF: synthetic method
   protected jebac_vexiahlxp3dgdu53f(jebac_vexiazwfkkk4iev4c this$0, Minecraft mcIn) {
      super(mcIn, this$0.width, this$0.height, 32, this$0.height - 64, 20);
      this.this$0 = this$0;
      this.field_148218_l = -1;
      this.field_148217_o = -1;
      this.setShowSelectionBox(false);
      this.setHasListHeader(true, 20);
   }

   // $FF: synthetic method
   protected void drawBackground() {
      this.this$0.drawDefaultBackground();
   }
}
