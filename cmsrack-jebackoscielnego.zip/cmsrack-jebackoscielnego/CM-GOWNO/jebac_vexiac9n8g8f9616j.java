public class jebac_vexiac9n8g8f9616j {
   // $FF: synthetic field
   public int counter = 0;
   // $FF: synthetic field
   public int index;
   // $FF: synthetic field
   public int duration;

   // $FF: synthetic method
   public jebac_vexiac9n8g8f9616j(int p_i96_1_, int p_i96_2_) {
      this.index = p_i96_1_;
      this.duration = p_i96_2_;
   }
}
