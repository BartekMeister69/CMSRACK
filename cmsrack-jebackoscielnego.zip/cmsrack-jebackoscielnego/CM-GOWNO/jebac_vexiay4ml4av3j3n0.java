import com.google.common.base.Objects;
import com.google.common.base.Predicate;
import com.google.common.base.Predicates;

public class jebac_vexiay4ml4av3j3n0 extends jebac_vexiamee1xbabsk4e {
   // $FF: synthetic field
   private final Predicate field_178951_a;

   // $FF: synthetic method
   public Predicate func_178950_a() {
      return this.field_178951_a;
   }

   // $FF: synthetic method
   public jebac_vexiay4ml4av3j3n0(int p_i45534_1_, String p_i45534_2_, boolean p_i45534_3_, Predicate p_i45534_4_) {
      super(p_i45534_1_, p_i45534_2_, p_i45534_3_);
      this.field_178951_a = (Predicate)Objects.firstNonNull(p_i45534_4_, Predicates.alwaysTrue());
   }
}
