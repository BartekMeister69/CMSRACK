public class jebac_vexiakpenqvpvl5i9 extends jebac_vexiat51dq4htxchd {
   // $FF: synthetic field
   public jebac_vexiau47ipgjckapi signBoard = new jebac_vexiau47ipgjckapi(this, 0, 0);
   // $FF: synthetic field
   public jebac_vexiau47ipgjckapi signStick;

   // $FF: synthetic method
   public jebac_vexiakpenqvpvl5i9() {
      this.signBoard.addBox(-12.0F, -14.0F, -1.0F, 24, 12, 2, 0.0F);
      this.signStick = new jebac_vexiau47ipgjckapi(this, 0, 14);
      this.signStick.addBox(-1.0F, -2.0F, -1.0F, 2, 14, 2, 0.0F);
   }

   // $FF: synthetic method
   public void renderSign() {
      this.signBoard.render(0.0625F);
      this.signStick.render(0.0625F);
   }
}
