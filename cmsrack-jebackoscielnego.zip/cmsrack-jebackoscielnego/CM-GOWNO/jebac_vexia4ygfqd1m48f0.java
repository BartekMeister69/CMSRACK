import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.util.MathHelper;
import net.minecraft.util.ResourceLocation;

public class jebac_vexia4ygfqd1m48f0 extends jebac_vexiabhi02xzapwrh implements jebac_vexia2ut457nkbgny {
   // $FF: synthetic field
   private static final ResourceLocation field_175267_f = new ResourceLocation("textures/gui/widgets.png");
   // $FF: synthetic field
   private jebac_vexiabhmyylutxyzx field_175271_i;
   // $FF: synthetic field
   private final Minecraft field_175268_g;
   // $FF: synthetic field
   private long field_175270_h;
   // $FF: synthetic field
   public static final ResourceLocation field_175269_a = new ResourceLocation("textures/gui/spectator_widgets.png");

   // $FF: synthetic method
   public void func_175260_a(int p_175260_1_) {
      this.field_175270_h = Minecraft.getSystemTime();
      if (this.field_175271_i != null) {
         this.field_175271_i.func_178644_b(p_175260_1_);
      } else {
         this.field_175271_i = new jebac_vexiabhmyylutxyzx(this);
      }

   }

   // $FF: synthetic method
   public void func_175261_b() {
      this.field_175270_h = Minecraft.getSystemTime();
      if (this.func_175262_a()) {
         int i = this.field_175271_i.func_178648_e();
         if (i != -1) {
            this.field_175271_i.func_178644_b(i);
         }
      } else {
         this.field_175271_i = new jebac_vexiabhmyylutxyzx(this);
      }

   }

   // $FF: synthetic method
   public void func_175263_a(jebac_vexiakl8zv2fyoaq8 p_175263_1_) {
      int i = (int)(this.func_175265_c() * 255.0F);
      if (i > 3 && this.field_175271_i != null) {
         jebac_vexia9nzh0zm3n32z ispectatormenuobject = this.field_175271_i.func_178645_b();
         String s = ispectatormenuobject != jebac_vexiabhmyylutxyzx.field_178657_a ? ispectatormenuobject.getSpectatorName().getFormattedText() : this.field_175271_i.func_178650_c().func_178670_b().getFormattedText();
         if (s != null) {
            int j = (p_175263_1_.getScaledWidth() - this.field_175268_g.fontRendererObj.getStringWidth(s)) / 2;
            int k = p_175263_1_.getScaledHeight() - 35;
            GlStateManager.pushMatrix();
            GlStateManager.enableBlend();
            GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
            this.field_175268_g.fontRendererObj.drawStringWithShadow(s, (float)j, (float)k, 16777215 + (i << 24));
            GlStateManager.disableBlend();
            GlStateManager.popMatrix();
         }
      }

   }

   // $FF: synthetic method
   private float func_175265_c() {
      long i = this.field_175270_h - Minecraft.getSystemTime() + 5000L;
      return MathHelper.clamp_float((float)i / 2000.0F, 0.0F, 1.0F);
   }

   // $FF: synthetic method
   public jebac_vexia4ygfqd1m48f0(Minecraft mcIn) {
      this.field_175268_g = mcIn;
   }

   // $FF: synthetic method
   public void func_175259_b(int p_175259_1_) {
      int i;
      for(i = this.field_175271_i.func_178648_e() + p_175259_1_; i >= 0 && i <= 8 && (this.field_175271_i.func_178643_a(i) == jebac_vexiabhmyylutxyzx.field_178657_a || !this.field_175271_i.func_178643_a(i).func_178662_A_()); i += p_175259_1_) {
      }

      if (i >= 0 && i <= 8) {
         this.field_175271_i.func_178644_b(i);
         this.field_175270_h = Minecraft.getSystemTime();
      }

   }

   // $FF: synthetic method
   public boolean func_175262_a() {
      return this.field_175271_i != null;
   }

   // $FF: synthetic method
   public void func_175257_a(jebac_vexiabhmyylutxyzx p_175257_1_) {
      this.field_175271_i = null;
      this.field_175270_h = 0L;
   }

   // $FF: synthetic method
   public void renderTooltip(jebac_vexiakl8zv2fyoaq8 p_175264_1_, float p_175264_2_) {
      if (this.field_175271_i != null) {
         float f = this.func_175265_c();
         if (f <= 0.0F) {
            this.field_175271_i.func_178641_d();
         } else {
            int i = p_175264_1_.getScaledWidth() / 2;
            float f1 = this.zLevel;
            this.zLevel = -90.0F;
            float f2 = (float)p_175264_1_.getScaledHeight() - 22.0F * f;
            jebac_vexiam1glxj46m3t5 spectatordetails = this.field_175271_i.func_178646_f();
            this.func_175258_a(p_175264_1_, f, i, f2, spectatordetails);
            this.zLevel = f1;
         }
      }

   }

   // $FF: synthetic method
   private void func_175266_a(int p_175266_1_, int p_175266_2_, float p_175266_3_, float p_175266_4_, jebac_vexia9nzh0zm3n32z p_175266_5_) {
      this.field_175268_g.getTextureManager().bindTexture(field_175269_a);
      if (p_175266_5_ != jebac_vexiabhmyylutxyzx.field_178657_a) {
         int i = (int)(p_175266_4_ * 255.0F);
         GlStateManager.pushMatrix();
         GlStateManager.translate((float)p_175266_2_, p_175266_3_, 0.0F);
         float f = p_175266_5_.func_178662_A_() ? 1.0F : 0.25F;
         GlStateManager.color(f, f, f, p_175266_4_);
         p_175266_5_.func_178663_a(f, i);
         GlStateManager.popMatrix();
         String s = String.valueOf(GameSettings.getKeyDisplayString(this.field_175268_g.gameSettings.keyBindsHotbar[p_175266_1_].getKeyCode()));
         if (i > 3 && p_175266_5_.func_178662_A_()) {
            this.field_175268_g.fontRendererObj.drawStringWithShadow(s, (float)(p_175266_2_ + 19 - 2 - this.field_175268_g.fontRendererObj.getStringWidth(s)), p_175266_3_ + 6.0F + 3.0F, 16777215 + (i << 24));
         }
      }

   }

   // $FF: synthetic method
   protected void func_175258_a(jebac_vexiakl8zv2fyoaq8 p_175258_1_, float p_175258_2_, int p_175258_3_, float p_175258_4_, jebac_vexiam1glxj46m3t5 p_175258_5_) {
      GlStateManager.enableRescaleNormal();
      GlStateManager.enableBlend();
      GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
      GlStateManager.color(1.0F, 1.0F, 1.0F, p_175258_2_);
      this.field_175268_g.getTextureManager().bindTexture(field_175267_f);
      this.drawTexturedModalRect((float)(p_175258_3_ - 91), p_175258_4_, 0, 0, 182, 22);
      if (p_175258_5_.func_178681_b() >= 0) {
         this.drawTexturedModalRect((float)(p_175258_3_ - 91 - 1 + p_175258_5_.func_178681_b() * 20), p_175258_4_ - 1.0F, 0, 22, 24, 22);
      }

      RenderHelper.enableGUIStandardItemLighting();

      for(int i = 0; i < 9; ++i) {
         this.func_175266_a(i, p_175258_1_.getScaledWidth() / 2 - 90 + i * 20 + 2, p_175258_4_ + 3.0F, p_175258_2_, p_175258_5_.func_178680_a(i));
      }

      RenderHelper.disableStandardItemLighting();
      GlStateManager.disableRescaleNormal();
      GlStateManager.disableBlend();
   }
}
