import java.io.InputStream;

public interface jebac_vexiab8fgirhwov0i {
   // $FF: synthetic method
   boolean hasDirectory(String var1);

   // $FF: synthetic method
   void close();

   // $FF: synthetic method
   String getName();

   // $FF: synthetic method
   InputStream getResourceAsStream(String var1);
}
