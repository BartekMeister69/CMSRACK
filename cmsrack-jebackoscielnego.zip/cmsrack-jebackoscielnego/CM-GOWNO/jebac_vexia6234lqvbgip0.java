import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.ICrafting;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;

public class jebac_vexia6234lqvbgip0 implements ICrafting {
   // $FF: synthetic field
   private final Minecraft mc;

   // $FF: synthetic method
   public jebac_vexia6234lqvbgip0(Minecraft mc) {
      this.mc = mc;
   }

   // $FF: synthetic method
   public void sendSlotContents(Container containerToSend, int slotInd, ItemStack stack) {
      this.mc.playerController.sendSlotPacket(stack, slotInd);
   }

   // $FF: synthetic method
   public void func_175173_a(Container p_175173_1_, IInventory p_175173_2_) {
   }

   // $FF: synthetic method
   public void updateCraftingInventory(Container containerToSend, List itemsList) {
   }

   // $FF: synthetic method
   public void sendProgressBarUpdate(Container containerIn, int varToUpdate, int newValue) {
   }
}
