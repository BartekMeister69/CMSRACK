import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

public class jebac_vexiajeba1ufmgebr {
   private final jebac_vexiau47ipgjckapi  is;
   private static final int[]  it;
   private static final String[]  iu;

   // $FF: synthetic method
   private void render3D(WorldRenderer var1) {
      jebac_vexiajeba1ufmgebr var2 = Tessellator.getInstance();
      GL11.glTranslated(0.0D, 0.0D, 0.0D);
      GL11.glTranslatef(1.0F, -0.10000001F, 0.1F);
      GL11.glScalef(1.875F, 1.875F, 1.0F);
      GL11.glRotatef(0.0F, 0.0F, 200.0F, 1.0F);
      GL11.glRotatef(0.0F, 0.0F, 0.0F, 1.0F);
      GL11.glTranslatef(-0.9375F, -0.0625F, 0.0F);
      GL11.glScaled(1.0D, 1.0D, 0.7D);
      var1.begin( it[2], DefaultVertexFormats.POSITION_TEX_NORMAL);
      var1.pos(0.0D, 0.0D, 0.0D).tex(1.0D, 1.0D).normal(1.0F, 1.0F, 1.0F).endVertex();
      var1.pos(1.0D, 0.0D, 0.0D).tex(0.0D, 1.0D).normal(1.0F, 1.0F, 1.0F).endVertex();
      var1.pos(1.0D, 1.0D, 0.0D).tex(0.0D, 0.0D).normal(0.0F, 0.0F, 1.0F).endVertex();
      var1.pos(0.0D, 1.0D, 0.0D).tex(1.0D, 0.0D).normal(0.0F, 0.0F, 1.0F).endVertex();
      var2.draw();
      var1.begin( it[2], DefaultVertexFormats.POSITION_TEX_NORMAL);
      var1.pos(0.0D, 1.0D, -0.078125D).tex(1.0D, 0.0D).normal(0.0F, 0.0F, 1.0F).endVertex();
      var1.pos(1.0D, 1.0D, -0.078125D).tex(0.0D, 0.0D).normal(0.0F, 0.0F, 1.0F).endVertex();
      var1.pos(1.0D, 0.0D, -0.078125D).tex(0.0D, 1.0D).normal(1.0F, 1.0F, 1.0F).endVertex();
      var1.pos(0.0D, 0.0D, -0.078125D).tex(1.0D, 1.0D).normal(1.0F, 1.0F, 1.0F).endVertex();
      var2.draw();
      var1.begin( it[2], DefaultVertexFormats.POSITION_TEX_NORMAL);
      int var3 =  it[0];

      do {
         float var4;
         float var5;
         if (!lIllIIll(lIllIIlI((float)var3, 32.0F))) {
            var2.draw();
            var1.begin( it[2], DefaultVertexFormats.POSITION_TEX_NORMAL);
            var3 =  it[0];

            do {
               if (!lIllIIll(lIllIIlI((float)var3, 32.0F))) {
                  var2.draw();
                  return;
               }

               var4 = (float)var3 / 32.0F;
               var5 = 1.0F + -1.0F * var4 - 2.5E-5F;
               var4 += 0.02125F;
               var1.pos(1.0D, (double)var4, 0.0D).tex(0.0D, (double)var5).normal(0.0F, 0.0F, 0.0F).endVertex();
               var1.pos(0.0D, (double)var4, 0.0D).tex(1.0D, (double)var5).normal(0.0F, 0.0F, 0.0F).endVertex();
               var1.pos(0.0D, (double)var4, -0.078125D).tex(1.0D, (double)var5).normal(0.0F, 0.0F, 0.0F).endVertex();
               var1.pos(1.0D, (double)var4, -0.078125D).tex(0.0D, (double)var5).normal(0.0F, 0.0F, 0.0F).endVertex();
               ++var3;
               jebac_vexiaqb58506wt8o3.  ‏ ("", -848386181).length();
            } while(((254 ^ 162 ^ 49 ^ 118) & (127 ^ 34 ^ 214 ^ 144 ^ -jebac_vexiaqb58506wt8o3.  ‏ ("౷", -1869411241).length())) >= 0);

            return;
         }

         var4 = (float)var3 / 32.0F;
         var5 = 1.0F + -1.0F * var4 - 2.5E-5F;
         var4 += 0.02125F;
         var1.pos((double)var4, 0.0D, -0.078125D).tex((double)var5, 1.0D).normal(0.0F, 0.0F, 0.0F).endVertex();
         var1.pos((double)var4, 0.0D, 0.0D).tex((double)var5, 1.0D).normal(0.0F, 0.0F, 0.0F).endVertex();
         var1.pos((double)var4, 1.0D, 0.0D).tex((double)var5, 0.0D).normal(0.0F, 0.0F, 0.0F).endVertex();
         var1.pos((double)var4, 1.0D, -0.078125D).tex((double)var5, 0.0D).normal(0.0F, 0.0F, 0.0F).endVertex();
         ++var3;
         jebac_vexiaqb58506wt8o3.  ‏ ("", 1210493946).length();
      } while(jebac_vexiaqb58506wt8o3.  ‏ ("\ud8f5", 1264572629).length() != -jebac_vexiaqb58506wt8o3.  ‏ ("鍹", 3969881).length());

   }

   // $FF: synthetic method
   private static String lIlIlIIl(String var0, String var1) {
      var0 = new String(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder var2 = new StringBuilder();
      boolean var3 = var1.toCharArray();
      double var4 =  it[0];
      int var5 = var0.toCharArray();
      String var6 = var5.length;
      int var7 =  it[0];

      do {
         if (!lIllIlII(var7, var6)) {
            return String.valueOf(var2);
         }

         char var8 = var5[var7];
         var2.append((char)(var8 ^ var3[var4 % var3.length]));
         jebac_vexiaqb58506wt8o3.  ‏ ("", 1773602115).length();
         ++var4;
         ++var7;
         jebac_vexiaqb58506wt8o3.  ‏ ("", -714037047).length();
      } while(((8 ^ 106 ^ 230 ^ 173) & (37 ^ 52 ^ 174 ^ 150 ^ -jebac_vexiaqb58506wt8o3.  ‏ ("⎚", 2000298938).length())) == 0);

      return null;
   }

   // $FF: synthetic method
   public void render(EntityPlayer var1, int var2) {
      if (lIlIlllI(var1.item) && lIlIllll(var1.triedDownloadItem)) {
         jebac_vexiagwvukypcaxyp.downloadAndSetTexture(String.valueOf((new StringBuilder()).append( iu[ it[0]]).append(var2).append( iu[ it[1]])), jebac_vexiajeba1ufmgebr::lambda$render$0);
         var1.triedDownloadItem = (boolean) it[1];
      }

      if (lIllIIII(var1.item)) {
         GL11.glPushMatrix();
         EntityPlayer var3 = Tessellator.getInstance();
         GL11.glRotatef(-29.0F, 1.5F, 0.0F, 0.0F);
         GL11.glRotatef(90.0F, 0.0F, 0.5F, 0.0F);
         GL11.glTranslatef(-0.15F, 0.125F, 0.3F);
         if (lIllIIIl(var1.isSneaking())) {
            GL11.glRotatef(this. is.rotateAngleX * 57.295776F, 0.0F, 0.0F, 0.5F);
            jebac_vexiaqb58506wt8o3.  ‏ ("", 1458240347).length();
            if (jebac_vexiaqb58506wt8o3.  ‏ ("濐濐濐", -1308659728).length() <= ((85 ^ 47 ^ 241 ^ 135) & (54 ^ 106 ^ 104 ^ 56 ^ -jebac_vexiaqb58506wt8o3.  ‏ ("\ue9d1", -1708529167).length()))) {
               return;
            }
         } else {
            GL11.glRotatef(this. is.rotateAngleX * 57.295776F, 0.0F, 0.0F, 1.0F);
         }

         GL11.glRotatef(this. is.rotateAngleY * 57.295776F, 0.0F, 0.0F, 0.0F);
         GL11.glRotatef(this. is.rotateAngleZ * -57.295776F, 1.5F, 0.0F, 0.0F);
         Minecraft.getMinecraft().getTextureManager().bindTexture(var1.item);
         this.render3D(var3.getWorldRenderer());
         GL11.glPopMatrix();
      }

   }

   // $FF: synthetic method
   private static boolean lIlIlllI(Object var0) {
      return var0 == null;
   }

   // $FF: synthetic method
   private static boolean lIllIIll(int var0) {
      return var0 < 0;
   }

   // $FF: synthetic method
   public jebac_vexiajeba1ufmgebr(jebac_vexia88utjmuujofl var1) {
      this. is = var1.bipedLeftArm;
   }

   // $FF: synthetic method
   private static String lIlIlIlI(String var0, String var1) {
      try {
         byte var2 = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("\uef8c\uef85\ueff4", -464785471)).digest(var1.getBytes(StandardCharsets.UTF_8)),  it[4]), jebac_vexiaqb58506wt8o3.  ‏ ("랪랫랽", 30783470));
         String var3 = Cipher.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("痉痈痞", 1975154061));
         var3.init( it[3], var2);
         return new String(var3.doFinal(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var10) {
         var10.printStackTrace();
         return null;
      }
   }

   // $FF: synthetic method
   private static boolean lIllIlII(int var0, int var1) {
      return var0 < var1;
   }

   // $FF: synthetic method
   private static boolean lIlIllll(int var0) {
      return var0 == 0;
   }

   static {
      lIlIllIl();
      lIlIlIll();
   }

   // $FF: synthetic method
   private static boolean lIllIIIl(int var0) {
      return var0 != 0;
   }

   // $FF: synthetic method
   private static void lIlIlIll() {
       iu = new String[ it[3]];
       iu[ it[0]] = lIlIlIIl(jebac_vexiaqb58506wt8o3.  ‏ ("卣卨印协卫危卯千危卸华印即千卞卽卪卫匜卅卹卫匜卬卯卭博卅卫卯卙午占千华危卫华即卂卣卸印卦卮卨匔匔", -204254423), jebac_vexiaqb58506wt8o3.  ‏ ("\uf1cc\uf1f2\uf1eb\uf1f5\uf1cb", -2112687744));
       iu[ it[1]] = lIlIlIlI(jebac_vexiaqb58506wt8o3.  ‏ ("\u0e7f่\u0e72\u0e6c\u0e78\u0e60\u0e3b\u0e63๏\u0e71\u0e64ึ", -705425909), jebac_vexiaqb58506wt8o3.  ‏ ("봕봽봲봶봑", 1971895674));
   }

   // $FF: synthetic method
   private static boolean lIllIIII(Object var0) {
      return var0 != null;
   }

   // $FF: synthetic method
   private static int lIllIIlI(float var0, float var1) {
      float var2;
      return (var2 = var0 - var1) == 0.0F ? 0 : (var2 < 0.0F ? -1 : 1);
   }

   private static void lambda$render$0(EntityPlayer var0, ResourceLocation var1) {
      var0.item = var1;
   }

   // $FF: synthetic method
   private static void lIlIllIl() {
       it = new int[5];
       it[0] = (52 ^ 116 ^ 25 ^ 65) & (193 ^ 198 ^ 71 ^ 88 ^ -jebac_vexiaqb58506wt8o3.  ‏ ("쿔", -579940364).length());
       it[1] = jebac_vexiaqb58506wt8o3.  ‏ ("嫇", 584669927).length();
       it[2] = 49 ^ 84 ^ 199 ^ 165;
       it[3] = jebac_vexiaqb58506wt8o3.  ‏ ("姃姃", -264873501).length();
       it[4] = 204 ^ 196;
   }
}
