import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.resources.I18n;

public class jebac_vexianom2t793wdjw extends jebac_vexiakl614w3uw0xg {
   private final jebac_vexiakl614w3uw0xg  fx;
   private static final int[]  fz;
   private static final String[]  fy;

   // $FF: synthetic method
   private static boolean lIlllI(int var0) {
      return var0 != 0;
   }

   // $FF: synthetic method
   public jebac_vexianom2t793wdjw(jebac_vexiakl614w3uw0xg var1) {
      this. fx = var1;
   }

   // $FF: synthetic method
   private static boolean llIIlI(int var0, int var1) {
      return var0 == var1;
   }

   // $FF: synthetic method
   public void initGui() {
      List var10000 = this.buttonList;
      jebac_vexia4oibzo50ubf0 var10001 = new jebac_vexia4oibzo50ubf0;
      int var10003 =  fz[0];
      int var10004 = this.width /  fz[1] -  fz[2];
      int var10005 = this.height /  fz[3] -  fz[3];
      int var10006 =  fz[4];
      int var10007 =  fz[5];
      String var10008;
      if (lIlllI(jebac_vexiawzpzy1x3sez8. bk)) {
         var10008 =  fy[ fz[0]];
         jebac_vexiaqb58506wt8o3.  ‏ ("", -371175953).length();
         if (((0 ^ 19 ^ 44 ^ 17) & (159 ^ 140 ^ 132 ^ 185 ^ -jebac_vexiaqb58506wt8o3.  ‏ ("谮", 1450281998).length())) >= jebac_vexiaqb58506wt8o3.  ‏ ("\ue014\ue014\ue014", -245768140).length()) {
            return;
         }
      } else {
         var10008 =  fy[ fz[6]];
      }

      var10001.<init>(var10003, var10004, var10005, var10006, var10007, var10008);
      var10000.add(var10001);
      jebac_vexiaqb58506wt8o3.  ‏ ("", 962441721).length();
      var10000 = this.buttonList;
      var10001 = new jebac_vexia4oibzo50ubf0;
      var10003 =  fz[6];
      var10004 = this.width /  fz[1] +  fz[7];
      var10005 = this.height /  fz[3] -  fz[3];
      var10006 =  fz[4];
      var10007 =  fz[5];
      if (lIlllI(jebac_vexiawzpzy1x3sez8. bq)) {
         var10008 =  fy[ fz[1]];
         jebac_vexiaqb58506wt8o3.  ‏ ("", 1823061227).length();
         if (-(3 ^ 28 ^ 119 ^ 108) > 0) {
            return;
         }
      } else {
         var10008 =  fy[ fz[8]];
      }

      var10001.<init>(var10003, var10004, var10005, var10006, var10007, var10008);
      var10000.add(var10001);
      jebac_vexiaqb58506wt8o3.  ‏ ("", 404997741).length();
      var10000 = this.buttonList;
      var10001 = new jebac_vexia4oibzo50ubf0;
      var10003 =  fz[1];
      var10004 = this.width /  fz[1] -  fz[2];
      var10005 = this.height /  fz[3] +  fz[9] -  fz[3];
      var10006 =  fz[4];
      var10007 =  fz[5];
      if (lIlllI(jebac_vexiawzpzy1x3sez8. bd)) {
         var10008 =  fy[ fz[10]];
         jebac_vexiaqb58506wt8o3.  ‏ ("", -1776660713).length();
         if (((68 ^ 61 ^ 16 ^ 121) & (38 ^ 29 ^ 39 ^ 12 ^ -jebac_vexiaqb58506wt8o3.  ‏ ("\uf699", -1636305223).length())) < -jebac_vexiaqb58506wt8o3.  ‏ ("❧", 1071523655).length()) {
            return;
         }
      } else {
         var10008 =  fy[ fz[7]];
      }

      var10001.<init>(var10003, var10004, var10005, var10006, var10007, var10008);
      var10000.add(var10001);
      jebac_vexiaqb58506wt8o3.  ‏ ("", 251334193).length();
      this.buttonList.add(new jebac_vexia4oibzo50ubf0( fz[8], this.width /  fz[1] -  fz[11], this.height /  fz[3] +  fz[12], I18n.format( fy[ fz[3]])));
      jebac_vexiaqb58506wt8o3.  ‏ ("", -1760856671).length();
   }

   // $FF: synthetic method
   private static String ll(String var0, String var1) {
      try {
         SecretKeySpec var2 = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("\u19cfᧆᦷ", 1784682882)).digest(var1.getBytes(StandardCharsets.UTF_8)),  fz[16]), jebac_vexiaqb58506wt8o3.  ‏ ("䞚䞛䞍", -1068480546));
         Cipher var3 = Cipher.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("㕀㕁㕗", 110572804));
         var3.init( fz[1], var2);
         return new String(var3.doFinal(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var9) {
         var9.printStackTrace();
         return null;
      }
   }

   // $FF: synthetic method
   public void drawScreen(int var1, int var2, float var3) {
      this.drawDefaultBackground();
      this.drawCenteredString(this.fontRendererObj,  fy[ fz[13]], this.width /  fz[1],  fz[14],  fz[15]);
      super.drawScreen(var1, var2, var3);
   }

   // $FF: synthetic method
   private static void lIlll() {
       fy = new String[ fz[16]];
       fy[ fz[0]] = ll(jebac_vexiaqb58506wt8o3.  ‏ ("皴相盯盁盤皹盯盏盀盛盗皾盎皻盾盎皢盈盫盗皼皿盛盈盞盿監盕盼盻皼盌直盏盌盗皿皵盌皺盪盥盘皰", 476214925), jebac_vexiaqb58506wt8o3.  ‏ ("┴│┈┖─", -1720179376));
       fy[ fz[6]] = lII(jebac_vexiaqb58506wt8o3.  ‏ ("DalO[bJBEY|dA|Z`^OdlHXZX@OxFn:OOybdaHO^6", -575078389), jebac_vexiaqb58506wt8o3.  ‏ ("㵆㵪㵛㵢㵢", -1271579349));
       fy[ fz[1]] = ll(jebac_vexiaqb58506wt8o3.  ‏ ("\u19ac\u19cdᦱᦗᦶᧄ\u19cbᦲᦌᧄᦺᦒᦻᦖᦾᦵᦊᦗ\u19cbᦗᧅᦇᦍ\u19acᦫᦖᦚᦌᦥᦵ\u19ceᦻ", 583997949), jebac_vexiaqb58506wt8o3.  ‏ ("铴铂铔铤铴", -1480944511));
       fy[ fz[8]] = ll(jebac_vexiaqb58506wt8o3.  ‏ ("垟垜垠埧埿埸垜埸垤垕垄垧垚垊垊垟基埿基垦垥垦垝垾垙垣埸垇埣垘埴埼", 1706186700), jebac_vexiaqb58506wt8o3.  ‏ ("ꫝ\uaaf8ꫝ\uaace\uaacc", -623400261));
       fy[ fz[10]] = lIl(jebac_vexiaqb58506wt8o3.  ‏ ("觚要觇要親覮覑觝觜觛覉觐覒覧規覞覽覤觜覲覹覙觇覠覀覩覜覊覰覺覦覊覰見覡規覯規覡覧覭覸覇觕", -39941656), jebac_vexiaqb58506wt8o3.  ‏ ("\ue7b6\ue7a4\ue7b7\ue7aa\ue792", -565909561));
       fy[ fz[7]] = ll(jebac_vexiaqb58506wt8o3.  ‏ ("䱈䱀䱧䱵䱺䱶䰽䱇䱾䱛䱄䰦䰣䱡䱧䱝䱱䱞䱂䱵䱀䱔䱴䱰䱈䱝䱅䱙䱘䱪䱔䱚䱕䱟䱤䱷䱧䰣䱐䱳䰹䱤䰪䰯", -709407726), jebac_vexiaqb58506wt8o3.  ‏ ("\ue115\ue10c\ue11b\ue12a\ue11f", 45670744));
       fy[ fz[3]] = ll(jebac_vexiaqb58506wt8o3.  ‏ ("\uda09\uda73\uda2a\uda0d\uda6c\uda00\uda36\uda35\uda0c\uda16\uda12\uda0b\uda1c\uda17\uda00\uda08\uda32\uda2e\uda02\uda12\uda3f\uda3f\uda65\uda65", 1913248344), jebac_vexiaqb58506wt8o3.  ‏ ("\ue471\ue470\ue444\ue470\ue459", 1005315080));
       fy[ fz[13]] = ll(jebac_vexiaqb58506wt8o3.  ‏ ("扆扐戂扼扵扞戄扟承戆扙戇戀扰扱払扷扜扦扬扷扻扼扄扽扦扁扷扅扻扜扟", 1036149300), jebac_vexiaqb58506wt8o3.  ‏ ("쌞쌇쌝쌔쌇", 1842660174));
   }

   // $FF: synthetic method
   private static boolean llIlll(int var0, int var1) {
      return var0 < var1;
   }

   // $FF: synthetic method
   protected void actionPerformed(jebac_vexia4oibzo50ubf0 var1) throws IOException {
      if (lIlllI(var1.enabled)) {
         int var10000;
         if (llIIIl(var1.id)) {
            if (llIIIl(jebac_vexiawzpzy1x3sez8. bk)) {
               var10000 =  fz[6];
               jebac_vexiaqb58506wt8o3.  ‏ ("", -575763317).length();
               if (jebac_vexiaqb58506wt8o3.  ‏ ("⩮⩮⩮", 1708730958).length() < -jebac_vexiaqb58506wt8o3.  ‏ ("忼", -816488484).length()) {
                  return;
               }
            } else {
               var10000 =  fz[0];
            }

            jebac_vexiawzpzy1x3sez8. bk = (boolean)var10000;
            this.mc.displayGuiScreen(this);
            jebac_vexiaqb58506wt8o3.  ‏ ("", 1648347592).length();
            if (((133 ^ 166) & ~(51 ^ 16)) == (130 ^ 134)) {
               return;
            }
         } else if (llIIlI(var1.id,  fz[6])) {
            if (llIIIl(jebac_vexiawzpzy1x3sez8. bq)) {
               var10000 =  fz[6];
               jebac_vexiaqb58506wt8o3.  ‏ ("", 471985421).length();
               if (jebac_vexiaqb58506wt8o3.  ‏ ("ꓔꓔꓔ", -941644556).length() < 0) {
                  return;
               }
            } else {
               var10000 =  fz[0];
            }

            jebac_vexiawzpzy1x3sez8. bq = (boolean)var10000;
            this.mc.displayGuiScreen(this);
            jebac_vexiaqb58506wt8o3.  ‏ ("", 1860894111).length();
            if (((244 ^ 147 ^ 121 ^ 67) & (62 + 149 - 149 + 92 ^ 28 + 153 - 101 + 119 ^ -jebac_vexiaqb58506wt8o3.  ‏ ("汈", 1339124840).length())) < 0) {
               return;
            }
         } else if (llIIlI(var1.id,  fz[1])) {
            if (llIIIl(jebac_vexiawzpzy1x3sez8. bd)) {
               var10000 =  fz[6];
               jebac_vexiaqb58506wt8o3.  ‏ ("", -1004437676).length();
               if (jebac_vexiaqb58506wt8o3.  ‏ ("뼌뼌", 1624031020).length() >= (70 ^ 66)) {
                  return;
               }
            } else {
               var10000 =  fz[0];
            }

            jebac_vexiawzpzy1x3sez8. bd = (boolean)var10000;
            this.mc.displayGuiScreen(this);
            jebac_vexiaqb58506wt8o3.  ‏ ("", 99394420).length();
            if (null != null) {
               return;
            }
         } else if (llIIlI(var1.id,  fz[8])) {
            this.mc.displayGuiScreen(this. fx);
         }

         jebac_vexia67ba3dligh23.save();
      }

   }

   // $FF: synthetic method
   private static String lII(String var0, String var1) {
      var0 = new String(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      String var2 = new StringBuilder();
      int var3 = var1.toCharArray();
      Exception var4 =  fz[0];
      StringBuilder var5 = var0.toCharArray();
      String var6 = var5.length;
      int var7 =  fz[0];

      do {
         if (!llIlll(var7, var6)) {
            return String.valueOf(var2);
         }

         boolean var8 = var5[var7];
         var2.append((char)(var8 ^ var3[var4 % var3.length]));
         jebac_vexiaqb58506wt8o3.  ‏ ("", -808920076).length();
         ++var4;
         ++var7;
         jebac_vexiaqb58506wt8o3.  ‏ ("", -538431282).length();
      } while(((135 ^ 148) & ~(28 ^ 15)) == 0);

      return null;
   }

   static {
      lIllII();
      lIlll();
   }

   // $FF: synthetic method
   private static void lIllII() {
       fz = new int[17];
       fz[0] = (73 ^ 0) & ~(50 ^ 123);
       fz[1] = jebac_vexiaqb58506wt8o3.  ‏ ("ΨΨ", 610599816).length();
       fz[2] = (69 ^ 16) + (5 ^ 121) - (45 + 106 - 106 + 108) + (211 ^ 176);
       fz[3] = 12 ^ 93 ^ 46 ^ 121;
       fz[4] = 69 + 24 - 60 + 117;
       fz[5] = 6 ^ 18;
       fz[6] = jebac_vexiaqb58506wt8o3.  ‏ ("\ueb51", 13101937).length();
       fz[7] = 115 + 140 - 169 + 80 ^ 93 + 142 - 175 + 103;
       fz[8] = jebac_vexiaqb58506wt8o3.  ‏ ("帝帝帝", -2018681283).length();
       fz[9] = 71 ^ 95;
       fz[10] = 29 ^ 25;
       fz[11] = 107 ^ 45 ^ 91 ^ 121;
       fz[12] = 139 + 49 - 140 + 120;
       fz[13] = 23 ^ 16;
       fz[14] = 152 ^ 151;
       fz[15] = -1 & 16777215;
       fz[16] = 87 ^ 95;
   }

   // $FF: synthetic method
   private static boolean llIIIl(int var0) {
      return var0 == 0;
   }

   // $FF: synthetic method
   private static String lIl(String var0, String var1) {
      try {
         SecretKeySpec var2 = new SecretKeySpec(MessageDigest.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("폅폌펽", 1284428680)).digest(var1.getBytes(StandardCharsets.UTF_8)), jebac_vexiaqb58506wt8o3.  ‏ ("\u1a8a᪤ᪧ\u1abf\u1aae᪡᪻᪠", -719643960));
         String var3 = Cipher.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("뮹뮗뮔뮌뮝뮒뮈뮓", 1664334843));
         var3.init( fz[1], var2);
         return new String(var3.doFinal(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var9) {
         var9.printStackTrace();
         return null;
      }
   }
}
