import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;

public class jebac_vexiaqhca1c1sogph extends jebac_vexia4oibzo50ubf0 {
   // $FF: synthetic method
   public jebac_vexiaqhca1c1sogph(int buttonID, int xPos, int yPos) {
      super(buttonID, xPos, yPos, 20, 20, "");
   }

   // $FF: synthetic method
   public void drawButton(Minecraft mc, int mouseX, int mouseY) {
      if (this.visible) {
         mc.getTextureManager().bindTexture(jebac_vexia4oibzo50ubf0.buttonTextures);
         GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
         boolean flag = mouseX >= this.xPosition && mouseY >= this.yPosition && mouseX < this.xPosition + this.width && mouseY < this.yPosition + this.height;
         int i = 106;
         if (flag) {
            i += this.height;
         }

         this.drawTexturedModalRect(this.xPosition, this.yPosition, 0, i, this.width, this.height);
      }

   }
}
