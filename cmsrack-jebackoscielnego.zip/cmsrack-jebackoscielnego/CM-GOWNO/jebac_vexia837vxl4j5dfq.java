public class jebac_vexia837vxl4j5dfq {
   // $FF: synthetic field
   public long timeNano = 0L;
   // $FF: synthetic field
   public long timeStartNano = 0L;

   // $FF: synthetic method
   public void end() {
      if (jebac_vexia80g0n7bakxaq.active && this.timeStartNano != 0L) {
         this.timeNano += System.nanoTime() - this.timeStartNano;
         this.timeStartNano = 0L;
      }

   }

   // $FF: synthetic method
   private void reset() {
      this.timeNano = 0L;
      this.timeStartNano = 0L;
   }

   // $FF: synthetic method
   public void start() {
      if (jebac_vexia80g0n7bakxaq.active && this.timeStartNano == 0L) {
         this.timeStartNano = System.nanoTime();
      }

   }

   static void access$000(jebac_vexia837vxl4j5dfq x0) {
      x0.reset();
   }
}
