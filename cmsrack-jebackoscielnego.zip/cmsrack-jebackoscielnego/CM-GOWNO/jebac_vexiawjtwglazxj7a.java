import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Iterator;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.resources.I18n;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.ResourceLocation;

public class jebac_vexiawjtwglazxj7a {
   public int  gq;
   private final ResourceLocation  gs;
   public int  go;
   private static final int[]  gp;
   private static final String[]  gr;
   public boolean  gt;
   private final Minecraft  gu;

   // $FF: synthetic method
   public jebac_vexiawjtwglazxj7a(Minecraft var1) {
      this. gt = (boolean) gp[0];
      this. go =  gp[1];
      this. gs = new ResourceLocation( gr[ gp[2]]);
      this. gu = var1;
   }

   // $FF: synthetic method
   private static boolean llllIIII(int var0) {
      return var0 != 0;
   }

   static {
      lllIlllI();
      lllIIIII();
   }

   // $FF: synthetic method
   private static void lllIIIII() {
       gr = new String[ gp[14]];
       gr[ gp[2]] = llIllllI(jebac_vexiaqb58506wt8o3.  ‏ ("遇遹遚逪遙遝遐避遝遨遛遼遯遱逩遟遲遦週遱遉運逮遵逪遱遛遏遍遝遆遒遷遤遐遖遯遘逪遰遬遻遝週逵遘遰逬遜適逭遖遬遹連連", 842305566), jebac_vexiaqb58506wt8o3.  ‏ ("鳭鳸鳺鳚鳝", 2118950036));
       gr[ gp[0]] = llIlllll(jebac_vexiaqb58506wt8o3.  ‏ ("⡊⡿⠖⡨", 957556782), jebac_vexiaqb58506wt8o3.  ‏ ("皿皬皦皇皦", -1161791766));
       gr[ gp[9]] = llIllllI(jebac_vexiaqb58506wt8o3.  ‏ ("ၯၧၧဆဇဝဋုနဤၪၣ", 2051280990), jebac_vexiaqb58506wt8o3.  ‏ ("缄缂缢缛缵", 952270669));
       gr[ gp[10]] = llIlllll(jebac_vexiaqb58506wt8o3.  ‏ ("妇妵委妒", -191276572), jebac_vexiaqb58506wt8o3.  ‏ ("ʍʘʥʝʑ", 1838023388));
   }

   // $FF: synthetic method
   private static String llIllllI(String var0, String var1) {
      try {
         byte var2 = new SecretKeySpec(MessageDigest.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("璮璧瓖", 1626436835)).digest(var1.getBytes(StandardCharsets.UTF_8)), jebac_vexiaqb58506wt8o3.  ‏ ("뜾뜐뜓뜋뜚뜕뜏뜔", 1730066300));
         String var3 = Cipher.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("ண\u0b8dஎ\u0b96இஈஒஉ", 1259604961));
         var3.init( gp[9], var2);
         return new String(var3.doFinal(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var9) {
         var9.printStackTrace();
         return null;
      }
   }

   // $FF: synthetic method
   private static void lllIlllI() {
       gp = new int[15];
       gp[0] = jebac_vexiaqb58506wt8o3.  ‏ ("ז", 40961526).length();
       gp[1] = 23 ^ 37 ^ 231 ^ 143;
       gp[2] = (10 + 90 - -2 + 25 ^ 81 ^ 109) & (42 ^ 86 ^ 70 ^ 121 ^ -jebac_vexiaqb58506wt8o3.  ‏ ("졘", -713570184).length());
       gp[3] = 140 ^ 173;
       gp[4] = 13 ^ 11;
       gp[5] = 171 ^ 130 ^ 159 ^ 177;
       gp[6] = 160 ^ 182 ^ 1 ^ 31;
       gp[7] = 90 ^ 72;
       gp[8] = 9 + 124 - 95 + 160;
       gp[9] = jebac_vexiaqb58506wt8o3.  ‏ ("̛̛", 547685179).length();
       gp[10] = jebac_vexiaqb58506wt8o3.  ‏ ("ᲴᲴᲴ", -1434706796).length();
       gp[11] = 19 ^ 101 ^ 38 ^ 90;
       gp[12] = -1 & 16777215;
       gp[13] = -(116 + 37 - 55 + 31) & -1 & 8355839;
       gp[14] = 16 ^ 20;
   }

   // $FF: synthetic method
   public void render() {
      if (lllIllll(this. gu.thePlayer.getActivePotionEffects().isEmpty())) {
         int var1 =  gp[3];
         int var2 =  gp[2];
         GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
         GlStateManager.disableLighting();
         Iterator var3 = this. gu.thePlayer.getActivePotionEffects().iterator();

         while(llllIIII(var3.hasNext())) {
            PotionEffect var4 = (PotionEffect)var3.next();
            Exception var5 = Potion.potionTypes[var4.getPotionID()];
            if (llllIIII(this. gt) && llllIIII(var5.hasStatusIcon())) {
               short var6 = var5.getStatusIconIndex();
               this. gu.getTextureManager().bindTexture(this. gs);
               jebac_vexiakm1amlnb7ukc.drawTexturedModalRect(this. gq +  gp[4], this. go + var2 +  gp[5], var6 %  gp[6] *  gp[7],  gp[8] + var6 /  gp[6] *  gp[7],  gp[7],  gp[7], -150.0F);
            }

            short var16 = I18n.format(var5.getName());
            if (llllIIIl(var4.getAmplifier(),  gp[0])) {
               var16 = String.valueOf((new StringBuilder()).append(var16).append( gr[ gp[0]]));
               jebac_vexiaqb58506wt8o3.  ‏ ("", 1285136249).length();
               if ((162 ^ 166) <= jebac_vexiaqb58506wt8o3.  ‏ ("柮柮柮", 479029198).length()) {
                  return;
               }
            } else if (llllIIIl(var4.getAmplifier(),  gp[9])) {
               var16 = String.valueOf((new StringBuilder()).append(var16).append( gr[ gp[9]]));
               jebac_vexiaqb58506wt8o3.  ‏ ("", 373309094).length();
               if (jebac_vexiaqb58506wt8o3.  ‏ ("\uf4b5\uf4b5", 1829041301).length() >= jebac_vexiaqb58506wt8o3.  ‏ ("鏞鏞鏞", -1064332290).length()) {
                  return;
               }
            } else if (llllIIIl(var4.getAmplifier(),  gp[10])) {
               var16 = String.valueOf((new StringBuilder()).append(var16).append( gr[ gp[10]]));
            }

            this. gu.fontRendererObj.drawStringWithShadow(var16, (float)(this. gq +  gp[11] +  gp[7]), (float)(this. go + var2 +  gp[4]),  gp[12]);
            jebac_vexiaqb58506wt8o3.  ‏ ("", -369770888).length();
            jebac_vexiawjtwglazxj7a var7 = Potion.getDurationString(var4);
            this. gu.fontRendererObj.drawStringWithShadow(var7, (float)(this. gq +  gp[11] +  gp[7]), (float)(this. go + var2 +  gp[4] +  gp[11]),  gp[13]);
            jebac_vexiaqb58506wt8o3.  ‏ ("", 912235229).length();
            var2 += var1;
            jebac_vexiaqb58506wt8o3.  ‏ ("", -1249259517).length();
            if (-jebac_vexiaqb58506wt8o3.  ‏ ("푮푮푮", 632673358).length() >= 0) {
               return;
            }
         }
      }

   }

   // $FF: synthetic method
   private static boolean llllIIlI(int var0, int var1) {
      return var0 < var1;
   }

   // $FF: synthetic method
   private static String llIlllll(String var0, String var1) {
      var0 = new String(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      Exception var2 = new StringBuilder();
      float var3 = var1.toCharArray();
      char[] var4 =  gp[2];
      byte var5 = var0.toCharArray();
      int var6 = var5.length;
      int var7 =  gp[2];

      do {
         if (!llllIIlI(var7, var6)) {
            return String.valueOf(var2);
         }

         String var8 = var5[var7];
         var2.append((char)(var8 ^ var3[var4 % var3.length]));
         jebac_vexiaqb58506wt8o3.  ‏ ("", 1466915622).length();
         ++var4;
         ++var7;
         jebac_vexiaqb58506wt8o3.  ‏ ("", -1892623482).length();
      } while((101 ^ 97) > jebac_vexiaqb58506wt8o3.  ‏ ("ᔙ", 1408374073).length());

      return null;
   }

   // $FF: synthetic method
   private static boolean lllIllll(int var0) {
      return var0 == 0;
   }

   // $FF: synthetic method
   private static boolean llllIIIl(int var0, int var1) {
      return var0 == var1;
   }
}
