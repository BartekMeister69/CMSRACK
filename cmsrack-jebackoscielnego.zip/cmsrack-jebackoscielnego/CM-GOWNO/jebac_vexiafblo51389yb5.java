import com.google.common.collect.Maps;
import java.util.Iterator;
import java.util.Map;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.storage.MapData;

public class jebac_vexiafblo51389yb5 {
   // $FF: synthetic field
   private final TextureManager textureManager;
   // $FF: synthetic field
   private final Map loadedMaps = Maps.newHashMap();
   // $FF: synthetic field
   private static final ResourceLocation mapIcons = new ResourceLocation("textures/map/map_icons.png");

   // $FF: synthetic method
   public jebac_vexiafblo51389yb5(TextureManager textureManagerIn) {
      this.textureManager = textureManagerIn;
   }

   static TextureManager access$400(jebac_vexiafblo51389yb5 x0) {
      return x0.textureManager;
   }

   static ResourceLocation access$500() {
      return mapIcons;
   }

   // $FF: synthetic method
   private jebac_vexiatlvfr1hn5twm getMapRendererInstance(MapData mapdataIn) {
      jebac_vexiatlvfr1hn5twm mapitemrenderer$instance = (jebac_vexiatlvfr1hn5twm)this.loadedMaps.get(mapdataIn.mapName);
      if (mapitemrenderer$instance == null) {
         mapitemrenderer$instance = new jebac_vexiatlvfr1hn5twm(this, mapdataIn);
         this.loadedMaps.put(mapdataIn.mapName, mapitemrenderer$instance);
      }

      return mapitemrenderer$instance;
   }

   // $FF: synthetic method
   public void renderMap(MapData mapdataIn, boolean p_148250_2_) {
      jebac_vexiatlvfr1hn5twm.access$100(this.getMapRendererInstance(mapdataIn), p_148250_2_);
   }

   // $FF: synthetic method
   public void updateMapTexture(MapData mapdataIn) {
      jebac_vexiatlvfr1hn5twm.access$000(this.getMapRendererInstance(mapdataIn));
   }

   // $FF: synthetic method
   public void clearLoadedMaps() {
      Iterator var1 = this.loadedMaps.values().iterator();

      while(var1.hasNext()) {
         jebac_vexiatlvfr1hn5twm mapitemrenderer$instance = (jebac_vexiatlvfr1hn5twm)var1.next();
         this.textureManager.deleteTexture(jebac_vexiatlvfr1hn5twm.access$300(mapitemrenderer$instance));
      }

      this.loadedMaps.clear();
   }
}
