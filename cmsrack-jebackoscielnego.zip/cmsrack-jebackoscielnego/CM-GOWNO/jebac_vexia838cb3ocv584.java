import com.google.common.collect.Lists;
import java.util.Comparator;
import java.util.Iterator;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.item.Item;
import net.minecraft.stats.StatBase;
import net.minecraft.stats.StatCrafting;
import net.minecraft.stats.StatList;

class jebac_vexia838cb3ocv584 extends jebac_vexiahlxp3dgdu53f {
   final jebac_vexiazwfkkk4iev4c this$0;

   // $FF: synthetic method
   protected void drawListHeader(int p_148129_1_, int p_148129_2_, Tessellator p_148129_3_) {
      super.drawListHeader(p_148129_1_, p_148129_2_, p_148129_3_);
      if (this.field_148218_l == 0) {
         jebac_vexiazwfkkk4iev4c.access$000(this.this$0, p_148129_1_ + 115 - 18 + 1, p_148129_2_ + 1 + 1, 18, 18);
      } else {
         jebac_vexiazwfkkk4iev4c.access$000(this.this$0, p_148129_1_ + 115 - 18, p_148129_2_ + 1, 18, 18);
      }

      if (this.field_148218_l == 1) {
         jebac_vexiazwfkkk4iev4c.access$000(this.this$0, p_148129_1_ + 165 - 18 + 1, p_148129_2_ + 1 + 1, 36, 18);
      } else {
         jebac_vexiazwfkkk4iev4c.access$000(this.this$0, p_148129_1_ + 165 - 18, p_148129_2_ + 1, 36, 18);
      }

      if (this.field_148218_l == 2) {
         jebac_vexiazwfkkk4iev4c.access$000(this.this$0, p_148129_1_ + 215 - 18 + 1, p_148129_2_ + 1 + 1, 54, 18);
      } else {
         jebac_vexiazwfkkk4iev4c.access$000(this.this$0, p_148129_1_ + 215 - 18, p_148129_2_ + 1, 54, 18);
      }

   }

   // $FF: synthetic method
   protected void drawSlot(int entryID, int p_180791_2_, int p_180791_3_, int p_180791_4_, int mouseXIn, int mouseYIn) {
      StatCrafting statcrafting = this.func_148211_c(entryID);
      Item item = statcrafting.func_150959_a();
      jebac_vexiazwfkkk4iev4c.access$1200(this.this$0, p_180791_2_ + 40, p_180791_3_, item);
      int i = Item.getIdFromItem(item);
      this.func_148209_a(StatList.objectCraftStats[i], p_180791_2_ + 115, p_180791_3_, entryID % 2 == 0);
      this.func_148209_a(StatList.objectUseStats[i], p_180791_2_ + 165, p_180791_3_, entryID % 2 == 0);
      this.func_148209_a(statcrafting, p_180791_2_ + 215, p_180791_3_, entryID % 2 == 0);
   }

   // $FF: synthetic method
   protected String func_148210_b(int p_148210_1_) {
      return p_148210_1_ == 0 ? "stat.crafted" : (p_148210_1_ == 1 ? "stat.used" : "stat.mined");
   }

   // $FF: synthetic method
   public jebac_vexia838cb3ocv584(jebac_vexiazwfkkk4iev4c this$0, Minecraft mcIn) {
      super(this$0, mcIn);
      this.this$0 = this$0;
      this.statsHolder = Lists.newArrayList();
      Iterator var3 = StatList.objectMineStats.iterator();

      while(var3.hasNext()) {
         StatCrafting statcrafting = (StatCrafting)var3.next();
         boolean flag = false;
         int i = Item.getIdFromItem(statcrafting.func_150959_a());
         if (jebac_vexiazwfkkk4iev4c.access$100(this$0).readStat(statcrafting) > 0) {
            flag = true;
         } else if (StatList.objectUseStats[i] != null && jebac_vexiazwfkkk4iev4c.access$100(this$0).readStat(StatList.objectUseStats[i]) > 0) {
            flag = true;
         } else if (StatList.objectCraftStats[i] != null && jebac_vexiazwfkkk4iev4c.access$100(this$0).readStat(StatList.objectCraftStats[i]) > 0) {
            flag = true;
         }

         if (flag) {
            this.statsHolder.add(statcrafting);
         }
      }

      this.statSorter = new Comparator(this, this$0) {
         final jebac_vexiazwfkkk4iev4c val$this$0;
         final jebac_vexia838cb3ocv584 this$1;

         // $FF: synthetic method
         {
            this.this$1 = this$1;
            this.val$this$0 = var2;
         }

         // $FF: synthetic method
         public int compare(StatCrafting p_compare_1_, StatCrafting p_compare_2_) {
            int j = Item.getIdFromItem(p_compare_1_.func_150959_a());
            int k = Item.getIdFromItem(p_compare_2_.func_150959_a());
            StatBase statbase = null;
            StatBase statbase1 = null;
            if (this.this$1.field_148217_o == 2) {
               statbase = StatList.mineBlockStatArray[j];
               statbase1 = StatList.mineBlockStatArray[k];
            } else if (this.this$1.field_148217_o == 0) {
               statbase = StatList.objectCraftStats[j];
               statbase1 = StatList.objectCraftStats[k];
            } else if (this.this$1.field_148217_o == 1) {
               statbase = StatList.objectUseStats[j];
               statbase1 = StatList.objectUseStats[k];
            }

            if (statbase != null || statbase1 != null) {
               if (statbase == null) {
                  return 1;
               }

               if (statbase1 == null) {
                  return -1;
               }

               int l = jebac_vexiazwfkkk4iev4c.access$100(this.this$1.this$0).readStat(statbase);
               int i1 = jebac_vexiazwfkkk4iev4c.access$100(this.this$1.this$0).readStat(statbase1);
               if (l != i1) {
                  return (l - i1) * this.this$1.field_148215_p;
               }
            }

            return j - k;
         }
      };
   }
}
