import java.lang.reflect.Field;

public class jebac_vexiab2s3j88xnwyz implements jebac_vexiasxnrrk3b6ekg {
   // $FF: synthetic field
   private jebac_vexiajs8ej2dllnvc reflectorClass = null;
   // $FF: synthetic field
   private int targetFieldIndex;
   // $FF: synthetic field
   private Class targetFieldType = null;

   // $FF: synthetic method
   public Field getField() {
      Class oclass = this.reflectorClass.getTargetClass();
      if (oclass == null) {
         return null;
      } else {
         try {
            Field[] afield = oclass.getDeclaredFields();
            int i = 0;
            Field[] var4 = afield;
            int var5 = afield.length;

            for(int var6 = 0; var6 < var5; ++var6) {
               Field field = var4[var6];
               if (field.getType() == this.targetFieldType) {
                  if (i == this.targetFieldIndex) {
                     field.setAccessible(true);
                     return field;
                  }

                  ++i;
               }
            }

            jebac_vexiakrwecfs16wve.log("(Reflector) Field not present: " + oclass.getName() + ".(type: " + this.targetFieldType + ", index: " + this.targetFieldIndex + ")");
            return null;
         } catch (Throwable var8) {
            var8.printStackTrace();
            return null;
         }
      }
   }

   // $FF: synthetic method
   public jebac_vexiab2s3j88xnwyz(jebac_vexiajs8ej2dllnvc p_i40_1_, Class p_i40_2_, int p_i40_3_) {
      this.reflectorClass = p_i40_1_;
      this.targetFieldType = p_i40_2_;
      this.targetFieldIndex = p_i40_3_;
   }
}
