import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.MathHelper;
import org.lwjgl.input.Mouse;

public abstract class jebac_vexiado18oeh2l9bq {
   // $FF: synthetic field
   private int scrollUpButtonID;
   // $FF: synthetic field
   protected int height;
   // $FF: synthetic field
   protected final int slotHeight;
   // $FF: synthetic field
   protected int right;
   // $FF: synthetic field
   protected long lastClicked;
   // $FF: synthetic field
   protected int headerPadding;
   // $FF: synthetic field
   protected boolean showSelectionBox = true;
   // $FF: synthetic field
   protected float scrollMultiplier;
   // $FF: synthetic field
   protected boolean field_148163_i = true;
   // $FF: synthetic field
   protected int left;
   // $FF: synthetic field
   protected int selectedElement = -1;
   // $FF: synthetic field
   protected int mouseY;
   // $FF: synthetic field
   protected int width;
   // $FF: synthetic field
   protected boolean field_178041_q = true;
   // $FF: synthetic field
   protected final Minecraft mc;
   // $FF: synthetic field
   private int scrollDownButtonID;
   // $FF: synthetic field
   protected boolean hasListHeader;
   // $FF: synthetic field
   private boolean enabled = true;
   // $FF: synthetic field
   protected int initialClickY = -2;
   // $FF: synthetic field
   protected int bottom;
   // $FF: synthetic field
   protected float amountScrolled;
   // $FF: synthetic field
   protected int top;
   // $FF: synthetic field
   protected int mouseX;

   // $FF: synthetic method
   protected abstract void elementClicked(int var1, boolean var2, int var3, int var4);

   // $FF: synthetic method
   protected void func_148132_a(int p_148132_1_, int p_148132_2_) {
   }

   // $FF: synthetic method
   public void setEnabled(boolean enabledIn) {
      this.enabled = enabledIn;
   }

   // $FF: synthetic method
   public void drawScreen(int mouseXIn, int mouseYIn, float p_148128_3_) {
      if (this.field_178041_q) {
         this.mouseX = mouseXIn;
         this.mouseY = mouseYIn;
         this.drawBackground();
         int i = this.getScrollBarX();
         int j = i + 6;
         this.bindAmountScrolled();
         GlStateManager.disableLighting();
         GlStateManager.disableFog();
         Tessellator tessellator = Tessellator.getInstance();
         WorldRenderer worldrenderer = tessellator.getWorldRenderer();
         int k = this.left + this.width / 2 - this.getListWidth() / 2 + 2;
         int l = this.top + 4 - (int)this.amountScrolled;
         if (this.hasListHeader) {
            this.drawListHeader(k, l, tessellator);
         }

         this.drawSelectionBox(k, l, mouseXIn, mouseYIn);
         GlStateManager.disableDepth();
         int i1 = 4;
         this.overlayBackground(0, this.top, 255, 255);
         this.overlayBackground(this.bottom, this.height, 255, 255);
         GlStateManager.enableBlend();
         GlStateManager.tryBlendFuncSeparate(770, 771, 0, 1);
         GlStateManager.disableAlpha();
         GlStateManager.shadeModel(7425);
         GlStateManager.disableTexture2D();
         worldrenderer.begin(7, DefaultVertexFormats.POSITION_TEX_COLOR);
         worldrenderer.pos((double)this.left, (double)(this.top + i1), 0.0D).tex(0.0D, 1.0D).color(0, 0, 0, 0).endVertex();
         worldrenderer.pos((double)this.right, (double)(this.top + i1), 0.0D).tex(1.0D, 1.0D).color(0, 0, 0, 0).endVertex();
         worldrenderer.pos((double)this.right, (double)this.top, 0.0D).tex(1.0D, 0.0D).color(0, 0, 0, 255).endVertex();
         worldrenderer.pos((double)this.left, (double)this.top, 0.0D).tex(0.0D, 0.0D).color(0, 0, 0, 255).endVertex();
         tessellator.draw();
         worldrenderer.begin(7, DefaultVertexFormats.POSITION_TEX_COLOR);
         worldrenderer.pos((double)this.left, (double)this.bottom, 0.0D).tex(0.0D, 1.0D).color(0, 0, 0, 255).endVertex();
         worldrenderer.pos((double)this.right, (double)this.bottom, 0.0D).tex(1.0D, 1.0D).color(0, 0, 0, 255).endVertex();
         worldrenderer.pos((double)this.right, (double)(this.bottom - i1), 0.0D).tex(1.0D, 0.0D).color(0, 0, 0, 0).endVertex();
         worldrenderer.pos((double)this.left, (double)(this.bottom - i1), 0.0D).tex(0.0D, 0.0D).color(0, 0, 0, 0).endVertex();
         tessellator.draw();
         int j1 = this.func_148135_f();
         if (j1 > 0) {
            int k1 = (this.bottom - this.top) * (this.bottom - this.top) / this.getContentHeight();
            k1 = MathHelper.clamp_int(k1, 32, this.bottom - this.top - 8);
            int l1 = (int)this.amountScrolled * (this.bottom - this.top - k1) / j1 + this.top;
            if (l1 < this.top) {
               l1 = this.top;
            }

            worldrenderer.begin(7, DefaultVertexFormats.POSITION_TEX_COLOR);
            worldrenderer.pos((double)i, (double)this.bottom, 0.0D).tex(0.0D, 1.0D).color(0, 0, 0, 255).endVertex();
            worldrenderer.pos((double)j, (double)this.bottom, 0.0D).tex(1.0D, 1.0D).color(0, 0, 0, 255).endVertex();
            worldrenderer.pos((double)j, (double)this.top, 0.0D).tex(1.0D, 0.0D).color(0, 0, 0, 255).endVertex();
            worldrenderer.pos((double)i, (double)this.top, 0.0D).tex(0.0D, 0.0D).color(0, 0, 0, 255).endVertex();
            tessellator.draw();
            worldrenderer.begin(7, DefaultVertexFormats.POSITION_TEX_COLOR);
            worldrenderer.pos((double)i, (double)(l1 + k1), 0.0D).tex(0.0D, 1.0D).color(128, 128, 128, 255).endVertex();
            worldrenderer.pos((double)j, (double)(l1 + k1), 0.0D).tex(1.0D, 1.0D).color(128, 128, 128, 255).endVertex();
            worldrenderer.pos((double)j, (double)l1, 0.0D).tex(1.0D, 0.0D).color(128, 128, 128, 255).endVertex();
            worldrenderer.pos((double)i, (double)l1, 0.0D).tex(0.0D, 0.0D).color(128, 128, 128, 255).endVertex();
            tessellator.draw();
            worldrenderer.begin(7, DefaultVertexFormats.POSITION_TEX_COLOR);
            worldrenderer.pos((double)i, (double)(l1 + k1 - 1), 0.0D).tex(0.0D, 1.0D).color(192, 192, 192, 255).endVertex();
            worldrenderer.pos((double)(j - 1), (double)(l1 + k1 - 1), 0.0D).tex(1.0D, 1.0D).color(192, 192, 192, 255).endVertex();
            worldrenderer.pos((double)(j - 1), (double)l1, 0.0D).tex(1.0D, 0.0D).color(192, 192, 192, 255).endVertex();
            worldrenderer.pos((double)i, (double)l1, 0.0D).tex(0.0D, 0.0D).color(192, 192, 192, 255).endVertex();
            tessellator.draw();
         }

         this.func_148142_b(mouseXIn, mouseYIn);
         GlStateManager.enableTexture2D();
         GlStateManager.shadeModel(7424);
         GlStateManager.enableAlpha();
         GlStateManager.disableBlend();
      }

   }

   // $FF: synthetic method
   public void registerScrollButtons(int scrollUpButtonIDIn, int scrollDownButtonIDIn) {
      this.scrollUpButtonID = scrollUpButtonIDIn;
      this.scrollDownButtonID = scrollDownButtonIDIn;
   }

   // $FF: synthetic method
   protected int getScrollBarX() {
      return this.width / 2 + 124;
   }

   // $FF: synthetic method
   public void setDimensions(int widthIn, int heightIn, int topIn, int bottomIn) {
      this.width = widthIn;
      this.height = heightIn;
      this.top = topIn;
      this.bottom = bottomIn;
      this.left = 0;
      this.right = widthIn;
   }

   // $FF: synthetic method
   public int getListWidth() {
      return 220;
   }

   // $FF: synthetic method
   public int getAmountScrolled() {
      return (int)this.amountScrolled;
   }

   // $FF: synthetic method
   protected void func_178040_a(int p_178040_1_, int p_178040_2_, int p_178040_3_) {
   }

   // $FF: synthetic method
   public void setSlotXBoundsFromLeft(int leftIn) {
      this.left = leftIn;
      this.right = leftIn + this.width;
   }

   // $FF: synthetic method
   public int getSlotHeight() {
      return this.slotHeight;
   }

   // $FF: synthetic method
   protected void func_148142_b(int p_148142_1_, int p_148142_2_) {
   }

   // $FF: synthetic method
   public void scrollBy(int amount) {
      this.amountScrolled += (float)amount;
      this.bindAmountScrolled();
      this.initialClickY = -2;
   }

   // $FF: synthetic method
   protected int getContentHeight() {
      return this.getSize() * this.slotHeight + this.headerPadding;
   }

   // $FF: synthetic method
   protected void bindAmountScrolled() {
      this.amountScrolled = MathHelper.clamp_float(this.amountScrolled, 0.0F, (float)this.func_148135_f());
   }

   // $FF: synthetic method
   protected abstract void drawBackground();

   // $FF: synthetic method
   protected void setHasListHeader(boolean hasListHeaderIn, int headerPaddingIn) {
      this.hasListHeader = hasListHeaderIn;
      this.headerPadding = headerPaddingIn;
      if (!hasListHeaderIn) {
         this.headerPadding = 0;
      }

   }

   // $FF: synthetic method
   public jebac_vexiado18oeh2l9bq(Minecraft mcIn, int width, int height, int topIn, int bottomIn, int slotHeightIn) {
      this.mc = mcIn;
      this.width = width;
      this.height = height;
      this.top = topIn;
      this.bottom = bottomIn;
      this.slotHeight = slotHeightIn;
      this.left = 0;
      this.right = width;
   }

   // $FF: synthetic method
   public int func_148135_f() {
      return Math.max(0, this.getContentHeight() - (this.bottom - this.top - 4));
   }

   // $FF: synthetic method
   public boolean getEnabled() {
      return this.enabled;
   }

   // $FF: synthetic method
   protected void overlayBackground(int startY, int endY, int startAlpha, int endAlpha) {
      Tessellator tessellator = Tessellator.getInstance();
      WorldRenderer worldrenderer = tessellator.getWorldRenderer();
      this.mc.getTextureManager().bindTexture(jebac_vexiabhi02xzapwrh.optionsBackground);
      GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
      worldrenderer.begin(7, DefaultVertexFormats.POSITION_TEX_COLOR);
      worldrenderer.pos((double)this.left, (double)endY, 0.0D).tex(0.0D, (double)((float)endY / 32.0F)).color(64, 64, 64, endAlpha).endVertex();
      worldrenderer.pos((double)(this.left + this.width), (double)endY, 0.0D).tex((double)((float)this.width / 32.0F), (double)((float)endY / 32.0F)).color(64, 64, 64, endAlpha).endVertex();
      worldrenderer.pos((double)(this.left + this.width), (double)startY, 0.0D).tex((double)((float)this.width / 32.0F), (double)((float)startY / 32.0F)).color(64, 64, 64, startAlpha).endVertex();
      worldrenderer.pos((double)this.left, (double)startY, 0.0D).tex(0.0D, (double)((float)startY / 32.0F)).color(64, 64, 64, startAlpha).endVertex();
      tessellator.draw();
   }

   // $FF: synthetic method
   protected void drawListHeader(int p_148129_1_, int p_148129_2_, Tessellator p_148129_3_) {
   }

   // $FF: synthetic method
   protected abstract int getSize();

   // $FF: synthetic method
   protected abstract boolean isSelected(int var1);

   // $FF: synthetic method
   public void handleMouseInput() {
      if (this.isMouseYWithinSlotBounds(this.mouseY)) {
         int i2;
         int j2;
         int k2;
         int l2;
         if (Mouse.getEventButton() == 0 && Mouse.getEventButtonState() && this.mouseY >= this.top && this.mouseY <= this.bottom) {
            i2 = (this.width - this.getListWidth()) / 2;
            j2 = (this.width + this.getListWidth()) / 2;
            k2 = this.mouseY - this.top - this.headerPadding + (int)this.amountScrolled - 4;
            l2 = k2 / this.slotHeight;
            if (l2 < this.getSize() && this.mouseX >= i2 && this.mouseX <= j2 && l2 >= 0 && k2 >= 0) {
               this.elementClicked(l2, false, this.mouseX, this.mouseY);
               this.selectedElement = l2;
            } else if (this.mouseX >= i2 && this.mouseX <= j2 && k2 < 0) {
               this.func_148132_a(this.mouseX - i2, this.mouseY - this.top + (int)this.amountScrolled - 4);
            }
         }

         if (Mouse.isButtonDown(0) && this.getEnabled()) {
            if (this.initialClickY != -1) {
               if (this.initialClickY >= 0) {
                  this.amountScrolled -= (float)(this.mouseY - this.initialClickY) * this.scrollMultiplier;
                  this.initialClickY = this.mouseY;
               }
            } else {
               boolean flag1 = true;
               if (this.mouseY >= this.top && this.mouseY <= this.bottom) {
                  j2 = (this.width - this.getListWidth()) / 2;
                  k2 = (this.width + this.getListWidth()) / 2;
                  l2 = this.mouseY - this.top - this.headerPadding + (int)this.amountScrolled - 4;
                  int i1 = l2 / this.slotHeight;
                  if (i1 < this.getSize() && this.mouseX >= j2 && this.mouseX <= k2 && i1 >= 0 && l2 >= 0) {
                     boolean flag = i1 == this.selectedElement && Minecraft.getSystemTime() - this.lastClicked < 250L;
                     this.elementClicked(i1, flag, this.mouseX, this.mouseY);
                     this.selectedElement = i1;
                     this.lastClicked = Minecraft.getSystemTime();
                  } else if (this.mouseX >= j2 && this.mouseX <= k2 && l2 < 0) {
                     this.func_148132_a(this.mouseX - j2, this.mouseY - this.top + (int)this.amountScrolled - 4);
                     flag1 = false;
                  }

                  int i3 = this.getScrollBarX();
                  int j1 = i3 + 6;
                  if (this.mouseX >= i3 && this.mouseX <= j1) {
                     this.scrollMultiplier = -1.0F;
                     int k1 = this.func_148135_f();
                     if (k1 < 1) {
                        k1 = 1;
                     }

                     int l1 = (int)((float)((this.bottom - this.top) * (this.bottom - this.top)) / (float)this.getContentHeight());
                     l1 = MathHelper.clamp_int(l1, 32, this.bottom - this.top - 8);
                     this.scrollMultiplier /= (float)(this.bottom - this.top - l1) / (float)k1;
                  } else {
                     this.scrollMultiplier = 1.0F;
                  }

                  if (flag1) {
                     this.initialClickY = this.mouseY;
                  } else {
                     this.initialClickY = -2;
                  }
               } else {
                  this.initialClickY = -2;
               }
            }
         } else {
            this.initialClickY = -1;
         }

         i2 = Mouse.getEventDWheel();
         if (i2 != 0) {
            byte i2;
            if (i2 > 0) {
               i2 = -1;
            } else {
               i2 = 1;
            }

            this.amountScrolled += (float)(i2 * this.slotHeight / 2);
         }
      }

   }

   // $FF: synthetic method
   protected void drawSelectionBox(int p_148120_1_, int p_148120_2_, int mouseXIn, int mouseYIn) {
      int i = this.getSize();
      Tessellator tessellator = Tessellator.getInstance();
      WorldRenderer worldrenderer = tessellator.getWorldRenderer();

      for(int j = 0; j < i; ++j) {
         int k = p_148120_2_ + j * this.slotHeight + this.headerPadding;
         int l = this.slotHeight - 4;
         if (k > this.bottom || k + l < this.top) {
            this.func_178040_a(j, p_148120_1_, k);
         }

         if (this.showSelectionBox && this.isSelected(j)) {
            int i1 = this.left + (this.width / 2 - this.getListWidth() / 2);
            int j1 = this.left + this.width / 2 + this.getListWidth() / 2;
            GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
            GlStateManager.disableTexture2D();
            worldrenderer.begin(7, DefaultVertexFormats.POSITION_TEX_COLOR);
            worldrenderer.pos((double)i1, (double)(k + l + 2), 0.0D).tex(0.0D, 1.0D).color(128, 128, 128, 255).endVertex();
            worldrenderer.pos((double)j1, (double)(k + l + 2), 0.0D).tex(1.0D, 1.0D).color(128, 128, 128, 255).endVertex();
            worldrenderer.pos((double)j1, (double)(k - 2), 0.0D).tex(1.0D, 0.0D).color(128, 128, 128, 255).endVertex();
            worldrenderer.pos((double)i1, (double)(k - 2), 0.0D).tex(0.0D, 0.0D).color(128, 128, 128, 255).endVertex();
            worldrenderer.pos((double)(i1 + 1), (double)(k + l + 1), 0.0D).tex(0.0D, 1.0D).color(0, 0, 0, 255).endVertex();
            worldrenderer.pos((double)(j1 - 1), (double)(k + l + 1), 0.0D).tex(1.0D, 1.0D).color(0, 0, 0, 255).endVertex();
            worldrenderer.pos((double)(j1 - 1), (double)(k - 1), 0.0D).tex(1.0D, 0.0D).color(0, 0, 0, 255).endVertex();
            worldrenderer.pos((double)(i1 + 1), (double)(k - 1), 0.0D).tex(0.0D, 0.0D).color(0, 0, 0, 255).endVertex();
            tessellator.draw();
            GlStateManager.enableTexture2D();
         }

         this.drawSlot(j, p_148120_1_, k, l, mouseXIn, mouseYIn);
      }

   }

   // $FF: synthetic method
   protected abstract void drawSlot(int var1, int var2, int var3, int var4, int var5, int var6);

   // $FF: synthetic method
   public void actionPerformed(jebac_vexia4oibzo50ubf0 button) {
      if (button.enabled) {
         if (button.id == this.scrollUpButtonID) {
            this.amountScrolled -= (float)(this.slotHeight * 2 / 3);
            this.initialClickY = -2;
            this.bindAmountScrolled();
         } else if (button.id == this.scrollDownButtonID) {
            this.amountScrolled += (float)(this.slotHeight * 2 / 3);
            this.initialClickY = -2;
            this.bindAmountScrolled();
         }
      }

   }

   // $FF: synthetic method
   public int getSlotIndexFromScreenCoords(int p_148124_1_, int p_148124_2_) {
      int i = this.left + this.width / 2 - this.getListWidth() / 2;
      int j = this.left + this.width / 2 + this.getListWidth() / 2;
      int k = p_148124_2_ - this.top - this.headerPadding + (int)this.amountScrolled - 4;
      int l = k / this.slotHeight;
      return p_148124_1_ < this.getScrollBarX() && p_148124_1_ >= i && p_148124_1_ <= j && l >= 0 && k >= 0 && l < this.getSize() ? l : -1;
   }

   // $FF: synthetic method
   public void setShowSelectionBox(boolean showSelectionBoxIn) {
      this.showSelectionBox = showSelectionBoxIn;
   }

   // $FF: synthetic method
   public boolean isMouseYWithinSlotBounds(int p_148141_1_) {
      return p_148141_1_ >= this.top && p_148141_1_ <= this.bottom && this.mouseX >= this.left && this.mouseX <= this.right;
   }
}
