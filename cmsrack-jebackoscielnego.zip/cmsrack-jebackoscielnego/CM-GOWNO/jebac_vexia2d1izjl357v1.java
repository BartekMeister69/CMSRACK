public class jebac_vexia2d1izjl357v1 {
   // $FF: synthetic method
   public static int alphaBlend(int p_alphaBlend_0_, int p_alphaBlend_1_, int p_alphaBlend_2_, int p_alphaBlend_3_) {
      int i = alphaBlend(p_alphaBlend_0_, p_alphaBlend_1_);
      int j = alphaBlend(p_alphaBlend_2_, p_alphaBlend_3_);
      return alphaBlend(i, j);
   }

   // $FF: synthetic method
   private static int alphaBlend(int p_alphaBlend_0_, int p_alphaBlend_1_) {
      int i = (p_alphaBlend_0_ & -16777216) >> 24 & 255;
      int j = (p_alphaBlend_1_ & -16777216) >> 24 & 255;
      int k = (i + j) / 2;
      if (i == 0 && j == 0) {
         i = 1;
         j = 1;
      } else {
         if (i == 0) {
            p_alphaBlend_0_ = p_alphaBlend_1_;
            k /= 2;
         }

         if (j == 0) {
            p_alphaBlend_1_ = p_alphaBlend_0_;
            k /= 2;
         }
      }

      int l = (p_alphaBlend_0_ >> 16 & 255) * i;
      int i1 = (p_alphaBlend_0_ >> 8 & 255) * i;
      int j1 = (p_alphaBlend_0_ & 255) * i;
      int k1 = (p_alphaBlend_1_ >> 16 & 255) * j;
      int l1 = (p_alphaBlend_1_ >> 8 & 255) * j;
      int i2 = (p_alphaBlend_1_ & 255) * j;
      int j2 = (l + k1) / (i + j);
      int k2 = (i1 + l1) / (i + j);
      int l2 = (j1 + i2) / (i + j);
      return k << 24 | j2 << 16 | k2 << 8 | l2;
   }
}
