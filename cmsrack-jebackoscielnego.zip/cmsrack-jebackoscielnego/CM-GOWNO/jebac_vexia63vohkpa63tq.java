import net.minecraft.entity.EntityLiving;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.biome.BiomeGenBase;

public class jebac_vexia63vohkpa63tq {
   // $FF: synthetic field
   public int[] sumWeights = null;
   // $FF: synthetic field
   private BiomeGenBase[] biomes = null;
   // $FF: synthetic field
   private ResourceLocation[] resourceLocations = null;
   // $FF: synthetic field
   public int sumAllWeights = 1;
   // $FF: synthetic field
   private int[] weights = null;
   // $FF: synthetic field
   private jebac_vexiauw6xjpymnteq heights = null;
   // $FF: synthetic field
   private ResourceLocation baseResLoc = null;
   // $FF: synthetic field
   private int[] skins = null;

   // $FF: synthetic method
   public ResourceLocation getTextureLocation(ResourceLocation p_getTextureLocation_1_, int p_getTextureLocation_2_) {
      int i = 0;
      if (this.weights == null) {
         i = p_getTextureLocation_2_ % this.resourceLocations.length;
      } else {
         int j = p_getTextureLocation_2_ % this.sumAllWeights;

         for(int k = 0; k < this.sumWeights.length; ++k) {
            if (this.sumWeights[k] > j) {
               i = k;
               break;
            }
         }
      }

      return this.resourceLocations[i];
   }

   // $FF: synthetic method
   public boolean isValid(String p_isValid_1_) {
      this.resourceLocations = new ResourceLocation[this.skins.length];
      ResourceLocation resourcelocation = jebac_vexia5fz97xnisel2.getMcpatcherLocation(this.baseResLoc);
      if (resourcelocation == null) {
         jebac_vexiakrwecfs16wve.warn("Invalid path: " + this.baseResLoc.getResourcePath());
         return false;
      } else {
         int k;
         int i1;
         for(k = 0; k < this.resourceLocations.length; ++k) {
            i1 = this.skins[k];
            if (i1 <= 1) {
               this.resourceLocations[k] = this.baseResLoc;
            } else {
               ResourceLocation resourcelocation1 = jebac_vexia5fz97xnisel2.getLocationIndexed(resourcelocation, i1);
               if (resourcelocation1 == null) {
                  jebac_vexiakrwecfs16wve.warn("Invalid path: " + this.baseResLoc.getResourcePath());
                  return false;
               }

               if (!jebac_vexiakrwecfs16wve.hasResource(resourcelocation1)) {
                  jebac_vexiakrwecfs16wve.warn("Texture not found: " + resourcelocation1.getResourcePath());
                  return false;
               }

               this.resourceLocations[k] = resourcelocation1;
            }
         }

         if (this.weights != null) {
            int[] aint1;
            if (this.weights.length > this.resourceLocations.length) {
               jebac_vexiakrwecfs16wve.warn("More weights defined than skins, trimming weights: " + p_isValid_1_);
               aint1 = new int[this.resourceLocations.length];
               System.arraycopy(this.weights, 0, aint1, 0, aint1.length);
               this.weights = aint1;
            }

            if (this.weights.length < this.resourceLocations.length) {
               jebac_vexiakrwecfs16wve.warn("Less weights defined than skins, expanding weights: " + p_isValid_1_);
               aint1 = new int[this.resourceLocations.length];
               System.arraycopy(this.weights, 0, aint1, 0, this.weights.length);
               i1 = jebac_vexiasjtxkx13x4pe.getAverage(this.weights);

               for(int j1 = this.weights.length; j1 < aint1.length; ++j1) {
                  aint1[j1] = i1;
               }

               this.weights = aint1;
            }

            this.sumWeights = new int[this.weights.length];
            k = 0;

            for(i1 = 0; i1 < this.weights.length; ++i1) {
               if (this.weights[i1] < 0) {
                  jebac_vexiakrwecfs16wve.warn("Invalid weight: " + this.weights[i1]);
                  return false;
               }

               k += this.weights[i1];
               this.sumWeights[i1] = k;
            }

            this.sumAllWeights = k;
            if (this.sumAllWeights <= 0) {
               jebac_vexiakrwecfs16wve.warn("Invalid sum of all weights: " + k);
               this.sumAllWeights = 1;
            }
         }

         return true;
      }
   }

   // $FF: synthetic method
   public boolean matches(EntityLiving p_matches_1_) {
      return !jebac_vexiazz7bslggeoy9.biome(p_matches_1_.spawnBiome, this.biomes) ? false : (this.heights != null && p_matches_1_.spawnPosition != null ? this.heights.isInRange(p_matches_1_.spawnPosition.getY()) : true);
   }

   // $FF: synthetic method
   public jebac_vexia63vohkpa63tq(ResourceLocation p_i79_1_, int[] p_i79_2_, int[] p_i79_3_, BiomeGenBase[] p_i79_4_, jebac_vexiauw6xjpymnteq p_i79_5_) {
      this.baseResLoc = p_i79_1_;
      this.skins = p_i79_2_;
      this.weights = p_i79_3_;
      this.biomes = p_i79_4_;
      this.heights = p_i79_5_;
   }
}
