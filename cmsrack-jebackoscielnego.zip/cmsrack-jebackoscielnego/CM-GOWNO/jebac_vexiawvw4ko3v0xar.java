public class jebac_vexiawvw4ko3v0xar extends jebac_vexiamee1xbabsk4e {
   // $FF: synthetic field
   private final float field_178946_d;
   // $FF: synthetic field
   private final float field_178947_b;
   // $FF: synthetic field
   private final jebac_vexiajena7f8xtrrr field_178949_a;
   // $FF: synthetic field
   private final float field_178948_c;

   // $FF: synthetic method
   public float func_178943_e() {
      return this.field_178947_b;
   }

   // $FF: synthetic method
   public float func_178944_f() {
      return this.field_178948_c;
   }

   // $FF: synthetic method
   public jebac_vexiawvw4ko3v0xar(int p_i45530_1_, String p_i45530_2_, boolean p_i45530_3_, jebac_vexiajena7f8xtrrr p_i45530_4_, float p_i45530_5_, float p_i45530_6_, float p_i45530_7_) {
      super(p_i45530_1_, p_i45530_2_, p_i45530_3_);
      this.field_178949_a = p_i45530_4_;
      this.field_178947_b = p_i45530_5_;
      this.field_178948_c = p_i45530_6_;
      this.field_178946_d = p_i45530_7_;
   }

   // $FF: synthetic method
   public jebac_vexiajena7f8xtrrr func_178945_a() {
      return this.field_178949_a;
   }

   // $FF: synthetic method
   public float func_178942_g() {
      return this.field_178946_d;
   }
}
