import net.minecraft.util.Vec3;

public class jebac_vexiac14wv2hx3agx {
   // $FF: synthetic field
   public float texturePositionY;
   // $FF: synthetic field
   public Vec3 vector3D;
   // $FF: synthetic field
   public float texturePositionX;

   // $FF: synthetic method
   public jebac_vexiac14wv2hx3agx(float p_i1158_1_, float p_i1158_2_, float p_i1158_3_, float p_i1158_4_, float p_i1158_5_) {
      this(new Vec3((double)p_i1158_1_, (double)p_i1158_2_, (double)p_i1158_3_), p_i1158_4_, p_i1158_5_);
   }

   // $FF: synthetic method
   public jebac_vexiac14wv2hx3agx(Vec3 vector3DIn, float texturePositionXIn, float texturePositionYIn) {
      this.vector3D = vector3DIn;
      this.texturePositionX = texturePositionXIn;
      this.texturePositionY = texturePositionYIn;
   }

   // $FF: synthetic method
   public jebac_vexiac14wv2hx3agx setTexturePosition(float p_78240_1_, float p_78240_2_) {
      return new jebac_vexiac14wv2hx3agx(this, p_78240_1_, p_78240_2_);
   }

   // $FF: synthetic method
   public jebac_vexiac14wv2hx3agx(jebac_vexiac14wv2hx3agx textureVertex, float texturePositionXIn, float texturePositionYIn) {
      this.vector3D = textureVertex.vector3D;
      this.texturePositionX = texturePositionXIn;
      this.texturePositionY = texturePositionYIn;
   }
}
