import net.minecraft.util.IProgressUpdate;

public class jebac_vexiamy1bwvs6vmxb extends jebac_vexiakl614w3uw0xg implements IProgressUpdate {
   // $FF: synthetic field
   private String field_146589_f = "";
   // $FF: synthetic field
   private int progress;
   // $FF: synthetic field
   private boolean doneWorking;
   // $FF: synthetic field
   private String field_146591_a = "";

   // $FF: synthetic method
   public void drawScreen(int mouseX, int mouseY, float partialTicks) {
      if (this.doneWorking) {
         this.mc.displayGuiScreen((jebac_vexiakl614w3uw0xg)null);
      } else {
         this.drawDefaultBackground();
         this.drawCenteredString(this.fontRendererObj, this.field_146591_a, this.width / 2, 70, 16777215);
         this.drawCenteredString(this.fontRendererObj, this.field_146589_f + " " + this.progress + "%", this.width / 2, 90, 16777215);
         super.drawScreen(mouseX, mouseY, partialTicks);
      }

   }

   // $FF: synthetic method
   public void setDoneWorking() {
      this.doneWorking = true;
   }

   // $FF: synthetic method
   public void displaySavingString(String message) {
      this.resetProgressAndMessage(message);
   }

   // $FF: synthetic method
   public void resetProgressAndMessage(String message) {
      this.field_146591_a = message;
      this.displayLoadingString("Working...");
   }

   // $FF: synthetic method
   public void setLoadingProgress(int progress) {
      this.progress = progress;
   }

   // $FF: synthetic method
   public void displayLoadingString(String message) {
      this.field_146589_f = message;
      this.setLoadingProgress(0);
   }
}
