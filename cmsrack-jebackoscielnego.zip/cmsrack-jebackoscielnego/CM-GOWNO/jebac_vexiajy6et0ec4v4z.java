import com.google.common.collect.Lists;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.util.IntHashMap;

public class jebac_vexiajy6et0ec4v4z extends jebac_vexiadrxrz0b4x3gp {
   // $FF: synthetic field
   private final List field_178072_w = Lists.newArrayList();
   // $FF: synthetic field
   private final jebac_vexiamee1xbabsk4e[][] field_178078_x;
   // $FF: synthetic field
   private jebac_vexiatghjrcxoegiy field_178076_z;
   // $FF: synthetic field
   private int field_178077_y;
   // $FF: synthetic field
   private final IntHashMap field_178073_v = new IntHashMap();
   // $FF: synthetic field
   private jebac_vexiabhi02xzapwrh field_178075_A;
   // $FF: synthetic field
   private final List field_178074_u = Lists.newArrayList();

   // $FF: synthetic method
   public void func_181155_a(boolean p_181155_1_) {
      Iterator var2 = this.field_178074_u.iterator();

      while(var2.hasNext()) {
         jebac_vexia7nj1i85wxdvv guipagebuttonlist$guientry = (jebac_vexia7nj1i85wxdvv)var2.next();
         if (jebac_vexia7nj1i85wxdvv.access$000(guipagebuttonlist$guientry) instanceof jebac_vexia4oibzo50ubf0) {
            ((jebac_vexia4oibzo50ubf0)jebac_vexia7nj1i85wxdvv.access$000(guipagebuttonlist$guientry)).enabled = p_181155_1_;
         }

         if (jebac_vexia7nj1i85wxdvv.access$100(guipagebuttonlist$guientry) instanceof jebac_vexia4oibzo50ubf0) {
            ((jebac_vexia4oibzo50ubf0)jebac_vexia7nj1i85wxdvv.access$100(guipagebuttonlist$guientry)).enabled = p_181155_1_;
         }
      }

   }

   // $FF: synthetic method
   public jebac_vexia7nj1i85wxdvv getListEntry(int index) {
      return (jebac_vexia7nj1i85wxdvv)this.field_178074_u.get(index);
   }

   // $FF: synthetic method
   public int getSize() {
      return this.field_178074_u.size();
   }

   // $FF: synthetic method
   public void func_181156_c(int p_181156_1_) {
      if (p_181156_1_ != this.field_178077_y) {
         int i = this.field_178077_y;
         this.field_178077_y = p_181156_1_;
         this.func_178055_t();
         this.func_178060_e(i, p_181156_1_);
         this.amountScrolled = 0.0F;
      }

   }

   // $FF: synthetic method
   public void func_178062_a(char p_178062_1_, int p_178062_2_) {
      if (this.field_178075_A instanceof jebac_vexiaa29g8ikthjc5) {
         jebac_vexiaa29g8ikthjc5 guitextfield = (jebac_vexiaa29g8ikthjc5)this.field_178075_A;
         int i1;
         if (!jebac_vexiakl614w3uw0xg.isKeyComboCtrlV(p_178062_2_)) {
            if (p_178062_2_ == 15) {
               guitextfield.setFocused(false);
               int k = this.field_178072_w.indexOf(this.field_178075_A);
               if (jebac_vexiakl614w3uw0xg.isShiftKeyDown()) {
                  if (k == 0) {
                     k = this.field_178072_w.size() - 1;
                  } else {
                     --k;
                  }
               } else if (k == this.field_178072_w.size() - 1) {
                  k = 0;
               } else {
                  ++k;
               }

               this.field_178075_A = (jebac_vexiabhi02xzapwrh)this.field_178072_w.get(k);
               guitextfield = (jebac_vexiaa29g8ikthjc5)this.field_178075_A;
               guitextfield.setFocused(true);
               int l = guitextfield.yPosition + this.slotHeight;
               i1 = guitextfield.yPosition;
               if (l > this.bottom) {
                  this.amountScrolled += (float)(l - this.bottom);
               } else if (i1 < this.top) {
                  this.amountScrolled = (float)i1;
               }
            } else {
               guitextfield.textboxKeyTyped(p_178062_1_, p_178062_2_);
            }
         } else {
            String s = jebac_vexiakl614w3uw0xg.getClipboardString();
            String[] astring = s.split(";");
            i1 = this.field_178072_w.indexOf(this.field_178075_A);
            int j = i1;
            String[] var8 = astring;
            int var9 = astring.length;

            for(int var10 = 0; var10 < var9; ++var10) {
               String s1 = var8[var10];
               ((jebac_vexiaa29g8ikthjc5)this.field_178072_w.get(j)).setText(s1);
               if (j == this.field_178072_w.size() - 1) {
                  j = 0;
               } else {
                  ++j;
               }

               if (j == i1) {
                  break;
               }
            }
         }
      }

   }

   // $FF: synthetic method
   protected int getScrollBarX() {
      return super.getScrollBarX() + 32;
   }

   // $FF: synthetic method
   private jebac_vexia8klesz79u5uq func_178063_a(int p_178063_1_, int p_178063_2_, jebac_vexiaqjl6i4rxan1x p_178063_3_, boolean p_178063_4_) {
      jebac_vexia8klesz79u5uq guilabel;
      if (p_178063_4_) {
         guilabel = new jebac_vexia8klesz79u5uq(this.mc.fontRendererObj, p_178063_3_.func_178935_b(), p_178063_1_, p_178063_2_, this.width - p_178063_1_ * 2, 20, -1);
      } else {
         guilabel = new jebac_vexia8klesz79u5uq(this.mc.fontRendererObj, p_178063_3_.func_178935_b(), p_178063_1_, p_178063_2_, 150, 20, -1);
      }

      guilabel.visible = p_178063_3_.func_178934_d();
      guilabel.func_175202_a(p_178063_3_.func_178936_c());
      guilabel.setCentered();
      return guilabel;
   }

   // $FF: synthetic method
   private void func_178055_t() {
      this.field_178074_u.clear();

      for(int i = 0; i < this.field_178078_x[this.field_178077_y].length; i += 2) {
         jebac_vexiamee1xbabsk4e guipagebuttonlist$guilistentry = this.field_178078_x[this.field_178077_y][i];
         jebac_vexiamee1xbabsk4e guipagebuttonlist$guilistentry1 = i < this.field_178078_x[this.field_178077_y].length - 1 ? this.field_178078_x[this.field_178077_y][i + 1] : null;
         jebac_vexiabhi02xzapwrh gui = (jebac_vexiabhi02xzapwrh)this.field_178073_v.lookup(guipagebuttonlist$guilistentry.func_178935_b());
         jebac_vexiabhi02xzapwrh gui1 = guipagebuttonlist$guilistentry1 != null ? (jebac_vexiabhi02xzapwrh)this.field_178073_v.lookup(guipagebuttonlist$guilistentry1.func_178935_b()) : null;
         jebac_vexia7nj1i85wxdvv guipagebuttonlist$guientry = new jebac_vexia7nj1i85wxdvv(gui, gui1);
         this.field_178074_u.add(guipagebuttonlist$guientry);
      }

   }

   // $FF: synthetic method
   private jebac_vexiaa29g8ikthjc5 func_178068_a(int p_178068_1_, int p_178068_2_, jebac_vexiay4ml4av3j3n0 p_178068_3_) {
      jebac_vexiaa29g8ikthjc5 guitextfield = new jebac_vexiaa29g8ikthjc5(p_178068_3_.func_178935_b(), this.mc.fontRendererObj, p_178068_1_, p_178068_2_, 150, 20);
      guitextfield.setText(p_178068_3_.func_178936_c());
      guitextfield.func_175207_a(this.field_178076_z);
      guitextfield.setVisible(p_178068_3_.func_178934_d());
      guitextfield.func_175205_a(p_178068_3_.func_178950_a());
      return guitextfield;
   }

   // $FF: synthetic method
   private void func_178066_a(jebac_vexiabhi02xzapwrh p_178066_1_, boolean p_178066_2_) {
      if (p_178066_1_ instanceof jebac_vexia4oibzo50ubf0) {
         ((jebac_vexia4oibzo50ubf0)p_178066_1_).visible = p_178066_2_;
      } else if (p_178066_1_ instanceof jebac_vexiaa29g8ikthjc5) {
         ((jebac_vexiaa29g8ikthjc5)p_178066_1_).setVisible(p_178066_2_);
      } else if (p_178066_1_ instanceof jebac_vexia8klesz79u5uq) {
         ((jebac_vexia8klesz79u5uq)p_178066_1_).visible = p_178066_2_;
      }

   }

   // $FF: synthetic method
   public void func_178071_h() {
      if (this.field_178077_y > 0) {
         this.func_181156_c(this.field_178077_y - 1);
      }

   }

   // $FF: synthetic method
   private void func_178069_s() {
      jebac_vexiamee1xbabsk4e[][] var1 = this.field_178078_x;
      int var2 = var1.length;

      for(int var3 = 0; var3 < var2; ++var3) {
         jebac_vexiamee1xbabsk4e[] aguipagebuttonlist$guilistentry = var1[var3];

         for(int i = 0; i < aguipagebuttonlist$guilistentry.length; i += 2) {
            jebac_vexiamee1xbabsk4e guipagebuttonlist$guilistentry = aguipagebuttonlist$guilistentry[i];
            jebac_vexiamee1xbabsk4e guipagebuttonlist$guilistentry1 = i < aguipagebuttonlist$guilistentry.length - 1 ? aguipagebuttonlist$guilistentry[i + 1] : null;
            jebac_vexiabhi02xzapwrh gui = this.func_178058_a(guipagebuttonlist$guilistentry, 0, guipagebuttonlist$guilistentry1 == null);
            jebac_vexiabhi02xzapwrh gui1 = this.func_178058_a(guipagebuttonlist$guilistentry1, 160, guipagebuttonlist$guilistentry == null);
            jebac_vexia7nj1i85wxdvv guipagebuttonlist$guientry = new jebac_vexia7nj1i85wxdvv(gui, gui1);
            this.field_178074_u.add(guipagebuttonlist$guientry);
            if (guipagebuttonlist$guilistentry != null && gui != null) {
               this.field_178073_v.addKey(guipagebuttonlist$guilistentry.func_178935_b(), gui);
               if (gui instanceof jebac_vexiaa29g8ikthjc5) {
                  this.field_178072_w.add((jebac_vexiaa29g8ikthjc5)gui);
               }
            }

            if (guipagebuttonlist$guilistentry1 != null && gui1 != null) {
               this.field_178073_v.addKey(guipagebuttonlist$guilistentry1.func_178935_b(), gui1);
               if (gui1 instanceof jebac_vexiaa29g8ikthjc5) {
                  this.field_178072_w.add((jebac_vexiaa29g8ikthjc5)gui1);
               }
            }
         }
      }

   }

   // $FF: synthetic method
   public int func_178059_e() {
      return this.field_178077_y;
   }

   // $FF: synthetic method
   public jebac_vexiabhi02xzapwrh func_178056_g() {
      return this.field_178075_A;
   }

   // $FF: synthetic method
   public jebac_vexiabhi02xzapwrh func_178061_c(int p_178061_1_) {
      return (jebac_vexiabhi02xzapwrh)this.field_178073_v.lookup(p_178061_1_);
   }

   // $FF: synthetic method
   public boolean mouseClicked(int mouseX, int mouseY, int mouseEvent) {
      boolean flag = super.mouseClicked(mouseX, mouseY, mouseEvent);
      int i = this.getSlotIndexFromScreenCoords(mouseX, mouseY);
      if (i >= 0) {
         jebac_vexia7nj1i85wxdvv guipagebuttonlist$guientry = this.getListEntry(i);
         if (this.field_178075_A != jebac_vexia7nj1i85wxdvv.access$200(guipagebuttonlist$guientry) && this.field_178075_A != null && this.field_178075_A instanceof jebac_vexiaa29g8ikthjc5) {
            ((jebac_vexiaa29g8ikthjc5)this.field_178075_A).setFocused(false);
         }

         this.field_178075_A = jebac_vexia7nj1i85wxdvv.access$200(guipagebuttonlist$guientry);
      }

      return flag;
   }

   // $FF: synthetic method
   private jebac_vexiaiui810ba7biw func_178067_a(int p_178067_1_, int p_178067_2_, jebac_vexiawvw4ko3v0xar p_178067_3_) {
      jebac_vexiaiui810ba7biw guislider = new jebac_vexiaiui810ba7biw(this.field_178076_z, p_178067_3_.func_178935_b(), p_178067_1_, p_178067_2_, p_178067_3_.func_178936_c(), p_178067_3_.func_178943_e(), p_178067_3_.func_178944_f(), p_178067_3_.func_178942_g(), p_178067_3_.func_178945_a());
      guislider.visible = p_178067_3_.func_178934_d();
      return guislider;
   }

   // $FF: synthetic method
   private jebac_vexia98jsdrfcbi94 func_178065_a(int p_178065_1_, int p_178065_2_, jebac_vexiaahfk36d5geld p_178065_3_) {
      jebac_vexia98jsdrfcbi94 guilistbutton = new jebac_vexia98jsdrfcbi94(this.field_178076_z, p_178065_3_.func_178935_b(), p_178065_1_, p_178065_2_, p_178065_3_.func_178936_c(), p_178065_3_.func_178940_a());
      guilistbutton.visible = p_178065_3_.func_178934_d();
      return guilistbutton;
   }

   // $FF: synthetic method
   private jebac_vexiabhi02xzapwrh func_178058_a(jebac_vexiamee1xbabsk4e p_178058_1_, int p_178058_2_, boolean p_178058_3_) {
      return (jebac_vexiabhi02xzapwrh)(p_178058_1_ instanceof jebac_vexiawvw4ko3v0xar ? this.func_178067_a(this.width / 2 - 155 + p_178058_2_, 0, (jebac_vexiawvw4ko3v0xar)p_178058_1_) : (p_178058_1_ instanceof jebac_vexiaahfk36d5geld ? this.func_178065_a(this.width / 2 - 155 + p_178058_2_, 0, (jebac_vexiaahfk36d5geld)p_178058_1_) : (p_178058_1_ instanceof jebac_vexiay4ml4av3j3n0 ? this.func_178068_a(this.width / 2 - 155 + p_178058_2_, 0, (jebac_vexiay4ml4av3j3n0)p_178058_1_) : (p_178058_1_ instanceof jebac_vexiaqjl6i4rxan1x ? this.func_178063_a(this.width / 2 - 155 + p_178058_2_, 0, (jebac_vexiaqjl6i4rxan1x)p_178058_1_, p_178058_3_) : null))));
   }

   // $FF: synthetic method
   public int func_178057_f() {
      return this.field_178078_x.length;
   }

   // $FF: synthetic method
   public void func_178064_i() {
      if (this.field_178077_y < this.field_178078_x.length - 1) {
         this.func_181156_c(this.field_178077_y + 1);
      }

   }

   // $FF: synthetic method
   public jebac_vexiajy6et0ec4v4z(Minecraft mcIn, int widthIn, int heightIn, int topIn, int bottomIn, int slotHeightIn, jebac_vexiatghjrcxoegiy p_i45536_7_, jebac_vexiamee1xbabsk4e[]... p_i45536_8_) {
      super(mcIn, widthIn, heightIn, topIn, bottomIn, slotHeightIn);
      this.field_178076_z = p_i45536_7_;
      this.field_178078_x = p_i45536_8_;
      this.field_148163_i = false;
      this.func_178069_s();
      this.func_178055_t();
   }

   // $FF: synthetic method
   public int getListWidth() {
      return 400;
   }

   // $FF: synthetic method
   private void func_178060_e(int p_178060_1_, int p_178060_2_) {
      jebac_vexiamee1xbabsk4e[] var3 = this.field_178078_x[p_178060_1_];
      int var4 = var3.length;

      int var5;
      jebac_vexiamee1xbabsk4e guipagebuttonlist$guilistentry1;
      for(var5 = 0; var5 < var4; ++var5) {
         guipagebuttonlist$guilistentry1 = var3[var5];
         if (guipagebuttonlist$guilistentry1 != null) {
            this.func_178066_a((jebac_vexiabhi02xzapwrh)this.field_178073_v.lookup(guipagebuttonlist$guilistentry1.func_178935_b()), false);
         }
      }

      var3 = this.field_178078_x[p_178060_2_];
      var4 = var3.length;

      for(var5 = 0; var5 < var4; ++var5) {
         guipagebuttonlist$guilistentry1 = var3[var5];
         if (guipagebuttonlist$guilistentry1 != null) {
            this.func_178066_a((jebac_vexiabhi02xzapwrh)this.field_178073_v.lookup(guipagebuttonlist$guilistentry1.func_178935_b()), true);
         }
      }

   }
}
