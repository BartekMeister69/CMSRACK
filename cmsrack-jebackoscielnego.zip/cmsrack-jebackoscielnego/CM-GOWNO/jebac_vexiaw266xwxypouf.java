import java.io.IOException;
import net.minecraft.client.resources.I18n;

public class jebac_vexiaw266xwxypouf extends jebac_vexianjbtt6en4mmt {
   // $FF: synthetic field
   private final String linkText;
   // $FF: synthetic field
   private final String copyLinkButtonText;
   // $FF: synthetic field
   private boolean showSecurityWarning = true;
   // $FF: synthetic field
   private final String openLinkWarning;

   // $FF: synthetic method
   public void copyLinkToClipboard() {
      setClipboardString(this.linkText);
   }

   // $FF: synthetic method
   protected void actionPerformed(jebac_vexia4oibzo50ubf0 button) throws IOException {
      if (button.id == 2) {
         this.copyLinkToClipboard();
      }

      this.parentScreen.confirmClicked(button.id == 0, this.parentButtonClickedId);
   }

   // $FF: synthetic method
   public jebac_vexiaw266xwxypouf(jebac_vexiaa9gjo3qagx3k p_i1084_1_, String linkTextIn, int p_i1084_3_, boolean p_i1084_4_) {
      super(p_i1084_1_, I18n.format(p_i1084_4_ ? "chat.link.confirmTrusted" : "chat.link.confirm"), linkTextIn, p_i1084_3_);
      this.confirmButtonText = I18n.format(p_i1084_4_ ? "chat.link.open" : "gui.yes");
      this.cancelButtonText = I18n.format(p_i1084_4_ ? "gui.cancel" : "gui.no");
      this.copyLinkButtonText = I18n.format("chat.copy");
      this.openLinkWarning = I18n.format("chat.link.warning");
      this.linkText = linkTextIn;
   }

   // $FF: synthetic method
   public void drawScreen(int mouseX, int mouseY, float partialTicks) {
      super.drawScreen(mouseX, mouseY, partialTicks);
      if (this.showSecurityWarning) {
         this.drawCenteredString(this.fontRendererObj, this.openLinkWarning, this.width / 2, 110, 16764108);
      }

   }

   // $FF: synthetic method
   public void initGui() {
      super.initGui();
      this.buttonList.clear();
      this.buttonList.add(new jebac_vexia4oibzo50ubf0(0, this.width / 2 - 50 - 105, this.height / 6 + 96, 100, 20, this.confirmButtonText));
      this.buttonList.add(new jebac_vexia4oibzo50ubf0(2, this.width / 2 - 50, this.height / 6 + 96, 100, 20, this.copyLinkButtonText));
      this.buttonList.add(new jebac_vexia4oibzo50ubf0(1, this.width / 2 - 50 + 105, this.height / 6 + 96, 100, 20, this.cancelButtonText));
   }

   // $FF: synthetic method
   public void disableSecurityWarning() {
      this.showSecurityWarning = false;
   }
}
