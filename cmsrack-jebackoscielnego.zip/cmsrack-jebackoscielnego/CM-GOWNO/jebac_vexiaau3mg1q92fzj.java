import net.minecraft.client.Minecraft;

public class jebac_vexiaau3mg1q92fzj extends jebac_vexia1v9udehroezu {
   public static jebac_vexia7k1fepxln7md  dz;
   public static jebac_vexia5c4je8aazc78  ea;
   public static jebac_vexiaffroustvvf49  dy;
   public static jebac_vexiawjtwglazxj7a  eb;

   // $FF: synthetic method
   public void renderGameOverlay(float var1) {
      super.renderGameOverlay(var1);
      if (lIIIIIlll(jebac_vexiawzpzy1x3sez8. bl)) {
          dy.render();
      }

      if (lIIIIIlll(jebac_vexiawzpzy1x3sez8. by)) {
         jebac_vexiaau3mg1q92fzj var2 = new jebac_vexiakl8zv2fyoaq8(Minecraft.getMinecraft());
          ea.drawCompass(var2.getScaledWidth());
      }

      if (lIIIIIlll(jebac_vexiawzpzy1x3sez8. bz)) {
          eb.render();
      }

   }

   // $FF: synthetic method
   private static boolean lIIIIIlll(int var0) {
      return var0 != 0;
   }

   // $FF: synthetic method
   public jebac_vexiaau3mg1q92fzj(Minecraft var1) {
      super(var1);
       ea = new jebac_vexia5c4je8aazc78(var1);
       dy = new jebac_vexiaffroustvvf49(var1);
       eb = new jebac_vexiawjtwglazxj7a(var1);
       dz = new jebac_vexia7k1fepxln7md(var1);
      jebac_vexia67ba3dligh23.load();
   }
}
