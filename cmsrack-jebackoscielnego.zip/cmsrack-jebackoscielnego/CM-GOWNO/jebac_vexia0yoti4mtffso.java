import net.minecraft.util.BlockPos;
import net.minecraft.world.IBlockAccess;

public interface jebac_vexia0yoti4mtffso {
   // $FF: synthetic method
   int getColor(IBlockAccess var1, BlockPos var2);

   // $FF: synthetic method
   boolean isColorConstant();
}
