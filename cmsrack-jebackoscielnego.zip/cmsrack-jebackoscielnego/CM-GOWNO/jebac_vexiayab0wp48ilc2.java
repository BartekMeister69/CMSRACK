import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import net.minecraft.block.properties.IProperty;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.biome.BiomeGenBase;

public class jebac_vexiayab0wp48ilc2 {
   // $FF: synthetic field
   public int[] metadatas = null;
   // $FF: synthetic field
   public String name = null;
   // $FF: synthetic field
   public int height = 0;
   // $FF: synthetic field
   public int symmetry = 1;
   // $FF: synthetic field
   public int minHeight = 0;
   // $FF: synthetic field
   public BiomeGenBase[] biomes = null;
   // $FF: synthetic field
   public TextureAtlasSprite[] tileIcons = null;
   // $FF: synthetic field
   public int maxHeight = 1024;
   // $FF: synthetic field
   public String basePath = null;
   // $FF: synthetic field
   public int[] weights = null;
   // $FF: synthetic field
   public int renderPass = 0;
   // $FF: synthetic field
   public int[] sumWeights = null;
   // $FF: synthetic field
   public int sumAllWeights = 1;
   // $FF: synthetic field
   public int width = 0;
   // $FF: synthetic field
   public TextureAtlasSprite[] matchTileIcons = null;
   // $FF: synthetic field
   public int method = 0;
   // $FF: synthetic field
   public boolean innerSeams = false;
   // $FF: synthetic field
   public jebac_vexia2nnti3ppoopl[] matchBlocks = null;
   // $FF: synthetic field
   public int connect = 0;
   // $FF: synthetic field
   public String[] tiles = null;
   // $FF: synthetic field
   public String[] matchTiles = null;
   // $FF: synthetic field
   public int faces = 63;

   // $FF: synthetic method
   private String[] detectMatchTiles() {
      TextureAtlasSprite textureatlassprite = getIcon(this.name);
      return textureatlassprite == null ? null : new String[]{this.name};
   }

   // $FF: synthetic method
   private boolean isValidRandom(String p_isValidRandom_1_) {
      if (this.tiles != null && this.tiles.length > 0) {
         if (this.weights != null) {
            int[] aint1;
            if (this.weights.length > this.tiles.length) {
               jebac_vexiakrwecfs16wve.warn("More weights defined than tiles, trimming weights: " + p_isValidRandom_1_);
               aint1 = new int[this.tiles.length];
               System.arraycopy(this.weights, 0, aint1, 0, aint1.length);
               this.weights = aint1;
            }

            int l;
            if (this.weights.length < this.tiles.length) {
               jebac_vexiakrwecfs16wve.warn("Less weights defined than tiles, expanding weights: " + p_isValidRandom_1_);
               aint1 = new int[this.tiles.length];
               System.arraycopy(this.weights, 0, aint1, 0, this.weights.length);
               l = jebac_vexiasjtxkx13x4pe.getAverage(this.weights);

               for(int j = this.weights.length; j < aint1.length; ++j) {
                  aint1[j] = l;
               }

               this.weights = aint1;
            }

            this.sumWeights = new int[this.weights.length];
            int k = 0;

            for(l = 0; l < this.weights.length; ++l) {
               k += this.weights[l];
               this.sumWeights[l] = k;
            }

            this.sumAllWeights = k;
            if (this.sumAllWeights <= 0) {
               jebac_vexiakrwecfs16wve.warn("Invalid sum of all weights: " + k);
               this.sumAllWeights = 1;
            }
         }

         return true;
      } else {
         jebac_vexiakrwecfs16wve.warn("Tiles not defined: " + p_isValidRandom_1_);
         return false;
      }
   }

   // $FF: synthetic method
   private String[] parseTileNames(String p_parseTileNames_1_) {
      if (p_parseTileNames_1_ == null) {
         return null;
      } else {
         List list = new ArrayList();
         String[] astring = jebac_vexiakrwecfs16wve.tokenize(p_parseTileNames_1_, " ,");
         String[] astring2 = astring;
         int i1 = astring.length;

         String s2;
         label65:
         for(int var6 = 0; var6 < i1; ++var6) {
            s2 = astring2[var6];
            if (s2.contains("-")) {
               String[] astring1 = jebac_vexiakrwecfs16wve.tokenize(s2, "-");
               if (astring1.length == 2) {
                  int j = jebac_vexiakrwecfs16wve.parseInt(astring1[0], -1);
                  int k = jebac_vexiakrwecfs16wve.parseInt(astring1[1], -1);
                  if (j >= 0 && k >= 0) {
                     if (j > k) {
                        jebac_vexiakrwecfs16wve.warn("Invalid interval: " + s2 + ", when parsing: " + p_parseTileNames_1_);
                        continue;
                     }

                     int l = j;

                     while(true) {
                        if (l > k) {
                           continue label65;
                        }

                        list.add(String.valueOf(l));
                        ++l;
                     }
                  }
               }
            }

            list.add(s2);
         }

         astring2 = (String[])((String[])list.toArray(new String[0]));

         for(i1 = 0; i1 < astring2.length; ++i1) {
            String s1 = astring2[i1];
            s1 = jebac_vexiamg04e8zzk81s.fixResourcePath(s1, this.basePath);
            if (!s1.startsWith(this.basePath) && !s1.startsWith("textures/") && !s1.startsWith("mcpatcher/")) {
               s1 = this.basePath + "/" + s1;
            }

            if (s1.endsWith(".png")) {
               s1 = s1.substring(0, s1.length() - 4);
            }

            s2 = "textures/blocks/";
            if (s1.startsWith(s2)) {
               s1 = s1.substring(s2.length());
            }

            if (s1.startsWith("/")) {
               s1 = s1.substring(1);
            }

            astring2[i1] = s1;
         }

         return astring2;
      }
   }

   // $FF: synthetic method
   public static IProperty getProperty(String p_getProperty_0_, Collection p_getProperty_1_) {
      Iterator var2 = p_getProperty_1_.iterator();

      Object iproperty;
      do {
         if (!var2.hasNext()) {
            return null;
         }

         iproperty = var2.next();
      } while(!p_getProperty_0_.equals(((IProperty)iproperty).getName()));

      return (IProperty)iproperty;
   }

   // $FF: synthetic method
   public boolean matchesBlockId(int p_matchesBlockId_1_) {
      return jebac_vexiazz7bslggeoy9.blockId(p_matchesBlockId_1_, this.matchBlocks);
   }

   // $FF: synthetic method
   private static int parseFace(String p_parseFace_0_) {
      p_parseFace_0_ = p_parseFace_0_.toLowerCase();
      if (!p_parseFace_0_.equals("bottom") && !p_parseFace_0_.equals("down")) {
         if (!p_parseFace_0_.equals("top") && !p_parseFace_0_.equals("up")) {
            byte var2 = -1;
            switch(p_parseFace_0_.hashCode()) {
            case 96673:
               if (p_parseFace_0_.equals("all")) {
                  var2 = 5;
               }
               break;
            case 3105789:
               if (p_parseFace_0_.equals("east")) {
                  var2 = 2;
               }
               break;
            case 3645871:
               if (p_parseFace_0_.equals("west")) {
                  var2 = 3;
               }
               break;
            case 105007365:
               if (p_parseFace_0_.equals("north")) {
                  var2 = 0;
               }
               break;
            case 109432316:
               if (p_parseFace_0_.equals("sides")) {
                  var2 = 4;
               }
               break;
            case 109627853:
               if (p_parseFace_0_.equals("south")) {
                  var2 = 1;
               }
            }

            switch(var2) {
            case 0:
               return 4;
            case 1:
               return 8;
            case 2:
               return 32;
            case 3:
               return 16;
            case 4:
               return 60;
            case 5:
               return 63;
            default:
               jebac_vexiakrwecfs16wve.warn("Unknown face: " + p_parseFace_0_);
               return 128;
            }
         } else {
            return 2;
         }
      } else {
         return 1;
      }
   }

   // $FF: synthetic method
   private boolean isValidVerticalHorizontal(String p_isValidVerticalHorizontal_1_) {
      if (this.tiles == null) {
         jebac_vexiakrwecfs16wve.warn("No tiles defined for vertical+horizontal: " + p_isValidVerticalHorizontal_1_);
         return false;
      } else if (this.tiles.length != 7) {
         jebac_vexiakrwecfs16wve.warn("Invalid tiles, must be exactly 7: " + p_isValidVerticalHorizontal_1_);
         return false;
      } else {
         return true;
      }
   }

   // $FF: synthetic method
   private boolean isValidFixed(String p_isValidFixed_1_) {
      if (this.tiles == null) {
         jebac_vexiakrwecfs16wve.warn("Tiles not defined: " + p_isValidFixed_1_);
         return false;
      } else if (this.tiles.length != 1) {
         jebac_vexiakrwecfs16wve.warn("Number of tiles should be 1 for method: fixed.");
         return false;
      } else {
         return true;
      }
   }

   // $FF: synthetic method
   public void updateIcons(TextureMap p_updateIcons_1_) {
      if (this.matchTiles != null) {
         this.matchTileIcons = registerIcons(this.matchTiles, p_updateIcons_1_);
      }

      if (this.tiles != null) {
         this.tileIcons = registerIcons(this.tiles, p_updateIcons_1_);
      }

   }

   // $FF: synthetic method
   private static int parseFaces(String p_parseFaces_0_) {
      if (p_parseFaces_0_ == null) {
         return 63;
      } else {
         String[] astring = jebac_vexiakrwecfs16wve.tokenize(p_parseFaces_0_, " ,");
         int i = 0;
         String[] var3 = astring;
         int var4 = astring.length;

         for(int var5 = 0; var5 < var4; ++var5) {
            String s = var3[var5];
            int k = parseFace(s);
            i |= k;
         }

         return i;
      }
   }

   // $FF: synthetic method
   private int detectConnect() {
      return this.matchBlocks != null ? 1 : (this.matchTiles != null ? 2 : 128);
   }

   // $FF: synthetic method
   private boolean isValidHorizontal(String p_isValidHorizontal_1_) {
      if (this.tiles == null) {
         this.tiles = this.parseTileNames("12-15");
      }

      if (this.tiles.length != 4) {
         jebac_vexiakrwecfs16wve.warn("Invalid tiles, must be exactly 4: " + p_isValidHorizontal_1_);
         return false;
      } else {
         return true;
      }
   }

   // $FF: synthetic method
   public boolean matchesIcon(TextureAtlasSprite p_matchesIcon_1_) {
      return jebac_vexiazz7bslggeoy9.sprite(p_matchesIcon_1_, this.matchTileIcons);
   }

   // $FF: synthetic method
   private static TextureAtlasSprite getIcon(String p_getIcon_0_) {
      TextureMap texturemap = Minecraft.getMinecraft().getTextureMapBlocks();
      TextureAtlasSprite textureatlassprite = texturemap.getSpriteSafe(p_getIcon_0_);
      if (textureatlassprite != null) {
         return textureatlassprite;
      } else {
         textureatlassprite = texturemap.getSpriteSafe("blocks/" + p_getIcon_0_);
         return textureatlassprite;
      }
   }

   // $FF: synthetic method
   private int getMax(int[] p_getMax_1_, int p_getMax_2_) {
      if (p_getMax_1_ == null) {
         return p_getMax_2_;
      } else {
         int[] var3 = p_getMax_1_;
         int var4 = p_getMax_1_.length;

         for(int var5 = 0; var5 < var4; ++var5) {
            int j = var3[var5];
            if (j > p_getMax_2_) {
               p_getMax_2_ = j;
            }
         }

         return p_getMax_2_;
      }
   }

   // $FF: synthetic method
   private String[] parseMatchTiles(String p_parseMatchTiles_1_) {
      if (p_parseMatchTiles_1_ == null) {
         return null;
      } else {
         String[] astring = jebac_vexiakrwecfs16wve.tokenize(p_parseMatchTiles_1_, " ");

         for(int i = 0; i < astring.length; ++i) {
            String s = astring[i];
            if (s.endsWith(".png")) {
               s = s.substring(0, s.length() - 4);
            }

            s = jebac_vexiamg04e8zzk81s.fixResourcePath(s, this.basePath);
            astring[i] = s;
         }

         return astring;
      }
   }

   // $FF: synthetic method
   private static int parseMethod(String p_parseMethod_0_) {
      if (p_parseMethod_0_ == null) {
         return 1;
      } else if (!p_parseMethod_0_.equals("ctm") && !p_parseMethod_0_.equals("glass")) {
         if (!p_parseMethod_0_.equals("horizontal") && !p_parseMethod_0_.equals("bookshelf")) {
            if (p_parseMethod_0_.equals("vertical")) {
               return 6;
            } else if (p_parseMethod_0_.equals("top")) {
               return 3;
            } else if (p_parseMethod_0_.equals("random")) {
               return 4;
            } else if (p_parseMethod_0_.equals("repeat")) {
               return 5;
            } else if (p_parseMethod_0_.equals("fixed")) {
               return 7;
            } else if (!p_parseMethod_0_.equals("horizontal+vertical") && !p_parseMethod_0_.equals("h+v")) {
               if (!p_parseMethod_0_.equals("vertical+horizontal") && !p_parseMethod_0_.equals("v+h")) {
                  jebac_vexiakrwecfs16wve.warn("Unknown method: " + p_parseMethod_0_);
                  return 0;
               } else {
                  return 9;
               }
            } else {
               return 8;
            }
         } else {
            return 2;
         }
      } else {
         return 1;
      }
   }

   // $FF: synthetic method
   private boolean isValidHorizontalVertical(String p_isValidHorizontalVertical_1_) {
      if (this.tiles == null) {
         jebac_vexiakrwecfs16wve.warn("No tiles defined for horizontal+vertical: " + p_isValidHorizontalVertical_1_);
         return false;
      } else if (this.tiles.length != 7) {
         jebac_vexiakrwecfs16wve.warn("Invalid tiles, must be exactly 7: " + p_isValidHorizontalVertical_1_);
         return false;
      } else {
         return true;
      }
   }

   // $FF: synthetic method
   private boolean isValidVertical(String p_isValidVertical_1_) {
      if (this.tiles == null) {
         jebac_vexiakrwecfs16wve.warn("No tiles defined for vertical: " + p_isValidVertical_1_);
         return false;
      } else if (this.tiles.length != 4) {
         jebac_vexiakrwecfs16wve.warn("Invalid tiles, must be exactly 4: " + p_isValidVertical_1_);
         return false;
      } else {
         return true;
      }
   }

   // $FF: synthetic method
   private static int parseConnect(String p_parseConnect_0_) {
      if (p_parseConnect_0_ == null) {
         return 0;
      } else if (p_parseConnect_0_.equals("block")) {
         return 1;
      } else if (p_parseConnect_0_.equals("tile")) {
         return 2;
      } else if (p_parseConnect_0_.equals("material")) {
         return 3;
      } else {
         jebac_vexiakrwecfs16wve.warn("Unknown connect: " + p_parseConnect_0_);
         return 128;
      }
   }

   // $FF: synthetic method
   public boolean matchesBiome(BiomeGenBase p_matchesBiome_1_) {
      return jebac_vexiazz7bslggeoy9.biome(p_matchesBiome_1_, this.biomes);
   }

   // $FF: synthetic method
   private boolean isValidRepeat(String p_isValidRepeat_1_) {
      if (this.tiles == null) {
         jebac_vexiakrwecfs16wve.warn("Tiles not defined: " + p_isValidRepeat_1_);
         return false;
      } else if (this.width > 0 && this.width <= 16) {
         if (this.height > 0 && this.height <= 16) {
            if (this.tiles.length != this.width * this.height) {
               jebac_vexiakrwecfs16wve.warn("Number of tiles does not equal width x height: " + p_isValidRepeat_1_);
               return false;
            } else {
               return true;
            }
         } else {
            jebac_vexiakrwecfs16wve.warn("Invalid height: " + p_isValidRepeat_1_);
            return false;
         }
      } else {
         jebac_vexiakrwecfs16wve.warn("Invalid width: " + p_isValidRepeat_1_);
         return false;
      }
   }

   // $FF: synthetic method
   public boolean isValid(String p_isValid_1_) {
      if (this.name != null && this.name.length() > 0) {
         if (this.basePath == null) {
            jebac_vexiakrwecfs16wve.warn("No base path found: " + p_isValid_1_);
            return false;
         } else {
            if (this.matchBlocks == null) {
               this.matchBlocks = this.detectMatchBlocks();
            }

            if (this.matchTiles == null && this.matchBlocks == null) {
               this.matchTiles = this.detectMatchTiles();
            }

            if (this.matchBlocks == null && this.matchTiles == null) {
               jebac_vexiakrwecfs16wve.warn("No matchBlocks or matchTiles specified: " + p_isValid_1_);
               return false;
            } else if (this.method == 0) {
               jebac_vexiakrwecfs16wve.warn("No method: " + p_isValid_1_);
               return false;
            } else if (this.tiles != null && this.tiles.length > 0) {
               if (this.connect == 0) {
                  this.connect = this.detectConnect();
               }

               if (this.connect == 128) {
                  jebac_vexiakrwecfs16wve.warn("Invalid connect in: " + p_isValid_1_);
                  return false;
               } else if (this.renderPass > 0) {
                  jebac_vexiakrwecfs16wve.warn("Render pass not supported: " + this.renderPass);
                  return false;
               } else if ((this.faces & 128) != 0) {
                  jebac_vexiakrwecfs16wve.warn("Invalid faces in: " + p_isValid_1_);
                  return false;
               } else if ((this.symmetry & 128) != 0) {
                  jebac_vexiakrwecfs16wve.warn("Invalid symmetry in: " + p_isValid_1_);
                  return false;
               } else {
                  switch(this.method) {
                  case 1:
                     return this.isValidCtm(p_isValid_1_);
                  case 2:
                     return this.isValidHorizontal(p_isValid_1_);
                  case 3:
                     return this.isValidTop(p_isValid_1_);
                  case 4:
                     return this.isValidRandom(p_isValid_1_);
                  case 5:
                     return this.isValidRepeat(p_isValid_1_);
                  case 6:
                     return this.isValidVertical(p_isValid_1_);
                  case 7:
                     return this.isValidFixed(p_isValid_1_);
                  case 8:
                     return this.isValidHorizontalVertical(p_isValid_1_);
                  case 9:
                     return this.isValidVerticalHorizontal(p_isValid_1_);
                  default:
                     jebac_vexiakrwecfs16wve.warn("Unknown method: " + p_isValid_1_);
                     return false;
                  }
               }
            } else {
               jebac_vexiakrwecfs16wve.warn("No tiles specified: " + p_isValid_1_);
               return false;
            }
         }
      } else {
         jebac_vexiakrwecfs16wve.warn("No name found: " + p_isValid_1_);
         return false;
      }
   }

   // $FF: synthetic method
   private boolean isValidTop(String p_isValidTop_1_) {
      if (this.tiles == null) {
         this.tiles = this.parseTileNames("66");
      }

      if (this.tiles.length != 1) {
         jebac_vexiakrwecfs16wve.warn("Invalid tiles, must be exactly 1: " + p_isValidTop_1_);
         return false;
      } else {
         return true;
      }
   }

   // $FF: synthetic method
   public jebac_vexiayab0wp48ilc2(Properties p_i32_1_, String p_i32_2_) {
      jebac_vexiadw49qo6dh8al connectedparser = new jebac_vexiadw49qo6dh8al("ConnectedTextures");
      this.name = connectedparser.parseName(p_i32_2_);
      this.basePath = connectedparser.parseBasePath(p_i32_2_);
      this.matchBlocks = connectedparser.parseMatchBlocks(p_i32_1_.getProperty("matchBlocks"));
      this.metadatas = connectedparser.parseIntList(p_i32_1_.getProperty("metadata"));
      this.matchTiles = this.parseMatchTiles(p_i32_1_.getProperty("matchTiles"));
      this.method = parseMethod(p_i32_1_.getProperty("method"));
      this.tiles = this.parseTileNames(p_i32_1_.getProperty("tiles"));
      this.connect = parseConnect(p_i32_1_.getProperty("connect"));
      this.faces = parseFaces(p_i32_1_.getProperty("faces"));
      this.biomes = connectedparser.parseBiomes(p_i32_1_.getProperty("biomes"));
      this.minHeight = connectedparser.parseInt(p_i32_1_.getProperty("minHeight"), -1);
      this.maxHeight = connectedparser.parseInt(p_i32_1_.getProperty("maxHeight"), 1024);
      this.renderPass = connectedparser.parseInt(p_i32_1_.getProperty("renderPass"));
      this.innerSeams = jebac_vexiadw49qo6dh8al.parseBoolean(p_i32_1_.getProperty("innerSeams"));
      this.width = connectedparser.parseInt(p_i32_1_.getProperty("width"));
      this.height = connectedparser.parseInt(p_i32_1_.getProperty("height"));
      this.weights = connectedparser.parseIntList(p_i32_1_.getProperty("weights"));
      this.symmetry = parseSymmetry(p_i32_1_.getProperty("symmetry"));
   }

   // $FF: synthetic method
   private int[] detectMatchBlockIds() {
      if (!this.name.startsWith("block")) {
         return null;
      } else {
         int i = "block".length();

         int j;
         for(j = i; j < this.name.length(); ++j) {
            char c0 = this.name.charAt(j);
            if (c0 < '0' || c0 > '9') {
               break;
            }
         }

         if (j == i) {
            return null;
         } else {
            String s = this.name.substring(i, j);
            int k = jebac_vexiakrwecfs16wve.parseInt(s, -1);
            return k < 0 ? null : new int[]{k};
         }
      }
   }

   // $FF: synthetic method
   public boolean matchesBlock(int p_matchesBlock_1_, int p_matchesBlock_2_) {
      return jebac_vexiazz7bslggeoy9.block(p_matchesBlock_1_, p_matchesBlock_2_, this.matchBlocks) && jebac_vexiazz7bslggeoy9.metadata(p_matchesBlock_2_, this.metadatas);
   }

   // $FF: synthetic method
   private static TextureAtlasSprite[] registerIcons(String[] p_registerIcons_0_, TextureMap p_registerIcons_1_) {
      if (p_registerIcons_0_ == null) {
         return null;
      } else {
         List list = new ArrayList();
         String[] var3 = p_registerIcons_0_;
         int var4 = p_registerIcons_0_.length;

         for(int var5 = 0; var5 < var4; ++var5) {
            String s = var3[var5];
            ResourceLocation resourcelocation = new ResourceLocation(s);
            String s1 = resourcelocation.getResourceDomain();
            String s2 = resourcelocation.getResourcePath();
            if (!s2.contains("/")) {
               s2 = "textures/blocks/" + s2;
            }

            String s3 = s2 + ".png";
            ResourceLocation resourcelocation1 = new ResourceLocation(s1, s3);
            boolean flag = jebac_vexiakrwecfs16wve.hasResource(resourcelocation1);
            if (!flag) {
               jebac_vexiakrwecfs16wve.warn("File not found: " + s3);
            }

            String s4 = "textures/";
            String s5 = s2;
            if (s2.startsWith(s4)) {
               s5 = s2.substring(s4.length());
            }

            ResourceLocation resourcelocation2 = new ResourceLocation(s1, s5);
            TextureAtlasSprite textureatlassprite = p_registerIcons_1_.registerSprite(resourcelocation2);
            list.add(textureatlassprite);
         }

         return (TextureAtlasSprite[])((TextureAtlasSprite[])list.toArray(new TextureAtlasSprite[0]));
      }
   }

   // $FF: synthetic method
   private boolean isValidCtm(String p_isValidCtm_1_) {
      if (this.tiles == null) {
         this.tiles = this.parseTileNames("0-11 16-27 32-43 48-58");
      }

      if (this.tiles.length < 47) {
         jebac_vexiakrwecfs16wve.warn("Invalid tiles, must be at least 47: " + p_isValidCtm_1_);
         return false;
      } else {
         return true;
      }
   }

   // $FF: synthetic method
   public int getMetadataMax() {
      int i = -1;
      int i = this.getMax(this.metadatas, i);
      if (this.matchBlocks != null) {
         jebac_vexia2nnti3ppoopl[] var2 = this.matchBlocks;
         int var3 = var2.length;

         for(int var4 = 0; var4 < var3; ++var4) {
            jebac_vexia2nnti3ppoopl matchblock = var2[var4];
            i = this.getMax(matchblock.getMetadatas(), i);
         }
      }

      return i;
   }

   // $FF: synthetic method
   private static int parseSymmetry(String p_parseSymmetry_0_) {
      if (p_parseSymmetry_0_ == null) {
         return 1;
      } else if (p_parseSymmetry_0_.equals("opposite")) {
         return 2;
      } else if (p_parseSymmetry_0_.equals("all")) {
         return 6;
      } else {
         jebac_vexiakrwecfs16wve.warn("Unknown symmetry: " + p_parseSymmetry_0_);
         return 1;
      }
   }

   // $FF: synthetic method
   private jebac_vexia2nnti3ppoopl[] detectMatchBlocks() {
      int[] aint = this.detectMatchBlockIds();
      if (aint == null) {
         return null;
      } else {
         jebac_vexia2nnti3ppoopl[] amatchblock = new jebac_vexia2nnti3ppoopl[aint.length];

         for(int i = 0; i < amatchblock.length; ++i) {
            amatchblock[i] = new jebac_vexia2nnti3ppoopl(aint[i]);
         }

         return amatchblock;
      }
   }

   // $FF: synthetic method
   public String toString() {
      return "CTM name: " + this.name + ", basePath: " + this.basePath + ", matchBlocks: " + jebac_vexiakrwecfs16wve.arrayToString((Object[])this.matchBlocks) + ", matchTiles: " + jebac_vexiakrwecfs16wve.arrayToString((Object[])this.matchTiles);
   }
}
