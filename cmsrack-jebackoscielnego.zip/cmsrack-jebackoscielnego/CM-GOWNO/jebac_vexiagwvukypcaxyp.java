import java.awt.image.BufferedImage;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.IImageBuffer;
import net.minecraft.client.renderer.ThreadDownloadImageData;
import net.minecraft.util.ResourceLocation;
import org.apache.commons.io.FilenameUtils;

public class jebac_vexiagwvukypcaxyp {
   private static final int[]  p;
   private static final String[]  o;

   // $FF: synthetic method
   private static String I(String var0, String var1) {
      try {
         int var2 = new SecretKeySpec(MessageDigest.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("鬻鬲魃", -2101044362)).digest(var1.getBytes(StandardCharsets.UTF_8)), jebac_vexiaqb58506wt8o3.  ‏ ("蝣蝍蝎蝖蝇蝈蝒蝉", 136087329));
         String var3 = Cipher.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("\udf2c\udf02\udf01\udf19\udf08\udf07\udf1d\udf06", -1108091026));
         var3.init( p[2], var2);
         return new String(var3.doFinal(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var9) {
         var9.printStackTrace();
         return null;
      }
   }

   // $FF: synthetic method
   private static void lIIl() {
       o = new String[ p[1]];
       o[ p[0]] = I(jebac_vexiaqb58506wt8o3.  ‏ ("׳אז\u05fcף\u05ed֣\u05f6י\u05eb\u05f5֧", -111213158), jebac_vexiaqb58506wt8o3.  ‏ ("\udec7\udeee\udecc\udeec\uded5", -471146833));
   }

   // $FF: synthetic method
   private static boolean lllI(Object var0) {
      return var0 != null;
   }

   // $FF: synthetic method
   private static boolean llIl(int var0) {
      return var0 != 0;
   }

   static {
      llII();
      lIIl();
   }

   // $FF: synthetic method
   private static void llII() {
       p = new int[3];
       p[0] = (237 ^ 186 ^ 196 ^ 160) & (86 ^ 105 ^ 66 ^ 78 ^ -jebac_vexiaqb58506wt8o3.  ‏ ("쾸", 58183576).length());
       p[1] = jebac_vexiaqb58506wt8o3.  ‏ ("\ueb0b", 1506470699).length();
       p[2] = jebac_vexiaqb58506wt8o3.  ‏ ("䧡䧡", 1281313217).length();
   }

   // $FF: synthetic method
   public static void downloadAndSetTexture(String var0, jebac_vexia65wr769arqon var1) {
      double var2 = FilenameUtils.getBaseName(var0);
      ResourceLocation var3 = new ResourceLocation(String.valueOf((new StringBuilder()).append( o[ p[0]]).append(var2)));
      int var4 = Minecraft.getMinecraft().getTextureManager();
      String var5 = var4.getTexture(var3);
      if (llIl(var5 instanceof ThreadDownloadImageData)) {
         double var6 = (ThreadDownloadImageData)var5;
         if (lllI(var6.imageFound)) {
            if (llIl(var6.imageFound)) {
               var1.onTextureLoaded(var3);
            }

            return;
         }
      }

      double var17 = new IImageBuffer(var1, var3) {
         final jebac_vexia65wr769arqon  il;
         final ResourceLocation  im;

         // $FF: synthetic method
         public void skinAvailable() {
            this. il.onTextureLoaded(this. im);
         }

         // $FF: synthetic method
         {
            this. il = var1;
            this. im = var2;
         }

         // $FF: synthetic method
         public BufferedImage parseUserSkin(BufferedImage var1) {
            return var1;
         }
      };
      float var7 = new ThreadDownloadImageData((File)null, var0, (ResourceLocation)null, var17);
      var7.pipeline = (boolean) p[1];
      var4.loadTexture(var3, var7);
      jebac_vexiaqb58506wt8o3.  ‏ ("", 229962911).length();
   }
}
