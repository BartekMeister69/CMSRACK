import java.util.ArrayList;
import java.util.List;

public class jebac_vexiagg7zbvolgevb extends jebac_vexiazrxtvwdcml9w {
   // $FF: synthetic field
   private jebac_vexiazrxtvwdcml9w[] options = null;
   // $FF: synthetic field
   private jebac_vexiai4ghla0oxuww[] profiles = null;

   // $FF: synthetic method
   public void updateProfile() {
      jebac_vexiai4ghla0oxuww shaderprofile = this.getProfile(this.getValue());
      if (!jebac_vexiao69nzag0tqzs.matchProfile(shaderprofile, this.options, false)) {
         String s = detectProfileName(this.profiles, this.options);
         this.setValue(s);
      }

   }

   // $FF: synthetic method
   private jebac_vexiai4ghla0oxuww getProfile(String name) {
      jebac_vexiai4ghla0oxuww[] var2 = this.profiles;
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         jebac_vexiai4ghla0oxuww shaderprofile = var2[var4];
         if (shaderprofile.getName().equals(name)) {
            return shaderprofile;
         }
      }

      return null;
   }

   // $FF: synthetic method
   private void applyProfileOptions() {
      jebac_vexiai4ghla0oxuww shaderprofile = this.getProfile(this.getValue());
      if (shaderprofile != null) {
         String[] astring = shaderprofile.getOptions();
         String[] var3 = astring;
         int var4 = astring.length;

         for(int var5 = 0; var5 < var4; ++var5) {
            String s = var3[var5];
            jebac_vexiazrxtvwdcml9w shaderoption = this.getOption(s);
            if (shaderoption != null) {
               String s1 = shaderprofile.getValue(s);
               shaderoption.setValue(s1);
            }
         }
      }

   }

   // $FF: synthetic method
   private static String detectProfileName(jebac_vexiai4ghla0oxuww[] profs, jebac_vexiazrxtvwdcml9w[] opts) {
      return detectProfileName(profs, opts, false);
   }

   // $FF: synthetic method
   public void nextValue() {
      super.nextValue();
      if (this.getValue().equals("<custom>")) {
         super.nextValue();
      }

      this.applyProfileOptions();
   }

   // $FF: synthetic method
   public String getValueColor(String val) {
      return val.equals("<custom>") ? "§c" : "§a";
   }

   // $FF: synthetic method
   private static String[] getProfileNames(jebac_vexiai4ghla0oxuww[] profs) {
      List list = new ArrayList();
      jebac_vexiai4ghla0oxuww[] var2 = profs;
      int var3 = profs.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         jebac_vexiai4ghla0oxuww shaderprofile = var2[var4];
         list.add(shaderprofile.getName());
      }

      list.add("<custom>");
      return (String[])list.toArray(new String[0]);
   }

   // $FF: synthetic method
   public String getNameText() {
      return jebac_vexia7gzdvsc1kfyf.get("of.shaders.profile");
   }

   // $FF: synthetic method
   public jebac_vexiagg7zbvolgevb(jebac_vexiai4ghla0oxuww[] profiles, jebac_vexiazrxtvwdcml9w[] options) {
      super("<profile>", "", detectProfileName(profiles, options), getProfileNames(profiles), detectProfileName(profiles, options, true), (String)null);
      this.profiles = profiles;
      this.options = options;
   }

   // $FF: synthetic method
   private static String detectProfileName(jebac_vexiai4ghla0oxuww[] profs, jebac_vexiazrxtvwdcml9w[] opts, boolean def) {
      jebac_vexiai4ghla0oxuww shaderprofile = jebac_vexiao69nzag0tqzs.detectProfile(profs, opts, def);
      return shaderprofile == null ? "<custom>" : shaderprofile.getName();
   }

   // $FF: synthetic method
   private jebac_vexiazrxtvwdcml9w getOption(String name) {
      jebac_vexiazrxtvwdcml9w[] var2 = this.options;
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         jebac_vexiazrxtvwdcml9w shaderoption = var2[var4];
         if (shaderoption.getName().equals(name)) {
            return shaderoption;
         }
      }

      return null;
   }

   // $FF: synthetic method
   public String getValueText(String val) {
      return val.equals("<custom>") ? jebac_vexia7gzdvsc1kfyf.get("of.general.custom", "<custom>") : jebac_vexiaflhnh80r1906.translate("profile." + val, val);
   }
}
