public class jebac_vexianytr9dqjsedo {
   // $FF: synthetic field
   private float scaleFactor = 0.0F;
   // $FF: synthetic field
   private int attachTo = 0;
   // $FF: synthetic field
   private jebac_vexiau47ipgjckapi modelRenderer = null;

   // $FF: synthetic method
   public void render(jebac_vexia88utjmuujofl p_render_1_, float p_render_2_) {
      jebac_vexiau47ipgjckapi modelrenderer = jebac_vexiaygbu8cvjfpcg.getAttachModel(p_render_1_, this.attachTo);
      if (modelrenderer != null) {
         modelrenderer.postRender(p_render_2_);
      }

      this.modelRenderer.render(p_render_2_ * this.scaleFactor);
   }

   // $FF: synthetic method
   public jebac_vexianytr9dqjsedo(int p_i75_1_, float p_i75_2_, jebac_vexiau47ipgjckapi p_i75_3_) {
      this.attachTo = p_i75_1_;
      this.scaleFactor = p_i75_2_;
      this.modelRenderer = p_i75_3_;
   }
}
