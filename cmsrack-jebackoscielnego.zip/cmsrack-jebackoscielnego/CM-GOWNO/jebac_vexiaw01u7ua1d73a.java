public class jebac_vexiaw01u7ua1d73a {
   // $FF: synthetic field
   public final int textureOffsetX;
   // $FF: synthetic field
   public final int textureOffsetY;

   // $FF: synthetic method
   public jebac_vexiaw01u7ua1d73a(int textureOffsetXIn, int textureOffsetYIn) {
      this.textureOffsetX = textureOffsetXIn;
      this.textureOffsetY = textureOffsetYIn;
   }
}
