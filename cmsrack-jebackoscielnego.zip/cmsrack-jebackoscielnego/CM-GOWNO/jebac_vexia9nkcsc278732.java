import java.awt.Color;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.resources.I18n;

public class jebac_vexia9nkcsc278732 extends jebac_vexiakl614w3uw0xg {
   private static final int[]  dv;
   private static final String[]  du;
   private final jebac_vexiakl614w3uw0xg  dw;
   private jebac_vexiadrxrz0b4x3gp  dx;

   static {
      llllllI();
      lllllIl();
   }

   // $FF: synthetic method
   public void initGui() {
      this. dx = new jebac_vexia1385s0ty88cj(this.mc, this, this.width, this.height,  dv[0], this.height -  dv[0],  dv[1], jebac_vexiatj0yt8p6od53.values());
      this.buttonList.add(new jebac_vexia4oibzo50ubf0( dv[2], this.width /  dv[3] -  dv[4], this.height -  dv[5],  dv[6],  dv[7], I18n.format( du[ dv[8]])));
      jebac_vexiaqb58506wt8o3.  ‏ ("", 2118315103).length();
      this.buttonList.add(new jebac_vexia4oibzo50ubf0( dv[9], this.width /  dv[3] -  dv[4] +  dv[10], this.height -  dv[5],  dv[6],  dv[7],  du[ dv[11]]));
      jebac_vexiaqb58506wt8o3.  ‏ ("", 1346306287).length();
   }

   // $FF: synthetic method
   public void actionPerformed(jebac_vexia4oibzo50ubf0 var1) throws IOException {
      if (lllllll(var1.id,  dv[2])) {
         this.mc.displayGuiScreen(this. dw);
         jebac_vexiaqb58506wt8o3.  ‏ ("", -919332055).length();
         if (((242 ^ 180) & ~(218 ^ 156)) < 0) {
            return;
         }
      } else if (lllllll(var1.id,  dv[9])) {
         jebac_vexiawzpzy1x3sez8. bj =  du[ dv[3]];
         jebac_vexiawzpzy1x3sez8. bl = (boolean) dv[11];
         jebac_vexiawzpzy1x3sez8. cd = (boolean) dv[11];
         jebac_vexiawzpzy1x3sez8. bw = (boolean) dv[11];
         jebac_vexiawzpzy1x3sez8. ce = (boolean) dv[11];
         jebac_vexiawzpzy1x3sez8. bb = (boolean) dv[8];
         jebac_vexiawzpzy1x3sez8. by = (boolean) dv[11];
         jebac_vexiawzpzy1x3sez8. bz = (boolean) dv[8];
         jebac_vexiawzpzy1x3sez8. bx = (boolean) dv[11];
         jebac_vexiawzpzy1x3sez8. be = (boolean) dv[8];
         jebac_vexiawzpzy1x3sez8. cc = (boolean) dv[11];
         jebac_vexiawzpzy1x3sez8. br = (boolean) dv[11];
         jebac_vexiawzpzy1x3sez8. bk = (boolean) dv[11];
         jebac_vexiawzpzy1x3sez8. bq = (boolean) dv[11];
         jebac_vexiawzpzy1x3sez8. bd = (boolean) dv[11];
         jebac_vexiaau3mg1q92fzj. dy. jq =  dv[8];
         jebac_vexiaau3mg1q92fzj. dy. jn =  dv[8];
         jebac_vexiaau3mg1q92fzj. dy. jo = Color.WHITE;
         jebac_vexiaau3mg1q92fzj. dy. ju = (boolean) dv[11];
         jebac_vexiaau3mg1q92fzj. dy. jp = (boolean) dv[11];
         jebac_vexiaau3mg1q92fzj. ea. fp =  dv[8];
         jebac_vexiaau3mg1q92fzj. ea. fn =  dv[8];
         jebac_vexiaau3mg1q92fzj. ea. fm =  dv[6];
         jebac_vexiaau3mg1q92fzj. ea. fk =  dv[12];
         jebac_vexiaau3mg1q92fzj. ea. fu = (boolean) dv[8];
         jebac_vexiaau3mg1q92fzj. ea. fw = (boolean) dv[11];
         jebac_vexiaau3mg1q92fzj. ea. fr = (boolean) dv[11];
         jebac_vexiaau3mg1q92fzj. eb. gq =  dv[8];
         jebac_vexiaau3mg1q92fzj. eb. go =  dv[13];
         jebac_vexiaau3mg1q92fzj. eb. gt = (boolean) dv[11];
         jebac_vexiaau3mg1q92fzj. dz. k = jebac_vexiabjvb6fu2xswx. jl;
         jebac_vexiaau3mg1q92fzj. dz. n = 1.0F;
         jebac_vexiaau3mg1q92fzj. dz. i = Color.BLACK;
         jebac_vexiaau3mg1q92fzj. dz. j = (boolean) dv[11];
         jebac_vexia67ba3dligh23.save();
         this.mc.displayGuiScreen(this);
      }

   }

   // $FF: synthetic method
   private static String llIIIlI(String var0, String var1) {
      var0 = new String(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder var2 = new StringBuilder();
      String var3 = var1.toCharArray();
      int var4 =  dv[8];
      Exception var5 = var0.toCharArray();
      StringBuilder var6 = var5.length;
      int var7 =  dv[8];

      do {
         if (!lIIIIIII(var7, var6)) {
            return String.valueOf(var2);
         }

         char var8 = var5[var7];
         var2.append((char)(var8 ^ var3[var4 % var3.length]));
         jebac_vexiaqb58506wt8o3.  ‏ ("", -265012439).length();
         ++var4;
         ++var7;
         jebac_vexiaqb58506wt8o3.  ‏ ("", -979895458).length();
      } while(jebac_vexiaqb58506wt8o3.  ‏ ("撻撻撻", 2054513819).length() > 0);

      return null;
   }

   // $FF: synthetic method
   private static boolean lIIIIIII(int var0, int var1) {
      return var0 < var1;
   }

   // $FF: synthetic method
   private static String llIIIIl(String var0, String var1) {
      try {
         double var2 = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("폇폎펿", 944493450)).digest(var1.getBytes(StandardCharsets.UTF_8)),  dv[18]), jebac_vexiaqb58506wt8o3.  ‏ ("窾窿窩", -1530430726));
         String var3 = Cipher.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("耘耙耏", -1523416996));
         var3.init( dv[3], var2);
         return new String(var3.doFinal(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var9) {
         var9.printStackTrace();
         return null;
      }
   }

   // $FF: synthetic method
   protected void mouseClicked(int var1, int var2, int var3) throws IOException {
      super.mouseClicked(var1, var2, var3);
      this. dx.mouseClicked(var1, var2, var3);
      jebac_vexiaqb58506wt8o3.  ‏ ("", 764262518).length();
   }

   // $FF: synthetic method
   protected void mouseReleased(int var1, int var2, int var3) {
      super.mouseReleased(var1, var2, var3);
      this. dx.mouseReleased(var1, var2, var3);
      jebac_vexiaqb58506wt8o3.  ‏ ("", 1387498500).length();
   }

   // $FF: synthetic method
   private static boolean lllllll(int var0, int var1) {
      return var0 == var1;
   }

   // $FF: synthetic method
   public void handleMouseInput() throws IOException {
      super.handleMouseInput();
      this. dx.handleMouseInput();
   }

   // $FF: synthetic method
   private static void lllllIl() {
       du = new String[ dv[17]];
       du[ dv[8]] = llIIIII(jebac_vexiaqb58506wt8o3.  ‏ ("戃戧户房扼户戈戍戬扡戧戁戠戯扼戞戽戠戔戥戶戹扳扳", -509975986), jebac_vexiaqb58506wt8o3.  ‏ ("ꆋꆘꆐꆋꆼ", 1114481097));
       du[ dv[11]] = llIIIIl(jebac_vexiaqb58506wt8o3.  ‏ ("\ue54b\ue55a\ue56c\ue531\ue550\ue556\ue54f\ue54e\ue56e\ue574\ue567\ue531\ue574\ue527\ue54c\ue57f\ue56d\ue535\ue56b\ue57b\ue551\ue570\ue54a\ue544\ue55f\ue529\ue549\ue546\ue553\ue52f\ue52d\ue52c", -69475042), jebac_vexiaqb58506wt8o3.  ‏ ("⁎⁶\u206a\u2065\u2063", 470425612));
       du[ dv[3]] = llIIIIl(jebac_vexiaqb58506wt8o3.  ‏ ("蝔蜬蝧蝞蝜蜭蝩蝏蝆蜩蜭蝖蝥蝐蝊蝮蝪蝆蝭蝙蝦蜨蝛蝧蝜蝎蝾蝴蝝蜦蝧蝨蝩蜯蝏蜫蝵蝻蝬蜩蝩蝚蝒蜢", 1760593695), jebac_vexiaqb58506wt8o3.  ‏ ("扐扡扜扢扬", 1261199910));
       du[ dv[14]] = llIIIlI(jebac_vexiaqb58506wt8o3.  ‏ ("촟촃쵩촓촞촃촟촰총촒쵩촕촗촩촺촔", -702034607), jebac_vexiaqb58506wt8o3.  ‏ ("偭偸偵偄偡", 2100121623));
   }

   // $FF: synthetic method
   private static String llIIIII(String var0, String var1) {
      try {
         Exception var2 = new SecretKeySpec(MessageDigest.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("\u2fda⿓⾢", -1643368553)).digest(var1.getBytes(StandardCharsets.UTF_8)), jebac_vexiaqb58506wt8o3.  ‏ ("㘘㘶㘵㘭㘼㘳㘩㘲", 1918449242));
         String var3 = Cipher.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("麺麔麗麏麞麑麋麐", 578068216));
         var3.init( dv[3], var2);
         return new String(var3.doFinal(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var9) {
         var9.printStackTrace();
         return null;
      }
   }

   // $FF: synthetic method
   public jebac_vexia9nkcsc278732(jebac_vexiakl614w3uw0xg var1) {
      this. dw = var1;
   }

   // $FF: synthetic method
   public void drawScreen(int var1, int var2, float var3) {
      this.drawDefaultBackground();
      this. dx.drawScreen(var1, var2, var3);
      this.drawCenteredString(this.fontRendererObj,  du[ dv[14]], this.width /  dv[3],  dv[15],  dv[16]);
      super.drawScreen(var1, var2, var3);
   }

   // $FF: synthetic method
   private static void llllllI() {
       dv = new int[19];
       dv[0] = 55 ^ 23;
       dv[1] = 8 ^ 92 ^ 41 ^ 100;
       dv[2] = 161 + 184 - 317 + 172;
       dv[3] = jebac_vexiaqb58506wt8o3.  ‏ ("尳尳", 146955283).length();
       dv[4] = 62 + 88 - 136 + 141;
       dv[5] = 143 + 110 - 222 + 131 ^ 40 + 144 - 95 + 102;
       dv[6] = (75 ^ 120) + (189 ^ 178) - -jebac_vexiaqb58506wt8o3.  ‏ ("惥惥", 1329750213).length() + (61 ^ 111);
       dv[7] = 19 ^ 40 ^ 235 ^ 196;
       dv[8] = (48 ^ 123) & ~(200 ^ 131);
       dv[9] = (40 ^ 1) + (144 ^ 199) - -(219 ^ 159) + (197 ^ 192);
       dv[10] = 158 + 49 - 136 + 89;
       dv[11] = jebac_vexiaqb58506wt8o3.  ‏ ("ʗ", 353960631).length();
       dv[12] = -29186 & 29685;
       dv[13] = 42 ^ 112;
       dv[14] = jebac_vexiaqb58506wt8o3.  ‏ ("윻윻윻", 697681691).length();
       dv[15] = 23 + 155 - 153 + 135 ^ 150 + 7 - 69 + 87;
       dv[16] = -1 & 16777215;
       dv[17] = 123 ^ 127;
       dv[18] = 20 + 0 - -60 + 64 ^ 54 + 70 - 106 + 134;
   }
}
