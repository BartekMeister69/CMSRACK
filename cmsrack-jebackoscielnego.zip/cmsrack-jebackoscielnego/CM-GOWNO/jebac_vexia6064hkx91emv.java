import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.resources.I18n;

public class jebac_vexia6064hkx91emv extends jebac_vexiakl614w3uw0xg {
   private static final int[]  dn;
   private static final String[]  do;
   private final jebac_vexiakl614w3uw0xg  dp;

   // $FF: synthetic method
   public void initGui() {
      List var10000 = this.buttonList;
      jebac_vexia4oibzo50ubf0 var10001 = new jebac_vexia4oibzo50ubf0;
      int var10003 =  dn[0];
      int var10004 = this.width /  dn[1] -  dn[2];
      int var10005 = this.height /  dn[3] -  dn[3];
      int var10006 =  dn[4];
      int var10007 =  dn[5];
      String var10008;
      if (lIIIIlI(jebac_vexiawzpzy1x3sez8. bz)) {
         var10008 =  do[ dn[0]];
         jebac_vexiaqb58506wt8o3.  ‏ ("", 1962333622).length();
         if (jebac_vexiaqb58506wt8o3.  ‏ ("䕙", -947829383).length() == 0) {
            return;
         }
      } else {
         var10008 =  do[ dn[6]];
      }

      var10001.<init>(var10003, var10004, var10005, var10006, var10007, var10008);
      var10000.add(var10001);
      jebac_vexiaqb58506wt8o3.  ‏ ("", -1113676612).length();
      var10000 = this.buttonList;
      var10001 = new jebac_vexia4oibzo50ubf0;
      var10003 =  dn[6];
      var10004 = this.width /  dn[1] +  dn[7];
      var10005 = this.height /  dn[3] -  dn[3];
      var10006 =  dn[4];
      var10007 =  dn[5];
      if (lIIIIlI(jebac_vexiaau3mg1q92fzj. eb. gt)) {
         var10008 =  do[ dn[1]];
         jebac_vexiaqb58506wt8o3.  ‏ ("", 755424301).length();
         if (jebac_vexiaqb58506wt8o3.  ‏ ("殷", 913206167).length() > jebac_vexiaqb58506wt8o3.  ‏ ("獎獎獎", -478383250).length()) {
            return;
         }
      } else {
         var10008 =  do[ dn[8]];
      }

      var10001.<init>(var10003, var10004, var10005, var10006, var10007, var10008);
      var10000.add(var10001);
      jebac_vexiaqb58506wt8o3.  ‏ ("", 1356582899).length();
      this.buttonList.add(new jebac_vexia4oibzo50ubf0( dn[1], this.width /  dn[1] -  dn[9], this.height /  dn[3] +  dn[10], I18n.format( do[ dn[11]])));
      jebac_vexiaqb58506wt8o3.  ‏ ("", -1693710543).length();
   }

   // $FF: synthetic method
   private static boolean lIIIlII(int var0, int var1) {
      return var0 == var1;
   }

   static {
      lIIIIIl();
      lIIIIII();
   }

   // $FF: synthetic method
   private static void lIIIIIl() {
       dn = new int[15];
       dn[0] = (31 ^ 2) & ~(172 ^ 177);
       dn[1] = jebac_vexiaqb58506wt8o3.  ‏ ("㶔㶔", -11256396).length();
       dn[2] = 63 + 87 - 53 + 58;
       dn[3] = 77 ^ 75;
       dn[4] = 6 + 74 - 60 + 130;
       dn[5] = 154 ^ 142;
       dn[6] = jebac_vexiaqb58506wt8o3.  ‏ ("\uec03", -1482888157).length();
       dn[7] = 121 + 17 - 121 + 147 ^ 13 + 53 - 24 + 119;
       dn[8] = jebac_vexiaqb58506wt8o3.  ‏ ("퇡퇡퇡", -1241460287).length();
       dn[9] = 1 + 203 - 104 + 148 ^ 116 + 145 - 152 + 47;
       dn[10] = (30 ^ 109) + (57 ^ 86) - (56 + 127 - 161 + 159) + (103 ^ 28);
       dn[11] = 183 ^ 179;
       dn[12] = 120 + 84 - 81 + 13 ^ 24 + 79 - -29 + 3;
       dn[13] = -jebac_vexiaqb58506wt8o3.  ‏ ("훽", 1925633757).length() & -1 & 16777215;
       dn[14] = 178 ^ 186;
   }

   // $FF: synthetic method
   private static boolean lIIIIlI(int var0) {
      return var0 != 0;
   }

   // $FF: synthetic method
   public jebac_vexia6064hkx91emv(jebac_vexiakl614w3uw0xg var1) {
      this. dp = var1;
   }

   // $FF: synthetic method
   private static boolean lIIIlIl(int var0, int var1) {
      return var0 < var1;
   }

   // $FF: synthetic method
   private static String llllIl(String var0, String var1) {
      try {
         float var2 = new SecretKeySpec(MessageDigest.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("萩萠葑", -1323400092)).digest(var1.getBytes(StandardCharsets.UTF_8)), jebac_vexiaqb58506wt8o3.  ‏ ("孌孢孡孹孨孧孽学", -396731634));
         Cipher var3 = Cipher.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("\uda98\udab6\udab5\udaad\udabc\udab3\udaa9\udab2", 1511447258));
         var3.init( dn[1], var2);
         return new String(var3.doFinal(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var9) {
         var9.printStackTrace();
         return null;
      }
   }

   // $FF: synthetic method
   protected void actionPerformed(jebac_vexia4oibzo50ubf0 var1) throws IOException {
      if (lIIIIlI(var1.enabled)) {
         if (lIIIIll(var1.id)) {
            int var10000;
            if (lIIIIll(jebac_vexiawzpzy1x3sez8. bz)) {
               var10000 =  dn[6];
               jebac_vexiaqb58506wt8o3.  ‏ ("", 2053998889).length();
               if (jebac_vexiaqb58506wt8o3.  ‏ ("䆒", -1392754254).length() == 0) {
                  return;
               }
            } else {
               var10000 =  dn[0];
            }

            jebac_vexiawzpzy1x3sez8. bz = (boolean)var10000;
            this.mc.displayGuiScreen(this);
            jebac_vexiaqb58506wt8o3.  ‏ ("", -303912997).length();
            if (-jebac_vexiaqb58506wt8o3.  ‏ ("鹵", -1820680619).length() >= jebac_vexiaqb58506wt8o3.  ‏ ("襝襝襝", 965183869).length()) {
               return;
            }
         } else if (lIIIlII(var1.id,  dn[6])) {
            jebac_vexiawjtwglazxj7a var5 = jebac_vexiaau3mg1q92fzj. eb;
            int var10001;
            if (lIIIIll(jebac_vexiaau3mg1q92fzj. eb. gt)) {
               var10001 =  dn[6];
               jebac_vexiaqb58506wt8o3.  ‏ ("", -950999534).length();
               if ((212 ^ 197 ^ 78 ^ 90) <= 0) {
                  return;
               }
            } else {
               var10001 =  dn[0];
            }

            var5. gt = (boolean)var10001;
            this.mc.displayGuiScreen(this);
            jebac_vexiaqb58506wt8o3.  ‏ ("", 120771167).length();
            if (null != null) {
               return;
            }
         } else if (lIIIlII(var1.id,  dn[1])) {
            this.mc.displayGuiScreen(this. dp);
         }

         jebac_vexia67ba3dligh23.save();
      }

   }

   // $FF: synthetic method
   private static boolean lIIIIll(int var0) {
      return var0 == 0;
   }

   // $FF: synthetic method
   private static String lllllI(String var0, String var1) {
      var0 = new String(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      float var2 = new StringBuilder();
      double var3 = var1.toCharArray();
      Exception var4 =  dn[0];
      char var5 = var0.toCharArray();
      int var6 = var5.length;
      int var7 =  dn[0];

      do {
         if (!lIIIlIl(var7, var6)) {
            return String.valueOf(var2);
         }

         String var8 = var5[var7];
         var2.append((char)(var8 ^ var3[var4 % var3.length]));
         jebac_vexiaqb58506wt8o3.  ‏ ("", -2002167038).length();
         ++var4;
         ++var7;
         jebac_vexiaqb58506wt8o3.  ‏ ("", 651576127).length();
      } while((233 ^ 182 ^ 226 ^ 185) == (108 ^ 118 ^ 89 ^ 71));

      return null;
   }

   // $FF: synthetic method
   public void drawScreen(int var1, int var2, float var3) {
      this.drawDefaultBackground();
      this.drawCenteredString(this.fontRendererObj,  do[ dn[7]], this.width /  dn[1],  dn[12],  dn[13]);
      super.drawScreen(var1, var2, var3);
   }

   // $FF: synthetic method
   private static String llllll(String var0, String var1) {
      try {
         String var2 = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("볊볃벲", -390546297)).digest(var1.getBytes(StandardCharsets.UTF_8)),  dn[14]), jebac_vexiaqb58506wt8o3.  ‏ ("䎪䎫䎽", 1390167022));
         float var3 = Cipher.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("忤忥忳", -150511712));
         var3.init( dn[1], var2);
         return new String(var3.doFinal(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var9) {
         var9.printStackTrace();
         return null;
      }
   }

   // $FF: synthetic method
   private static void lIIIIII() {
       do = new String[ dn[3]];
       do[ dn[0]] = llllIl(jebac_vexiaqb58506wt8o3.  ‏ ("ὒὝὌὢὃὁὓὧὁἎὦὣώὣὀἓἎ\u1f47ὼὀ\u1f5c\u1f16\u1f7fὍἔὪὕὭὰὃὢὍὭἝὄὰὐέὮἒ\u1f17ὐὴἘ", 1784618789), jebac_vexiaqb58506wt8o3.  ‏ ("ౘ\u0c76౨౮౻", 2099579906));
       do[ dn[6]] = lllllI(jebac_vexiaqb58506wt8o3.  ‏ ("\ud89d\ud886\ud8bd\ud881\ud89c\ud8bb\ud893\ud89e\ud89c\ud8a5\ud8e2\ud8b5\ud898\ud8a5\ud8b1\ud8bf\ud883\ud881\ud883\ud8a4\ud891\ud8ab\ud8b5\ud884\ud89e\ud8b8\ud8e7\ud887\ud88b\ud8ea\ud89d\ud895\ud89b\ud8b5\ud8b1\ud8bc\ud890\ud8b5\ud8ef\ud8ef", 66377938), jebac_vexiaqb58506wt8o3.  ‏ ("僊僧僅僥僭", -2114826076));
       do[ dn[1]] = lllllI(jebac_vexiaqb58506wt8o3.  ‏ ("䤐䤮䥣䤧䤐䤮䤸䤧䤞䤭䤎䤙䤛䤄䤂䤮䤲䤰䤂䤸䤞䤭䤼䤽䤁䤺䤇䤓䤦䤭䤎䤘䤛䤆䤰䥪", -1391638185), jebac_vexiaqb58506wt8o3.  ‏ ("㹄㹟㹒㹤㹋", -130269688));
       do[ dn[8]] = llllll(jebac_vexiaqb58506wt8o3.  ‏ ("ꃼꃕꃻꃰꃒꃏꂠꂫꃞꃢꃀꃫꃯꃢꂳꃶꃼꃋꂪꂪꃵꂭꃵꂡꃴꃒꃷꃺꃋꃨꃞꂨꂳꃐꂩꃺꃪꂠꂫꂭꃍꃭꃫꂥ", -898129768), jebac_vexiaqb58506wt8o3.  ‏ ("릛릸릚릖릯", -883312129));
       do[ dn[11]] = lllllI(jebac_vexiaqb58506wt8o3.  ‏ ("⛟⛗⛓⛆⛅⛕⛵⛹⛑⛱⛛⚫", 957228694), jebac_vexiaqb58506wt8o3.  ‏ ("袻袈袚袚袿", 416057596));
       do[ dn[7]] = llllll(jebac_vexiaqb58506wt8o3.  ‏ ("\uda09\uda56\uda0f\uda54\uda66\uda66\uda49\uda7e\uda54\uda0e\uda74\uda50\uda6a\uda77\uda49\uda0e\uda70\uda47\uda76\uda68\uda54\uda46\uda57\uda54\uda4f\uda77\uda0a\uda69\uda53\uda74\uda7e\uda6f", -768484801), jebac_vexiaqb58506wt8o3.  ‏ ("橸橂橽橜橪", -678204870));
   }
}
