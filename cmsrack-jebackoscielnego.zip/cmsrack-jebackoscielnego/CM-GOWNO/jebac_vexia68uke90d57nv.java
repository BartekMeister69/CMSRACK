public interface jebac_vexia68uke90d57nv {
   // $FF: synthetic method
   void mouseReleased(int var1, int var2, int var3, int var4, int var5, int var6);

   // $FF: synthetic method
   void drawEntry(int var1, int var2, int var3, int var4, int var5, int var6, int var7, boolean var8);

   // $FF: synthetic method
   void setSelected(int var1, int var2, int var3);

   // $FF: synthetic method
   boolean mousePressed(int var1, int var2, int var3, int var4, int var5, int var6);
}
