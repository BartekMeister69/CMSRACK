import io.netty.buffer.Unpooled;
import java.io.IOException;
import java.util.Iterator;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.init.Items;
import net.minecraft.inventory.ContainerBeacon;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.client.C17PacketCustomPayload;
import net.minecraft.tileentity.TileEntityBeacon;
import net.minecraft.util.ResourceLocation;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class jebac_vexiajrsmxgnpvxgq extends jebac_vexiaeojg9sk3h8nx {
   // $FF: synthetic field
   private jebac_vexiakccnrrck7p2v beaconConfirmButton;
   // $FF: synthetic field
   private static final ResourceLocation beaconGuiTextures = new ResourceLocation("textures/gui/container/beacon.png");
   // $FF: synthetic field
   private boolean buttonsNotDrawn;
   // $FF: synthetic field
   private static final Logger logger = LogManager.getLogger();
   // $FF: synthetic field
   private IInventory tileBeacon;

   // $FF: synthetic method
   protected void drawGuiContainerBackgroundLayer(float partialTicks, int mouseX, int mouseY) {
      GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
      this.mc.getTextureManager().bindTexture(beaconGuiTextures);
      int i = (this.width - this.xSize) / 2;
      int j = (this.height - this.ySize) / 2;
      this.drawTexturedModalRect(i, j, 0, 0, this.xSize, this.ySize);
      this.itemRender.zLevel = 100.0F;
      this.itemRender.renderItemAndEffectIntoGUI(new ItemStack(Items.emerald), i + 42, j + 109);
      this.itemRender.renderItemAndEffectIntoGUI(new ItemStack(Items.diamond), i + 42 + 22, j + 109);
      this.itemRender.renderItemAndEffectIntoGUI(new ItemStack(Items.gold_ingot), i + 42 + 44, j + 109);
      this.itemRender.renderItemAndEffectIntoGUI(new ItemStack(Items.iron_ingot), i + 42 + 66, j + 109);
      this.itemRender.zLevel = 0.0F;
   }

   static void access$300(jebac_vexiajrsmxgnpvxgq x0, String x1, int x2, int x3) {
      x0.drawCreativeTabHoveringText(x1, x2, x3);
   }

   // $FF: synthetic method
   public jebac_vexiajrsmxgnpvxgq(InventoryPlayer playerInventory, IInventory tileBeaconIn) {
      super(new ContainerBeacon(playerInventory, tileBeaconIn));
      this.tileBeacon = tileBeaconIn;
      this.xSize = 230;
      this.ySize = 219;
   }

   // $FF: synthetic method
   public void initGui() {
      super.initGui();
      this.buttonList.add(this.beaconConfirmButton = new jebac_vexiakccnrrck7p2v(this, -1, this.guiLeft + 164, this.guiTop + 107));
      this.buttonList.add(new jebac_vexiaf4ox3ywz3yhu(this, -2, this.guiLeft + 190, this.guiTop + 107));
      this.buttonsNotDrawn = true;
      this.beaconConfirmButton.enabled = false;
   }

   // $FF: synthetic method
   protected void drawGuiContainerForegroundLayer(int mouseX, int mouseY) {
      RenderHelper.disableStandardItemLighting();
      this.drawCenteredString(this.fontRendererObj, I18n.format("tile.beacon.primary"), 62, 10, 14737632);
      this.drawCenteredString(this.fontRendererObj, I18n.format("tile.beacon.secondary"), 169, 10, 14737632);
      Iterator var3 = this.buttonList.iterator();

      while(var3.hasNext()) {
         jebac_vexia4oibzo50ubf0 guibutton = (jebac_vexia4oibzo50ubf0)var3.next();
         if (guibutton.isMouseOver()) {
            guibutton.drawButtonForegroundLayer(mouseX - this.guiLeft, mouseY - this.guiTop);
            break;
         }
      }

      RenderHelper.enableGUIStandardItemLighting();
   }

   static ResourceLocation access$000() {
      return beaconGuiTextures;
   }

   // $FF: synthetic method
   public void updateScreen() {
      super.updateScreen();
      int i = this.tileBeacon.getField(0);
      int j = this.tileBeacon.getField(1);
      int k = this.tileBeacon.getField(2);
      if (this.buttonsNotDrawn && i >= 0) {
         this.buttonsNotDrawn = false;

         int j2;
         int k2;
         int l2;
         int i3;
         jebac_vexiav195hg2n24di guibeacon$powerbutton2;
         for(int l = 0; l <= 2; ++l) {
            j2 = TileEntityBeacon.effectsList[l].length;
            k2 = j2 * 22 + (j2 - 1) * 2;

            for(l2 = 0; l2 < j2; ++l2) {
               i3 = TileEntityBeacon.effectsList[l][l2].id;
               guibeacon$powerbutton2 = new jebac_vexiav195hg2n24di(this, l << 8 | i3, this.guiLeft + 76 + l2 * 24 - k2 / 2, this.guiTop + 22 + l * 25, i3, l);
               this.buttonList.add(guibeacon$powerbutton2);
               if (l >= i) {
                  guibeacon$powerbutton2.enabled = false;
               } else if (i3 == j) {
                  guibeacon$powerbutton2.func_146140_b(true);
               }
            }
         }

         int i2 = 3;
         j2 = TileEntityBeacon.effectsList[i2].length + 1;
         k2 = j2 * 22 + (j2 - 1) * 2;

         for(l2 = 0; l2 < j2 - 1; ++l2) {
            i3 = TileEntityBeacon.effectsList[i2][l2].id;
            guibeacon$powerbutton2 = new jebac_vexiav195hg2n24di(this, i2 << 8 | i3, this.guiLeft + 167 + l2 * 24 - k2 / 2, this.guiTop + 47, i3, i2);
            this.buttonList.add(guibeacon$powerbutton2);
            if (i2 >= i) {
               guibeacon$powerbutton2.enabled = false;
            } else if (i3 == k) {
               guibeacon$powerbutton2.func_146140_b(true);
            }
         }

         if (j > 0) {
            jebac_vexiav195hg2n24di guibeacon$powerbutton1 = new jebac_vexiav195hg2n24di(this, i2 << 8 | j, this.guiLeft + 167 + (j2 - 1) * 24 - k2 / 2, this.guiTop + 47, j, i2);
            this.buttonList.add(guibeacon$powerbutton1);
            if (i2 >= i) {
               guibeacon$powerbutton1.enabled = false;
            } else if (j == k) {
               guibeacon$powerbutton1.func_146140_b(true);
            }
         }
      }

      this.beaconConfirmButton.enabled = this.tileBeacon.getStackInSlot(0) != null && j > 0;
   }

   // $FF: synthetic method
   protected void actionPerformed(jebac_vexia4oibzo50ubf0 button) throws IOException {
      if (button.id == -2) {
         this.mc.displayGuiScreen((jebac_vexiakl614w3uw0xg)null);
      } else if (button.id == -1) {
         String s = "MC|Beacon";
         PacketBuffer packetbuffer = new PacketBuffer(Unpooled.buffer());
         packetbuffer.writeInt(this.tileBeacon.getField(1));
         packetbuffer.writeInt(this.tileBeacon.getField(2));
         this.mc.getNetHandler().addToSendQueue(new C17PacketCustomPayload(s, packetbuffer));
         this.mc.displayGuiScreen((jebac_vexiakl614w3uw0xg)null);
      } else if (button instanceof jebac_vexiav195hg2n24di) {
         if (((jebac_vexiav195hg2n24di)button).func_146141_c()) {
            return;
         }

         int j = button.id;
         int k = j & 255;
         int i = j >> 8;
         if (i < 3) {
            this.tileBeacon.setField(1, k);
         } else {
            this.tileBeacon.setField(2, k);
         }

         this.buttonList.clear();
         this.initGui();
         this.updateScreen();
      }

   }

   static void access$200(jebac_vexiajrsmxgnpvxgq x0, String x1, int x2, int x3) {
      x0.drawCreativeTabHoveringText(x1, x2, x3);
   }

   static void access$100(jebac_vexiajrsmxgnpvxgq x0, String x1, int x2, int x3) {
      x0.drawCreativeTabHoveringText(x1, x2, x3);
   }
}
