import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public enum jebac_vexiabjvb6fu2xswx {
   private static final jebac_vexiabjvb6fu2xswx[]  je;
   private static final int[]  jf;
    jg;

   private final String  jh;
    ji;

   private static final String[]  jj;
    jk,
    jl;

   // $FF: synthetic method
   public String getName() {
      return lllIIlllIIIIIIl. jh;
   }

   // $FF: synthetic method
   private static void lIIIllIIl() {
       jf = new int[9];
       jf[0] = jebac_vexiaqb58506wt8o3.  ‏ ("뛧", 174569159).length();
       jf[1] = (117 ^ 90) & ~(16 ^ 63);
       jf[2] = jebac_vexiaqb58506wt8o3.  ‏ ("鯲鯲", 1073322962).length();
       jf[3] = jebac_vexiaqb58506wt8o3.  ‏ ("柼柼柼", -1162582052).length();
       jf[4] = 43 ^ 47;
       jf[5] = 47 ^ 42;
       jf[6] = 167 + 132 - 170 + 54 ^ 122 + 41 - 76 + 90;
       jf[7] = 44 ^ 43;
       jf[8] = 147 + 65 - 96 + 67 ^ 97 + 98 - 4 + 0;
   }

   // $FF: synthetic method
   private static String lIIIlIIlI(String lllIIllIlllIIlI, String lllIIllIlllIIIl) {
      lllIIllIlllIIlI = new String(Base64.getDecoder().decode(lllIIllIlllIIlI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder lllIIllIlllIIII = new StringBuilder();
      float lllIIllIllIlIlI = lllIIllIlllIIIl.toCharArray();
      int lllIIllIllIlllI =  jf[1];
      long lllIIllIllIlIII = lllIIllIlllIIlI.toCharArray();
      float lllIIllIllIIlll = lllIIllIllIlIII.length;
      int lllIIllIllIIllI =  jf[1];

      do {
         if (!lIIIllIlI(lllIIllIllIIllI, lllIIllIllIIlll)) {
            return String.valueOf(lllIIllIlllIIII);
         }

         short lllIIllIllIIlIl = lllIIllIllIlIII[lllIIllIllIIllI];
         lllIIllIlllIIII.append((char)(lllIIllIllIIlIl ^ lllIIllIllIlIlI[lllIIllIllIlllI % lllIIllIllIlIlI.length]));
         jebac_vexiaqb58506wt8o3.  ‏ ("", -1142132631).length();
         ++lllIIllIllIlllI;
         ++lllIIllIllIIllI;
         jebac_vexiaqb58506wt8o3.  ‏ ("", 1528605235).length();
      } while(jebac_vexiaqb58506wt8o3.  ‏ ("∩∩∩", -1396497911).length() >= 0);

      return null;
   }

   // $FF: synthetic method
   private jebac_vexiabjvb6fu2xswx(String lllIIlllIIIIIll) {
      lllIIlllIIIlIII. jh = lllIIlllIIIIIll;
   }

   // $FF: synthetic method
   private static void lIIIlIlII() {
       jj = new String[ jf[8]];
       jj[ jf[1]] = lIIIlIIIl(jebac_vexiaqb58506wt8o3.  ‏ ("顟顪顯顮项頇願顇顫须頎頃", -1281058754), jebac_vexiaqb58506wt8o3.  ‏ ("\ude54\ude74\ude41\ude48\ude47", -762257870));
       jj[ jf[0]] = lIIIlIIlI(jebac_vexiaqb58506wt8o3.  ‏ ("\uf5e1\uf5f5\uf5c5\uf5d7\uf5ee\uf5e7\uf59b\uf59b", 895677862), jebac_vexiaqb58506wt8o3.  ‏ ("鳦鳙鳕鳨鳝", -615473999));
       jj[ jf[2]] = lIIIlIIll(jebac_vexiaqb58506wt8o3.  ‏ ("甎甼甪甴男畕甩甬由甫甽留", -174819996), jebac_vexiaqb58506wt8o3.  ‏ ("汛汉汸汢汈", -2138608596));
       jj[ jf[3]] = lIIIlIIlI(jebac_vexiaqb58506wt8o3.  ‏ ("뺆뺙뺉뺺뺂뺰뺉뻱뺍뺙뻵뻵", -1630421304), jebac_vexiaqb58506wt8o3.  ‏ ("⥙⥭⥅⥎⥭", 1179855144));
       jj[ jf[4]] = lIIIlIIll(jebac_vexiaqb58506wt8o3.  ‏ ("ൖൌ൭\u0d65ു൚ൕ൬\u0d0d൱൧ട", 1310395682), jebac_vexiaqb58506wt8o3.  ‏ ("ќюѿью", -722205637));
       jj[ jf[5]] = lIIIlIIIl(jebac_vexiaqb58506wt8o3.  ‏ ("৫৸\u09d9আ৹২৻ৈ৻৻৬ঔ", 1754270121), jebac_vexiaqb58506wt8o3.  ‏ ("촐촣촏촄촆", -96285353));
       jj[ jf[6]] = lIIIlIIll(jebac_vexiaqb58506wt8o3.  ‏ ("籄籃籽簂籀籸籴籕籞簝籼簐", -1087669203), jebac_vexiaqb58506wt8o3.  ‏ ("↹↗↜↲ↀ", 945365464));
       jj[ jf[7]] = lIIIlIIIl(jebac_vexiaqb58506wt8o3.  ‏ ("꒲ꓐꓫ꓆꒶\ua4c7ꓡꓰ\ua4c9꓄ꓛ꒿", -1360747390), jebac_vexiaqb58506wt8o3.  ‏ ("雚雂雊雊雭", -1687316855));
   }

   // $FF: synthetic method
   private static boolean lIIIllIlI(int var0, int var1) {
      return var0 < var1;
   }

   // $FF: synthetic method
   private static String lIIIlIIIl(String lllIIllIlIllIll, String lllIIllIlIlllII) {
      try {
         SecretKeySpec lllIIllIllIIIII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("噤噭嘜", 1231377961)).digest(lllIIllIlIlllII.getBytes(StandardCharsets.UTF_8)),  jf[8]), jebac_vexiaqb58506wt8o3.  ‏ ("孙存孎", 1773099805));
         Cipher lllIIllIlIlllll = Cipher.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("㑁㑀㑖", 1731343365));
         lllIIllIlIlllll.init( jf[2], lllIIllIllIIIII);
         return new String(lllIIllIlIlllll.doFinal(Base64.getDecoder().decode(lllIIllIlIllIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var4) {
         var4.printStackTrace();
         return null;
      }
   }

   // $FF: synthetic method
   public static jebac_vexiabjvb6fu2xswx getNextMode(jebac_vexiabjvb6fu2xswx lllIIllIllllllI) {
      return values()[(lllIIllIllllllI.ordinal() +  jf[0]) % values().length];
   }

   static {
      lIIIllIIl();
      lIIIlIlII();
       jk = new jebac_vexiabjvb6fu2xswx( jj[ jf[1]],  jf[1],  jj[ jf[0]]);
       jl = new jebac_vexiabjvb6fu2xswx( jj[ jf[2]],  jf[0],  jj[ jf[3]]);
       ji = new jebac_vexiabjvb6fu2xswx( jj[ jf[4]],  jf[2],  jj[ jf[5]]);
       jg = new jebac_vexiabjvb6fu2xswx( jj[ jf[6]],  jf[3],  jj[ jf[7]]);
      jebac_vexiabjvb6fu2xswx[] var10000 = new jebac_vexiabjvb6fu2xswx[ jf[4]];
      var10000[ jf[1]] =  jk;
      var10000[ jf[0]] =  jl;
      var10000[ jf[2]] =  ji;
      var10000[ jf[3]] =  jg;
       je = var10000;
   }

   // $FF: synthetic method
   private static String lIIIlIIll(String lllIIllIlIIlllI, String lllIIllIlIIllll) {
      try {
         String lllIIllIlIIllII = new SecretKeySpec(MessageDigest.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("죧죮좟", -412563286)).digest(lllIIllIlIIllll.getBytes(StandardCharsets.UTF_8)), jebac_vexiaqb58506wt8o3.  ‏ ("玓玽玾玦玷玸玢玹", 135623633));
         byte lllIIllIlIIlIll = Cipher.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("ꜽ꜓꜐꜈ꜙ꜖꜌ꜗ", 517056383));
         lllIIllIlIIlIll.init( jf[2], lllIIllIlIIllII);
         return new String(lllIIllIlIIlIll.doFinal(Base64.getDecoder().decode(lllIIllIlIIlllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var4) {
         var4.printStackTrace();
         return null;
      }
   }
}
