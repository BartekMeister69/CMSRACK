import java.lang.reflect.Field;

public interface jebac_vexiasxnrrk3b6ekg {
   // $FF: synthetic method
   Field getField();
}
