import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

public class jebac_vexiakytowmxlbl5k implements jebac_vexiab8fgirhwov0i {
   // $FF: synthetic field
   protected File packFile;

   // $FF: synthetic method
   public String getName() {
      return this.packFile.getName();
   }

   // $FF: synthetic method
   public jebac_vexiakytowmxlbl5k(String name, File file) {
      this.packFile = file;
   }

   // $FF: synthetic method
   public void close() {
   }

   // $FF: synthetic method
   public boolean hasDirectory(String name) {
      File file1 = new File(this.packFile, name.substring(1));
      return !file1.exists() ? false : file1.isDirectory();
   }

   // $FF: synthetic method
   public InputStream getResourceAsStream(String resName) {
      try {
         String s = jebac_vexianzkdk43wtdrt.removePrefixSuffix(resName, "/", "/");
         File file1 = new File(this.packFile, s);
         return !file1.exists() ? null : new BufferedInputStream(new FileInputStream(file1));
      } catch (Exception var4) {
         return null;
      }
   }
}
