import java.io.InputStream;

public class jebac_vexiaa46q1feamijc implements jebac_vexiab8fgirhwov0i {
   // $FF: synthetic method
   public InputStream getResourceAsStream(String resName) {
      return null;
   }

   // $FF: synthetic method
   public String getName() {
      return jebac_vexiaflhnh80r1906.packNameNone;
   }

   // $FF: synthetic method
   public void close() {
   }

   // $FF: synthetic method
   public boolean hasDirectory(String name) {
      return false;
   }
}
