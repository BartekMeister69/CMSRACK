import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.GameSettings;

public class jebac_vexia4vw9pdgkxjsi implements jebac_vexia68uke90d57nv {
   // $FF: synthetic field
   private final jebac_vexia4oibzo50ubf0 field_148324_c;
   // $FF: synthetic field
   private final Minecraft field_148325_a = Minecraft.getMinecraft();
   // $FF: synthetic field
   private final jebac_vexia4oibzo50ubf0 field_148323_b;

   // $FF: synthetic method
   public void drawEntry(int slotIndex, int x, int y, int listWidth, int slotHeight, int mouseX, int mouseY, boolean isSelected) {
      if (this.field_148323_b != null) {
         this.field_148323_b.yPosition = y;
         this.field_148323_b.drawButton(this.field_148325_a, mouseX, mouseY);
      }

      if (this.field_148324_c != null) {
         this.field_148324_c.yPosition = y;
         this.field_148324_c.drawButton(this.field_148325_a, mouseX, mouseY);
      }

   }

   // $FF: synthetic method
   public void setSelected(int p_178011_1_, int p_178011_2_, int p_178011_3_) {
   }

   // $FF: synthetic method
   public jebac_vexia4vw9pdgkxjsi(jebac_vexia4oibzo50ubf0 p_i45014_1_, jebac_vexia4oibzo50ubf0 p_i45014_2_) {
      this.field_148323_b = p_i45014_1_;
      this.field_148324_c = p_i45014_2_;
   }

   // $FF: synthetic method
   public boolean mousePressed(int slotIndex, int p_148278_2_, int p_148278_3_, int p_148278_4_, int p_148278_5_, int p_148278_6_) {
      if (this.field_148323_b.mousePressed(this.field_148325_a, p_148278_2_, p_148278_3_)) {
         if (this.field_148323_b instanceof jebac_vexiatgc7sxy17ln0) {
            this.field_148325_a.gameSettings.setOptionValue(((jebac_vexiatgc7sxy17ln0)this.field_148323_b).returnEnumOptions(), 1);
            this.field_148323_b.displayString = this.field_148325_a.gameSettings.getKeyBinding(GameSettings.Options.getEnumOptions(this.field_148323_b.id));
         }

         return true;
      } else if (this.field_148324_c != null && this.field_148324_c.mousePressed(this.field_148325_a, p_148278_2_, p_148278_3_)) {
         if (this.field_148324_c instanceof jebac_vexiatgc7sxy17ln0) {
            this.field_148325_a.gameSettings.setOptionValue(((jebac_vexiatgc7sxy17ln0)this.field_148324_c).returnEnumOptions(), 1);
            this.field_148324_c.displayString = this.field_148325_a.gameSettings.getKeyBinding(GameSettings.Options.getEnumOptions(this.field_148324_c.id));
         }

         return true;
      } else {
         return false;
      }
   }

   // $FF: synthetic method
   public void mouseReleased(int slotIndex, int x, int y, int mouseEvent, int relativeX, int relativeY) {
      if (this.field_148323_b != null) {
         this.field_148323_b.mouseReleased(x, y);
      }

      if (this.field_148324_c != null) {
         this.field_148324_c.mouseReleased(x, y);
      }

   }
}
