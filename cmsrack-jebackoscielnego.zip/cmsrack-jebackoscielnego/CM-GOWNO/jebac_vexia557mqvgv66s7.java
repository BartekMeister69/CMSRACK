import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.Map;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.renderer.RenderGlobal;

public class jebac_vexia557mqvgv66s7 {
   // $FF: synthetic method
   public static void putLaunchBlackboard(String p_putLaunchBlackboard_0_, Object p_putLaunchBlackboard_1_) {
      Map map = (Map)jebac_vexiawp5rpzl0e6ma.getFieldValue(jebac_vexiawp5rpzl0e6ma.Launch_blackboard);
      if (map != null) {
         map.put(p_putLaunchBlackboard_0_, p_putLaunchBlackboard_1_);
      }

   }

   // $FF: synthetic method
   public static InputStream getOptiFineResourceStream(String p_getOptiFineResourceStream_0_) {
      if (!jebac_vexiawp5rpzl0e6ma.OptiFineClassTransformer_instance.exists()) {
         return null;
      } else {
         Object object = jebac_vexiawp5rpzl0e6ma.getFieldValue(jebac_vexiawp5rpzl0e6ma.OptiFineClassTransformer_instance);
         if (object == null) {
            return null;
         } else {
            if (p_getOptiFineResourceStream_0_.startsWith("/")) {
               p_getOptiFineResourceStream_0_ = p_getOptiFineResourceStream_0_.substring(1);
            }

            byte[] abyte = (byte[])((byte[])((byte[])jebac_vexiawp5rpzl0e6ma.call(object, jebac_vexiawp5rpzl0e6ma.OptiFineClassTransformer_getOptiFineResource, p_getOptiFineResourceStream_0_)));
            if (abyte == null) {
               return null;
            } else {
               InputStream inputstream = new ByteArrayInputStream(abyte);
               return inputstream;
            }
         }
      }
   }

   // $FF: synthetic method
   public static boolean blockHasTileEntity(IBlockState p_blockHasTileEntity_0_) {
      Block block = p_blockHasTileEntity_0_.getBlock();
      return !jebac_vexiawp5rpzl0e6ma.ForgeBlock_hasTileEntity.exists() ? block.hasTileEntity() : jebac_vexiawp5rpzl0e6ma.callBoolean(block, jebac_vexiawp5rpzl0e6ma.ForgeBlock_hasTileEntity, p_blockHasTileEntity_0_);
   }

   // $FF: synthetic method
   public static boolean renderFirstPersonHand(RenderGlobal p_renderFirstPersonHand_0_, float p_renderFirstPersonHand_1_, int p_renderFirstPersonHand_2_) {
      return !jebac_vexiawp5rpzl0e6ma.ForgeHooksClient_renderFirstPersonHand.exists() ? false : jebac_vexiawp5rpzl0e6ma.callBoolean(jebac_vexiawp5rpzl0e6ma.ForgeHooksClient_renderFirstPersonHand, p_renderFirstPersonHand_0_, p_renderFirstPersonHand_1_, p_renderFirstPersonHand_2_);
   }
}
