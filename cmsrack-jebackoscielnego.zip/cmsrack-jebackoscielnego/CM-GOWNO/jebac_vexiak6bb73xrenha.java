import java.io.InputStream;

public class jebac_vexiak6bb73xrenha implements jebac_vexiab8fgirhwov0i {
   // $FF: synthetic method
   public String getName() {
      return jebac_vexiaflhnh80r1906.packNameDefault;
   }

   // $FF: synthetic method
   public boolean hasDirectory(String name) {
      return false;
   }

   // $FF: synthetic method
   public void close() {
   }

   // $FF: synthetic method
   public InputStream getResourceAsStream(String resName) {
      return jebac_vexiak6bb73xrenha.class.getResourceAsStream(resName);
   }
}
