import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import java.util.List;
import java.util.Map;
import java.util.Random;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;

public abstract class jebac_vexiat51dq4htxchd {
   // $FF: synthetic field
   public boolean isChild = true;
   // $FF: synthetic field
   public int textureWidth = 64;
   // $FF: synthetic field
   public float swingProgress;
   // $FF: synthetic field
   public List boxList = Lists.newArrayList();
   // $FF: synthetic field
   private Map modelTextureMap = Maps.newHashMap();
   // $FF: synthetic field
   public int textureHeight = 32;
   // $FF: synthetic field
   public boolean isRiding;

   // $FF: synthetic method
   public void render(Entity entityIn, float p_78088_2_, float p_78088_3_, float p_78088_4_, float p_78088_5_, float p_78088_6_, float scale) {
   }

   // $FF: synthetic method
   public jebac_vexiaw01u7ua1d73a getTextureOffset(String partName) {
      return (jebac_vexiaw01u7ua1d73a)this.modelTextureMap.get(partName);
   }

   // $FF: synthetic method
   public void setModelAttributes(jebac_vexiat51dq4htxchd model) {
      this.swingProgress = model.swingProgress;
      this.isRiding = model.isRiding;
      this.isChild = model.isChild;
   }

   // $FF: synthetic method
   public void setLivingAnimations(EntityLivingBase entitylivingbaseIn, float p_78086_2_, float p_78086_3_, float partialTickTime) {
   }

   // $FF: synthetic method
   public static void copyModelAngles(jebac_vexiau47ipgjckapi source, jebac_vexiau47ipgjckapi dest) {
      dest.rotateAngleX = source.rotateAngleX;
      dest.rotateAngleY = source.rotateAngleY;
      dest.rotateAngleZ = source.rotateAngleZ;
      dest.rotationPointX = source.rotationPointX;
      dest.rotationPointY = source.rotationPointY;
      dest.rotationPointZ = source.rotationPointZ;
   }

   // $FF: synthetic method
   public void setRotationAngles(float p_78087_1_, float p_78087_2_, float p_78087_3_, float p_78087_4_, float p_78087_5_, float p_78087_6_, Entity entityIn) {
   }

   // $FF: synthetic method
   public jebac_vexiau47ipgjckapi getRandomModelBox(Random rand) {
      return (jebac_vexiau47ipgjckapi)this.boxList.get(rand.nextInt(this.boxList.size()));
   }

   // $FF: synthetic method
   protected void setTextureOffset(String partName, int x, int y) {
      this.modelTextureMap.put(partName, new jebac_vexiaw01u7ua1d73a(x, y));
   }
}
