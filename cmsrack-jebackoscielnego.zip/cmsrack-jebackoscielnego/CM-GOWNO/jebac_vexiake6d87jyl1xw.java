import java.util.concurrent.Callable;
import net.minecraft.client.renderer.OpenGlHelper;

public class jebac_vexiake6d87jyl1xw implements Callable {
   // $FF: synthetic method
   public Object call() throws Exception {
      return OpenGlHelper.func_183029_j();
   }
}
