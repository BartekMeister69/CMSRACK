import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

public class jebac_vexiaty3hns3gyjac implements jebac_vexiae21v1yzd8ma8 {
   // $FF: synthetic field
   private String player = null;

   // $FF: synthetic method
   public jebac_vexiaty3hns3gyjac(String p_i72_1_) {
      this.player = p_i72_1_;
   }

   // $FF: synthetic method
   public void fileDownloadFinished(String p_fileDownloadFinished_1_, byte[] p_fileDownloadFinished_2_, Throwable p_fileDownloadFinished_3_) {
      if (p_fileDownloadFinished_2_ != null) {
         try {
            String s = new String(p_fileDownloadFinished_2_, "ASCII");
            JsonParser jsonparser = new JsonParser();
            JsonElement jsonelement = jsonparser.parse(s);
            jebac_vexia66b28ivahtuo playerconfigurationparser = new jebac_vexia66b28ivahtuo(this.player);
            jebac_vexiapcxfoumj8ln8 playerconfiguration = playerconfigurationparser.parsePlayerConfiguration(jsonelement);
            if (playerconfiguration != null) {
               playerconfiguration.setInitialized(true);
               jebac_vexiara06cijtnxiy.setPlayerConfiguration(this.player, playerconfiguration);
            }
         } catch (Exception var9) {
            jebac_vexiakrwecfs16wve.dbg("Error parsing configuration: " + p_fileDownloadFinished_1_ + ", " + var9.getClass().getName() + ": " + var9.getMessage());
         }
      }

   }
}
