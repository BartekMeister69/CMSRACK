import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;

public class jebac_vexiaaszouda0tp80 extends jebac_vexia88utjmuujofl {
   // $FF: synthetic field
   private final jebac_vexiau47ipgjckapi bipedCape;
   // $FF: synthetic field
   public jebac_vexiau47ipgjckapi bipedRightLegwear;
   // $FF: synthetic field
   private final jebac_vexiajeba1ufmgebr item;
   // $FF: synthetic field
   private final jebac_vexia57y3y6t1owoj wings;
   // $FF: synthetic field
   private final jebac_vexiau47ipgjckapi bipedDeadmau5Head;
   // $FF: synthetic field
   public jebac_vexiau47ipgjckapi bipedBodyWear;
   // $FF: synthetic field
   private final boolean smallArms;
   // $FF: synthetic field
   private final jebac_vexia4bw0ukdih5op crown;
   // $FF: synthetic field
   public jebac_vexiau47ipgjckapi bipedRightArmwear;
   // $FF: synthetic field
   private final jebac_vexiavdm51ia04gsr basicHat;
   // $FF: synthetic field
   private final jebac_vexiai9o9gt6qqu7h santaHat;
   // $FF: synthetic field
   public jebac_vexiau47ipgjckapi bipedLeftLegwear;
   // $FF: synthetic field
   public jebac_vexiau47ipgjckapi bipedLeftArmwear;

   // $FF: synthetic method
   public jebac_vexiaaszouda0tp80(float p_i46304_1_, boolean p_i46304_2_) {
      super(p_i46304_1_, 0.0F, 64, 64);
      this.smallArms = p_i46304_2_;
      this.bipedDeadmau5Head = new jebac_vexiau47ipgjckapi(this, 24, 0);
      this.bipedDeadmau5Head.addBox(-3.0F, -6.0F, -1.0F, 6, 6, 1, p_i46304_1_);
      this.bipedCape = new jebac_vexiau47ipgjckapi(this, 0, 0);
      this.bipedCape.setTextureSize(64, 32);
      this.bipedCape.addBox(-5.0F, 0.0F, -1.0F, 10, 16, 1, p_i46304_1_);
      if (p_i46304_2_) {
         this.bipedLeftArm = new jebac_vexiau47ipgjckapi(this, 32, 48);
         this.bipedLeftArm.addBox(-1.0F, -2.0F, -2.0F, 3, 12, 4, p_i46304_1_);
         this.bipedLeftArm.setRotationPoint(5.0F, 2.5F, 0.0F);
         this.bipedRightArm = new jebac_vexiau47ipgjckapi(this, 40, 16);
         this.bipedRightArm.addBox(-2.0F, -2.0F, -2.0F, 3, 12, 4, p_i46304_1_);
         this.bipedRightArm.setRotationPoint(-5.0F, 2.5F, 0.0F);
         this.bipedLeftArmwear = new jebac_vexiau47ipgjckapi(this, 48, 48);
         this.bipedLeftArmwear.addBox(-1.0F, -2.0F, -2.0F, 3, 12, 4, p_i46304_1_ + 0.25F);
         this.bipedLeftArmwear.setRotationPoint(5.0F, 2.5F, 0.0F);
         this.bipedRightArmwear = new jebac_vexiau47ipgjckapi(this, 40, 32);
         this.bipedRightArmwear.addBox(-2.0F, -2.0F, -2.0F, 3, 12, 4, p_i46304_1_ + 0.25F);
         this.bipedRightArmwear.setRotationPoint(-5.0F, 2.5F, 10.0F);
      } else {
         this.bipedLeftArm = new jebac_vexiau47ipgjckapi(this, 32, 48);
         this.bipedLeftArm.addBox(-1.0F, -2.0F, -2.0F, 4, 12, 4, p_i46304_1_);
         this.bipedLeftArm.setRotationPoint(5.0F, 2.0F, 0.0F);
         this.bipedLeftArmwear = new jebac_vexiau47ipgjckapi(this, 48, 48);
         this.bipedLeftArmwear.addBox(-1.0F, -2.0F, -2.0F, 4, 12, 4, p_i46304_1_ + 0.25F);
         this.bipedLeftArmwear.setRotationPoint(5.0F, 2.0F, 0.0F);
         this.bipedRightArmwear = new jebac_vexiau47ipgjckapi(this, 40, 32);
         this.bipedRightArmwear.addBox(-3.0F, -2.0F, -2.0F, 4, 12, 4, p_i46304_1_ + 0.25F);
         this.bipedRightArmwear.setRotationPoint(-5.0F, 2.0F, 10.0F);
      }

      this.bipedLeftLeg = new jebac_vexiau47ipgjckapi(this, 16, 48);
      this.bipedLeftLeg.addBox(-2.0F, 0.0F, -2.0F, 4, 12, 4, p_i46304_1_);
      this.bipedLeftLeg.setRotationPoint(1.9F, 12.0F, 0.0F);
      this.bipedLeftLegwear = new jebac_vexiau47ipgjckapi(this, 0, 48);
      this.bipedLeftLegwear.addBox(-2.0F, 0.0F, -2.0F, 4, 12, 4, p_i46304_1_ + 0.25F);
      this.bipedLeftLegwear.setRotationPoint(1.9F, 12.0F, 0.0F);
      this.bipedRightLegwear = new jebac_vexiau47ipgjckapi(this, 0, 32);
      this.bipedRightLegwear.addBox(-2.0F, 0.0F, -2.0F, 4, 12, 4, p_i46304_1_ + 0.25F);
      this.bipedRightLegwear.setRotationPoint(-1.9F, 12.0F, 0.0F);
      this.bipedBodyWear = new jebac_vexiau47ipgjckapi(this, 16, 32);
      this.bipedBodyWear.addBox(-4.0F, 0.0F, -2.0F, 8, 12, 4, p_i46304_1_ + 0.25F);
      this.bipedBodyWear.setRotationPoint(0.0F, 0.0F, 0.0F);
      this.basicHat = new jebac_vexiavdm51ia04gsr(this);
      this.item = new jebac_vexiajeba1ufmgebr(this);
      this.wings = new jebac_vexia57y3y6t1owoj();
      this.crown = new jebac_vexia4bw0ukdih5op(this);
      this.santaHat = new jebac_vexiai9o9gt6qqu7h(this);
   }

   // $FF: synthetic method
   public void renderDeadmau5Head(float p_178727_1_) {
      copyModelAngles(this.bipedHead, this.bipedDeadmau5Head);
      this.bipedDeadmau5Head.rotationPointX = 0.0F;
      this.bipedDeadmau5Head.rotationPointY = 0.0F;
      this.bipedDeadmau5Head.render(p_178727_1_);
   }

   // $FF: synthetic method
   public void postRenderArm(float scale) {
      if (this.smallArms) {
         ++this.bipedRightArm.rotationPointX;
         this.bipedRightArm.postRender(scale);
         --this.bipedRightArm.rotationPointX;
      } else {
         this.bipedRightArm.postRender(scale);
      }

   }

   // $FF: synthetic method
   public void renderCape(float p_178728_1_) {
      this.bipedCape.render(p_178728_1_);
   }

   // $FF: synthetic method
   public void setRotationAngles(float p_78087_1_, float p_78087_2_, float p_78087_3_, float p_78087_4_, float p_78087_5_, float p_78087_6_, Entity entityIn) {
      super.setRotationAngles(p_78087_1_, p_78087_2_, p_78087_3_, p_78087_4_, p_78087_5_, p_78087_6_, entityIn);
      copyModelAngles(this.bipedLeftLeg, this.bipedLeftLegwear);
      copyModelAngles(this.bipedRightLeg, this.bipedRightLegwear);
      copyModelAngles(this.bipedLeftArm, this.bipedLeftArmwear);
      copyModelAngles(this.bipedRightArm, this.bipedRightArmwear);
      copyModelAngles(this.bipedBody, this.bipedBodyWear);
   }

   // $FF: synthetic method
   public void renderLeftArm() {
      this.bipedLeftArm.render(0.0625F);
      this.bipedLeftArmwear.render(0.0625F);
   }

   // $FF: synthetic method
   public void setInvisible(boolean invisible) {
      super.setInvisible(invisible);
      this.bipedLeftArmwear.showModel = invisible;
      this.bipedRightArmwear.showModel = invisible;
      this.bipedLeftLegwear.showModel = invisible;
      this.bipedRightLegwear.showModel = invisible;
      this.bipedBodyWear.showModel = invisible;
      this.bipedCape.showModel = invisible;
      this.bipedDeadmau5Head.showModel = invisible;
   }

   // $FF: synthetic method
   public void render(Entity entityIn, float p_78088_2_, float p_78088_3_, float p_78088_4_, float p_78088_5_, float p_78088_6_, float scale) {
      super.render(entityIn, p_78088_2_, p_78088_3_, p_78088_4_, p_78088_5_, p_78088_6_, scale);
      GlStateManager.pushMatrix();
      if (this.isChild) {
         float f = 2.0F;
         GlStateManager.scale(1.0F / f, 1.0F / f, 1.0F / f);
         GlStateManager.translate(0.0F, 24.0F * scale, 0.0F);
         this.bipedLeftLegwear.render(scale);
         this.bipedRightLegwear.render(scale);
         this.bipedLeftArmwear.render(scale);
         this.bipedRightArmwear.render(scale);
         this.bipedBodyWear.render(scale);
      } else {
         if (entityIn.isSneaking()) {
            GlStateManager.translate(0.0F, 0.2F, 0.0F);
         }

         this.bipedLeftLegwear.render(scale);
         this.bipedRightLegwear.render(scale);
         this.bipedLeftArmwear.render(scale);
         this.bipedRightArmwear.render(scale);
         this.bipedBodyWear.render(scale);
      }

      if (jebac_vexiawzpzy1x3sez8. cd && jebac_vexiawzpzy1x3sez8. cb.containsKey(entityIn.getName())) {
         this.wings.render((EntityPlayer)entityIn, (Integer)jebac_vexiawzpzy1x3sez8. cb.get(entityIn.getName()));
      }

      if (jebac_vexiawzpzy1x3sez8. cc && jebac_vexiawzpzy1x3sez8. bs.containsKey(entityIn.getName())) {
         Integer id = (Integer)jebac_vexiawzpzy1x3sez8. bs.get(entityIn.getName());
         switch(id) {
         case 1:
         case 2:
         case 3:
         case 4:
         case 5:
            this.basicHat.render(entityIn, scale, id);
            break;
         case 6:
            this.crown.render(entityIn);
            break;
         case 7:
            this.santaHat.render(entityIn, scale, p_78088_4_);
         }
      }

      if (jebac_vexiawzpzy1x3sez8. br && jebac_vexiawzpzy1x3sez8. bo.containsKey(entityIn.getName())) {
         this.item.render((EntityPlayer)entityIn, (Integer)jebac_vexiawzpzy1x3sez8. bo.get(entityIn.getName()));
      }

      GlStateManager.popMatrix();
   }

   // $FF: synthetic method
   public void renderRightArm() {
      this.bipedRightArm.render(0.0625F);
      this.bipedRightArmwear.render(0.0625F);
   }
}
