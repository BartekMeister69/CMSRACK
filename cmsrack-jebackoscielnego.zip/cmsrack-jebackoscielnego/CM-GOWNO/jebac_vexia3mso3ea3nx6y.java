public class jebac_vexia3mso3ea3nx6y extends jebac_vexia4oibzo50ubf0 {
   private final jebac_vexiatj0yt8p6od53  gv;
   private static final int[]  gw;

   // $FF: synthetic method
   private static void lllllIIl() {
       gw = new int[2];
       gw[0] = 54 + 91 - 73 + 58 + (60 ^ 39) - (88 ^ 10) + (219 ^ 144);
       gw[1] = 146 + 143 - 194 + 66 ^ 0 + 122 - 2 + 61;
   }

   // $FF: synthetic method
   jebac_vexia3mso3ea3nx6y(int var1, int var2, int var3, String var4, jebac_vexiatj0yt8p6od53 var5) {
      super(var1, var2, var3,  gw[0],  gw[1], var4);
      this. gv = var5;
   }

   static {
      lllllIIl();
   }

   // $FF: synthetic method
   public jebac_vexiatj0yt8p6od53 getEnum() {
      return this. gv;
   }
}
