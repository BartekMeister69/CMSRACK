import java.awt.Color;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.resources.I18n;

public class jebac_vexiafvn8jpnskm4h extends jebac_vexiakl614w3uw0xg {
   private static final String[]  gb;
   private static final int[]  ga;
   private final jebac_vexiakl614w3uw0xg  gc;
   private jebac_vexia1571lv7keca1  gd;

   // $FF: synthetic method
   protected void mouseClickMove(int var1, int var2, int var3, long var4) {
      super.mouseClickMove(var1, var2, var3, var4);
      this.update();
   }

   // $FF: synthetic method
   private static void llllI() {
       gb = new String[ ga[22]];
       gb[ ga[0]] = llIll(jebac_vexiaqb58506wt8o3.  ‏ ("\ue816\ue85b\ue85c\ue85c\ue878\ue861\ue85b\ue868\ue817\ue842\ue819\ue86d\ue878\ue85e\ue85d\ue85e\ue87e\ue87a\ue845\ue85f\ue86b\ue819\ue85a\ue859\ue878\ue857\ue818\ue81a\ue857\ue865\ue87d\ue805", 1811081262), jebac_vexiaqb58506wt8o3.  ‏ ("䳤䳶䳎䳖䳿", 652758206));
       gb[ ga[6]] = lllII(jebac_vexiaqb58506wt8o3.  ‏ ("阴阾阌阶阱阕阱阻阵阘阘降阶阘阗阺阴阆陇阔阺阮阘阹阶阷阋阻", -68905345), jebac_vexiaqb58506wt8o3.  ‏ ("ꖀꖇꖇꖺꖢ", 414885347));
       gb[ ga[1]] = llIll(jebac_vexiaqb58506wt8o3.  ‏ ("죑좟죶죛죱죛좆죃죎죐죟좉", -1812019020), jebac_vexiaqb58506wt8o3.  ‏ ("\ueeda\ueef8\ueeec\ueec4\ueed1", 1627647637));
       gb[ ga[9]] = lllIl(jebac_vexiaqb58506wt8o3.  ‏ ("\ufade\ufaf4\ufafd\ufafc瘝遲鬒䀹\ufae7𣏕\ufadf鉶頻瑱𢡊䀹\ufaf9\ufafd㮝鬒鬒\ufae2直直", -629736811), jebac_vexiaqb58506wt8o3.  ‏ ("죏죈주죀죊", 1710540953));
       gb[ ga[12]] = llIll(jebac_vexiaqb58506wt8o3.  ‏ ("\uec2b\uec33\uec3f\uec10\uec62\uec1a\uec10\uec0a\uec36\uec13\uec1c\uec34\uec14\uec3f\uec39\uec1a\uec6a\uec3f\uec07\uec35\uec62\uec03\uec6f\uec6f", 933817426), jebac_vexiaqb58506wt8o3.  ‏ ("箬箑箪箯箄", -1832158270));
       gb[ ga[7]] = lllIl(jebac_vexiaqb58506wt8o3.  ‏ ("蔽蔰蔆蔋蔩蔌蕴蔬蕧蔎蔒蕢", 1320781151), jebac_vexiaqb58506wt8o3.  ‏ ("孝孀孡孰孛", 155212565));
       gb[ ga[3]] = llIll(jebac_vexiaqb58506wt8o3.  ‏ ("뇤뇊놽뇭뇞뇲뇼놺뇛뇨뇊놶", 1345630603), jebac_vexiaqb58506wt8o3.  ‏ ("\ue7bc\ue7a3\ue78d\ue7b0\ue797", -1886918668));
       gb[ ga[13]] = lllII(jebac_vexiaqb58506wt8o3.  ‏ ("턮턱턯턖턩턕텟텟", -228535966), jebac_vexiaqb58506wt8o3.  ‏ ("釗釗釀釖釬", -1410297416));
       gb[ ga[14]] = lllII(jebac_vexiaqb58506wt8o3.  ‏ ("狰狭狯狙狴狔狍犃", 1367896766), jebac_vexiaqb58506wt8o3.  ‏ ("셟셛셈셎션", 1463140653));
       gb[ ga[15]] = lllIl(jebac_vexiaqb58506wt8o3.  ‏ ("疫痖痍痤疶痈痎痁疶痹痫疽", 2020570496), jebac_vexiaqb58506wt8o3.  ‏ ("ᾁᾧᾠᾲ\u1fb5", -388816922));
       gb[ ga[16]] = lllII(jebac_vexiaqb58506wt8o3.  ‏ ("譡譤謞證", -1583117530), jebac_vexiaqb58506wt8o3.  ‏ ("\uea90\uea80\ueab6\ueaa3\uea92", 405727962));
       gb[ ga[17]] = llIll(jebac_vexiaqb58506wt8o3.  ‏ ("毸毜毬毌毲毵毠毳毧毡毯残", -1324389450), jebac_vexiaqb58506wt8o3.  ‏ ("ᘤᘶᘔᘜᘸ", -1317005737));
       gb[ ga[18]] = llIll(jebac_vexiaqb58506wt8o3.  ‏ ("䭑䭱䭥䭘䭎䭁䭘䭓䭭䭁䭄䬴", 568085257), jebac_vexiaqb58506wt8o3.  ‏ ("諈諶諟請諶", -661288281));
       gb[ ga[19]] = lllIl(jebac_vexiaqb58506wt8o3.  ‏ ("ӠӺ҄ҏҜҌҝҊҝҾҪқӻ҅҈ӻҡқҬҢҜҿҽ҄ҳ҃҆ӤґӳҮҼҀҸҌұҜӻҽүҢҡҬӶ", -2026437429), jebac_vexiaqb58506wt8o3.  ‏ ("\ua4cdꓽꓟꓣꓶ", 681288855));
   }

   // $FF: synthetic method
   private static boolean lIIIIl(int var0) {
      return var0 != 0;
   }

   // $FF: synthetic method
   public void initGui() {
      this.buttonList.add(new jebac_vexia4oibzo50ubf0( ga[0], this.width /  ga[1] -  ga[2], this.height /  ga[3] -  ga[3],  ga[4],  ga[5], String.valueOf((new StringBuilder()).append( gb[ ga[0]]).append(jebac_vexiaau3mg1q92fzj. dz. k.getName()))));
      jebac_vexiaqb58506wt8o3.  ‏ ("", -852003233).length();
      List var10000 = this.buttonList;
      jebac_vexia4oibzo50ubf0 var10001 = new jebac_vexia4oibzo50ubf0;
      int var10003 =  ga[6];
      int var10004 = this.width /  ga[1] +  ga[7];
      int var10005 = this.height /  ga[3] -  ga[3];
      int var10006 =  ga[4];
      int var10007 =  ga[5];
      StringBuilder var10008 = (new StringBuilder()).append( gb[ ga[6]]);
      String var10009;
      if (lIIIIl(jebac_vexiaau3mg1q92fzj. dz. j)) {
         var10009 =  gb[ ga[1]];
         jebac_vexiaqb58506wt8o3.  ‏ ("", 1357576358).length();
         if (jebac_vexiaqb58506wt8o3.  ‏ ("ᖛᖛᖛ", -985852485).length() < 0) {
            return;
         }
      } else {
         var10009 = jebac_vexiacs3qcki5ln4n.toString(jebac_vexiaau3mg1q92fzj. dz. i);
      }

      var10001.<init>(var10003, var10004, var10005, var10006, var10007, String.valueOf(var10008.append(var10009)));
      var10000.add(var10001);
      jebac_vexiaqb58506wt8o3.  ‏ ("", -666991606).length();
      this.buttonList.add(this. gd = new jebac_vexia1571lv7keca1( ga[1], this.width /  ga[1] -  ga[2], this.height /  ga[3] +  ga[8] -  ga[3],  ga[4],  ga[5],  gb[ ga[9]], 1.0D, 10.0D, (double)jebac_vexiaau3mg1q92fzj. dz. n));
      jebac_vexiaqb58506wt8o3.  ‏ ("", -767393242).length();
      this.buttonList.add(new jebac_vexia4oibzo50ubf0( ga[9], this.width /  ga[1] -  ga[10], this.height /  ga[3] +  ga[11], I18n.format( gb[ ga[12]])));
      jebac_vexiaqb58506wt8o3.  ‏ ("", -2015614138).length();
   }

   // $FF: synthetic method
   private static void lllll() {
       ga = new int[23];
       ga[0] = (125 ^ 21 ^ 177 ^ 142) & (5 ^ 88 ^ 86 ^ 92 ^ -jebac_vexiaqb58506wt8o3.  ‏ ("\uf088", -1717636952).length());
       ga[1] = jebac_vexiaqb58506wt8o3.  ‏ ("젠젠", -1954232320).length();
       ga[2] = 59 + 64 - 105 + 137;
       ga[3] = 112 ^ 31 ^ 92 ^ 53;
       ga[4] = (40 ^ 52) + (10 ^ 42) - (171 ^ 178) + (209 ^ 162);
       ga[5] = 135 + 121 - 196 + 104 ^ 57 + 89 - -17 + 13;
       ga[6] = jebac_vexiaqb58506wt8o3.  ‏ ("៉", -54323223).length();
       ga[7] = 139 ^ 142;
       ga[8] = 169 ^ 177;
       ga[9] = jebac_vexiaqb58506wt8o3.  ‏ ("ᏐᏐᏐ", 1580667888).length();
       ga[10] = 200 ^ 172;
       ga[11] = 133 + 6 - -25 + 4;
       ga[12] = 2 ^ 61 ^ 191 ^ 132;
       ga[13] = 197 ^ 194;
       ga[14] = 90 + 153 - 178 + 109 ^ 56 + 40 - 69 + 139;
       ga[15] = 124 ^ 57 ^ 98 ^ 46;
       ga[16] = 234 ^ 176 ^ 91 ^ 11;
       ga[17] = 138 ^ 129;
       ga[18] = 58 ^ 18 ^ 70 ^ 98;
       ga[19] = 99 + 49 - 25 + 27 ^ 58 + 29 - -13 + 55;
       ga[20] = 77 ^ 23 ^ 76 ^ 25;
       ga[21] = -1 & 16777215;
       ga[22] = 52 + 73 - 20 + 37 ^ 96 + 58 - 152 + 126;
   }

   // $FF: synthetic method
   public void drawScreen(int var1, int var2, float var3) {
      this.drawDefaultBackground();
      this.drawCenteredString(this.fontRendererObj,  gb[ ga[19]], this.width /  ga[1],  ga[20],  ga[21]);
      super.drawScreen(var1, var2, var3);
   }

   // $FF: synthetic method
   private static String lllII(String var0, String var1) {
      var0 = new String(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder var2 = new StringBuilder();
      short var3 = var1.toCharArray();
      String var4 =  ga[0];
      Exception var5 = var0.toCharArray();
      char[] var6 = var5.length;
      int var7 =  ga[0];

      do {
         if (!lIIlII(var7, var6)) {
            return String.valueOf(var2);
         }

         char var8 = var5[var7];
         var2.append((char)(var8 ^ var3[var4 % var3.length]));
         jebac_vexiaqb58506wt8o3.  ‏ ("", 761192253).length();
         ++var4;
         ++var7;
         jebac_vexiaqb58506wt8o3.  ‏ ("", 1645961657).length();
      } while(-jebac_vexiaqb58506wt8o3.  ‏ ("\uec0b\uec0b", 1241705515).length() <= 0);

      return null;
   }

   // $FF: synthetic method
   private static String lllIl(String var0, String var1) {
      try {
         SecretKeySpec var2 = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("ﾲﾻￊ", -264044545)).digest(var1.getBytes(StandardCharsets.UTF_8)),  ga[14]), jebac_vexiaqb58506wt8o3.  ‏ ("↢↣↵", 514728422));
         SecretKeySpec var3 = Cipher.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("엕엔엂", -958675567));
         var3.init( ga[1], var2);
         return new String(var3.doFinal(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var9) {
         var9.printStackTrace();
         return null;
      }
   }

   // $FF: synthetic method
   private static boolean lIIlII(int var0, int var1) {
      return var0 < var1;
   }

   // $FF: synthetic method
   public jebac_vexiafvn8jpnskm4h(jebac_vexiakl614w3uw0xg var1) {
      this. gc = var1;
   }

   // $FF: synthetic method
   private static String llIll(String var0, String var1) {
      try {
         int var2 = new SecretKeySpec(MessageDigest.getInstance(jebac_vexiaqb58506wt8o3.  ‏ (";ͷ̆", -1918041293)).digest(var1.getBytes(StandardCharsets.UTF_8)), jebac_vexiaqb58506wt8o3.  ‏ ("ꢏꢡꢢꢺꢫꢤꢾꢥ", -757618483));
         String var3 = Cipher.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("\uea0a\uea24\uea27\uea3f\uea2e\uea21\uea3b\uea20", -272700856));
         var3.init( ga[1], var2);
         return new String(var3.doFinal(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var9) {
         var9.printStackTrace();
         return null;
      }
   }

   // $FF: synthetic method
   private void update() {
      jebac_vexiaau3mg1q92fzj. dz. n = (float)this. gd.getValueInt();
   }

   // $FF: synthetic method
   protected void actionPerformed(jebac_vexia4oibzo50ubf0 var1) throws IOException {
      if (lIIIIl(var1.enabled)) {
         if (lIIIlI(var1.id)) {
            jebac_vexiaau3mg1q92fzj. dz. k = jebac_vexiabjvb6fu2xswx.getNextMode(jebac_vexiaau3mg1q92fzj. dz. k);
            this.mc.displayGuiScreen(this);
            jebac_vexiaqb58506wt8o3.  ‏ ("", 1494547144).length();
            if ((189 ^ 185) <= -jebac_vexiaqb58506wt8o3.  ‏ ("崐", 708009264).length()) {
               return;
            }
         } else if (lIIIll(var1.id,  ga[6])) {
            if (lIIIIl(var1.displayString.contains( gb[ ga[7]]))) {
               jebac_vexiaau3mg1q92fzj. dz. i = Color.BLACK;
               jebac_vexiaqb58506wt8o3.  ‏ ("", 1090689158).length();
               if (((137 ^ 185 ^ 80 ^ 91) & (191 ^ 172 ^ 58 ^ 18 ^ -jebac_vexiaqb58506wt8o3.  ‏ ("㛼", -1495583012).length())) != 0) {
                  return;
               }
            } else if (lIIIIl(var1.displayString.contains( gb[ ga[3]]))) {
               jebac_vexiaau3mg1q92fzj. dz. i = Color.BLUE;
               jebac_vexiaqb58506wt8o3.  ‏ ("", 2122658388).length();
               if (-(77 + 44 - 88 + 112 ^ 82 + 54 - 32 + 45) > 0) {
                  return;
               }
            } else if (lIIIIl(var1.displayString.contains( gb[ ga[13]]))) {
               jebac_vexiaau3mg1q92fzj. dz. i = Color.GREEN;
               jebac_vexiaqb58506wt8o3.  ‏ ("", 475435153).length();
               if (jebac_vexiaqb58506wt8o3.  ‏ ("笡", -2107802879).length() > jebac_vexiaqb58506wt8o3.  ‏ ("\ue588", 567141800).length()) {
                  return;
               }
            } else if (lIIIIl(var1.displayString.contains( gb[ ga[14]]))) {
               jebac_vexiaau3mg1q92fzj. dz. i = Color.MAGENTA;
               jebac_vexiaqb58506wt8o3.  ‏ ("", -1359882208).length();
               if (null != null) {
                  return;
               }
            } else if (lIIIIl(var1.displayString.contains( gb[ ga[15]]))) {
               jebac_vexiaau3mg1q92fzj. dz. i = Color.RED;
               jebac_vexiaqb58506wt8o3.  ‏ ("", -1504453565).length();
               if (jebac_vexiaqb58506wt8o3.  ‏ ("⛩⛩", 1735468745).length() == -jebac_vexiaqb58506wt8o3.  ‏ ("頰", 2057476112).length()) {
                  return;
               }
            } else if (lIIIIl(var1.displayString.contains( gb[ ga[16]]))) {
               jebac_vexiaau3mg1q92fzj. dz. i = Color.YELLOW;
               jebac_vexiaqb58506wt8o3.  ‏ ("", -273367004).length();
               if (((74 ^ 103) & ~(150 ^ 187)) != 0) {
                  return;
               }
            } else if (lIIIIl(var1.displayString.contains( gb[ ga[17]]))) {
               jebac_vexiaau3mg1q92fzj. dz. i = Color.CYAN;
               jebac_vexiaqb58506wt8o3.  ‏ ("", -713278393).length();
               if (jebac_vexiaqb58506wt8o3.  ‏ ("뢎", 1623505070).length() != jebac_vexiaqb58506wt8o3.  ‏ ("₠", 1178214528).length()) {
                  return;
               }
            } else if (lIIIIl(var1.displayString.contains( gb[ ga[18]]))) {
               jebac_vexiaau3mg1q92fzj. dz. j = (boolean) ga[6];
               jebac_vexiaqb58506wt8o3.  ‏ ("", 1760312355).length();
               if (null != null) {
                  return;
               }
            } else {
               jebac_vexiaau3mg1q92fzj. dz. i = Color.WHITE;
               jebac_vexiaau3mg1q92fzj. dz. j = (boolean) ga[0];
            }

            this.mc.displayGuiScreen(this);
            jebac_vexiaqb58506wt8o3.  ‏ ("", 1252655518).length();
            if (-(82 ^ 44 ^ 234 ^ 144) >= 0) {
               return;
            }
         } else if (lIIIll(var1.id,  ga[9])) {
            this.mc.displayGuiScreen(this. gc);
         }

         jebac_vexia67ba3dligh23.save();
      }

   }

   static {
      lllll();
      llllI();
   }

   // $FF: synthetic method
   private static boolean lIIIlI(int var0) {
      return var0 == 0;
   }

   // $FF: synthetic method
   protected void mouseClicked(int var1, int var2, int var3) throws IOException {
      super.mouseClicked(var1, var2, var3);
      this.update();
   }

   // $FF: synthetic method
   private static boolean lIIIll(int var0, int var1) {
      return var0 == var1;
   }

   // $FF: synthetic method
   protected void mouseReleased(int var1, int var2, int var3) {
      super.mouseReleased(var1, var2, var3);
      this.update();
   }
}
