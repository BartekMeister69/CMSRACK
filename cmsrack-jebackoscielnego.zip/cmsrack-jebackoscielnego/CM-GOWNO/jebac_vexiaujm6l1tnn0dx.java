import java.io.IOException;
import java.util.Iterator;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.resources.I18n;
import net.minecraft.util.EnumChatFormatting;

public class jebac_vexiaujm6l1tnn0dx extends jebac_vexiakl614w3uw0xg implements jebac_vexiaa9gjo3qagx3k {
   // $FF: synthetic field
   private boolean field_146346_f = false;
   // $FF: synthetic field
   private int enableButtonsTimer;

   // $FF: synthetic method
   public void initGui() {
      this.buttonList.clear();
      if (this.mc.theWorld.getWorldInfo().isHardcoreModeEnabled()) {
         if (this.mc.isIntegratedServerRunning()) {
            this.buttonList.add(new jebac_vexia4oibzo50ubf0(1, this.width / 2 - 100, this.height / 4 + 96, I18n.format("deathScreen.deleteWorld")));
         } else {
            this.buttonList.add(new jebac_vexia4oibzo50ubf0(1, this.width / 2 - 100, this.height / 4 + 96, I18n.format("deathScreen.leaveServer")));
         }
      } else {
         this.buttonList.add(new jebac_vexia4oibzo50ubf0(0, this.width / 2 - 100, this.height / 4 + 72, I18n.format("deathScreen.respawn")));
         this.buttonList.add(new jebac_vexia4oibzo50ubf0(1, this.width / 2 - 100, this.height / 4 + 96, I18n.format("deathScreen.titleScreen")));
         if (this.mc.getSession() == null) {
            ((jebac_vexia4oibzo50ubf0)this.buttonList.get(1)).enabled = false;
         }
      }

      jebac_vexia4oibzo50ubf0 guibutton;
      for(Iterator var1 = this.buttonList.iterator(); var1.hasNext(); guibutton.enabled = false) {
         guibutton = (jebac_vexia4oibzo50ubf0)var1.next();
      }

   }

   // $FF: synthetic method
   protected void actionPerformed(jebac_vexia4oibzo50ubf0 button) throws IOException {
      switch(button.id) {
      case 0:
         this.mc.thePlayer.respawnPlayer();
         this.mc.displayGuiScreen((jebac_vexiakl614w3uw0xg)null);
         break;
      case 1:
         if (this.mc.theWorld.getWorldInfo().isHardcoreModeEnabled()) {
            this.mc.displayGuiScreen(new jebac_vexiajsj9h47ef5xh());
         } else {
            jebac_vexianjbtt6en4mmt guiyesno = new jebac_vexianjbtt6en4mmt(this, I18n.format("deathScreen.quit.confirm"), "", I18n.format("deathScreen.titleScreen"), I18n.format("deathScreen.respawn"), 0);
            this.mc.displayGuiScreen(guiyesno);
            guiyesno.setButtonDelay(20);
         }
      }

   }

   // $FF: synthetic method
   public boolean doesGuiPauseGame() {
      return false;
   }

   // $FF: synthetic method
   public void confirmClicked(boolean result, int id) {
      if (result) {
         this.mc.theWorld.sendQuittingDisconnectingPacket();
         this.mc.loadWorld((WorldClient)null);
         this.mc.displayGuiScreen(new jebac_vexiajsj9h47ef5xh());
      } else {
         this.mc.thePlayer.respawnPlayer();
         this.mc.displayGuiScreen((jebac_vexiakl614w3uw0xg)null);
      }

   }

   // $FF: synthetic method
   protected void keyTyped(char typedChar, int keyCode) throws IOException {
   }

   // $FF: synthetic method
   public void drawScreen(int mouseX, int mouseY, float partialTicks) {
      this.drawGradientRect(0, 0, this.width, this.height, 1615855616, -1602211792);
      GlStateManager.pushMatrix();
      GlStateManager.scale(2.0F, 2.0F, 2.0F);
      boolean flag = this.mc.theWorld.getWorldInfo().isHardcoreModeEnabled();
      String s = flag ? I18n.format("deathScreen.title.hardcore") : I18n.format("deathScreen.title");
      this.drawCenteredString(this.fontRendererObj, s, this.width / 2 / 2, 30, 16777215);
      GlStateManager.popMatrix();
      if (flag) {
         this.drawCenteredString(this.fontRendererObj, I18n.format("deathScreen.hardcoreInfo"), this.width / 2, 144, 16777215);
      }

      this.drawCenteredString(this.fontRendererObj, I18n.format("deathScreen.score") + ": " + EnumChatFormatting.YELLOW + this.mc.thePlayer.getScore(), this.width / 2, 100, 16777215);
      super.drawScreen(mouseX, mouseY, partialTicks);
   }

   // $FF: synthetic method
   public void updateScreen() {
      super.updateScreen();
      ++this.enableButtonsTimer;
      jebac_vexia4oibzo50ubf0 guibutton;
      if (this.enableButtonsTimer == 20) {
         for(Iterator var1 = this.buttonList.iterator(); var1.hasNext(); guibutton.enabled = true) {
            guibutton = (jebac_vexia4oibzo50ubf0)var1.next();
         }
      }

   }
}
