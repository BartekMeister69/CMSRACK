enum jebac_vexia6w78omqjo6ey {
   private static final jebac_vexia6w78omqjo6ey[] $VALUES = new jebac_vexia6w78omqjo6ey[]{LOCKED, LOCKED_HOVER, LOCKED_DISABLED, UNLOCKED, UNLOCKED_HOVER, UNLOCKED_DISABLED};
   // $FF: synthetic field
   UNLOCKED(20, 146);

   // $FF: synthetic field
   private final int field_178914_g;
   // $FF: synthetic field
   UNLOCKED_HOVER(20, 166),
   // $FF: synthetic field
   UNLOCKED_DISABLED(20, 186),
   // $FF: synthetic field
   LOCKED_DISABLED(0, 186),
   // $FF: synthetic field
   LOCKED(0, 146),
   // $FF: synthetic field
   LOCKED_HOVER(0, 166);

   // $FF: synthetic field
   private final int field_178920_h;

   // $FF: synthetic method
   public int func_178910_a() {
      return this.field_178914_g;
   }

   // $FF: synthetic method
   public int func_178912_b() {
      return this.field_178920_h;
   }

   // $FF: synthetic method
   private jebac_vexia6w78omqjo6ey(int p_i45537_3_, int p_i45537_4_) {
      this.field_178914_g = p_i45537_3_;
      this.field_178920_h = p_i45537_4_;
   }
}
