import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonParser;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import javax.imageio.ImageIO;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ResourceLocation;

public class jebac_vexia66b28ivahtuo {
   // $FF: synthetic field
   private String player = null;

   // $FF: synthetic method
   private jebac_vexiaygbu8cvjfpcg downloadModel(String p_downloadModel_1_) {
      String s = "http://s.optifine.net/" + p_downloadModel_1_;

      try {
         byte[] abyte = jebac_vexia7dtg4ljk048p.get(s, Minecraft.getMinecraft().getProxy());
         String s1 = new String(abyte, StandardCharsets.US_ASCII);
         JsonParser jsonparser = new JsonParser();
         JsonObject jsonobject = (JsonObject)jsonparser.parse(s1);
         return jebac_vexiaffiyjf6kn6jt.parseItemModel(jsonobject);
      } catch (Exception var7) {
         jebac_vexiakrwecfs16wve.warn("Error loading item model " + p_downloadModel_1_ + ": " + var7.getClass().getName() + ": " + var7.getMessage());
         return null;
      }
   }

   // $FF: synthetic method
   private BufferedImage downloadTextureImage(String p_downloadTextureImage_1_) {
      String s = "http://s.optifine.net/" + p_downloadTextureImage_1_;

      try {
         byte[] abyte = jebac_vexia7dtg4ljk048p.get(s, Minecraft.getMinecraft().getProxy());
         return ImageIO.read(new ByteArrayInputStream(abyte));
      } catch (IOException var4) {
         jebac_vexiakrwecfs16wve.warn("Error loading item texture " + p_downloadTextureImage_1_ + ": " + var4.getClass().getName() + ": " + var4.getMessage());
         return null;
      }
   }

   // $FF: synthetic method
   public jebac_vexia66b28ivahtuo(String p_i71_1_) {
      this.player = p_i71_1_;
   }

   // $FF: synthetic method
   public jebac_vexiapcxfoumj8ln8 parsePlayerConfiguration(JsonElement p_parsePlayerConfiguration_1_) {
      if (p_parsePlayerConfiguration_1_ == null) {
         throw new JsonParseException("JSON object is null, player: " + this.player);
      } else {
         JsonObject jsonobject = (JsonObject)p_parsePlayerConfiguration_1_;
         jebac_vexiapcxfoumj8ln8 playerconfiguration = new jebac_vexiapcxfoumj8ln8();
         JsonArray jsonarray = (JsonArray)jsonobject.get("items");
         if (jsonarray != null) {
            for(int i = 0; i < jsonarray.size(); ++i) {
               JsonObject jsonobject1 = (JsonObject)jsonarray.get(i);
               boolean flag = jebac_vexia10ed95amnpom.getBoolean(jsonobject1, "active", true);
               if (flag) {
                  String s = jebac_vexia10ed95amnpom.getString(jsonobject1, "type");
                  if (s == null) {
                     jebac_vexiakrwecfs16wve.warn("Item type is null, player: " + this.player);
                  } else {
                     String s1 = jebac_vexia10ed95amnpom.getString(jsonobject1, "model");
                     if (s1 == null) {
                        s1 = "items/" + s + "/model.cfg";
                     }

                     jebac_vexiaygbu8cvjfpcg playeritemmodel = this.downloadModel(s1);
                     if (playeritemmodel != null) {
                        if (!playeritemmodel.isUsePlayerTexture()) {
                           String s2 = jebac_vexia10ed95amnpom.getString(jsonobject1, "texture");
                           if (s2 == null) {
                              s2 = "items/" + s + "/users/" + this.player + ".png";
                           }

                           BufferedImage bufferedimage = this.downloadTextureImage(s2);
                           if (bufferedimage == null) {
                              continue;
                           }

                           playeritemmodel.setTextureImage(bufferedimage);
                           ResourceLocation resourcelocation = new ResourceLocation("optifine.net", s2);
                           playeritemmodel.setTextureLocation(resourcelocation);
                        }

                        playerconfiguration.addPlayerItemModel(playeritemmodel);
                     }
                  }
               }
            }
         }

         return playerconfiguration;
      }
   }
}
