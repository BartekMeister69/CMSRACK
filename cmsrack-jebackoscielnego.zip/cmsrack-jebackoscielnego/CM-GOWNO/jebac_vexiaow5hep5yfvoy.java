import java.util.Iterator;
import java.util.NoSuchElementException;
import net.minecraft.util.BlockPos;

public class jebac_vexiaow5hep5yfvoy implements Iterator {
   // $FF: synthetic field
   private int xStart;
   // $FF: synthetic field
   private double zNext;
   // $FF: synthetic field
   private double yNext;
   // $FF: synthetic field
   private double zStart;
   // $FF: synthetic field
   private double yDelta;
   // $FF: synthetic field
   private double zDelta;
   // $FF: synthetic field
   private double yEnd;
   // $FF: synthetic field
   private double yStart;
   // $FF: synthetic field
   private int xEnd;
   // $FF: synthetic field
   private jebac_vexiaisxd96hccl8m pos = new jebac_vexiaisxd96hccl8m(0, 0, 0);
   // $FF: synthetic field
   private double zEnd;
   // $FF: synthetic field
   private boolean hasNext = false;
   // $FF: synthetic field
   private int xNext;

   // $FF: synthetic method
   public BlockPos next() {
      if (!this.hasNext) {
         throw new NoSuchElementException();
      } else {
         this.pos.setXyz((double)this.xNext, this.yNext, this.zNext);
         this.nextPos();
         this.hasNext = this.xNext < this.xEnd && this.yNext < this.yEnd && this.zNext < this.zEnd;
         return this.pos;
      }
   }

   // $FF: synthetic method
   private void nextPos() {
      ++this.zNext;
      if (this.zNext >= this.zEnd) {
         this.zNext = this.zStart;
         ++this.yNext;
         if (this.yNext >= this.yEnd) {
            this.yNext = this.yStart;
            this.yStart += this.yDelta;
            this.yEnd += this.yDelta;
            this.yNext = this.yStart;
            this.zStart += this.zDelta;
            this.zEnd += this.zDelta;
            this.zNext = this.zStart;
            ++this.xNext;
         }
      }

   }

   // $FF: synthetic method
   public boolean hasNext() {
      return this.hasNext;
   }

   // $FF: synthetic method
   public void remove() {
      throw new RuntimeException("Not implemented");
   }

   // $FF: synthetic method
   public jebac_vexiaow5hep5yfvoy(BlockPos posStart, BlockPos posEnd, double yDelta, double zDelta) {
      this.yDelta = yDelta;
      this.zDelta = zDelta;
      this.xStart = posStart.getX();
      this.xEnd = posEnd.getX();
      this.yStart = (double)posStart.getY();
      this.yEnd = (double)posEnd.getY() - 0.5D;
      this.zStart = (double)posStart.getZ();
      this.zEnd = (double)posEnd.getZ() - 0.5D;
      this.xNext = this.xStart;
      this.yNext = this.yStart;
      this.zNext = this.zStart;
      this.hasNext = this.xNext < this.xEnd && this.yNext < this.yEnd && this.zNext < this.zEnd;
   }
}
