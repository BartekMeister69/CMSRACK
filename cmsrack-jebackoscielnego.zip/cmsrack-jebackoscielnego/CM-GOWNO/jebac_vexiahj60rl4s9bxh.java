public class jebac_vexiahj60rl4s9bxh extends jebac_vexiankaoys7sjdxd {
   // $FF: synthetic field
   public static final String[] PROPERTY_VALUES = new String[]{"default", "fast", "fancy", "off"};
   // $FF: synthetic field
   public static final String[] USER_VALUES = new String[]{"Default", "Fast", "Fancy", "OFF"};

   // $FF: synthetic method
   public boolean setPropertyValue(String propVal) {
      if (jebac_vexiakrwecfs16wve.equals(propVal, "none")) {
         propVal = "off";
      }

      return super.setPropertyValue(propVal);
   }

   // $FF: synthetic method
   public jebac_vexiahj60rl4s9bxh(String propertyName, String userName, int defaultValue) {
      super(propertyName, PROPERTY_VALUES, userName, USER_VALUES, defaultValue);
   }

   // $FF: synthetic method
   public boolean isFancy() {
      return this.getValue() == 2;
   }

   // $FF: synthetic method
   public boolean isFast() {
      return this.getValue() == 1;
   }

   // $FF: synthetic method
   public boolean isOff() {
      return this.getValue() == 3;
   }

   // $FF: synthetic method
   public boolean isDefault() {
      return this.getValue() == 0;
   }
}
