import com.google.common.collect.Lists;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.resources.I18n;

public class jebac_vexiavonyz736wbrj extends jebac_vexiakl614w3uw0xg {
   // $FF: synthetic field
   private String messageLine1;
   // $FF: synthetic field
   protected String confirmButtonText;
   // $FF: synthetic field
   private int ticksUntilEnable;
   // $FF: synthetic field
   private jebac_vexiakl614w3uw0xg parentScreen;
   // $FF: synthetic field
   private final List listLines2 = Lists.newArrayList();
   // $FF: synthetic field
   private String messageLine2;

   // $FF: synthetic method
   public void initGui() {
      this.buttonList.add(new jebac_vexiatgc7sxy17ln0(0, this.width / 2 - 74, this.height / 6 + 96, this.confirmButtonText));
      this.listLines2.clear();
      this.listLines2.addAll(this.fontRendererObj.listFormattedStringToWidth(this.messageLine2, this.width - 50));
   }

   // $FF: synthetic method
   public void drawScreen(int mouseX, int mouseY, float partialTicks) {
      this.drawDefaultBackground();
      this.drawCenteredString(this.fontRendererObj, this.messageLine1, this.width / 2, 70, 16777215);
      int i = 90;

      for(Iterator var5 = this.listLines2.iterator(); var5.hasNext(); i += this.fontRendererObj.FONT_HEIGHT) {
         Object s = var5.next();
         this.drawCenteredString(this.fontRendererObj, (String)s, this.width / 2, i, 16777215);
      }

      super.drawScreen(mouseX, mouseY, partialTicks);
   }

   // $FF: synthetic method
   public jebac_vexiavonyz736wbrj(jebac_vexiakl614w3uw0xg p_i48_1_, String p_i48_2_, String p_i48_3_) {
      this.parentScreen = p_i48_1_;
      this.messageLine1 = p_i48_2_;
      this.messageLine2 = p_i48_3_;
      this.confirmButtonText = I18n.format("gui.done");
   }

   // $FF: synthetic method
   public void updateScreen() {
      super.updateScreen();
      jebac_vexia4oibzo50ubf0 guibutton;
      if (--this.ticksUntilEnable == 0) {
         for(Iterator var1 = this.buttonList.iterator(); var1.hasNext(); guibutton.enabled = true) {
            guibutton = (jebac_vexia4oibzo50ubf0)var1.next();
         }
      }

   }

   // $FF: synthetic method
   protected void actionPerformed(jebac_vexia4oibzo50ubf0 button) throws IOException {
      jebac_vexiakrwecfs16wve.getMinecraft().displayGuiScreen(this.parentScreen);
   }
}
