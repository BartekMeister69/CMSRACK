import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class jebac_vexian48zibs27a5f extends jebac_vexiakl614w3uw0xg {
   private static final int[]  fa;
   private final String  ez;
   private final String  fb;
   private static final String[]  ey;
   private final String  fc;

   // $FF: synthetic method
   private static String llI(String var0, String var1) {
      try {
         SecretKeySpec var2 = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("\ue1eb\ue1e2\ue193", 10543526)).digest(var1.getBytes(StandardCharsets.UTF_8)),  fa[10]), jebac_vexiaqb58506wt8o3.  ‏ ("憤憥憳", 999383520));
         String var3 = Cipher.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("噌噍噛", 99702280));
         var3.init( fa[1], var2);
         return new String(var3.doFinal(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var9) {
         var9.printStackTrace();
         return null;
      }
   }

   static {
      lIII();
      lll();
   }

   // $FF: synthetic method
   private static void lll() {
       ey = new String[ fa[9]];
       ey[ fa[0]] = lI(jebac_vexiaqb58506wt8o3.  ‏ ("\ue860\ue845\ue819\ue849\ue849\ue862\ue844\ue858\ue84a\ue862\ue84d\ue861\ue84f\ue87b\ue818\ue85e\ue85b\ue856\ue86c\ue84c\ue864\ue86b\ue801\ue869\ue845\ue862\ue862\ue840\ue845\ue805\ue84d\ue87d\ue842\ue849\ue858\ue841\ue87d\ue87b\ue858\ue841\ue85b\ue87b\ue85e\ue856\ue840\ue85f\ue84f\ue841\ue877\ue856\ue84d\ue874\ue81a\ue81c\ue805\ue85b\ue87a\ue864\ue856\ue86c\ue86d\ue846\ue866\ue863", -1094981586), jebac_vexiaqb58506wt8o3.  ‏ ("\u1cfb᳧᳛ᳲᳺ", -1669784428));
       ey[ fa[4]] = lI(jebac_vexiaqb58506wt8o3.  ‏ ("ɃɻɚɖɻɳɛɈɒɸɇɷɃɹȂɄɝɾɵɩɡɀȚɖɣɴɧȅɁɉɿɁɐȁɤɦȂɘɛɳɈȅȁȌ", 875627057), jebac_vexiaqb58506wt8o3.  ‏ ("둻둧둦둨둣", 1992930354));
       ey[ fa[1]] = llI(jebac_vexiaqb58506wt8o3.  ‏ ("帵帊帯帜帟帵师幭帰希帥幨帑帪帞帏师幨帰幫幤帮帄帧帺帛席帶帹帎帳帖", -1010737571), jebac_vexiaqb58506wt8o3.  ‏ ("왪와왲왱완", -40122840));
       ey[ fa[7]] = lI(jebac_vexiaqb58506wt8o3.  ‏ ("뷽붕뷪붚붖붙붟붅붰부붂붦붳뷽붞뷧붃붱붶붪붐부붚붰뷹뷹붢붻뷢뷧붐붇", -780616238), jebac_vexiaqb58506wt8o3.  ‏ ("\ufff3￮\ufff5￩ￌ", -515047520));
   }

   // $FF: synthetic method
   private static void lIII() {
       fa = new int[11];
       fa[0] = (109 ^ 57 ^ 216 ^ 183) & (40 + 67 - -54 + 21 ^ 104 + 7 - -27 + 3 ^ -jebac_vexiaqb58506wt8o3.  ‏ ("暽", 286615197).length());
       fa[1] = jebac_vexiaqb58506wt8o3.  ‏ ("辬辬", 1610780556).length();
       fa[2] = 17 ^ 127;
       fa[3] = -1 & 16777215;
       fa[4] = jebac_vexiaqb58506wt8o3.  ‏ ("篳", -1970111533).length();
       fa[5] = 22 ^ 110;
       fa[6] = (3 ^ 26) + (58 ^ 49) - -(71 ^ 115) + (176 ^ 154);
       fa[7] = jebac_vexiaqb58506wt8o3.  ‏ ("횘횘횘", 1358616248).length();
       fa[8] = (88 ^ 2) + (18 ^ 81) - (20 ^ 105) + (232 ^ 132);
       fa[9] = 59 ^ 29 ^ 97 ^ 67;
       fa[10] = 91 + 27 - 106 + 159 ^ 52 + 46 - 17 + 82;
   }

   // $FF: synthetic method
   public void drawScreen(int var1, int var2, float var3) {
      this.drawDefaultBackground();
      this.drawCenteredString(this.fontRendererObj,  ey[ fa[0]], this.width /  fa[1],  fa[2],  fa[3]);
      this.drawCenteredString(this.fontRendererObj, String.valueOf((new StringBuilder()).append( ey[ fa[4]]).append(this. ez)), this.width /  fa[1],  fa[5],  fa[3]);
      this.drawCenteredString(this.fontRendererObj, String.valueOf((new StringBuilder()).append( ey[ fa[1]]).append(this. fc)), this.width /  fa[1],  fa[6],  fa[3]);
      this.drawCenteredString(this.fontRendererObj, String.valueOf((new StringBuilder()).append( ey[ fa[7]]).append(this. fb)), this.width /  fa[1],  fa[8],  fa[3]);
      super.drawScreen(var1, var2, var3);
   }

   // $FF: synthetic method
   private static String lI(String var0, String var1) {
      try {
         String var2 = new SecretKeySpec(MessageDigest.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("ҤҭӜ", -1971911447)).digest(var1.getBytes(StandardCharsets.UTF_8)), jebac_vexiaqb58506wt8o3.  ‏ ("ԬԂԁԙԈԇԝԆ", 491717998));
         boolean var3 = Cipher.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("䋚䋴䋷䋯䋾䋱䋫䋰", -633060712));
         var3.init( fa[1], var2);
         return new String(var3.doFinal(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var9) {
         var9.printStackTrace();
         return null;
      }
   }

   // $FF: synthetic method
   protected void keyTyped(char var1, int var2) throws IOException {
   }

   // $FF: synthetic method
   public jebac_vexian48zibs27a5f(String var1, String var2, String var3) {
      this. ez = var1;
      this. fc = var2;
      this. fb = var3;
   }
}
