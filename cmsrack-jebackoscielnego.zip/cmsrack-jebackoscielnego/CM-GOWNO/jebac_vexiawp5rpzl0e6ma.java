import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.EntityRenderer;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.RendererLivingEntity;
import net.minecraft.client.renderer.tileentity.RenderItemFrame;
import net.minecraft.client.renderer.tileentity.TileEntityRendererDispatcher;
import net.minecraft.client.renderer.vertex.VertexFormatElement;
import net.minecraft.client.resources.DefaultResourcePack;
import net.minecraft.client.resources.ResourcePackRepository;
import net.minecraft.client.resources.model.ModelManager;
import net.minecraft.client.resources.model.ModelRotation;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityItemFrame;
import net.minecraft.item.Item;
import net.minecraft.item.ItemRecord;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumWorldBlockLayer;
import net.minecraft.world.World;
import net.minecraft.world.WorldProvider;
import net.minecraft.world.biome.BiomeGenBase;

public class jebac_vexiawp5rpzl0e6ma {
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 ForgeTileEntityRendererDispatcher_drawBatch;
   // $FF: synthetic field
   public static jebac_vexia061cdu2llyx7 EntityViewRenderEvent_FogColors_blue;
   // $FF: synthetic field
   public static jebac_vexiajs8ej2dllnvc IRenderHandler;
   // $FF: synthetic field
   public static jebac_vexiazv9vdnm35jbn WorldEvent_Load_Constructor;
   // $FF: synthetic field
   public static jebac_vexiajs8ej2dllnvc MinecraftForge;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 RenderingRegistry_loadEntityRenderers;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 ForgeWorldProvider_getSkyRenderer;
   // $FF: synthetic field
   public static jebac_vexiajs8ej2dllnvc Event_Result;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 ISmartBlockModel_handleBlockState;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 ForgeHooksClient_loadEntityShader;
   // $FF: synthetic field
   public static jebac_vexiazv9vdnm35jbn RenderLivingEvent_Post_Constructor;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 ForgeHooksClient_getArmorTexture;
   // $FF: synthetic field
   public static jebac_vexiazv9vdnm35jbn RenderItemInFrameEvent_Constructor;
   // $FF: synthetic field
   public static jebac_vexiajs8ej2dllnvc ModelLoader;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 CoreModManager_onCrash;
   // $FF: synthetic field
   public static jebac_vexiajs8ej2dllnvc RenderLivingEvent_Specials_Post;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 ForgeBlock_getExtendedState;
   // $FF: synthetic field
   public static jebac_vexia061cdu2llyx7 Event_Result_DEFAULT;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 FMLClientHandler_instance;
   // $FF: synthetic field
   public static jebac_vexiajs8ej2dllnvc ForgeBiome;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 ForgeHooksClient_setRenderLayer;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 FMLCommonHandler_enhanceCrashReport;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 MinecraftForgeClient_getRenderPass;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 ForgeEventFactory_renderWaterOverlay;
   // $FF: synthetic field
   public static jebac_vexiajs8ej2dllnvc IColoredBakedQuad;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 ForgeEntity_canRiderInteract;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 ForgeBlock_addDestroyEffects;
   // $FF: synthetic field
   public static jebac_vexia061cdu2llyx7 EntityViewRenderEvent_CameraSetup_yaw;
   // $FF: synthetic field
   public static jebac_vexiajs8ej2dllnvc BetterFoliageClient;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 ForgeHooksClient_dispatchRenderLast;
   // $FF: synthetic field
   public static jebac_vexiazv9vdnm35jbn EntityViewRenderEvent_FogColors_Constructor;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 ForgeHooksClient_onFogRender;
   // $FF: synthetic field
   public static jebac_vexiajs8ej2dllnvc EntityViewRenderEvent_CameraSetup;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 DimensionManager_getStaticDimensionIDs;
   // $FF: synthetic field
   public static jebac_vexia061cdu2llyx7 OptiFineClassTransformer_instance;
   // $FF: synthetic field
   public static jebac_vexiajs8ej2dllnvc RenderLivingEvent_Pre;
   // $FF: synthetic field
   public static jebac_vexiajs8ej2dllnvc ForgeEventFactory;
   // $FF: synthetic field
   public static jebac_vexiazv9vdnm35jbn ItemModelMesherForge_Constructor;
   // $FF: synthetic field
   public static jebac_vexiajs8ej2dllnvc ForgeHooksClient;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 FMLCommonHandler_handleServerStarting;
   // $FF: synthetic field
   public static jebac_vexiajs8ej2dllnvc ForgeWorldProvider;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 ForgeWorldProvider_getWeatherRenderer;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 ForgeHooksClient_setRenderPass;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 ForgeHooksClient_onTextureStitchedPost;
   // $FF: synthetic field
   public static jebac_vexiajs8ej2dllnvc LightUtil;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 ForgeTileEntity_shouldRenderInPass;
   // $FF: synthetic field
   public static jebac_vexiajs8ej2dllnvc WorldEvent_Load;
   // $FF: synthetic field
   public static jebac_vexiajs8ej2dllnvc ForgeBlock;
   // $FF: synthetic field
   public static jebac_vexia061cdu2llyx7 EntityViewRenderEvent_FogColors_green;
   // $FF: synthetic field
   public static jebac_vexiajs8ej2dllnvc OptiFineClassTransformer;
   // $FF: synthetic field
   public static jebac_vexia061cdu2llyx7 Minecraft_defaultResourcePack;
   // $FF: synthetic field
   public static jebac_vexiajs8ej2dllnvc Minecraft;
   // $FF: synthetic field
   public static jebac_vexia061cdu2llyx7 Launch_blackboard;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 ForgeBlock_hasTileEntity;
   // $FF: synthetic field
   public static jebac_vexiajs8ej2dllnvc RenderLivingEvent_Post;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 ForgeHooksClient_handleCameraTransforms;
   // $FF: synthetic field
   public static jebac_vexia061cdu2llyx7 EntityViewRenderEvent_CameraSetup_roll;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 ForgeHooks_onLivingSetAttackTarget;
   // $FF: synthetic field
   public static jebac_vexiajs8ej2dllnvc IExtendedBlockState;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 ForgeItem_getModel;
   // $FF: synthetic field
   public static jebac_vexia061cdu2llyx7 EntityViewRenderEvent_FogColors_red;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 IRenderHandler_render;
   // $FF: synthetic field
   public static jebac_vexiazv9vdnm35jbn EntityViewRenderEvent_CameraSetup_Constructor;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 IExtendedBlockState_getClean;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 ForgeVertexFormatElementEnumUseage_postDraw;
   // $FF: synthetic field
   public static jebac_vexiajs8ej2dllnvc ForgeWorld;
   // $FF: synthetic field
   public static jebac_vexiajs8ej2dllnvc SplashScreen;
   // $FF: synthetic field
   public static jebac_vexiajs8ej2dllnvc BlamingTransformer;
   // $FF: synthetic field
   public static jebac_vexia061cdu2llyx7 Attributes_DEFAULT_BAKED_FORMAT;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 ForgeHooksClient_onDrawBlockHighlight;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 FMLCommonHandler_handleServerAboutToStart;
   // $FF: synthetic field
   public static jebac_vexiajs8ej2dllnvc EventBus;
   // $FF: synthetic field
   public static jebac_vexia061cdu2llyx7 EntityViewRenderEvent_CameraSetup_pitch;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 ForgeWorldProvider_getCloudRenderer;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 ForgeBlock_canRenderInLayer;
   // $FF: synthetic field
   public static jebac_vexiajs8ej2dllnvc RenderItemInFrameEvent;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 ForgeBlock_getBedDirection;
   // $FF: synthetic field
   public static jebac_vexiajs8ej2dllnvc FMLClientHandler;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 FMLCommonHandler_instance;
   // $FF: synthetic field
   public static jebac_vexiajs8ej2dllnvc ForgeHooks;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 BlamingTransformer_onCrash;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 ForgeWorld_getPerWorldStorage;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 ForgeItem_shouldCauseReequipAnimation;
   // $FF: synthetic field
   public static jebac_vexiajs8ej2dllnvc ItemModelMesherForge;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 OptiFineClassTransformer_getOptiFineResource;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 ForgeHooksClient_transform;
   // $FF: synthetic field
   public static jebac_vexiajs8ej2dllnvc Launch;
   // $FF: synthetic field
   public static jebac_vexiazv9vdnm35jbn RenderLivingEvent_Specials_Post_Constructor;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 ForgeBlock_isAir;
   // $FF: synthetic field
   public static jebac_vexiazv9vdnm35jbn RenderLivingEvent_Specials_Pre_Constructor;
   // $FF: synthetic field
   public static jebac_vexiajs8ej2dllnvc RenderingRegistry;
   // $FF: synthetic field
   public static jebac_vexia061cdu2llyx7 LightUtil_itemConsumer;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 ForgeEventFactory_renderBlockOverlay;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 ForgeHooksClient_getOffsetFOV;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 ForgeEventFactory_renderFireOverlay;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 ForgeEntity_shouldRenderInPass;
   // $FF: synthetic field
   public static jebac_vexia061cdu2llyx7 Event_Result_DENY;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 ForgeHooksClient_drawScreen;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 ForgeBlock_addHitEffects;
   // $FF: synthetic field
   public static jebac_vexiajs8ej2dllnvc FMLCommonHandler;
   // $FF: synthetic field
   public static jebac_vexiajs8ej2dllnvc ResourcePackRepository;
   // $FF: synthetic field
   public static jebac_vexiazv9vdnm35jbn RenderLivingEvent_Pre_Constructor;
   // $FF: synthetic field
   public static jebac_vexiajs8ej2dllnvc RenderLivingEvent_Specials_Pre;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 ForgeEntity_shouldRiderSit;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 ForgeHooksClient_renderFirstPersonHand;
   // $FF: synthetic field
   public static jebac_vexia061cdu2llyx7 RenderBlockOverlayEvent_OverlayType_BLOCK;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 ForgeVertexFormatElementEnumUseage_preDraw;
   // $FF: synthetic field
   public static jebac_vexiajs8ej2dllnvc ForgeTileEntity;
   // $FF: synthetic field
   public static jebac_vexiajs8ej2dllnvc ForgeEntity;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 ForgeItem_showDurabilityBar;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 ForgeBiome_getWaterColorMultiplier;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 ForgeItemRecord_getRecordResource;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 ModelLoader_onRegisterItems;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 FMLClientHandler_isLoading;
   // $FF: synthetic field
   public static jebac_vexiajs8ej2dllnvc Attributes = new jebac_vexiajs8ej2dllnvc("net.minecraftforge.client.model.Attributes");
   // $FF: synthetic field
   public static jebac_vexiajs8ej2dllnvc ForgeVertexFormatElementEnumUseage;
   // $FF: synthetic field
   public static jebac_vexiajs8ej2dllnvc ForgeModContainer;
   // $FF: synthetic field
   public static jebac_vexiajs8ej2dllnvc MinecraftForgeClient;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 ForgeHooksClient_getFogDensity;
   // $FF: synthetic field
   public static jebac_vexiajs8ej2dllnvc EntityViewRenderEvent_FogColors;
   // $FF: synthetic field
   public static jebac_vexia061cdu2llyx7 MinecraftForge_EVENT_BUS;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 ForgeHooksClient_getMatrix;
   // $FF: synthetic field
   public static jebac_vexiajs8ej2dllnvc ForgeTileEntityRendererDispatcher;
   // $FF: synthetic field
   public static jebac_vexiajs8ej2dllnvc ForgeItem;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 ForgeItem_getDurabilityForDisplay;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 ForgeBlock_isBed;
   // $FF: synthetic field
   public static jebac_vexia061cdu2llyx7 ForgeModContainer_forgeLightPipelineEnabled;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 ForgeEventFactory_canEntityDespawn;
   // $FF: synthetic field
   public static jebac_vexiajs8ej2dllnvc RenderBlockOverlayEvent_OverlayType;
   // $FF: synthetic field
   public static jebac_vexiajs8ej2dllnvc DimensionManager;
   // $FF: synthetic field
   public static jebac_vexiajs8ej2dllnvc CoreModManager;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 EventBus_post;
   // $FF: synthetic field
   public static jebac_vexiajs8ej2dllnvc ForgeItemRecord;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 ForgeTileEntity_getRenderBoundingBox;
   // $FF: synthetic field
   public static jebac_vexia061cdu2llyx7 ResourcePackRepository_repositoryEntries;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 MinecraftForgeClient_onRebuildChunk;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 ForgeTileEntityRendererDispatcher_preDrawBatch;
   // $FF: synthetic field
   public static jebac_vexiajs8ej2dllnvc ISmartBlockModel;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 ForgeHooksClient_onTextureStitchedPre;
   // $FF: synthetic field
   public static jebac_vexia061cdu2llyx7 LightUtil_tessellator;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 ForgeHooksClient_orientBedCamera;
   // $FF: synthetic field
   public static jebac_vexiad5ih6npt6tn4 ForgeTileEntity_canRenderBreaking;

   // $FF: synthetic method
   public static void callVoid(Object p_callVoid_0_, jebac_vexiad5ih6npt6tn4 p_callVoid_1_, Object... p_callVoid_2_) {
      try {
         if (p_callVoid_0_ == null) {
            return;
         }

         Method method = p_callVoid_1_.getTargetMethod();
         if (method == null) {
            return;
         }

         method.invoke(p_callVoid_0_, p_callVoid_2_);
      } catch (Throwable var4) {
         handleException(var4, p_callVoid_0_, p_callVoid_1_, p_callVoid_2_);
      }

   }

   // $FF: synthetic method
   public static Object getFieldValue(jebac_vexia061cdu2llyx7 p_getFieldValue_0_) {
      return getFieldValue((Object)null, p_getFieldValue_0_);
   }

   // $FF: synthetic method
   public static boolean setFieldValue(jebac_vexia061cdu2llyx7 p_setFieldValue_0_, Object p_setFieldValue_1_) {
      return setFieldValue((Object)null, p_setFieldValue_0_, p_setFieldValue_1_);
   }

   // $FF: synthetic method
   public static boolean postForgeBusEvent(jebac_vexiazv9vdnm35jbn p_postForgeBusEvent_0_, Object... p_postForgeBusEvent_1_) {
      Object object = newInstance(p_postForgeBusEvent_0_, p_postForgeBusEvent_1_);
      return object == null ? false : postForgeBusEvent(object);
   }

   // $FF: synthetic method
   public static float getFieldValueFloat(Object p_getFieldValueFloat_0_, jebac_vexia061cdu2llyx7 p_getFieldValueFloat_1_, float p_getFieldValueFloat_2_) {
      Object object = getFieldValue(p_getFieldValueFloat_0_, p_getFieldValueFloat_1_);
      if (!(object instanceof Float)) {
         return p_getFieldValueFloat_2_;
      } else {
         Float f = (Float)object;
         return f;
      }
   }

   // $FF: synthetic method
   public static float callFloat(jebac_vexiad5ih6npt6tn4 p_callFloat_0_, Object... p_callFloat_1_) {
      try {
         Method method = p_callFloat_0_.getTargetMethod();
         if (method == null) {
            return 0.0F;
         } else {
            Float f = (Float)method.invoke((Object)null, p_callFloat_1_);
            return f;
         }
      } catch (Throwable var4) {
         handleException(var4, (Object)null, p_callFloat_0_, p_callFloat_1_);
         return 0.0F;
      }
   }

   // $FF: synthetic method
   private static void handleException(Throwable p_handleException_0_, jebac_vexiazv9vdnm35jbn p_handleException_1_, Object[] p_handleException_2_) {
      if (p_handleException_0_ instanceof InvocationTargetException) {
         p_handleException_0_.printStackTrace();
      } else {
         if (p_handleException_0_ instanceof IllegalArgumentException) {
            jebac_vexiakrwecfs16wve.warn("*** IllegalArgumentException ***");
            jebac_vexiakrwecfs16wve.warn("Constructor: " + p_handleException_1_.getTargetConstructor());
            jebac_vexiakrwecfs16wve.warn("Parameter classes: " + jebac_vexiakrwecfs16wve.arrayToString(getClasses(p_handleException_2_)));
            jebac_vexiakrwecfs16wve.warn("Parameters: " + jebac_vexiakrwecfs16wve.arrayToString(p_handleException_2_));
         }

         jebac_vexiakrwecfs16wve.warn("*** Exception outside of constructor ***");
         jebac_vexiakrwecfs16wve.warn("Constructor deactivated: " + p_handleException_1_.getTargetConstructor());
         p_handleException_1_.deactivate();
         p_handleException_0_.printStackTrace();
      }

   }

   // $FF: synthetic method
   public static boolean matchesTypes(Class[] p_matchesTypes_0_, Class[] p_matchesTypes_1_) {
      if (p_matchesTypes_0_.length != p_matchesTypes_1_.length) {
         return false;
      } else {
         for(int i = 0; i < p_matchesTypes_1_.length; ++i) {
            Class oclass = p_matchesTypes_0_[i];
            Class oclass1 = p_matchesTypes_1_[i];
            if (oclass != oclass1) {
               return false;
            }
         }

         return true;
      }
   }

   // $FF: synthetic method
   public static boolean postForgeBusEvent(Object p_postForgeBusEvent_0_) {
      if (p_postForgeBusEvent_0_ == null) {
         return false;
      } else {
         Object object = getFieldValue(MinecraftForge_EVENT_BUS);
         if (object == null) {
            return false;
         } else {
            Object object1 = call(object, EventBus_post, p_postForgeBusEvent_0_);
            if (!(object1 instanceof Boolean)) {
               return false;
            } else {
               Boolean obool = (Boolean)object1;
               return obool;
            }
         }
      }
   }

   // $FF: synthetic method
   private static Object[] getClasses(Object[] p_getClasses_0_) {
      if (p_getClasses_0_ == null) {
         return new Class[0];
      } else {
         Class[] aclass = new Class[p_getClasses_0_.length];

         for(int i = 0; i < aclass.length; ++i) {
            Object object = p_getClasses_0_[i];
            if (object != null) {
               aclass[i] = object.getClass();
            }
         }

         return aclass;
      }
   }

   // $FF: synthetic method
   public static void callVoid(jebac_vexiad5ih6npt6tn4 p_callVoid_0_, Object... p_callVoid_1_) {
      try {
         Method method = p_callVoid_0_.getTargetMethod();
         if (method == null) {
            return;
         }

         method.invoke((Object)null, p_callVoid_1_);
      } catch (Throwable var3) {
         handleException(var3, (Object)null, p_callVoid_0_, p_callVoid_1_);
      }

   }

   // $FF: synthetic method
   public static String callString(jebac_vexiad5ih6npt6tn4 p_callString_0_, Object... p_callString_1_) {
      try {
         Method method = p_callString_0_.getTargetMethod();
         if (method == null) {
            return null;
         } else {
            String s = (String)method.invoke((Object)null, p_callString_1_);
            return s;
         }
      } catch (Throwable var4) {
         handleException(var4, (Object)null, p_callString_0_, p_callString_1_);
         return null;
      }
   }

   // $FF: synthetic method
   public static boolean callBoolean(jebac_vexiad5ih6npt6tn4 p_callBoolean_0_, Object... p_callBoolean_1_) {
      try {
         Method method = p_callBoolean_0_.getTargetMethod();
         if (method == null) {
            return false;
         } else {
            Boolean obool = (Boolean)method.invoke((Object)null, p_callBoolean_1_);
            return obool;
         }
      } catch (Throwable var4) {
         handleException(var4, (Object)null, p_callBoolean_0_, p_callBoolean_1_);
         return false;
      }
   }

   // $FF: synthetic method
   public static Object call(jebac_vexiad5ih6npt6tn4 p_call_0_, Object... p_call_1_) {
      try {
         Method method = p_call_0_.getTargetMethod();
         if (method == null) {
            return null;
         } else {
            Object object = method.invoke((Object)null, p_call_1_);
            return object;
         }
      } catch (Throwable var4) {
         handleException(var4, (Object)null, p_call_0_, p_call_1_);
         return null;
      }
   }

   static {
      Attributes_DEFAULT_BAKED_FORMAT = new jebac_vexia061cdu2llyx7(Attributes, "DEFAULT_BAKED_FORMAT");
      BetterFoliageClient = new jebac_vexiajs8ej2dllnvc("mods.betterfoliage.client.BetterFoliageClient");
      BlamingTransformer = new jebac_vexiajs8ej2dllnvc("net.minecraftforge.fml.common.asm.transformers.BlamingTransformer");
      BlamingTransformer_onCrash = new jebac_vexiad5ih6npt6tn4(BlamingTransformer, "onCrash");
      CoreModManager = new jebac_vexiajs8ej2dllnvc("net.minecraftforge.fml.relauncher.CoreModManager");
      CoreModManager_onCrash = new jebac_vexiad5ih6npt6tn4(CoreModManager, "onCrash");
      DimensionManager = new jebac_vexiajs8ej2dllnvc("net.minecraftforge.common.DimensionManager");
      DimensionManager_getStaticDimensionIDs = new jebac_vexiad5ih6npt6tn4(DimensionManager, "getStaticDimensionIDs");
      EntityViewRenderEvent_CameraSetup = new jebac_vexiajs8ej2dllnvc("net.minecraftforge.client.event.EntityViewRenderEvent$CameraSetup");
      EntityViewRenderEvent_CameraSetup_Constructor = new jebac_vexiazv9vdnm35jbn(EntityViewRenderEvent_CameraSetup, new Class[]{EntityRenderer.class, Entity.class, Block.class, Double.TYPE, Float.TYPE, Float.TYPE, Float.TYPE});
      EntityViewRenderEvent_CameraSetup_yaw = new jebac_vexia061cdu2llyx7(EntityViewRenderEvent_CameraSetup, "yaw");
      EntityViewRenderEvent_CameraSetup_pitch = new jebac_vexia061cdu2llyx7(EntityViewRenderEvent_CameraSetup, "pitch");
      EntityViewRenderEvent_CameraSetup_roll = new jebac_vexia061cdu2llyx7(EntityViewRenderEvent_CameraSetup, "roll");
      EntityViewRenderEvent_FogColors = new jebac_vexiajs8ej2dllnvc("net.minecraftforge.client.event.EntityViewRenderEvent$FogColors");
      EntityViewRenderEvent_FogColors_Constructor = new jebac_vexiazv9vdnm35jbn(EntityViewRenderEvent_FogColors, new Class[]{EntityRenderer.class, Entity.class, Block.class, Double.TYPE, Float.TYPE, Float.TYPE, Float.TYPE});
      EntityViewRenderEvent_FogColors_red = new jebac_vexia061cdu2llyx7(EntityViewRenderEvent_FogColors, "red");
      EntityViewRenderEvent_FogColors_green = new jebac_vexia061cdu2llyx7(EntityViewRenderEvent_FogColors, "green");
      EntityViewRenderEvent_FogColors_blue = new jebac_vexia061cdu2llyx7(EntityViewRenderEvent_FogColors, "blue");
      EventBus = new jebac_vexiajs8ej2dllnvc("net.minecraftforge.fml.common.eventhandler.EventBus");
      EventBus_post = new jebac_vexiad5ih6npt6tn4(EventBus, "post");
      Event_Result = new jebac_vexiajs8ej2dllnvc("net.minecraftforge.fml.common.eventhandler.Event$Result");
      Event_Result_DENY = new jebac_vexia061cdu2llyx7(Event_Result, "DENY");
      Event_Result_DEFAULT = new jebac_vexia061cdu2llyx7(Event_Result, "DEFAULT");
      FMLClientHandler = new jebac_vexiajs8ej2dllnvc("net.minecraftforge.fml.client.FMLClientHandler");
      FMLClientHandler_instance = new jebac_vexiad5ih6npt6tn4(FMLClientHandler, "instance");
      FMLClientHandler_isLoading = new jebac_vexiad5ih6npt6tn4(FMLClientHandler, "isLoading");
      FMLCommonHandler = new jebac_vexiajs8ej2dllnvc("net.minecraftforge.fml.common.FMLCommonHandler");
      FMLCommonHandler_enhanceCrashReport = new jebac_vexiad5ih6npt6tn4(FMLCommonHandler, "enhanceCrashReport");
      FMLCommonHandler_handleServerAboutToStart = new jebac_vexiad5ih6npt6tn4(FMLCommonHandler, "handleServerAboutToStart");
      FMLCommonHandler_handleServerStarting = new jebac_vexiad5ih6npt6tn4(FMLCommonHandler, "handleServerStarting");
      FMLCommonHandler_instance = new jebac_vexiad5ih6npt6tn4(FMLCommonHandler, "instance");
      ForgeBiome = new jebac_vexiajs8ej2dllnvc(BiomeGenBase.class);
      ForgeBiome_getWaterColorMultiplier = new jebac_vexiad5ih6npt6tn4(ForgeBiome, "getWaterColorMultiplier");
      ForgeBlock = new jebac_vexiajs8ej2dllnvc(Block.class);
      ForgeBlock_addDestroyEffects = new jebac_vexiad5ih6npt6tn4(ForgeBlock, "addDestroyEffects");
      ForgeBlock_addHitEffects = new jebac_vexiad5ih6npt6tn4(ForgeBlock, "addHitEffects");
      ForgeBlock_canRenderInLayer = new jebac_vexiad5ih6npt6tn4(ForgeBlock, "canRenderInLayer", new Class[]{EnumWorldBlockLayer.class});
      ForgeBlock_getBedDirection = new jebac_vexiad5ih6npt6tn4(ForgeBlock, "getBedDirection");
      ForgeBlock_getExtendedState = new jebac_vexiad5ih6npt6tn4(ForgeBlock, "getExtendedState");
      ForgeBlock_hasTileEntity = new jebac_vexiad5ih6npt6tn4(ForgeBlock, "hasTileEntity", new Class[]{IBlockState.class});
      ForgeBlock_isAir = new jebac_vexiad5ih6npt6tn4(ForgeBlock, "isAir");
      ForgeBlock_isBed = new jebac_vexiad5ih6npt6tn4(ForgeBlock, "isBed");
      ForgeEntity = new jebac_vexiajs8ej2dllnvc(Entity.class);
      ForgeEntity_canRiderInteract = new jebac_vexiad5ih6npt6tn4(ForgeEntity, "canRiderInteract");
      ForgeEntity_shouldRenderInPass = new jebac_vexiad5ih6npt6tn4(ForgeEntity, "shouldRenderInPass");
      ForgeEntity_shouldRiderSit = new jebac_vexiad5ih6npt6tn4(ForgeEntity, "shouldRiderSit");
      ForgeEventFactory = new jebac_vexiajs8ej2dllnvc("net.minecraftforge.event.ForgeEventFactory");
      ForgeEventFactory_canEntityDespawn = new jebac_vexiad5ih6npt6tn4(ForgeEventFactory, "canEntityDespawn");
      ForgeEventFactory_renderBlockOverlay = new jebac_vexiad5ih6npt6tn4(ForgeEventFactory, "renderBlockOverlay");
      ForgeEventFactory_renderFireOverlay = new jebac_vexiad5ih6npt6tn4(ForgeEventFactory, "renderFireOverlay");
      ForgeEventFactory_renderWaterOverlay = new jebac_vexiad5ih6npt6tn4(ForgeEventFactory, "renderWaterOverlay");
      ForgeHooks = new jebac_vexiajs8ej2dllnvc("net.minecraftforge.common.ForgeHooks");
      ForgeHooks_onLivingSetAttackTarget = new jebac_vexiad5ih6npt6tn4(ForgeHooks, "onLivingSetAttackTarget");
      ForgeHooksClient = new jebac_vexiajs8ej2dllnvc("net.minecraftforge.client.ForgeHooksClient");
      ForgeHooksClient_dispatchRenderLast = new jebac_vexiad5ih6npt6tn4(ForgeHooksClient, "dispatchRenderLast");
      ForgeHooksClient_drawScreen = new jebac_vexiad5ih6npt6tn4(ForgeHooksClient, "drawScreen");
      ForgeHooksClient_handleCameraTransforms = new jebac_vexiad5ih6npt6tn4(ForgeHooksClient, "handleCameraTransforms");
      ForgeHooksClient_getArmorTexture = new jebac_vexiad5ih6npt6tn4(ForgeHooksClient, "getArmorTexture");
      ForgeHooksClient_getFogDensity = new jebac_vexiad5ih6npt6tn4(ForgeHooksClient, "getFogDensity");
      ForgeHooksClient_getMatrix = new jebac_vexiad5ih6npt6tn4(ForgeHooksClient, "getMatrix", new Class[]{ModelRotation.class});
      ForgeHooksClient_getOffsetFOV = new jebac_vexiad5ih6npt6tn4(ForgeHooksClient, "getOffsetFOV");
      ForgeHooksClient_loadEntityShader = new jebac_vexiad5ih6npt6tn4(ForgeHooksClient, "loadEntityShader");
      ForgeHooksClient_onDrawBlockHighlight = new jebac_vexiad5ih6npt6tn4(ForgeHooksClient, "onDrawBlockHighlight");
      ForgeHooksClient_onFogRender = new jebac_vexiad5ih6npt6tn4(ForgeHooksClient, "onFogRender");
      ForgeHooksClient_onTextureStitchedPre = new jebac_vexiad5ih6npt6tn4(ForgeHooksClient, "onTextureStitchedPre");
      ForgeHooksClient_onTextureStitchedPost = new jebac_vexiad5ih6npt6tn4(ForgeHooksClient, "onTextureStitchedPost");
      ForgeHooksClient_orientBedCamera = new jebac_vexiad5ih6npt6tn4(ForgeHooksClient, "orientBedCamera");
      ForgeHooksClient_renderFirstPersonHand = new jebac_vexiad5ih6npt6tn4(ForgeHooksClient, "renderFirstPersonHand");
      ForgeHooksClient_setRenderLayer = new jebac_vexiad5ih6npt6tn4(ForgeHooksClient, "setRenderLayer");
      ForgeHooksClient_setRenderPass = new jebac_vexiad5ih6npt6tn4(ForgeHooksClient, "setRenderPass");
      ForgeHooksClient_transform = new jebac_vexiad5ih6npt6tn4(ForgeHooksClient, "transform");
      ForgeItem = new jebac_vexiajs8ej2dllnvc(Item.class);
      ForgeItem_getDurabilityForDisplay = new jebac_vexiad5ih6npt6tn4(ForgeItem, "getDurabilityForDisplay");
      ForgeItem_getModel = new jebac_vexiad5ih6npt6tn4(ForgeItem, "getModel");
      ForgeItem_shouldCauseReequipAnimation = new jebac_vexiad5ih6npt6tn4(ForgeItem, "shouldCauseReequipAnimation");
      ForgeItem_showDurabilityBar = new jebac_vexiad5ih6npt6tn4(ForgeItem, "showDurabilityBar");
      ForgeItemRecord = new jebac_vexiajs8ej2dllnvc(ItemRecord.class);
      ForgeItemRecord_getRecordResource = new jebac_vexiad5ih6npt6tn4(ForgeItemRecord, "getRecordResource", new Class[]{String.class});
      ForgeModContainer = new jebac_vexiajs8ej2dllnvc("net.minecraftforge.common.ForgeModContainer");
      ForgeModContainer_forgeLightPipelineEnabled = new jebac_vexia061cdu2llyx7(ForgeModContainer, "forgeLightPipelineEnabled");
      ForgeTileEntity = new jebac_vexiajs8ej2dllnvc(TileEntity.class);
      ForgeTileEntity_canRenderBreaking = new jebac_vexiad5ih6npt6tn4(ForgeTileEntity, "canRenderBreaking");
      ForgeTileEntity_getRenderBoundingBox = new jebac_vexiad5ih6npt6tn4(ForgeTileEntity, "getRenderBoundingBox");
      ForgeTileEntity_shouldRenderInPass = new jebac_vexiad5ih6npt6tn4(ForgeTileEntity, "shouldRenderInPass");
      ForgeTileEntityRendererDispatcher = new jebac_vexiajs8ej2dllnvc(TileEntityRendererDispatcher.class);
      ForgeTileEntityRendererDispatcher_preDrawBatch = new jebac_vexiad5ih6npt6tn4(ForgeTileEntityRendererDispatcher, "preDrawBatch");
      ForgeTileEntityRendererDispatcher_drawBatch = new jebac_vexiad5ih6npt6tn4(ForgeTileEntityRendererDispatcher, "drawBatch");
      ForgeVertexFormatElementEnumUseage = new jebac_vexiajs8ej2dllnvc(VertexFormatElement.EnumUsage.class);
      ForgeVertexFormatElementEnumUseage_preDraw = new jebac_vexiad5ih6npt6tn4(ForgeVertexFormatElementEnumUseage, "preDraw");
      ForgeVertexFormatElementEnumUseage_postDraw = new jebac_vexiad5ih6npt6tn4(ForgeVertexFormatElementEnumUseage, "postDraw");
      ForgeWorld = new jebac_vexiajs8ej2dllnvc(World.class);
      ForgeWorld_getPerWorldStorage = new jebac_vexiad5ih6npt6tn4(ForgeWorld, "getPerWorldStorage");
      ForgeWorldProvider = new jebac_vexiajs8ej2dllnvc(WorldProvider.class);
      ForgeWorldProvider_getCloudRenderer = new jebac_vexiad5ih6npt6tn4(ForgeWorldProvider, "getCloudRenderer");
      ForgeWorldProvider_getSkyRenderer = new jebac_vexiad5ih6npt6tn4(ForgeWorldProvider, "getSkyRenderer");
      ForgeWorldProvider_getWeatherRenderer = new jebac_vexiad5ih6npt6tn4(ForgeWorldProvider, "getWeatherRenderer");
      IColoredBakedQuad = new jebac_vexiajs8ej2dllnvc("net.minecraftforge.client.model.IColoredBakedQuad");
      IExtendedBlockState = new jebac_vexiajs8ej2dllnvc("net.minecraftforge.common.property.IExtendedBlockState");
      IExtendedBlockState_getClean = new jebac_vexiad5ih6npt6tn4(IExtendedBlockState, "getClean");
      IRenderHandler = new jebac_vexiajs8ej2dllnvc("net.minecraftforge.client.IRenderHandler");
      IRenderHandler_render = new jebac_vexiad5ih6npt6tn4(IRenderHandler, "render");
      ISmartBlockModel = new jebac_vexiajs8ej2dllnvc("net.minecraftforge.client.model.ISmartBlockModel");
      ISmartBlockModel_handleBlockState = new jebac_vexiad5ih6npt6tn4(ISmartBlockModel, "handleBlockState");
      ItemModelMesherForge = new jebac_vexiajs8ej2dllnvc("net.minecraftforge.client.ItemModelMesherForge");
      ItemModelMesherForge_Constructor = new jebac_vexiazv9vdnm35jbn(ItemModelMesherForge, new Class[]{ModelManager.class});
      Launch = new jebac_vexiajs8ej2dllnvc("net.minecraft.launchwrapper.Launch");
      Launch_blackboard = new jebac_vexia061cdu2llyx7(Launch, "blackboard");
      LightUtil = new jebac_vexiajs8ej2dllnvc("net.minecraftforge.client.model.pipeline.LightUtil");
      LightUtil_itemConsumer = new jebac_vexia061cdu2llyx7(LightUtil, "itemConsumer");
      LightUtil_tessellator = new jebac_vexia061cdu2llyx7(LightUtil, "tessellator");
      MinecraftForge = new jebac_vexiajs8ej2dllnvc("net.minecraftforge.common.MinecraftForge");
      MinecraftForge_EVENT_BUS = new jebac_vexia061cdu2llyx7(MinecraftForge, "EVENT_BUS");
      MinecraftForgeClient = new jebac_vexiajs8ej2dllnvc("net.minecraftforge.client.MinecraftForgeClient");
      MinecraftForgeClient_getRenderPass = new jebac_vexiad5ih6npt6tn4(MinecraftForgeClient, "getRenderPass");
      MinecraftForgeClient_onRebuildChunk = new jebac_vexiad5ih6npt6tn4(MinecraftForgeClient, "onRebuildChunk");
      ModelLoader = new jebac_vexiajs8ej2dllnvc("net.minecraftforge.client.model.ModelLoader");
      ModelLoader_onRegisterItems = new jebac_vexiad5ih6npt6tn4(ModelLoader, "onRegisterItems");
      RenderBlockOverlayEvent_OverlayType = new jebac_vexiajs8ej2dllnvc("net.minecraftforge.client.event.RenderBlockOverlayEvent$OverlayType");
      RenderBlockOverlayEvent_OverlayType_BLOCK = new jebac_vexia061cdu2llyx7(RenderBlockOverlayEvent_OverlayType, "BLOCK");
      RenderingRegistry = new jebac_vexiajs8ej2dllnvc("net.minecraftforge.fml.client.registry.RenderingRegistry");
      RenderingRegistry_loadEntityRenderers = new jebac_vexiad5ih6npt6tn4(RenderingRegistry, "loadEntityRenderers", new Class[]{RenderManager.class, Map.class});
      RenderItemInFrameEvent = new jebac_vexiajs8ej2dllnvc("net.minecraftforge.client.event.RenderItemInFrameEvent");
      RenderItemInFrameEvent_Constructor = new jebac_vexiazv9vdnm35jbn(RenderItemInFrameEvent, new Class[]{EntityItemFrame.class, RenderItemFrame.class});
      RenderLivingEvent_Pre = new jebac_vexiajs8ej2dllnvc("net.minecraftforge.client.event.RenderLivingEvent$Pre");
      RenderLivingEvent_Pre_Constructor = new jebac_vexiazv9vdnm35jbn(RenderLivingEvent_Pre, new Class[]{EntityLivingBase.class, RendererLivingEntity.class, Double.TYPE, Double.TYPE, Double.TYPE});
      RenderLivingEvent_Post = new jebac_vexiajs8ej2dllnvc("net.minecraftforge.client.event.RenderLivingEvent$Post");
      RenderLivingEvent_Post_Constructor = new jebac_vexiazv9vdnm35jbn(RenderLivingEvent_Post, new Class[]{EntityLivingBase.class, RendererLivingEntity.class, Double.TYPE, Double.TYPE, Double.TYPE});
      RenderLivingEvent_Specials_Pre = new jebac_vexiajs8ej2dllnvc("net.minecraftforge.client.event.RenderLivingEvent$Specials$Pre");
      RenderLivingEvent_Specials_Pre_Constructor = new jebac_vexiazv9vdnm35jbn(RenderLivingEvent_Specials_Pre, new Class[]{EntityLivingBase.class, RendererLivingEntity.class, Double.TYPE, Double.TYPE, Double.TYPE});
      RenderLivingEvent_Specials_Post = new jebac_vexiajs8ej2dllnvc("net.minecraftforge.client.event.RenderLivingEvent$Specials$Post");
      RenderLivingEvent_Specials_Post_Constructor = new jebac_vexiazv9vdnm35jbn(RenderLivingEvent_Specials_Post, new Class[]{EntityLivingBase.class, RendererLivingEntity.class, Double.TYPE, Double.TYPE, Double.TYPE});
      SplashScreen = new jebac_vexiajs8ej2dllnvc("net.minecraftforge.fml.client.SplashProgress");
      WorldEvent_Load = new jebac_vexiajs8ej2dllnvc("net.minecraftforge.event.world.WorldEvent$Load");
      WorldEvent_Load_Constructor = new jebac_vexiazv9vdnm35jbn(WorldEvent_Load, new Class[]{World.class});
      Minecraft = new jebac_vexiajs8ej2dllnvc(Minecraft.class);
      Minecraft_defaultResourcePack = new jebac_vexia061cdu2llyx7(Minecraft, DefaultResourcePack.class);
      OptiFineClassTransformer = new jebac_vexiajs8ej2dllnvc("optifine.OptiFineClassTransformer");
      OptiFineClassTransformer_instance = new jebac_vexia061cdu2llyx7(OptiFineClassTransformer, "instance");
      OptiFineClassTransformer_getOptiFineResource = new jebac_vexiad5ih6npt6tn4(OptiFineClassTransformer, "getOptiFineResource");
      ResourcePackRepository = new jebac_vexiajs8ej2dllnvc(ResourcePackRepository.class);
      ResourcePackRepository_repositoryEntries = new jebac_vexia061cdu2llyx7(ResourcePackRepository, List.class, 1);
   }

   // $FF: synthetic method
   public static Object call(Object p_call_0_, jebac_vexiad5ih6npt6tn4 p_call_1_, Object... p_call_2_) {
      try {
         Method method = p_call_1_.getTargetMethod();
         if (method == null) {
            return null;
         } else {
            Object object = method.invoke(p_call_0_, p_call_2_);
            return object;
         }
      } catch (Throwable var5) {
         handleException(var5, p_call_0_, p_call_1_, p_call_2_);
         return null;
      }
   }

   // $FF: synthetic method
   public static Object getFieldValue(Object p_getFieldValue_0_, jebac_vexia061cdu2llyx7 p_getFieldValue_1_) {
      try {
         Field field = p_getFieldValue_1_.getTargetField();
         if (field == null) {
            return null;
         } else {
            Object object = field.get(p_getFieldValue_0_);
            return object;
         }
      } catch (Throwable var4) {
         var4.printStackTrace();
         return null;
      }
   }

   // $FF: synthetic method
   private static void handleException(Throwable p_handleException_0_, Object p_handleException_1_, jebac_vexiad5ih6npt6tn4 p_handleException_2_, Object[] p_handleException_3_) {
      if (p_handleException_0_ instanceof InvocationTargetException) {
         Throwable throwable = p_handleException_0_.getCause();
         if (throwable instanceof RuntimeException) {
            RuntimeException runtimeexception = (RuntimeException)throwable;
            throw runtimeexception;
         }

         p_handleException_0_.printStackTrace();
      } else {
         if (p_handleException_0_ instanceof IllegalArgumentException) {
            jebac_vexiakrwecfs16wve.warn("*** IllegalArgumentException ***");
            jebac_vexiakrwecfs16wve.warn("Method: " + p_handleException_2_.getTargetMethod());
            jebac_vexiakrwecfs16wve.warn("Object: " + p_handleException_1_);
            jebac_vexiakrwecfs16wve.warn("Parameter classes: " + jebac_vexiakrwecfs16wve.arrayToString(getClasses(p_handleException_3_)));
            jebac_vexiakrwecfs16wve.warn("Parameters: " + jebac_vexiakrwecfs16wve.arrayToString(p_handleException_3_));
         }

         jebac_vexiakrwecfs16wve.warn("*** Exception outside of method ***");
         jebac_vexiakrwecfs16wve.warn("Method deactivated: " + p_handleException_2_.getTargetMethod());
         p_handleException_2_.deactivate();
         p_handleException_0_.printStackTrace();
      }

   }

   // $FF: synthetic method
   public static int callInt(Object p_callInt_0_, jebac_vexiad5ih6npt6tn4 p_callInt_1_, Object... p_callInt_2_) {
      try {
         Method method = p_callInt_1_.getTargetMethod();
         if (method == null) {
            return 0;
         } else {
            Integer integer = (Integer)method.invoke(p_callInt_0_, p_callInt_2_);
            return integer;
         }
      } catch (Throwable var5) {
         handleException(var5, p_callInt_0_, p_callInt_1_, p_callInt_2_);
         return 0;
      }
   }

   // $FF: synthetic method
   public static Object newInstance(jebac_vexiazv9vdnm35jbn p_newInstance_0_, Object... p_newInstance_1_) {
      Constructor constructor = p_newInstance_0_.getTargetConstructor();
      if (constructor == null) {
         return null;
      } else {
         try {
            Object object = constructor.newInstance(p_newInstance_1_);
            return object;
         } catch (Throwable var4) {
            handleException(var4, p_newInstance_0_, p_newInstance_1_);
            return null;
         }
      }
   }

   // $FF: synthetic method
   public static boolean callBoolean(Object p_callBoolean_0_, jebac_vexiad5ih6npt6tn4 p_callBoolean_1_, Object... p_callBoolean_2_) {
      try {
         Method method = p_callBoolean_1_.getTargetMethod();
         if (method == null) {
            return false;
         } else {
            Boolean obool = (Boolean)method.invoke(p_callBoolean_0_, p_callBoolean_2_);
            return obool;
         }
      } catch (Throwable var5) {
         handleException(var5, p_callBoolean_0_, p_callBoolean_1_, p_callBoolean_2_);
         return false;
      }
   }

   // $FF: synthetic method
   public static double callDouble(Object p_callDouble_0_, jebac_vexiad5ih6npt6tn4 p_callDouble_1_, Object... p_callDouble_2_) {
      try {
         Method method = p_callDouble_1_.getTargetMethod();
         if (method == null) {
            return 0.0D;
         } else {
            Double d0 = (Double)method.invoke(p_callDouble_0_, p_callDouble_2_);
            return d0;
         }
      } catch (Throwable var5) {
         handleException(var5, p_callDouble_0_, p_callDouble_1_, p_callDouble_2_);
         return 0.0D;
      }
   }

   // $FF: synthetic method
   public static int callInt(jebac_vexiad5ih6npt6tn4 p_callInt_0_, Object... p_callInt_1_) {
      try {
         Method method = p_callInt_0_.getTargetMethod();
         if (method == null) {
            return 0;
         } else {
            Integer integer = (Integer)method.invoke((Object)null, p_callInt_1_);
            return integer;
         }
      } catch (Throwable var4) {
         handleException(var4, (Object)null, p_callInt_0_, p_callInt_1_);
         return 0;
      }
   }

   // $FF: synthetic method
   public static String callString(Object p_callString_0_, jebac_vexiad5ih6npt6tn4 p_callString_1_, Object... p_callString_2_) {
      try {
         Method method = p_callString_1_.getTargetMethod();
         if (method == null) {
            return null;
         } else {
            String s = (String)method.invoke(p_callString_0_, p_callString_2_);
            return s;
         }
      } catch (Throwable var5) {
         handleException(var5, p_callString_0_, p_callString_1_, p_callString_2_);
         return null;
      }
   }

   // $FF: synthetic method
   public static boolean setFieldValue(Object p_setFieldValue_0_, jebac_vexia061cdu2llyx7 p_setFieldValue_1_, Object p_setFieldValue_2_) {
      try {
         Field field = p_setFieldValue_1_.getTargetField();
         if (field == null) {
            return false;
         } else {
            field.set(p_setFieldValue_0_, p_setFieldValue_2_);
            return true;
         }
      } catch (Throwable var4) {
         var4.printStackTrace();
         return false;
      }
   }
}
