import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.I18n;

public class jebac_vexiakwchqo51kf8d extends jebac_vexia6fd2eiv9yfhn {
   // $FF: synthetic method
   protected String getListHeader() {
      return I18n.format("resourcePack.available.title");
   }

   // $FF: synthetic method
   public jebac_vexiakwchqo51kf8d(Minecraft mcIn, int p_i45054_2_, int p_i45054_3_, List p_i45054_4_) {
      super(mcIn, p_i45054_2_, p_i45054_3_, p_i45054_4_);
   }
}
