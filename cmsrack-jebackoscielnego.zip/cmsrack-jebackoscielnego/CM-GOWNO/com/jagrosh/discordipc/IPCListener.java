package com.jagrosh.discordipc;

import com.jagrosh.discordipc.entities.Packet;
import com.jagrosh.discordipc.entities.User;
import org.json.JSONObject;

public interface IPCListener {
   // $FF: synthetic method
   default void onActivityJoinRequest(IPCClient client, String secret, User user) {
   }

   // $FF: synthetic method
   default void onActivitySpectate(IPCClient client, String secret) {
   }

   // $FF: synthetic method
   default void onActivityJoin(IPCClient client, String secret) {
   }

   // $FF: synthetic method
   default void onDisconnect(IPCClient client, Throwable t) {
   }

   // $FF: synthetic method
   default void onPacketSent(IPCClient client, Packet packet) {
   }

   // $FF: synthetic method
   default void onPacketReceived(IPCClient client, Packet packet) {
   }

   // $FF: synthetic method
   default void onClose(IPCClient client, JSONObject json) {
   }

   // $FF: synthetic method
   default void onReady(IPCClient client) {
   }
}
