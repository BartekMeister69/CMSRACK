package com.jagrosh.discordipc;

import com.jagrosh.discordipc.entities.Callback;
import com.jagrosh.discordipc.entities.DiscordBuild;
import com.jagrosh.discordipc.entities.Packet;
import com.jagrosh.discordipc.entities.RichPresence;
import com.jagrosh.discordipc.entities.User;
import com.jagrosh.discordipc.entities.pipe.Pipe;
import com.jagrosh.discordipc.entities.pipe.PipeStatus;
import com.jagrosh.discordipc.exceptions.NoDiscordClientException;
import java.io.Closeable;
import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.util.HashMap;
import org.json.JSONException;
import org.json.JSONObject;

public final class IPCClient implements Closeable {
   // $FF: synthetic field
   private final HashMap callbacks = new HashMap();
   // $FF: synthetic field
   private IPCListener listener = null;
   // $FF: synthetic field
   private volatile Pipe pipe;
   // $FF: synthetic field
   private Thread readThread = null;
   // $FF: synthetic field
   private final long clientId;

   private void lambda$startReading$0() {
      while(true) {
         try {
            Packet p;
            if ((p = this.pipe.read()).getOp() != Packet.OpCode.CLOSE) {
               JSONObject json = p.getJson();
               IPCClient.Event event = IPCClient.Event.of(json.optString("evt", (String)null));
               String nonce = json.optString("nonce", (String)null);
               switch(event) {
               case NULL:
                  if (nonce != null && this.callbacks.containsKey(nonce)) {
                     ((Callback)this.callbacks.remove(nonce)).succeed(p);
                  }
                  break;
               case ERROR:
                  if (nonce != null && this.callbacks.containsKey(nonce)) {
                     ((Callback)this.callbacks.remove(nonce)).fail(json.getJSONObject("data").optString("message", (String)null));
                  }
               case ACTIVITY_JOIN:
               case ACTIVITY_SPECTATE:
               case ACTIVITY_JOIN_REQUEST:
               case UNKNOWN:
               }

               if (this.listener == null || !json.has("cmd") || !json.getString("cmd").equals("DISPATCH")) {
                  continue;
               }

               try {
                  JSONObject data = json.getJSONObject("data");
                  switch(IPCClient.Event.of(json.getString("evt"))) {
                  case ACTIVITY_JOIN:
                     this.listener.onActivityJoin(this, data.getString("secret"));
                     continue;
                  case ACTIVITY_SPECTATE:
                     this.listener.onActivitySpectate(this, data.getString("secret"));
                     continue;
                  case ACTIVITY_JOIN_REQUEST:
                     JSONObject u = data.getJSONObject("user");
                     User user = new User(u.getString("username"), u.getString("discriminator"), Long.parseLong(u.getString("id")), u.optString("avatar", (String)null));
                     this.listener.onActivityJoinRequest(this, data.optString("secret", (String)null), user);
                  }
               } catch (Exception var8) {
                  var8.printStackTrace();
               }
               continue;
            }

            this.pipe.setStatus(PipeStatus.DISCONNECTED);
            if (this.listener != null) {
               this.listener.onClose(this, p.getJson());
            }
         } catch (JSONException | IOException var9) {
            this.pipe.setStatus(PipeStatus.DISCONNECTED);
            if (this.listener != null) {
               this.listener.onDisconnect(this, var9);
            }
         }

         return;
      }
   }

   // $FF: synthetic method
   private void startReading() {
      this.readThread = new Thread(this::lambda$startReading$0);
      this.readThread.start();
   }

   // $FF: synthetic method
   public IPCClient(long clientId) {
      this.clientId = clientId;
   }

   // $FF: synthetic method
   public DiscordBuild getDiscordBuild() {
      return this.pipe == null ? null : this.pipe.getDiscordBuild();
   }

   // $FF: synthetic method
   private void checkConnected(boolean connected) {
      if (connected && this.getStatus() != PipeStatus.CONNECTED) {
         throw new IllegalStateException(String.format("IPCClient (ID: %d) is not connected!", this.clientId));
      } else if (!connected && this.getStatus() == PipeStatus.CONNECTED) {
         throw new IllegalStateException(String.format("IPCClient (ID: %d) is already connected!", this.clientId));
      }
   }

   // $FF: synthetic method
   public void setListener(IPCListener listener) {
      this.listener = listener;
      if (this.pipe != null) {
         this.pipe.setListener(listener);
      }

   }

   // $FF: synthetic method
   public void sendRichPresence(RichPresence presence, Callback callback) {
      this.checkConnected(true);
      this.pipe.send(Packet.OpCode.FRAME, (new JSONObject()).put("cmd", (Object)"SET_ACTIVITY").put("args", (Object)(new JSONObject()).put("pid", getPID()).put("activity", (Object)(presence == null ? null : presence.toJson()))), callback);
   }

   // $FF: synthetic method
   public void subscribe(IPCClient.Event sub) {
      this.subscribe(sub, (Callback)null);
   }

   // $FF: synthetic method
   public void sendRichPresence(RichPresence presence) {
      this.sendRichPresence(presence, (Callback)null);
   }

   // $FF: synthetic method
   private static int getPID() {
      String pr = ManagementFactory.getRuntimeMXBean().getName();
      return Integer.parseInt(pr.substring(0, pr.indexOf(64)));
   }

   // $FF: synthetic method
   public void connect(DiscordBuild... preferredOrder) throws NoDiscordClientException {
      this.checkConnected(false);
      this.callbacks.clear();
      this.pipe = null;
      this.pipe = Pipe.openPipe(this, this.clientId, this.callbacks, preferredOrder);
      if (this.listener != null) {
         this.listener.onReady(this);
      }

      this.startReading();
   }

   // $FF: synthetic method
   public PipeStatus getStatus() {
      return this.pipe == null ? PipeStatus.UNINITIALIZED : this.pipe.getStatus();
   }

   // $FF: synthetic method
   public void subscribe(IPCClient.Event sub, Callback callback) {
      this.checkConnected(true);
      if (!sub.isSubscribable()) {
         throw new IllegalStateException("Cannot subscribe to " + sub + " event!");
      } else {
         this.pipe.send(Packet.OpCode.FRAME, (new JSONObject()).put("cmd", (Object)"SUBSCRIBE").put("evt", (Object)sub.name()), callback);
      }
   }

   // $FF: synthetic method
   public void close() {
      this.checkConnected(true);

      try {
         this.pipe.close();
      } catch (IOException var2) {
         var2.printStackTrace();
      }

   }

   public static enum Event {
      // $FF: synthetic field
      NULL(false),
      // $FF: synthetic field
      READY(false),
      // $FF: synthetic field
      ERROR(false),
      // $FF: synthetic field
      ACTIVITY_JOIN(true),
      // $FF: synthetic field
      ACTIVITY_SPECTATE(true),
      // $FF: synthetic field
      ACTIVITY_JOIN_REQUEST(true),
      // $FF: synthetic field
      UNKNOWN(false);

      // $FF: synthetic field
      private final boolean subscribable;
      private static final IPCClient.Event[] $VALUES = new IPCClient.Event[]{NULL, READY, ERROR, ACTIVITY_JOIN, ACTIVITY_SPECTATE, ACTIVITY_JOIN_REQUEST, UNKNOWN};

      // $FF: synthetic method
      private Event(boolean subscribable) {
         this.subscribable = subscribable;
      }

      // $FF: synthetic method
      public boolean isSubscribable() {
         return this.subscribable;
      }

      // $FF: synthetic method
      static IPCClient.Event of(String str) {
         if (str == null) {
            return NULL;
         } else {
            IPCClient.Event[] var1 = values();
            int var2 = var1.length;

            for(int var3 = 0; var3 < var2; ++var3) {
               IPCClient.Event s = var1[var3];
               if (s != UNKNOWN && s.name().equalsIgnoreCase(str)) {
                  return s;
               }
            }

            return UNKNOWN;
         }
      }
   }
}
