package com.jagrosh.discordipc.entities;

public class User {
   // $FF: synthetic field
   private final String name;
   // $FF: synthetic field
   private final String avatar;
   // $FF: synthetic field
   private final String discriminator;
   // $FF: synthetic field
   private final long id;

   // $FF: synthetic method
   public String getAvatarUrl() {
      return this.getAvatarId() == null ? null : "https://cdn.discordapp.com/avatars/" + this.getId() + "/" + this.getAvatarId() + (this.getAvatarId().startsWith("a_") ? ".gif" : ".png");
   }

   // $FF: synthetic method
   public String getDefaultAvatarUrl() {
      return "https://discordapp.com/assets/" + this.getDefaultAvatarId() + ".png";
   }

   // $FF: synthetic method
   public boolean equals(Object o) {
      if (!(o instanceof User)) {
         return false;
      } else {
         User oUser = (User)o;
         return this == oUser || this.id == oUser.id;
      }
   }

   // $FF: synthetic method
   public String getDefaultAvatarId() {
      return User.DefaultAvatar.values()[Integer.parseInt(this.getDiscriminator()) % User.DefaultAvatar.values().length].toString();
   }

   // $FF: synthetic method
   public int hashCode() {
      return Long.hashCode(this.id);
   }

   // $FF: synthetic method
   public boolean isBot() {
      return false;
   }

   // $FF: synthetic method
   public String getAvatarId() {
      return this.avatar;
   }

   // $FF: synthetic method
   public String toString() {
      return "U:" + this.getName() + '(' + this.id + ')';
   }

   // $FF: synthetic method
   public User(String name, String discriminator, long id, String avatar) {
      this.name = name;
      this.discriminator = discriminator;
      this.id = id;
      this.avatar = avatar;
   }

   // $FF: synthetic method
   public String getId() {
      return Long.toString(this.id);
   }

   // $FF: synthetic method
   public String getEffectiveAvatarUrl() {
      return this.getAvatarUrl() == null ? this.getDefaultAvatarUrl() : this.getAvatarUrl();
   }

   // $FF: synthetic method
   public long getIdLong() {
      return this.id;
   }

   // $FF: synthetic method
   public String getName() {
      return this.name;
   }

   // $FF: synthetic method
   public String getAsMention() {
      return "<@" + this.id + '>';
   }

   // $FF: synthetic method
   public String getDiscriminator() {
      return this.discriminator;
   }

   public static enum DefaultAvatar {
      // $FF: synthetic field
      BLURPLE("6debd47ed13483642cf09e832ed0bc1b"),
      // $FF: synthetic field
      GREY("322c936a8c8be1b803cd94861bdfa868"),
      // $FF: synthetic field
      GREEN("dd4dbc0016779df1378e7812eabaa04d"),
      // $FF: synthetic field
      ORANGE("0e291f67c9274a1abdddeb3fd919cbaa"),
      // $FF: synthetic field
      RED("1cbd08c76f8af6dddce02c5138971129");

      // $FF: synthetic field
      private final String text;
      private static final User.DefaultAvatar[] $VALUES = new User.DefaultAvatar[]{BLURPLE, GREY, GREEN, ORANGE, RED};

      // $FF: synthetic method
      private DefaultAvatar(String text) {
         this.text = text;
      }

      // $FF: synthetic method
      public String toString() {
         return this.text;
      }
   }
}
