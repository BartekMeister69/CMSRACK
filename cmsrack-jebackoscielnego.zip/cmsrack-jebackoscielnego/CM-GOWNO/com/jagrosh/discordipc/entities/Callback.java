package com.jagrosh.discordipc.entities;

import java.util.function.Consumer;

public class Callback {
   // $FF: synthetic field
   private final Consumer success;
   // $FF: synthetic field
   private final Consumer failure;

   // $FF: synthetic method
   public boolean isEmpty() {
      return this.success == null && this.failure == null;
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated
   public Callback(Runnable success, Consumer failure) {
      this(Callback::lambda$new$0, failure);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated
   public Callback(Runnable success) {
      this((Consumer)(Callback::lambda$new$1), (Consumer)null);
   }

   private static void lambda$new$1(Runnable success, Packet p) {
      success.run();
   }

   // $FF: synthetic method
   public Callback(Consumer success, Consumer failure) {
      this.success = success;
      this.failure = failure;
   }

   // $FF: synthetic method
   public Callback(Consumer success) {
      this((Consumer)success, (Consumer)null);
   }

   private static void lambda$new$0(Runnable success, Packet p) {
      success.run();
   }

   // $FF: synthetic method
   public void fail(String message) {
      if (this.failure != null) {
         this.failure.accept(message);
      }

   }

   // $FF: synthetic method
   public void succeed(Packet packet) {
      if (this.success != null) {
         this.success.accept(packet);
      }

   }

   // $FF: synthetic method
   public Callback() {
      this((Consumer)((Consumer)null), (Consumer)null);
   }
}
