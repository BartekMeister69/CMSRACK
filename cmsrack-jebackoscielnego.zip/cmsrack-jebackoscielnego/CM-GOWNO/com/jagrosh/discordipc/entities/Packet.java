package com.jagrosh.discordipc.entities;

import java.nio.ByteBuffer;
import org.json.JSONObject;

public class Packet {
   // $FF: synthetic field
   private final JSONObject data;
   // $FF: synthetic field
   private final Packet.OpCode op;

   // $FF: synthetic method
   public Packet(Packet.OpCode op, JSONObject data) {
      this.op = op;
      this.data = data;
   }

   // $FF: synthetic method
   public byte[] toBytes() {
      byte[] d = this.data.toString().getBytes();
      ByteBuffer packet = ByteBuffer.allocate(d.length + 8);
      packet.putInt(Integer.reverseBytes(this.op.ordinal()));
      packet.putInt(Integer.reverseBytes(d.length));
      packet.put(d);
      return packet.array();
   }

   // $FF: synthetic method
   public JSONObject getJson() {
      return this.data;
   }

   // $FF: synthetic method
   public String toString() {
      return "Pkt:" + this.getOp() + this.getJson().toString();
   }

   // $FF: synthetic method
   public Packet.OpCode getOp() {
      return this.op;
   }

   public static enum OpCode {
      // $FF: synthetic field
      HANDSHAKE,
      // $FF: synthetic field
      FRAME,
      // $FF: synthetic field
      CLOSE,
      // $FF: synthetic field
      PING,
      // $FF: synthetic field
      PONG;

      private static final Packet.OpCode[] $VALUES = new Packet.OpCode[]{HANDSHAKE, FRAME, CLOSE, PING, PONG};
   }
}
