package com.jagrosh.discordipc.entities.pipe;

public enum PipeStatus {
   // $FF: synthetic field
   UNINITIALIZED,
   // $FF: synthetic field
   CONNECTING,
   // $FF: synthetic field
   CONNECTED,
   // $FF: synthetic field
   CLOSED,
   // $FF: synthetic field
   DISCONNECTED;

   private static final PipeStatus[] $VALUES = new PipeStatus[]{UNINITIALIZED, CONNECTING, CONNECTED, CLOSED, DISCONNECTED};
}
