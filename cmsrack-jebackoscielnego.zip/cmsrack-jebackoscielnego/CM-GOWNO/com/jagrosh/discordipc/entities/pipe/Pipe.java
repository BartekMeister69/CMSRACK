package com.jagrosh.discordipc.entities.pipe;

import com.jagrosh.discordipc.IPCClient;
import com.jagrosh.discordipc.IPCListener;
import com.jagrosh.discordipc.entities.Callback;
import com.jagrosh.discordipc.entities.DiscordBuild;
import com.jagrosh.discordipc.entities.Packet;
import com.jagrosh.discordipc.exceptions.NoDiscordClientException;
import java.io.IOException;
import java.util.HashMap;
import java.util.UUID;
import org.json.JSONException;
import org.json.JSONObject;

public abstract class Pipe {
   // $FF: synthetic field
   final IPCClient ipcClient;
   // $FF: synthetic field
   private static final String[] unixPaths = new String[]{"XDG_RUNTIME_DIR", "TMPDIR", "TMP", "TEMP"};
   // $FF: synthetic field
   private static final int VERSION = 1;
   // $FF: synthetic field
   private final HashMap callbacks;
   // $FF: synthetic field
   PipeStatus status;
   // $FF: synthetic field
   IPCListener listener;
   // $FF: synthetic field
   private DiscordBuild build;

   // $FF: synthetic method
   public abstract void close() throws IOException;

   // $FF: synthetic method
   public PipeStatus getStatus() {
      return this.status;
   }

   // $FF: synthetic method
   public DiscordBuild getDiscordBuild() {
      return this.build;
   }

   // $FF: synthetic method
   public abstract Packet read() throws IOException, JSONException;

   // $FF: synthetic method
   private static String getPipeLocation(int i) {
      if (System.getProperty("os.name").contains("Win")) {
         return "\\\\?\\pipe\\discord-ipc-" + i;
      } else {
         String tmppath = null;
         String[] var2 = unixPaths;
         int var3 = var2.length;

         for(int var4 = 0; var4 < var3; ++var4) {
            String str = var2[var4];
            tmppath = System.getenv(str);
            if (tmppath != null) {
               break;
            }
         }

         if (tmppath == null) {
            tmppath = "/tmp";
         }

         return tmppath + "/discord-ipc-" + i;
      }
   }

   // $FF: synthetic method
   Pipe(IPCClient ipcClient, HashMap callbacks) {
      this.status = PipeStatus.CONNECTING;
      this.ipcClient = ipcClient;
      this.callbacks = callbacks;
   }

   // $FF: synthetic method
   private static Pipe createPipe(IPCClient ipcClient, HashMap callbacks, String location) {
      String osName = System.getProperty("os.name").toLowerCase();
      if (osName.contains("win")) {
         return new WindowsPipe(ipcClient, callbacks, location);
      } else if (!osName.contains("linux") && !osName.contains("mac")) {
         throw new RuntimeException("Unsupported OS: " + osName);
      } else {
         try {
            return new UnixPipe(ipcClient, callbacks, location);
         } catch (IOException var5) {
            throw new RuntimeException(var5);
         }
      }
   }

   // $FF: synthetic method
   public void setListener(IPCListener listener) {
      this.listener = listener;
   }

   // $FF: synthetic method
   public void send(Packet.OpCode op, JSONObject data, Callback callback) {
      try {
         String nonce = generateNonce();
         Packet p = new Packet(op, data.put("nonce", (Object)nonce));
         if (callback != null && !callback.isEmpty()) {
            this.callbacks.put(nonce, callback);
         }

         this.write(p.toBytes());
         if (this.listener != null) {
            this.listener.onPacketSent(this.ipcClient, p);
         }
      } catch (IOException var6) {
         this.status = PipeStatus.DISCONNECTED;
      }

   }

   // $FF: synthetic method
   private static String generateNonce() {
      return UUID.randomUUID().toString();
   }

   // $FF: synthetic method
   public abstract void write(byte[] var1) throws IOException;

   // $FF: synthetic method
   public static Pipe openPipe(IPCClient ipcClient, long clientId, HashMap callbacks, DiscordBuild... preferredOrder) throws NoDiscordClientException {
      if (preferredOrder == null || preferredOrder.length == 0) {
         preferredOrder = new DiscordBuild[]{DiscordBuild.ANY};
      }

      Pipe pipe = null;
      Pipe[] open = new Pipe[DiscordBuild.values().length];

      int i;
      for(i = 0; i < 10; ++i) {
         try {
            String location = getPipeLocation(i);
            pipe = createPipe(ipcClient, callbacks, location);
            pipe.send(Packet.OpCode.HANDSHAKE, (new JSONObject()).put("v", 1).put("client_id", (Object)Long.toString(clientId)), (Callback)null);
            Packet p = pipe.read();
            pipe.build = DiscordBuild.from(p.getJson().getJSONObject("data").getJSONObject("config").getString("api_endpoint"));
            if (pipe.build == preferredOrder[0] || DiscordBuild.ANY == preferredOrder[0]) {
               break;
            }

            open[pipe.build.ordinal()] = pipe;
            open[DiscordBuild.ANY.ordinal()] = pipe;
            pipe.build = null;
            pipe = null;
         } catch (JSONException | IOException var11) {
            pipe = null;
         }
      }

      if (pipe == null) {
         label67:
         for(i = 1; i < preferredOrder.length; ++i) {
            DiscordBuild cb = preferredOrder[i];
            if (open[cb.ordinal()] != null) {
               pipe = open[cb.ordinal()];
               open[cb.ordinal()] = null;
               if (cb == DiscordBuild.ANY) {
                  int k = 0;

                  while(true) {
                     if (k >= open.length) {
                        break label67;
                     }

                     if (open[k] == pipe) {
                        pipe.build = DiscordBuild.values()[k];
                        open[k] = null;
                     }

                     ++k;
                  }
               }

               pipe.build = cb;
               break;
            }
         }

         if (pipe == null) {
            throw new NoDiscordClientException();
         }
      }

      for(i = 0; i < open.length; ++i) {
         if (i != DiscordBuild.ANY.ordinal() && open[i] != null) {
            try {
               open[i].close();
            } catch (IOException var10) {
            }
         }
      }

      pipe.status = PipeStatus.CONNECTED;
      return pipe;
   }

   // $FF: synthetic method
   public void setStatus(PipeStatus status) {
      this.status = status;
   }
}
