package com.jagrosh.discordipc.entities.pipe;

import com.jagrosh.discordipc.IPCClient;
import com.jagrosh.discordipc.entities.Callback;
import com.jagrosh.discordipc.entities.Packet;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.HashMap;
import org.json.JSONException;
import org.json.JSONObject;

public class WindowsPipe extends Pipe {
   // $FF: synthetic field
   private final RandomAccessFile file;

   // $FF: synthetic method
   public Packet read() throws IOException, JSONException {
      while(this.file.length() == 0L && this.status == PipeStatus.CONNECTED) {
         try {
            Thread.sleep(50L);
         } catch (InterruptedException var5) {
         }
      }

      if (this.status == PipeStatus.DISCONNECTED) {
         throw new IOException("Disconnected!");
      } else if (this.status == PipeStatus.CLOSED) {
         return new Packet(Packet.OpCode.CLOSE, (JSONObject)null);
      } else {
         Packet.OpCode op = Packet.OpCode.values()[Integer.reverseBytes(this.file.readInt())];
         int len = Integer.reverseBytes(this.file.readInt());
         byte[] d = new byte[len];
         this.file.readFully(d);
         Packet p = new Packet(op, new JSONObject(new String(d)));
         if (this.listener != null) {
            this.listener.onPacketReceived(this.ipcClient, p);
         }

         return p;
      }
   }

   // $FF: synthetic method
   public void close() throws IOException {
      this.send(Packet.OpCode.CLOSE, new JSONObject(), (Callback)null);
      this.status = PipeStatus.CLOSED;
      this.file.close();
   }

   // $FF: synthetic method
   WindowsPipe(IPCClient ipcClient, HashMap callbacks, String location) {
      super(ipcClient, callbacks);

      try {
         this.file = new RandomAccessFile(location, "rw");
      } catch (FileNotFoundException var5) {
         throw new RuntimeException(var5);
      }
   }

   // $FF: synthetic method
   public void write(byte[] b) throws IOException {
      this.file.write(b);
   }
}
