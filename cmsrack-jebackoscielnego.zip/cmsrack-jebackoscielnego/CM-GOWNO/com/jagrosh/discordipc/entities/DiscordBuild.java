package com.jagrosh.discordipc.entities;

public enum DiscordBuild {
   // $FF: synthetic field
   CANARY("//canary.discordapp.com/api"),
   // $FF: synthetic field
   PTB("//ptb.discordapp.com/api"),
   // $FF: synthetic field
   STABLE("//discordapp.com/api"),
   // $FF: synthetic field
   ANY;

   // $FF: synthetic field
   private final String endpoint;
   private static final DiscordBuild[] $VALUES = new DiscordBuild[]{CANARY, PTB, STABLE, ANY};

   // $FF: synthetic method
   private DiscordBuild(String endpoint) {
      this.endpoint = endpoint;
   }

   // $FF: synthetic method
   private DiscordBuild() {
      this((String)null);
   }

   // $FF: synthetic method
   public static DiscordBuild from(String endpoint) {
      DiscordBuild[] var1 = values();
      int var2 = var1.length;

      for(int var3 = 0; var3 < var2; ++var3) {
         DiscordBuild value = var1[var3];
         if (value.endpoint != null && value.endpoint.equals(endpoint)) {
            return value;
         }
      }

      return ANY;
   }
}
