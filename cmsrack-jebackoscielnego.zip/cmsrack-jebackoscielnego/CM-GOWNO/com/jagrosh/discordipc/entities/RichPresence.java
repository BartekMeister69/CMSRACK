package com.jagrosh.discordipc.entities;

import java.time.OffsetDateTime;
import org.json.JSONArray;
import org.json.JSONObject;

public class RichPresence {
   // $FF: synthetic field
   private final String partyId;
   // $FF: synthetic field
   private final String spectateSecret;
   // $FF: synthetic field
   private final String matchSecret;
   // $FF: synthetic field
   private final OffsetDateTime endTimestamp;
   // $FF: synthetic field
   private final boolean instance;
   // $FF: synthetic field
   private final int partySize;
   // $FF: synthetic field
   private final String joinSecret;
   // $FF: synthetic field
   private final String state;
   // $FF: synthetic field
   private final String smallImageText;
   // $FF: synthetic field
   private final String largeImageText;
   // $FF: synthetic field
   private final String smallImageKey;
   // $FF: synthetic field
   private final String details;
   // $FF: synthetic field
   private final String largeImageKey;
   // $FF: synthetic field
   private final int partyMax;
   // $FF: synthetic field
   private final OffsetDateTime startTimestamp;

   // $FF: synthetic method
   public RichPresence(String state, String details, OffsetDateTime startTimestamp, OffsetDateTime endTimestamp, String largeImageKey, String largeImageText, String smallImageKey, String smallImageText, String partyId, int partySize, int partyMax, String matchSecret, String joinSecret, String spectateSecret, boolean instance) {
      this.state = state;
      this.details = details;
      this.startTimestamp = startTimestamp;
      this.endTimestamp = endTimestamp;
      this.largeImageKey = largeImageKey;
      this.largeImageText = largeImageText;
      this.smallImageKey = smallImageKey;
      this.smallImageText = smallImageText;
      this.partyId = partyId;
      this.partySize = partySize;
      this.partyMax = partyMax;
      this.matchSecret = matchSecret;
      this.joinSecret = joinSecret;
      this.spectateSecret = spectateSecret;
      this.instance = instance;
   }

   // $FF: synthetic method
   public JSONObject toJson() {
      return (new JSONObject()).put("state", (Object)this.state).put("details", (Object)this.details).put("timestamps", (Object)(new JSONObject()).put("start", (Object)(this.startTimestamp == null ? null : this.startTimestamp.toEpochSecond())).put("end", (Object)(this.endTimestamp == null ? null : this.endTimestamp.toEpochSecond()))).put("assets", (Object)(new JSONObject()).put("large_image", (Object)this.largeImageKey).put("large_text", (Object)this.largeImageText).put("small_image", (Object)this.smallImageKey).put("small_text", (Object)this.smallImageText)).put("party", (Object)(this.partyId == null ? null : (new JSONObject()).put("id", (Object)this.partyId).put("size", (Object)(new JSONArray()).put(this.partySize).put(this.partyMax)))).put("secrets", (Object)(new JSONObject()).put("join", (Object)this.joinSecret).put("spectate", (Object)this.spectateSecret).put("match", (Object)this.matchSecret)).put("instance", this.instance);
   }

   public static class Builder {
      // $FF: synthetic field
      private String matchSecret;
      // $FF: synthetic field
      private String state;
      // $FF: synthetic field
      private String details;
      // $FF: synthetic field
      private String smallImageKey;
      // $FF: synthetic field
      private String partyId;
      // $FF: synthetic field
      private String largeImageKey;
      // $FF: synthetic field
      private String spectateSecret;
      // $FF: synthetic field
      private String largeImageText;
      // $FF: synthetic field
      private int partyMax;
      // $FF: synthetic field
      private OffsetDateTime endTimestamp;
      // $FF: synthetic field
      private boolean instance;
      // $FF: synthetic field
      private int partySize;
      // $FF: synthetic field
      private String joinSecret;
      // $FF: synthetic field
      private String smallImageText;
      // $FF: synthetic field
      private OffsetDateTime startTimestamp;

      // $FF: synthetic method
      public RichPresence.Builder setSmallImage(String smallImageKey) {
         return this.setSmallImage(smallImageKey, (String)null);
      }

      // $FF: synthetic method
      public RichPresence.Builder setEndTimestamp(OffsetDateTime endTimestamp) {
         this.endTimestamp = endTimestamp;
         return this;
      }

      // $FF: synthetic method
      public RichPresence.Builder setDetails(String details) {
         this.details = details;
         return this;
      }

      // $FF: synthetic method
      public RichPresence.Builder setInstance(boolean instance) {
         this.instance = instance;
         return this;
      }

      // $FF: synthetic method
      public RichPresence.Builder setMatchSecret(String matchSecret) {
         this.matchSecret = matchSecret;
         return this;
      }

      // $FF: synthetic method
      public RichPresence.Builder setLargeImage(String largeImageKey, String largeImageText) {
         this.largeImageKey = largeImageKey;
         this.largeImageText = largeImageText;
         return this;
      }

      // $FF: synthetic method
      public RichPresence.Builder setState(String state) {
         this.state = state;
         return this;
      }

      // $FF: synthetic method
      public RichPresence.Builder setParty(String partyId, int partySize, int partyMax) {
         this.partyId = partyId;
         this.partySize = partySize;
         this.partyMax = partyMax;
         return this;
      }

      // $FF: synthetic method
      public RichPresence.Builder setSpectateSecret(String spectateSecret) {
         this.spectateSecret = spectateSecret;
         return this;
      }

      // $FF: synthetic method
      public RichPresence build() {
         return new RichPresence(this.state, this.details, this.startTimestamp, this.endTimestamp, this.largeImageKey, this.largeImageText, this.smallImageKey, this.smallImageText, this.partyId, this.partySize, this.partyMax, this.matchSecret, this.joinSecret, this.spectateSecret, this.instance);
      }

      // $FF: synthetic method
      public RichPresence.Builder setStartTimestamp(OffsetDateTime startTimestamp) {
         this.startTimestamp = startTimestamp;
         return this;
      }

      // $FF: synthetic method
      public RichPresence.Builder setLargeImage(String largeImageKey) {
         return this.setLargeImage(largeImageKey, (String)null);
      }

      // $FF: synthetic method
      public RichPresence.Builder setSmallImage(String smallImageKey, String smallImageText) {
         this.smallImageKey = smallImageKey;
         this.smallImageText = smallImageText;
         return this;
      }

      // $FF: synthetic method
      public RichPresence.Builder setJoinSecret(String joinSecret) {
         this.joinSecret = joinSecret;
         return this;
      }
   }
}
