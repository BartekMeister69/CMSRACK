import net.minecraft.client.resources.I18n;

public class jebac_vexiadqmms1d1glhl extends jebac_vexia4oibzo50ubf0 {
   // $FF: synthetic field
   private jebac_vexiavrks9g79h9kq enumShaderOption;

   // $FF: synthetic method
   public jebac_vexiadqmms1d1glhl(jebac_vexiavrks9g79h9kq enumShaderOption, int x, int y, int widthIn, int heightIn) {
      super(enumShaderOption.ordinal(), x, y, widthIn, heightIn, getButtonText(enumShaderOption));
      this.enumShaderOption = enumShaderOption;
   }

   // $FF: synthetic method
   public void updateButtonText() {
      this.displayString = getButtonText(this.enumShaderOption);
   }

   // $FF: synthetic method
   public jebac_vexiavrks9g79h9kq getEnumShaderOption() {
      return this.enumShaderOption;
   }

   // $FF: synthetic method
   private static String getButtonText(jebac_vexiavrks9g79h9kq eso) {
      String s = I18n.format(eso.getResourceKey()) + ": ";
      switch(eso) {
      case ANTIALIASING:
         return s + jebac_vexia041b4maoxy7y.toStringAa(jebac_vexiaflhnh80r1906.configAntialiasingLevel);
      case NORMAL_MAP:
         return s + jebac_vexia041b4maoxy7y.toStringOnOff(jebac_vexiaflhnh80r1906.configNormalMap);
      case SPECULAR_MAP:
         return s + jebac_vexia041b4maoxy7y.toStringOnOff(jebac_vexiaflhnh80r1906.configSpecularMap);
      case RENDER_RES_MUL:
         return s + jebac_vexia041b4maoxy7y.toStringQuality(jebac_vexiaflhnh80r1906.configRenderResMul);
      case SHADOW_RES_MUL:
         return s + jebac_vexia041b4maoxy7y.toStringQuality(jebac_vexiaflhnh80r1906.configShadowResMul);
      case HAND_DEPTH_MUL:
         return s + jebac_vexia041b4maoxy7y.toStringHandDepth(jebac_vexiaflhnh80r1906.configHandDepthMul);
      case CLOUD_SHADOW:
         return s + jebac_vexia041b4maoxy7y.toStringOnOff(jebac_vexiaflhnh80r1906.configCloudShadow);
      case OLD_HAND_LIGHT:
         return s + jebac_vexiaflhnh80r1906.configOldHandLight.getUserValue();
      case OLD_LIGHTING:
         return s + jebac_vexiaflhnh80r1906.configOldLighting.getUserValue();
      case SHADOW_CLIP_FRUSTRUM:
         return s + jebac_vexia041b4maoxy7y.toStringOnOff(jebac_vexiaflhnh80r1906.configShadowClipFrustrum);
      case TWEAK_BLOCK_DAMAGE:
         return s + jebac_vexia041b4maoxy7y.toStringOnOff(jebac_vexiaflhnh80r1906.configTweakBlockDamage);
      default:
         return s + jebac_vexiaflhnh80r1906.getEnumShaderOption(eso);
      }
   }
}
