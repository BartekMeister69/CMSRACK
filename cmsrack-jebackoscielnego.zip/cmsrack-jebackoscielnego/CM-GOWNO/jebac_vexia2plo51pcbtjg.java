import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.resources.I18n;

public class jebac_vexia2plo51pcbtjg extends jebac_vexiakl614w3uw0xg {
   private final jebac_vexiakl614w3uw0xg  ei;
   private jebac_vexia1571lv7keca1  eg;
   private static final String[]  ee;
   private jebac_vexia1571lv7keca1  ef;
   private static final int[]  eh;

   // $FF: synthetic method
   private static boolean lIIIIIllI(int var0, int var1) {
      return var0 < var1;
   }

   // $FF: synthetic method
   private static boolean lllIlIlI(int var0) {
      return var0 != 0;
   }

   // $FF: synthetic method
   private static String llIlIlll(String var0, String var1) {
      var0 = new String(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      String var2 = new StringBuilder();
      StringBuilder var3 = var1.toCharArray();
      long var4 =  eh[0];
      short var5 = var0.toCharArray();
      String var6 = var5.length;
      int var7 =  eh[0];

      do {
         if (!lIIIIIllI(var7, var6)) {
            return String.valueOf(var2);
         }

         char[] var8 = var5[var7];
         var2.append((char)(var8 ^ var3[var4 % var3.length]));
         jebac_vexiaqb58506wt8o3.  ‏ ("", -1914576675).length();
         ++var4;
         ++var7;
         jebac_vexiaqb58506wt8o3.  ‏ ("", -528718747).length();
      } while(-jebac_vexiaqb58506wt8o3.  ‏ ("᥎", -1869014674).length() == -jebac_vexiaqb58506wt8o3.  ‏ ("吞", 18961470).length());

      return null;
   }

   // $FF: synthetic method
   private static String llIllIIl(String var0, String var1) {
      try {
         SecretKeySpec var2 = new SecretKeySpec(MessageDigest.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("冨冡凐", 982405605)).digest(var1.getBytes(StandardCharsets.UTF_8)), jebac_vexiaqb58506wt8o3.  ‏ ("濶濘濛濃濒濝濇濜", 1566142388));
         Cipher var3 = Cipher.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("斿斑斒斊斛斔斎斕", -2044566019));
         var3.init( eh[1], var2);
         return new String(var3.doFinal(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var10) {
         var10.printStackTrace();
         return null;
      }
   }

   // $FF: synthetic method
   private static void lllIIIIl() {
       ee = new String[ eh[21]];
       ee[ eh[0]] = llIlIlll(jebac_vexiaqb58506wt8o3.  ‏ ("譝譎謹謹證譥譌譂譄譴譮譔譋譺譄譴譬譵譄譚譏譤譮譼譎譪譵譟譩謵譂譾譊譎謽譼譅譌謰謰", 1561103117), jebac_vexiaqb58506wt8o3.  ‏ ("刐刬到刂刂", -1536208261));
       ee[ eh[6]] = llIllIII(jebac_vexiaqb58506wt8o3.  ‏ ("텱템텬텿템텖템텇텴텐턔턗텟턎텼텷턐텵텏텨텷텪텮텔텤텗턕텊텿텓텁텲텁텓텡텠텨텐텏텂텒텬텨턘", 510972197), jebac_vexiaqb58506wt8o3.  ‏ ("烧烮烑烚烻", -1598721900));
       ee[ eh[1]] = llIllIIl(jebac_vexiaqb58506wt8o3.  ‏ ("謨謊謼譩譥謴謱譤謼譤譡謃謝謣謊謂謳謆謆謒謈謗謇謻謽謣謘謠謶謻譡謅", 66161488), jebac_vexiaqb58506wt8o3.  ‏ ("枢枙枢枈枼", 820406232));
       ee[ eh[8]] = llIlIlll(jebac_vexiaqb58506wt8o3.  ‏ ("ﮃ﮸ﯹﮭﮠﮀﯱﯹﮍﮫﮮﮱﮇﮒﮛﯴﮠ﮲ﮎ﮷ﮃﮓﯱﮊﮅ﮶ﯼﯼ", -203162687), jebac_vexiaqb58506wt8o3.  ‏ ("덢덲덻덹덗", -1151356111));
       ee[ eh[10]] = llIllIII(jebac_vexiaqb58506wt8o3.  ‏ ("閰间閁閔閵閌閹闯閚閜閸閫閫閽閗閯開閶閵閐閁閮閳閬閶閏閗閼閉閷閶閟", 1605932507), jebac_vexiaqb58506wt8o3.  ‏ ("﹝﹛﹂﹪﹡", -1843986896));
       ee[ eh[7]] = llIllIIl(jebac_vexiaqb58506wt8o3.  ‏ ("㮦㮄㮭㮾㯦㮡㮘㮸㮡㮺㮛㮷㮦㮭㮖㮓㯦㮘㮢㮙㮙㮏㮇㮘㯢㮒㮧㮑㯢㮇㮆㮅", -1055704107), jebac_vexiaqb58506wt8o3.  ‏ ("䬡䬱䬴䬨䬕", 1931955046));
       ee[ eh[3]] = llIllIIl(jebac_vexiaqb58506wt8o3.  ‏ ("儠儧儜儇儳兿儡兹儩儠儰儯儌儻儲儚儓养兿儲儾儛具具", -925216438), jebac_vexiaqb58506wt8o3.  ‏ ("㫑㫽㫟㫔㫣", -857392458));
       ee[ eh[11]] = llIllIIl(jebac_vexiaqb58506wt8o3.  ‏ ("嵌嵩嵕嵉嵙嵋嵝嵓嵟嵢崫嵪嵙嵟崰崩崰嵶崬嵙嵸嵊崦崦", -1395696357), jebac_vexiaqb58506wt8o3.  ‏ ("㴼㴦㴨㴐㴼", -1005175478));
       ee[ eh[13]] = llIlIlll(jebac_vexiaqb58506wt8o3.  ‏ ("芳芵芥芥芲芃苅苅芠芥苉苉", -1479376140), jebac_vexiaqb58506wt8o3.  ‏ ("\uf130\uf112\uf10b\uf11c\uf11a", 945680767));
       ee[ eh[14]] = llIllIII(jebac_vexiaqb58506wt8o3.  ‏ ("蚄蚘蚹蛛蚞蚊蚺蚡蚳蚀蚉蚉蛀蛜蚻蚀蚉蚎蚱蛚蛙蚜蛖蛖", -1650620693), jebac_vexiaqb58506wt8o3.  ‏ ("͚͛ͤ̈́ͱ", 1452344086));
       ee[ eh[17]] = llIllIII(jebac_vexiaqb58506wt8o3.  ‏ ("撦撰撸撨撷撗撷撧撓撖撳擎撚撺撉撉操擊撯撲撟撯擃擃", 498099454), jebac_vexiaqb58506wt8o3.  ‏ ("\ue674\ue67c\ue67c\ue65e\ue674", -6101479));
       ee[ eh[18]] = llIlIlll(jebac_vexiaqb58506wt8o3.  ‏ ("ꩋꩿꩇꩇꩌ꩗\uaa3e꩖ꩈꩮꩩꩲꩁ꩓꩟ꨲꩁꩿꩭ\uaa4fꩄꩿꩇꩄ", -797267450), jebac_vexiaqb58506wt8o3.  ‏ ("횣횖횱횁횽", -885729595));
   }

   // $FF: synthetic method
   protected void actionPerformed(jebac_vexia4oibzo50ubf0 var1) throws IOException {
      if (lllIlIlI(var1.enabled)) {
         if (lIIIIIlII(var1.id)) {
            int var10000;
            if (lIIIIIlII(jebac_vexiawzpzy1x3sez8. by)) {
               var10000 =  eh[6];
               jebac_vexiaqb58506wt8o3.  ‏ ("", -2119852101).length();
               if ((36 + 129 - 53 + 75 ^ 127 + 169 - 123 + 17) == 0) {
                  return;
               }
            } else {
               var10000 =  eh[0];
            }

            jebac_vexiawzpzy1x3sez8. by = (boolean)var10000;
            this.mc.displayGuiScreen(this);
            jebac_vexiaqb58506wt8o3.  ‏ ("", 739509144).length();
            if (-jebac_vexiaqb58506wt8o3.  ‏ ("མ", -1057353864).length() >= 0) {
               return;
            }
         } else {
            int var10001;
            jebac_vexia5c4je8aazc78 var4;
            if (lIIIIIlIl(var1.id,  eh[6])) {
               var4 = jebac_vexiaau3mg1q92fzj. ea;
               if (lIIIIIlII(jebac_vexiaau3mg1q92fzj. ea. fw)) {
                  var10001 =  eh[6];
                  jebac_vexiaqb58506wt8o3.  ‏ ("", 1278583918).length();
                  if ((76 ^ 72) <= jebac_vexiaqb58506wt8o3.  ‏ ("祦祦", -823887546).length()) {
                     return;
                  }
               } else {
                  var10001 =  eh[0];
               }

               var4. fw = (boolean)var10001;
               this.mc.displayGuiScreen(this);
               jebac_vexiaqb58506wt8o3.  ‏ ("", -647560009).length();
               if (-jebac_vexiaqb58506wt8o3.  ‏ ("\uf655", -694487435).length() < -jebac_vexiaqb58506wt8o3.  ‏ ("ʆ", 246809254).length()) {
                  return;
               }
            } else if (lIIIIIlIl(var1.id,  eh[1])) {
               var4 = jebac_vexiaau3mg1q92fzj. ea;
               if (lIIIIIlII(jebac_vexiaau3mg1q92fzj. ea. fr)) {
                  var10001 =  eh[6];
                  jebac_vexiaqb58506wt8o3.  ‏ ("", 1403734760).length();
                  if (jebac_vexiaqb58506wt8o3.  ‏ ("\uf4be", 438301854).length() < 0) {
                     return;
                  }
               } else {
                  var10001 =  eh[0];
               }

               var4. fr = (boolean)var10001;
               this.mc.displayGuiScreen(this);
               jebac_vexiaqb58506wt8o3.  ‏ ("", -737525526).length();
               if ((84 ^ 80) < ((24 ^ 35) & ~(75 ^ 112))) {
                  return;
               }
            } else if (lIIIIIlIl(var1.id,  eh[8])) {
               var4 = jebac_vexiaau3mg1q92fzj. ea;
               if (lIIIIIlII(jebac_vexiaau3mg1q92fzj. ea. fu)) {
                  var10001 =  eh[6];
                  jebac_vexiaqb58506wt8o3.  ‏ ("", 144947028).length();
                  if ((59 + 110 - 25 + 9 ^ 128 + 135 - 120 + 14) <= 0) {
                     return;
                  }
               } else {
                  var10001 =  eh[0];
               }

               var4. fu = (boolean)var10001;
               this.mc.displayGuiScreen(this);
               jebac_vexiaqb58506wt8o3.  ‏ ("", 1209340006).length();
               if (jebac_vexiaqb58506wt8o3.  ‏ ("\udd63\udd63\udd63", -1136992957).length() <= 0) {
                  return;
               }
            } else if (lIIIIIlIl(var1.id,  eh[3])) {
               this.mc.displayGuiScreen(this. ei);
            }
         }

         jebac_vexia67ba3dligh23.save();
      }

   }

   // $FF: synthetic method
   private static boolean lIIIIIlIl(int var0, int var1) {
      return var0 == var1;
   }

   // $FF: synthetic method
   private static void lllIlIIl() {
       eh = new int[22];
       eh[0] = (107 ^ 80) & ~(147 ^ 168);
       eh[1] = jebac_vexiaqb58506wt8o3.  ‏ ("ᰄᰄ", -929555420).length();
       eh[2] = (161 ^ 167) + 108 + 88 - 111 + 62 - (86 ^ 78) + (20 ^ 14);
       eh[3] = 105 ^ 120 ^ 180 ^ 163;
       eh[4] = (63 ^ 51) + (85 ^ 62) - -(46 ^ 63) + (149 ^ 155);
       eh[5] = 210 ^ 198;
       eh[6] = jebac_vexiaqb58506wt8o3.  ‏ ("扻", 1644454491).length();
       eh[7] = 185 ^ 188;
       eh[8] = jebac_vexiaqb58506wt8o3.  ‏ ("䔪䔪䔪", 1997554954).length();
       eh[9] = 167 ^ 182 ^ 66 ^ 75;
       eh[10] = 239 ^ 155 ^ 62 ^ 78;
       eh[11] = 73 ^ 78;
       eh[12] = 75 ^ 123;
       eh[13] = 74 ^ 66;
       eh[14] = 125 ^ 116;
       eh[15] = 199 ^ 163;
       eh[16] = 69 + 51 - 48 + 96;
       eh[17] = 62 ^ 71 ^ 6 ^ 117;
       eh[18] = 165 ^ 174;
       eh[19] = 81 + 58 - 85 + 73 ^ 2 ^ 114;
       eh[20] = -1 & 16777215;
       eh[21] = 93 ^ 81;
   }

   // $FF: synthetic method
   protected void mouseClickMove(int var1, int var2, int var3, long var4) {
      super.mouseClickMove(var1, var2, var3, var4);
      this.update();
   }

   // $FF: synthetic method
   private static boolean lIIIIIlII(int var0) {
      return var0 == 0;
   }

   // $FF: synthetic method
   public void drawScreen(int var1, int var2, float var3) {
      this.drawDefaultBackground();
      this.drawCenteredString(this.fontRendererObj,  ee[ eh[18]], this.width /  eh[1],  eh[19],  eh[20]);
      super.drawScreen(var1, var2, var3);
   }

   // $FF: synthetic method
   private static String llIllIII(String var0, String var1) {
      try {
         SecretKeySpec var2 = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("嫥嫬媝", -1801037144)).digest(var1.getBytes(StandardCharsets.UTF_8)),  eh[13]), jebac_vexiaqb58506wt8o3.  ‏ ("擨擩擿", 251749548));
         String var3 = Cipher.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("₀₁ₗ", 1701257412));
         var3.init( eh[1], var2);
         return new String(var3.doFinal(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var9) {
         var9.printStackTrace();
         return null;
      }
   }

   // $FF: synthetic method
   public jebac_vexia2plo51pcbtjg(jebac_vexiakl614w3uw0xg var1) {
      this. ei = var1;
   }

   // $FF: synthetic method
   public void initGui() {
      List var10000 = this.buttonList;
      jebac_vexia4oibzo50ubf0 var10001 = new jebac_vexia4oibzo50ubf0;
      int var10003 =  eh[0];
      int var10004 = this.width /  eh[1] -  eh[2];
      int var10005 = this.height /  eh[3] -  eh[3];
      int var10006 =  eh[4];
      int var10007 =  eh[5];
      String var10008;
      if (lllIlIlI(jebac_vexiawzpzy1x3sez8. by)) {
         var10008 =  ee[ eh[0]];
         jebac_vexiaqb58506wt8o3.  ‏ ("", 1369701429).length();
         if (-jebac_vexiaqb58506wt8o3.  ‏ ("\uf377", -1815678121).length() != -jebac_vexiaqb58506wt8o3.  ‏ ("੯", -1097463217).length()) {
            return;
         }
      } else {
         var10008 =  ee[ eh[6]];
      }

      var10001.<init>(var10003, var10004, var10005, var10006, var10007, var10008);
      var10000.add(var10001);
      jebac_vexiaqb58506wt8o3.  ‏ ("", -647703852).length();
      var10000 = this.buttonList;
      var10001 = new jebac_vexia4oibzo50ubf0;
      var10003 =  eh[6];
      var10004 = this.width /  eh[1] +  eh[7];
      var10005 = this.height /  eh[3] -  eh[3];
      var10006 =  eh[4];
      var10007 =  eh[5];
      if (lllIlIlI(jebac_vexiaau3mg1q92fzj. ea. fw)) {
         var10008 =  ee[ eh[1]];
         jebac_vexiaqb58506wt8o3.  ‏ ("", -265064997).length();
         if (null != null) {
            return;
         }
      } else {
         var10008 =  ee[ eh[8]];
      }

      var10001.<init>(var10003, var10004, var10005, var10006, var10007, var10008);
      var10000.add(var10001);
      jebac_vexiaqb58506wt8o3.  ‏ ("", -254143379).length();
      var10000 = this.buttonList;
      var10001 = new jebac_vexia4oibzo50ubf0;
      var10003 =  eh[1];
      var10004 = this.width /  eh[1] -  eh[2];
      var10005 = this.height /  eh[3] +  eh[9] -  eh[3];
      var10006 =  eh[4];
      var10007 =  eh[5];
      if (lllIlIlI(jebac_vexiaau3mg1q92fzj. ea. fr)) {
         var10008 =  ee[ eh[10]];
         jebac_vexiaqb58506wt8o3.  ‏ ("", -1224398234).length();
         if (((185 ^ 147) & ~(152 ^ 178)) == -jebac_vexiaqb58506wt8o3.  ‏ ("繝", 1358593661).length()) {
            return;
         }
      } else {
         var10008 =  ee[ eh[7]];
      }

      var10001.<init>(var10003, var10004, var10005, var10006, var10007, var10008);
      var10000.add(var10001);
      jebac_vexiaqb58506wt8o3.  ‏ ("", 1228263488).length();
      var10000 = this.buttonList;
      var10001 = new jebac_vexia4oibzo50ubf0;
      var10003 =  eh[8];
      var10004 = this.width /  eh[1] +  eh[7];
      var10005 = this.height /  eh[3] +  eh[9] -  eh[3];
      var10006 =  eh[4];
      var10007 =  eh[5];
      if (lllIlIlI(jebac_vexiaau3mg1q92fzj. ea. fu)) {
         var10008 =  ee[ eh[3]];
         jebac_vexiaqb58506wt8o3.  ‏ ("", 1182203353).length();
         if (((156 ^ 189) & ~(231 ^ 198)) != 0) {
            return;
         }
      } else {
         var10008 =  ee[ eh[11]];
      }

      var10001.<init>(var10003, var10004, var10005, var10006, var10007, var10008);
      var10000.add(var10001);
      jebac_vexiaqb58506wt8o3.  ‏ ("", 291760600).length();
      this.buttonList.add(this. eg = new jebac_vexia1571lv7keca1( eh[10], this.width /  eh[1] -  eh[2], this.height /  eh[3] +  eh[12] -  eh[3],  eh[4],  eh[5],  ee[ eh[13]], 50.0D, 300.0D, (double)jebac_vexiaau3mg1q92fzj. ea. fm));
      jebac_vexiaqb58506wt8o3.  ‏ ("", -102012882).length();
      this.buttonList.add(this. ef = new jebac_vexia1571lv7keca1( eh[7], this.width /  eh[1] +  eh[7], this.height /  eh[3] +  eh[12] -  eh[3],  eh[4],  eh[5],  ee[ eh[14]], 300.0D, 1200.0D, (double)jebac_vexiaau3mg1q92fzj. ea. fk));
      jebac_vexiaqb58506wt8o3.  ‏ ("", -1842270768).length();
      this.buttonList.add(new jebac_vexia4oibzo50ubf0( eh[3], this.width /  eh[1] -  eh[15], this.height /  eh[3] +  eh[16], I18n.format( ee[ eh[17]])));
      jebac_vexiaqb58506wt8o3.  ‏ ("", -540722883).length();
      if (lIIIIIlII(jebac_vexiawzpzy1x3sez8. by)) {
         ((jebac_vexia4oibzo50ubf0)this.buttonList.get( eh[6])).enabled = (boolean) eh[0];
         ((jebac_vexia4oibzo50ubf0)this.buttonList.get( eh[1])).enabled = (boolean) eh[0];
         ((jebac_vexia4oibzo50ubf0)this.buttonList.get( eh[8])).enabled = (boolean) eh[0];
         ((jebac_vexia4oibzo50ubf0)this.buttonList.get( eh[10])).enabled = (boolean) eh[0];
         ((jebac_vexia4oibzo50ubf0)this.buttonList.get( eh[7])).enabled = (boolean) eh[0];
      }

   }

   // $FF: synthetic method
   protected void mouseReleased(int var1, int var2, int var3) {
      super.mouseReleased(var1, var2, var3);
      this.update();
   }

   // $FF: synthetic method
   protected void mouseClicked(int var1, int var2, int var3) throws IOException {
      super.mouseClicked(var1, var2, var3);
      this.update();
   }

   static {
      lllIlIIl();
      lllIIIIl();
   }

   // $FF: synthetic method
   private void update() {
      jebac_vexiaau3mg1q92fzj. ea. fm = this. eg.getValueInt();
      jebac_vexiaau3mg1q92fzj. ea. fk = this. ef.getValueInt();
   }
}
