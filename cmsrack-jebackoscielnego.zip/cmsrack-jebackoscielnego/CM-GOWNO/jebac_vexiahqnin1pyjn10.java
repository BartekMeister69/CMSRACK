import java.io.IOException;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.settings.GameSettings;

public class jebac_vexiahqnin1pyjn10 extends jebac_vexiakl614w3uw0xg {
   // $FF: synthetic field
   private jebac_vexiapguljx25lc0b tooltipManager = new jebac_vexiapguljx25lc0b(this);
   // $FF: synthetic field
   private GameSettings guiGameSettings;
   // $FF: synthetic field
   private static GameSettings.Options[] videoOptions;
   // $FF: synthetic field
   protected String screenTitle = "Video Settings";
   // $FF: synthetic field
   private jebac_vexiakl614w3uw0xg parentGuiScreen;

   // $FF: synthetic method
   public jebac_vexiahqnin1pyjn10(jebac_vexiakl614w3uw0xg parentScreenIn, GameSettings gameSettingsIn) {
      this.parentGuiScreen = parentScreenIn;
      this.guiGameSettings = gameSettingsIn;
   }

   // $FF: synthetic method
   public static int getButtonHeight(jebac_vexia4oibzo50ubf0 p_getButtonHeight_0_) {
      return p_getButtonHeight_0_.height;
   }

   // $FF: synthetic method
   public static void drawGradientRect(jebac_vexiakl614w3uw0xg p_drawGradientRect_0_, int p_drawGradientRect_1_, int p_drawGradientRect_2_, int p_drawGradientRect_3_, int p_drawGradientRect_4_, int p_drawGradientRect_5_, int p_drawGradientRect_6_) {
      p_drawGradientRect_0_.drawGradientRect(p_drawGradientRect_1_, p_drawGradientRect_2_, p_drawGradientRect_3_, p_drawGradientRect_4_, p_drawGradientRect_5_, p_drawGradientRect_6_);
   }

   // $FF: synthetic method
   public static int getButtonWidth(jebac_vexia4oibzo50ubf0 p_getButtonWidth_0_) {
      return p_getButtonWidth_0_.width;
   }

   // $FF: synthetic method
   public void initGui() {
      this.screenTitle = I18n.format("options.videoTitle");
      this.buttonList.clear();

      int l;
      for(l = 0; l < videoOptions.length; ++l) {
         GameSettings.Options gamesettings$options = videoOptions[l];
         int j = this.width / 2 - 155 + l % 2 * 160;
         int k = this.height / 6 + 21 * (l / 2) - 12;
         if (gamesettings$options.getEnumFloat()) {
            this.buttonList.add(new jebac_vexiaildxyx0dfrwq(gamesettings$options.returnEnumOrdinal(), j, k, gamesettings$options));
         } else {
            this.buttonList.add(new jebac_vexia93dz1y66pwuy(gamesettings$options.returnEnumOrdinal(), j, k, gamesettings$options, this.guiGameSettings.getKeyBinding(gamesettings$options)));
         }
      }

      l = this.height / 6 + 21 * (videoOptions.length / 2) - 12;
      int i1 = this.width / 2 - 155;
      this.buttonList.add(new jebac_vexiatgc7sxy17ln0(231, i1, l, jebac_vexia7gzdvsc1kfyf.get("of.options.shaders")));
      i1 = this.width / 2 - 155 + 160;
      this.buttonList.add(new jebac_vexiatgc7sxy17ln0(202, i1, l, jebac_vexia7gzdvsc1kfyf.get("of.options.quality")));
      l += 21;
      i1 = this.width / 2 - 155;
      this.buttonList.add(new jebac_vexiatgc7sxy17ln0(201, i1, l, jebac_vexia7gzdvsc1kfyf.get("of.options.details")));
      i1 = this.width / 2 - 155 + 160;
      this.buttonList.add(new jebac_vexiatgc7sxy17ln0(212, i1, l, jebac_vexia7gzdvsc1kfyf.get("of.options.performance")));
      l += 21;
      i1 = this.width / 2 - 155;
      this.buttonList.add(new jebac_vexiatgc7sxy17ln0(211, i1, l, jebac_vexia7gzdvsc1kfyf.get("of.options.animations")));
      i1 = this.width / 2 - 155 + 160;
      this.buttonList.add(new jebac_vexiatgc7sxy17ln0(222, i1, l, jebac_vexia7gzdvsc1kfyf.get("of.options.other")));
      this.buttonList.add(new jebac_vexia4oibzo50ubf0(200, this.width / 2 - 100, this.height / 6 + 168 + 11, I18n.format("gui.done")));
   }

   // $FF: synthetic method
   public void drawScreen(int mouseX, int mouseY, float partialTicks) {
      this.drawDefaultBackground();
      this.drawCenteredString(this.fontRendererObj, this.screenTitle, this.width / 2, 15, 16777215);
      String s = "OptiFine HD H8 Ultra";
      this.drawString(this.fontRendererObj, s, 2, this.height - 10, 8421504);
      String s2 = "Minecraft 1.8.8";
      int i = this.fontRendererObj.getStringWidth(s2);
      this.drawString(this.fontRendererObj, s2, this.width - i - 2, this.height - 10, 8421504);
      super.drawScreen(mouseX, mouseY, partialTicks);
      this.tooltipManager.drawTooltips(mouseX, mouseY, this.buttonList);
   }

   static {
      videoOptions = new GameSettings.Options[]{GameSettings.Options.GRAPHICS, GameSettings.Options.RENDER_DISTANCE, GameSettings.Options.AMBIENT_OCCLUSION, GameSettings.Options.FRAMERATE_LIMIT, GameSettings.Options.AO_LEVEL, GameSettings.Options.VIEW_BOBBING, GameSettings.Options.GUI_SCALE, GameSettings.Options.USE_VBO, GameSettings.Options.GAMMA, GameSettings.Options.BLOCK_ALTERNATIVES, GameSettings.Options.FOG_FANCY, GameSettings.Options.FOG_START};
   }

   // $FF: synthetic method
   protected void actionPerformed(jebac_vexia4oibzo50ubf0 button) throws IOException {
      if (button.enabled) {
         int i = this.guiGameSettings.guiScale;
         if (button.id < 200 && button instanceof jebac_vexiatgc7sxy17ln0) {
            this.guiGameSettings.setOptionValue(((jebac_vexiatgc7sxy17ln0)button).returnEnumOptions(), 1);
            button.displayString = this.guiGameSettings.getKeyBinding(GameSettings.Options.getEnumOptions(button.id));
         }

         if (button.id == 200) {
            this.mc.gameSettings.saveOptions();
            this.mc.displayGuiScreen(this.parentGuiScreen);
         }

         if (this.guiGameSettings.guiScale != i) {
            jebac_vexiakl8zv2fyoaq8 scaledresolution = new jebac_vexiakl8zv2fyoaq8(this.mc);
            int j = scaledresolution.getScaledWidth();
            int k = scaledresolution.getScaledHeight();
            this.setWorldAndResolution(this.mc, j, k);
         }

         if (button.id == 201) {
            this.mc.gameSettings.saveOptions();
            jebac_vexiab5x720hoz1oh guidetailsettingsof = new jebac_vexiab5x720hoz1oh(this, this.guiGameSettings);
            this.mc.displayGuiScreen(guidetailsettingsof);
         }

         if (button.id == 202) {
            this.mc.gameSettings.saveOptions();
            jebac_vexia5v1ccs4xkg7r guiqualitysettingsof = new jebac_vexia5v1ccs4xkg7r(this, this.guiGameSettings);
            this.mc.displayGuiScreen(guiqualitysettingsof);
         }

         if (button.id == 211) {
            this.mc.gameSettings.saveOptions();
            jebac_vexiaduvqejf2exos guianimationsettingsof = new jebac_vexiaduvqejf2exos(this, this.guiGameSettings);
            this.mc.displayGuiScreen(guianimationsettingsof);
         }

         if (button.id == 212) {
            this.mc.gameSettings.saveOptions();
            jebac_vexiagwbx2ibb3b4b guiperformancesettingsof = new jebac_vexiagwbx2ibb3b4b(this, this.guiGameSettings);
            this.mc.displayGuiScreen(guiperformancesettingsof);
         }

         if (button.id == 222) {
            this.mc.gameSettings.saveOptions();
            jebac_vexiap1jxh9xqi1qv guiothersettingsof = new jebac_vexiap1jxh9xqi1qv(this, this.guiGameSettings);
            this.mc.displayGuiScreen(guiothersettingsof);
         }

         if (button.id == 231) {
            if (jebac_vexiakrwecfs16wve.isAntialiasing() || jebac_vexiakrwecfs16wve.isAntialiasingConfigured()) {
               jebac_vexiakrwecfs16wve.showGuiMessage(jebac_vexia7gzdvsc1kfyf.get("of.message.shaders.aa1"), jebac_vexia7gzdvsc1kfyf.get("of.message.shaders.aa2"));
               return;
            }

            if (jebac_vexiakrwecfs16wve.isAnisotropicFiltering()) {
               jebac_vexiakrwecfs16wve.showGuiMessage(jebac_vexia7gzdvsc1kfyf.get("of.message.shaders.af1"), jebac_vexia7gzdvsc1kfyf.get("of.message.shaders.af2"));
               return;
            }

            if (jebac_vexiakrwecfs16wve.isFastRender()) {
               jebac_vexiakrwecfs16wve.showGuiMessage(jebac_vexia7gzdvsc1kfyf.get("of.message.shaders.fr1"), jebac_vexia7gzdvsc1kfyf.get("of.message.shaders.fr2"));
               return;
            }

            this.mc.gameSettings.saveOptions();
            jebac_vexia041b4maoxy7y guishaders = new jebac_vexia041b4maoxy7y(this, this.guiGameSettings);
            this.mc.displayGuiScreen(guishaders);
         }
      }

   }
}
