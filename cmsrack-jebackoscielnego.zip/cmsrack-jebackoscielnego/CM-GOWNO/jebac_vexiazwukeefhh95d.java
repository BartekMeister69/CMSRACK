import com.google.common.collect.Lists;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.scoreboard.ScorePlayerTeam;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.IChatComponent;

public class jebac_vexiazwukeefhh95d implements jebac_vexialqxnhsad8zg7, jebac_vexia9nzh0zm3n32z {
   // $FF: synthetic field
   private final List field_178672_a = Lists.newArrayList();

   // $FF: synthetic method
   public void func_178663_a(float p_178663_1_, int alpha) {
      Minecraft.getMinecraft().getTextureManager().bindTexture(jebac_vexia4ygfqd1m48f0.field_175269_a);
      jebac_vexiabhi02xzapwrh.drawModalRectWithCustomSizedTexture(0, 0, 16.0F, 0.0F, 16, 16, 256.0F, 256.0F);
   }

   // $FF: synthetic method
   public IChatComponent func_178670_b() {
      return new ChatComponentText("Select a team to teleport to");
   }

   // $FF: synthetic method
   public jebac_vexiazwukeefhh95d() {
      Minecraft minecraft = Minecraft.getMinecraft();
      Iterator var2 = minecraft.theWorld.getScoreboard().getTeams().iterator();

      while(var2.hasNext()) {
         ScorePlayerTeam scoreplayerteam = (ScorePlayerTeam)var2.next();
         this.field_178672_a.add(new jebac_vexiany1xa6v3zwzb(this, scoreplayerteam));
      }

   }

   // $FF: synthetic method
   public List func_178669_a() {
      return this.field_178672_a;
   }

   // $FF: synthetic method
   public IChatComponent getSpectatorName() {
      return new ChatComponentText("Teleport to team member");
   }

   // $FF: synthetic method
   public void func_178661_a(jebac_vexiabhmyylutxyzx menu) {
      menu.func_178647_a(this);
   }

   // $FF: synthetic method
   public boolean func_178662_A_() {
      Iterator var1 = this.field_178672_a.iterator();

      jebac_vexia9nzh0zm3n32z ispectatormenuobject;
      do {
         if (!var1.hasNext()) {
            return false;
         }

         ispectatormenuobject = (jebac_vexia9nzh0zm3n32z)var1.next();
      } while(!ispectatormenuobject.func_178662_A_());

      return true;
   }
}
