public interface jebac_vexiajena7f8xtrrr {
   // $FF: synthetic method
   String getText(int var1, String var2, float var3);
}
