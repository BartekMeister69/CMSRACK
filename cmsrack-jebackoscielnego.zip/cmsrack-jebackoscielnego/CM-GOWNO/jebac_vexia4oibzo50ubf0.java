import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;

public class jebac_vexia4oibzo50ubf0 extends jebac_vexiavi6p6nrwc2g9 {
   // $FF: synthetic field
   protected long animationUpdateTime;
   // $FF: synthetic field
   protected jebac_vexiav9r0ufqgdixo animation;

   // $FF: synthetic method
   public jebac_vexia4oibzo50ubf0(int buttonId, int x, int y, int widthIn, int heightIn, String buttonText) {
      super(buttonId, x, y, widthIn, heightIn, buttonText);
      this.animation = new jebac_vexiav9r0ufqgdixo(10);
   }

   // $FF: synthetic method
   public void drawButton(Minecraft mc, int mouseX, int mouseY) {
      if (jebac_vexiawzpzy1x3sez8. bx) {
         if (this.visible) {
            GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
            this.hovered = mouseX >= this.xPosition && mouseY >= this.yPosition && mouseX < this.xPosition + this.width && mouseY < this.yPosition + this.height;
            if (System.currentTimeMillis() >= this.animationUpdateTime) {
               this.animation.update(this.hovered);
               this.animationUpdateTime = System.currentTimeMillis() + 10L;
            }

            int color = 14737632;
            if (!this.enabled) {
               color = 10526880;
            } else if (this.hovered) {
               color = 16777120;
            }

            this.mouseDragged(mc, mouseX, mouseY);
            this.drawCenteredString(mc.fontRendererObj, this.displayString, this.xPosition + this.width / 2, this.yPosition + (this.height - 8) / 2, color);
            int stringWidth = mc.fontRendererObj.getStringWidth(this.displayString);
            if (this.enabled) {
               jebac_vexiawqkxo5ufmdem.drawLine2D((double)(this.xPosition + this.width / 2) - this.animation.getValue() * (double)stringWidth / 2.0D, (double)(this.yPosition + 18), (double)(this.xPosition + this.width / 2) + this.animation.getValue() * (double)stringWidth / 2.0D, (double)(this.yPosition + 18), 1.0F, jebac_vexiawzpzy1x3sez8. be ? jebac_vexiacs3qcki5ln4n.getRainbow(1000, 15).getRGB() : 14737632);
            }
         }
      } else {
         super.drawButton(mc, mouseX, mouseY);
      }

   }

   // $FF: synthetic method
   public jebac_vexia4oibzo50ubf0(int buttonId, int x, int y, String buttonText) {
      this(buttonId, x, y, 200, 20, buttonText);
   }
}
