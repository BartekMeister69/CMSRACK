import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class jebac_vexiai4ghla0oxuww {
   // $FF: synthetic field
   private Set disabledPrograms = new HashSet();
   // $FF: synthetic field
   private Map mapOptionValues = new HashMap();
   // $FF: synthetic field
   private String name;

   // $FF: synthetic method
   public void addOptionValues(jebac_vexiai4ghla0oxuww prof) {
      if (prof != null) {
         this.mapOptionValues.putAll(prof.mapOptionValues);
      }

   }

   // $FF: synthetic method
   public String getName() {
      return this.name;
   }

   // $FF: synthetic method
   public void addDisabledProgram(String program) {
      this.disabledPrograms.add(program);
   }

   // $FF: synthetic method
   public jebac_vexiai4ghla0oxuww(String name) {
      this.name = name;
   }

   // $FF: synthetic method
   public Collection getDisabledPrograms() {
      return new HashSet(this.disabledPrograms);
   }

   // $FF: synthetic method
   public String[] getOptions() {
      Set set = this.mapOptionValues.keySet();
      return (String[])set.toArray(new String[0]);
   }

   // $FF: synthetic method
   public void addOptionValue(String option, String value) {
      this.mapOptionValues.put(option, value);
   }

   // $FF: synthetic method
   public void addDisabledPrograms(Collection programs) {
      this.disabledPrograms.addAll(programs);
   }

   // $FF: synthetic method
   public String getValue(String key) {
      return (String)this.mapOptionValues.get(key);
   }

   // $FF: synthetic method
   public boolean isProgramDisabled(String program) {
      return this.disabledPrograms.contains(program);
   }
}
