public class jebac_vexiaqjl6i4rxan1x extends jebac_vexiamee1xbabsk4e {
   // $FF: synthetic method
   public jebac_vexiaqjl6i4rxan1x(int p_i45532_1_, String p_i45532_2_, boolean p_i45532_3_) {
      super(p_i45532_1_, p_i45532_2_, p_i45532_3_);
   }
}
