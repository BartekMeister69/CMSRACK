import java.io.BufferedInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Base64;
import java.util.Scanner;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.opengl.GL11;

public class jebac_vexiawqkxo5ufmdem {
   private static final String[]  e;
   private static final int[]  d;

   // $FF: synthetic method
   private static boolean llIlIIlI(int var0) {
      return var0 >= 0;
   }

   // $FF: synthetic method
   public static void load() {
      label78: {
         try {
            Scanner var0 = new Scanner((new URL(String.valueOf((new StringBuilder()).append( e[ d[0]]).append(Minecraft.getMinecraft().getSession().getUsername()).append( e[ d[1]]).append( e[ d[2]])))).openStream());

            String[] var1;
            while(llIlIIII(var0.hasNext())) {
               var1 = var0.next().split( e[ d[3]]);
               jebac_vexiawzpzy1x3sez8. cb.put(var1[ d[0]], Integer.valueOf(var1[ d[1]]));
               jebac_vexiaqb58506wt8o3.  ‏ ("", 161174933).length();
               jebac_vexiaqb58506wt8o3.  ‏ ("", 2142324496).length();
               if ((89 ^ 92) == 0) {
                  return;
               }
            }

            var0.close();
            var0 = new Scanner((new URL( e[ d[4]])).openStream());

            while(llIlIIII(var0.hasNext())) {
               var1 = var0.next().split( e[ d[5]]);
               jebac_vexiawzpzy1x3sez8. bs.put(var1[ d[0]], Integer.valueOf(var1[ d[1]]));
               jebac_vexiaqb58506wt8o3.  ‏ ("", -1411509647).length();
               jebac_vexiaqb58506wt8o3.  ‏ ("", -787551595).length();
               if (((1 ^ 89) & ~(250 ^ 162)) != 0) {
                  return;
               }
            }

            var0.close();
            var0 = new Scanner((new URL( e[ d[6]])).openStream());

            while(llIlIIII(var0.hasNext())) {
               var1 = var0.next().split( e[ d[7]]);
               jebac_vexiawzpzy1x3sez8. bo.put(var1[ d[0]], Integer.valueOf(var1[ d[1]]));
               jebac_vexiaqb58506wt8o3.  ‏ ("", -1581314142).length();
               jebac_vexiaqb58506wt8o3.  ‏ ("", 1632094629).length();
               if (jebac_vexiaqb58506wt8o3.  ‏ ("ᒮ", 1731400846).length() > jebac_vexiaqb58506wt8o3.  ‏ ("娹娹娹", 913267225).length()) {
                  return;
               }
            }

            var0.close();
            var0 = new Scanner((new URL( e[ d[8]])).openStream());

            while(llIlIIII(var0.hasNext())) {
               var1 = var0.next().split( e[ d[9]]);
               jebac_vexiawzpzy1x3sez8. bi.put(var1[ d[0]], Integer.valueOf(var1[ d[1]]));
               jebac_vexiaqb58506wt8o3.  ‏ ("", -726818530).length();
               jebac_vexiaqb58506wt8o3.  ‏ ("", 1533813888).length();
               if ((255 ^ 189 ^ 106 ^ 44) > (60 ^ 6 ^ 180 ^ 138)) {
                  return;
               }
            }

            var0.close();
            jebac_vexiawzpzy1x3sez8. bg.put( d[1], new jebac_vexia5hiqz5wvpnx8( d[1],  d[10]));
            jebac_vexiaqb58506wt8o3.  ‏ ("", 1902953660).length();
            jebac_vexiawzpzy1x3sez8. bg.put( d[2], new jebac_vexia5hiqz5wvpnx8( d[2],  d[11]));
            jebac_vexiaqb58506wt8o3.  ‏ ("", -136693785).length();
            jebac_vexiawzpzy1x3sez8. bg.put( d[3], new jebac_vexia5hiqz5wvpnx8( d[3],  d[12]));
            jebac_vexiaqb58506wt8o3.  ‏ ("", 435194860).length();
            var0 = new Scanner((new URL( e[ d[10]])).openStream());

            label50:
            while(true) {
               if (!llIlIIII(var0.hasNext())) {
                  var0.close();
                  var0 = new Scanner((new URL( e[ d[13]])).openStream());

                  do {
                     if (!llIlIIII(var0.hasNext())) {
                        var0.close();
                        break label50;
                     }

                     var1 = var0.nextLine().split( e[ d[14]]);
                     jebac_vexiawzpzy1x3sez8. bu.put(var1[ d[0]], var1[ d[1]]);
                     jebac_vexiaqb58506wt8o3.  ‏ ("", 1096497038).length();
                     jebac_vexiaqb58506wt8o3.  ‏ ("", -281190422).length();
                  } while(-(66 ^ 70) < 0);

                  return;
               }

               jebac_vexiawzpzy1x3sez8. bm.add(var0.next());
               jebac_vexiaqb58506wt8o3.  ‏ ("", 4953849).length();
               jebac_vexiaqb58506wt8o3.  ‏ ("", -2008759047).length();
               if (-(35 ^ 61 ^ 25 ^ 2) >= 0) {
                  return;
               }
            }
         } catch (Throwable var9) {
            var9.printStackTrace();
            break label78;
         }

         jebac_vexiaqb58506wt8o3.  ‏ ("", 1503338394).length();
         if (jebac_vexiaqb58506wt8o3.  ‏ ("쎺쎺", -1602436198).length() <= jebac_vexiaqb58506wt8o3.  ‏ ("卖", 1209619318).length()) {
            return;
         }
      }

      jebac_vexiani0fpd9y618w.a();
      jebac_vexiawzpzy1x3sez8. bf = getNewVersion();
   }

   // $FF: synthetic method
   private static String llIIIlll(String var0, String var1) {
      try {
         SecretKeySpec var2 = new SecretKeySpec(MessageDigest.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("ฺำโ", 1460473463)).digest(var1.getBytes(StandardCharsets.UTF_8)), jebac_vexiaqb58506wt8o3.  ‏ ("넪넄넇넟넎넁넛넀", 766095720));
         String var3 = Cipher.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("⊛⊵⊶⊮⊿⊰⊪⊱", -310369575));
         var3.init( d[2], var2);
         return new String(var3.doFinal(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var9) {
         var9.printStackTrace();
         return null;
      }
   }

   // $FF: synthetic method
   public static void update(Minecraft var0) {
      var0.displayGuiScreen(new jebac_vexia05c602fwacr8(0.0F));
      (new Thread(jebac_vexiawqkxo5ufmdem::lambda$update$0)).start();
   }

   // $FF: synthetic method
   private static boolean llIlIIII(int var0) {
      return var0 != 0;
   }

   // $FF: synthetic method
   private static boolean llIlIlII(int var0) {
      return var0 == 0;
   }

   // $FF: synthetic method
   public static void checkBlacklist() {
      try {
         Scanner var0 = new Scanner((new URL( e[ d[11]])).openStream());

         while(llIlIIII(var0.hasNextLine())) {
            String[] var1 = var0.nextLine().split( e[ d[16]]);
            byte var2 = var1[ d[0]];
            String var3 = var1[ d[1]];
            String var4 = var1[ d[2]];
            String var5 = var1[ d[3]];
            short var6 = (new SimpleDateFormat( e[ d[17]])).parse(var5, new ParsePosition( d[0])).getTime();
            if (llIlIIII(Minecraft.getMinecraft().getSession().getUsername().equalsIgnoreCase(var2)) && llIlIIlI(llIlIIIl(var6, System.currentTimeMillis()))) {
               Minecraft.getMinecraft().displayGuiScreen(new jebac_vexian48zibs27a5f(var3, var4, var5));
            }

            jebac_vexiaqb58506wt8o3.  ‏ ("", 1771308686).length();
            if (jebac_vexiaqb58506wt8o3.  ‏ ("\uef79\uef79", 1403580249).length() < ((90 ^ 117 ^ 1 + 6 - -41 + 79) & (103 + 143 - 163 + 134 ^ 48 + 54 - 49 + 84 ^ -jebac_vexiaqb58506wt8o3.  ‏ ("㹎", 784612974).length()))) {
               return;
            }
         }
      } catch (Throwable var15) {
         var15.printStackTrace();
         return;
      }

      jebac_vexiaqb58506wt8o3.  ‏ ("", 89917139).length();
      if (null == null) {
         ;
      }
   }

   // $FF: synthetic method
   private static int llIlIIll(float var0, float var1) {
      float var2;
      return (var2 = var0 - var1) == 0.0F ? 0 : (var2 < 0.0F ? -1 : 1);
   }

   // $FF: synthetic method
   private static int llIlIIIl(long var0, long var2) {
      long var4;
      return (var4 = var0 - var2) == 0L ? 0 : (var4 < 0L ? -1 : 1);
   }

   private static void lambda$update$0(Minecraft var0) {
      try {
         String var1 = String.valueOf((new StringBuilder()).append(var0.mcDataDir).append( e[ d[31]]));
         URL var2 = new URL( e[ d[32]]);
         URL var3 = (HttpURLConnection)var2.openConnection();
         Minecraft var4 = var3.getContentLength();
         HttpURLConnection var5 = 0.0F;
         BufferedInputStream var6 = new BufferedInputStream(var2.openStream());
         Exception var7 = new FileOutputStream(var1);
         byte[] var8 = new byte[ d[33]];

         int var9;
         while(llIlIIlI(var9 = var6.read(var8,  d[0],  d[33]))) {
            var5 += (float)var9;
            var7.write(var8,  d[0], var9);
            if (llIlIlII(llIlIlIl(var5, (float)var4))) {
               var6.close();
               var7.close();
               var0.displayGuiScreen(new jebac_vexia05c602fwacr8(100.0F));
               jebac_vexiaqb58506wt8o3.  ‏ ("", -1258319674).length();
               if (-(161 ^ 180 ^ 64 ^ 80) >= 0) {
                  return;
               }
               break;
            }

            var0.displayGuiScreen(new jebac_vexia05c602fwacr8(var5 * 100.0F / (float)var4));
            jebac_vexiaqb58506wt8o3.  ‏ ("", 1823508448).length();
            if ((70 ^ 50 ^ 9 ^ 120) == 0) {
               return;
            }
         }
      } catch (IOException var21) {
         var21.printStackTrace();
         return;
      }

      jebac_vexiaqb58506wt8o3.  ‏ ("", 172279463).length();
      if (null == null) {
         ;
      }
   }

   // $FF: synthetic method
   private static String llIIlIIl(String var0, String var1) {
      var0 = new String(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      String var2 = new StringBuilder();
      char[] var3 = var1.toCharArray();
      Exception var4 =  d[0];
      short var5 = var0.toCharArray();
      Exception var6 = var5.length;
      int var7 =  d[0];

      do {
         if (!llIlIllI(var7, var6)) {
            return String.valueOf(var2);
         }

         char[] var8 = var5[var7];
         var2.append((char)(var8 ^ var3[var4 % var3.length]));
         jebac_vexiaqb58506wt8o3.  ‏ ("", 627875513).length();
         ++var4;
         ++var7;
         jebac_vexiaqb58506wt8o3.  ‏ ("", -5170204).length();
      } while(((101 + 104 - 80 + 56 ^ 95 + 107 - 181 + 115) & (26 ^ 46 ^ 23 ^ 30 ^ -jebac_vexiaqb58506wt8o3.  ‏ ("⚱", 1393305233).length())) > -jebac_vexiaqb58506wt8o3.  ‏ ("\uf531", -561318639).length());

      return null;
   }

   // $FF: synthetic method
   private static int llIlIlIl(float var0, float var1) {
      float var2;
      return (var2 = var0 - var1) == 0.0F ? 0 : (var2 < 0.0F ? -1 : 1);
   }

   // $FF: synthetic method
   private static boolean llIlIllI(int var0, int var1) {
      return var0 < var1;
   }

   // $FF: synthetic method
   private static String llIIlIII(String var0, String var1) {
      try {
         float var2 = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("ტძႚ", -882241361)).digest(var1.getBytes(StandardCharsets.UTF_8)),  d[8]), jebac_vexiaqb58506wt8o3.  ‏ ("榑榐榆", -64853547));
         Cipher var3 = Cipher.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("蕜蕝蕋", 2032436504));
         var3.init( d[2], var2);
         return new String(var3.doFinal(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var9) {
         var9.printStackTrace();
         return null;
      }
   }

   // $FF: synthetic method
   private static void llIIlIlI() {
       e = new String[ d[34]];
       e[ d[0]] = llIIIlll(jebac_vexiaqb58506wt8o3.  ‏ ("ˏ˧ʅ˴˯˾˻˹˨ˊˠ˝ʙʜʛ˩˜ʘˈ˃ʙˤ˔ʜʅ˝ʙʟˠ˧˨ˏˇʁʗʅ˅˷˧˯ˀ˥ˉˊʚ˝ʟ˛˦˝ˡˈˈ˨ˤ˃ʘ˅ˊ˘˅˻˸ˈ", -40697170), jebac_vexiaqb58506wt8o3.  ‏ ("紙紜紪納紸", 1374256509));
       e[ d[1]] = llIIlIII(jebac_vexiaqb58506wt8o3.  ‏ ("繾縄縐縢縝縙縄繺縶縜縶繨", 540048981), jebac_vexiaqb58506wt8o3.  ‏ ("픙픆픰픖픭", -472853151));
       e[ d[2]] = llIIlIIl(jebac_vexiaqb58506wt8o3.  ‏ ("闁闷閨闽闊閩问閤", 48469401), jebac_vexiaqb58506wt8o3.  ‏ ("\ue6cd\ue6f1\ue6cc\ue6c7\ue6da", -199170398));
       e[ d[3]] = llIIlIIl(jebac_vexiaqb58506wt8o3.  ‏ ("翀翢羞羞", -1406435421), jebac_vexiaqb58506wt8o3.  ‏ ("潃潌潈潽潫", 468479753));
       e[ d[4]] = llIIIlll(jebac_vexiaqb58506wt8o3.  ‏ ("밞밨밿밲뱞밓밭박뱟밦밡밋밾밂뱈밽밽뱐및뱟밄밊밗및뱈밒밆밀밈밪밬밤밒밲뱓뱐밷밆밋밴밤밷밠밣뱌밝밭밀밗밁밴뱈밵뱑밭밴밳밓밤및밁밦밡밢", -1089618841), jebac_vexiaqb58506wt8o3.  ‏ ("囍囍囵囏囖", 1097225862));
       e[ d[5]] = llIIlIII(jebac_vexiaqb58506wt8o3.  ‏ ("⟩➐➘⟂➗⟸⟹⟈⟋⟥⟰➜", 266217377), jebac_vexiaqb58506wt8o3.  ‏ ("㮾㮭㮲㮙㮩", 1178942411));
       e[ d[6]] = llIIlIIl(jebac_vexiaqb58506wt8o3.  ‏ ("\ued09\ued3e\ued0b\ued07\ued0f\ued03\ued36\ued7e\ued15\ued04\ued25\ued7f\ued1e\ued15\ued0b\ued01\ued00\ued3c\ued32\ued23\ued0f\ued31\ued32\ued24\ued0b\ued3e\ued76\ued2c\ued04\ued2e\ued25\ued71\ued1e\ued3c\ued0f\ued1e\ued0e\ued1e\ued7e\ued1c\ued0c\ued31\ued0f\ued1c\ued04\ued17\ued0b\ued74\ued00\ued17\ued22\ued6d\ued04\ued05\ued35\ued12", 1795419462), jebac_vexiaqb58506wt8o3.  ‏ ("憯憛憈憬憌", 1657430524));
       e[ d[7]] = llIIlIIl(jebac_vexiaqb58506wt8o3.  ‏ ("殣殖毺毺", 1918987207), jebac_vexiaqb58506wt8o3.  ‏ ("\ueadd\ueae4\ueac4\uead5\ueaf3", -686691694));
       e[ d[8]] = llIIIlll(jebac_vexiaqb58506wt8o3.  ‏ ("쒙쓁쓝쓗쓈쓣쓯쓿쓨쓎쓧쓨쓢쓣쓆쓈쓚쓿쓇쓛쓄쒝쓆쓄쓢쒚쓟쓜쒕쓠쓤쓧쓊쓩쓼쓇쓩쓿쓘쓾쓽쓔쓢쓃쒘쓞쓗쓻쓼쓧쒚쓉쓉쓼쓚쓂쓮쓋쓮쓯쓚쒝쓌쓊쓝쓸쓛쓼쓵쒆쒟쓩쓟쒛쓎쒐", -1814444883), jebac_vexiaqb58506wt8o3.  ‏ ("㸤㸯㸿㸽㸴", -1594343867));
       e[ d[9]] = llIIlIII(jebac_vexiaqb58506wt8o3.  ‏ ("羡翢翮翼翳翹翕翝翤翚翂羪", 664567703), jebac_vexiaqb58506wt8o3.  ‏ ("떑떎떝떎떕", 202421722));
       e[ d[10]] = llIIIlll(jebac_vexiaqb58506wt8o3.  ‏ ("\ue45b\ue451\ue41c\ue462\ue41a\ue46a\ue47c\ue473\ue449\ue47a\ue472\ue451\ue471\ue45d\ue462\ue445\ue47f\ue47b\ue418\ue458\ue412\ue446\ue46f\ue448\ue41a\ue412\ue47d\ue472\ue448\ue413\ue412\ue46f\ue479\ue461\ue47d\ue47a\ue404\ue41d\ue47b\ue446\ue467\ue452\ue47f\ue46f\ue478\ue47f\ue467\ue471\ue47d\ue459\ue41c\ue479\ue441\ue471\ue458\ue41e\ue45c\ue419\ue459\ue47d\ue44a\ue469\ue478\ue47b", -1699617749), jebac_vexiaqb58506wt8o3.  ‏ ("\ue4e7\ue4da\ue4c4\ue4e2\ue4c8", 1705370794));
       e[ d[13]] = llIIlIIl(jebac_vexiaqb58506wt8o3.  ‏ ("憐憩憸憋憃憆憧憞憊憴憒憴憋憑憞憠憒憐憉憵憖憪憕憞憟憻憤憇憟憒憒憾憋憴憚懪憐憾憚憇憗憪憤憒憙憻懣憘憃憻憰憼憕憇憒憼憖憇憠憆憖憇懦憝憜憂憸憋", -1767677485), jebac_vexiaqb58506wt8o3.  ‏ ("\u12b7ኙ\u12b7ኙእ", -1098968364));
       e[ d[14]] = llIIIlll(jebac_vexiaqb58506wt8o3.  ‏ ("⮝⮮⯎⮼⮻⮤⯄⯏⮬\u2b97⮕⯋", 966536182), jebac_vexiaqb58506wt8o3.  ‏ ("\ue3e0\ue3ef\ue3ec\ue3d9\ue3f3", 1471275930));
       e[ d[12]] = llIIlIIl(jebac_vexiaqb58506wt8o3.  ‏ ("㔳㔸㔵㔯㔷㔑㔄㕓㔝㔭㔩㕏㔙㔅㔽㔒㔾㔨㔺㕈㔵㔿㔌㔶㔳㔨㔏㔛㔶㔋㔩㔄㔙㔨㔹㕎㔸㕏㔩㔑㔱㔯㔩㔲㔸㔸㔱㔕㔲㔭㕄㕍㔳㔴㕈㔕㔾㔅㕈㕏", -857524868), jebac_vexiaqb58506wt8o3.  ‏ ("瑈瑞瑾瑂瑎", -1854311400));
       e[ d[15]] = llIIIlll(jebac_vexiaqb58506wt8o3.  ‏ ("歍欬歾歘歿歘歲歔歔欺歌欨", 325217045), jebac_vexiaqb58506wt8o3.  ‏ ("ฎะฬีด", -874508702));
       e[ d[11]] = llIIlIII(jebac_vexiaqb58506wt8o3.  ‏ ("\ue7c8\ue7d3\ue7ed\ue7fe\ue7ef\ue794\ue7e8\ue7d6\ue7f7\ue7e3\ue7e8\ue7fc\ue7c4\ue7d7\ue79f\ue7f7\ue791\ue7c0\ue7de\ue7c4\ue7ee\ue7ff\ue7d6\ue7ca\ue7cc\ue7ed\ue7c3\ue7df\ue7c7\ue790\ue7cb\ue7d5\ue797\ue7ca\ue790\ue7c9\ue7d6\ue7d0\ue7ca\ue796\ue7c9\ue7cd\ue7cb\ue7f1\ue7d1\ue7e5\ue796\ue7e7\ue7c7\ue7ec\ue7e5\ue7f1\ue7ed\ue7f2\ue7cd\ue7df\ue7e7\ue7f0\ue7ff\ue7d6\ue7cf\ue796\ue793\ue7ea", 1537664934), jebac_vexiaqb58506wt8o3.  ‏ ("▚▃▋▟█", -322296370));
       e[ d[16]] = llIIIlll(jebac_vexiaqb58506wt8o3.  ‏ ("㶟㷨㷚㷦㷓㷯㷮㷀㷉㷽㶚㶗", -2125251158), jebac_vexiaqb58506wt8o3.  ‏ ("禼禡禹禂禟", 1981643213));
       e[ d[17]] = llIIlIIl(jebac_vexiaqb58506wt8o3.  ‏ ("윽윇윫읔윦윾윙읞육윮윆윉윥윚읐읐", -739915923), jebac_vexiaqb58506wt8o3.  ‏ ("\uf1ae\uf1a1\uf1a4\uf190\uf192", 1513615860));
       e[ d[19]] = llIIlIII(jebac_vexiaqb58506wt8o3.  ‏ ("慸慚慦慒愦慭慰慚慗慘愬愩", -65642220), jebac_vexiaqb58506wt8o3.  ‏ ("㸛㸍㸰㸦㸒", 1590378111));
       e[ d[20]] = llIIIlll(jebac_vexiaqb58506wt8o3.  ‏ ("깠긒김깇깭깸깨깥깦깲깳긗", 1840492074), jebac_vexiaqb58506wt8o3.  ‏ ("ᑊᑲᑓᑞᑱ", 1834816568));
       e[ d[21]] = llIIlIIl(jebac_vexiaqb58506wt8o3.  ‏ ("≼≼≽≈≨≏∅∅", 804069944), jebac_vexiaqb58506wt8o3.  ‏ ("\ua9da꧴꧵ꧣꧢ", -2027378288));
       e[ d[31]] = llIIlIII(jebac_vexiaqb58506wt8o3.  ‏ ("䈌䈶䈊䈺䈏䉶䈚䈥䈦䈅䈺䈘䈥䈐䉸䈊䈙䈲䈥䉱䈘䉫䈐䈖䈤䈖䈖䈇䈂䈌䉱䈧䈏䈎䉳䉸䉵䉯䉳䉰䈇䈅䈯䈤䈥䈵䈹䉯䈙䈖䉶䈸䈱䈪䈺䉲䈮䈂䈇䈺䈈䈦䈅䈊", 915751488), jebac_vexiaqb58506wt8o3.  ‏ ("낏낰낦낦낏", 1023979754));
       e[ d[32]] = llIIlIIl(jebac_vexiaqb58506wt8o3.  ‏ ("즢즯즧짙즧즻짗즜즹즽즙짖즹즪즿즶즢즪즞즌즠즬즞즉즣즆즉짞즨즗즙짘즹즇즻즩즤즀짚짜즭즽즷즛즣즆짚즌즨즔짖즆즹즔즫즩즥즔즯즬즧즿짓짓", -1663710738), jebac_vexiaqb58506wt8o3.  ‏ ("蹗蹥蹜蹂蹦", -616985069));
   }

   static {
      llIIllll();
      llIIlIlI();
   }

   // $FF: synthetic method
   private static void llIIllll() {
       d = new int[35];
       d[0] = (66 ^ 76 ^ 0 ^ 108) & (jebac_vexiaqb58506wt8o3.  ‏ ("儋", 2071417131).length() ^ 3 ^ 96 ^ -jebac_vexiaqb58506wt8o3.  ‏ ("⌊", -1987894486).length());
       d[1] = jebac_vexiaqb58506wt8o3.  ‏ ("確", 198867098).length();
       d[2] = jebac_vexiaqb58506wt8o3.  ‏ ("渗渗", -293245385).length();
       d[3] = jebac_vexiaqb58506wt8o3.  ‏ ("\udd8c\udd8c\udd8c", 2052578732).length();
       d[4] = 147 ^ 151;
       d[5] = 115 ^ 118;
       d[6] = 164 ^ 162;
       d[7] = 149 ^ 190 ^ 71 ^ 107;
       d[8] = 240 ^ 149 ^ 67 ^ 46;
       d[9] = 36 ^ 45;
       d[10] = 92 ^ 86;
       d[11] = 60 ^ 51;
       d[12] = 56 ^ 53;
       d[13] = 185 ^ 178;
       d[14] = 73 ^ 69;
       d[15] = 162 ^ 172;
       d[16] = 14 ^ 30;
       d[17] = 180 + 172 - 298 + 132 ^ 153 + 132 - 179 + 65;
       d[18] = -jebac_vexiaqb58506wt8o3.  ‏ ("䍧", -1023261881).length();
       d[19] = 221 ^ 196 ^ 0 ^ 11;
       d[20] = 106 + 15 - 114 + 168 ^ 34 + 81 - 40 + 113;
       d[21] = 15 ^ 27;
       d[22] = -4110 & 7151;
       d[23] = -20499 & 23382;
       d[24] = -24581 & 28133;
       d[25] = -(-8548 & 26099) & -12353 & 32751;
       d[26] = -11309 & 12078;
       d[27] = -(-26115 & 28287) & -5121 & 8063;
       d[28] = 93 ^ 69;
       d[29] = 171 + 65 - 106 + 125;
       d[30] = -16500 & 23923;
       d[31] = 24 ^ 13;
       d[32] = 133 ^ 147;
       d[33] = -6203 & 7226;
       d[34] = 179 ^ 164;
   }

   // $FF: synthetic method
   public static void drawLine2D(double var0, double var2, double var4, double var6, float var8, int var9) {
      GL11.glEnable( d[22]);
      GL11.glDisable( d[23]);
      GL11.glDisable( d[24]);
      GL11.glEnable( d[25]);
      GL11.glBlendFunc( d[26],  d[27]);
      GL11.glLineWidth(1.0F);
      double var10 = (float)(var9 >>  d[28] &  d[29]) / 255.0F;
      float var10000 = (float)(var9 >>  d[16] &  d[29]) / 255.0F;
      float var10001 = (float)(var9 >>  d[8] &  d[29]) / 255.0F;
      float var10002 = (float)(var9 &  d[29]) / 255.0F;
      float var10003;
      if (llIlIlII(llIlIIll(var10, 0.0F))) {
         var10003 = 1.0F;
         jebac_vexiaqb58506wt8o3.  ‏ ("", -362073274).length();
         if (jebac_vexiaqb58506wt8o3.  ‏ ("༂", 2078740258).length() > jebac_vexiaqb58506wt8o3.  ‏ ("୦", -1407644858).length()) {
            return;
         }
      } else {
         var10003 = var10;
      }

      GL11.glColor4f(var10000, var10001, var10002, var10003);
      GL11.glLineWidth(var8);
      GL11.glBegin( d[1]);
      GL11.glVertex2d(var0, var2);
      GL11.glVertex2d(var4, var6);
      GL11.glEnd();
      GL11.glDisable( d[22]);
      GL11.glEnable( d[23]);
      GL11.glEnable( d[24]);
      GL11.glDisable( d[25]);
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
      GlStateManager.shadeModel( d[30]);
      GlStateManager.disableBlend();
      GlStateManager.enableTexture2D();
   }

   // $FF: synthetic method
   public static String getNewVersion() {
      try {
         Scanner var0 = new Scanner((new URL( e[ d[12]])).openStream());
         return var0.next();
      } catch (Throwable var3) {
         var3.printStackTrace();
         return  e[ d[15]];
      }
   }

   // $FF: synthetic method
   public static jebac_vexiabjvb6fu2xswx getBlockOverlayMode(String var0) {
      long var2 =  d[18];
      switch(var0.hashCode()) {
      case -388262878:
         if (llIlIIII(var0.equals( e[ d[20]]))) {
            var2 =  d[1];
            jebac_vexiaqb58506wt8o3.  ‏ ("", 274522265).length();
            if (null != null) {
               return null;
            }
         }
         break;
      case 2169487:
         if (llIlIIII(var0.equals( e[ d[21]]))) {
            var2 =  d[2];
         }
         break;
      case 2402104:
         if (llIlIIII(var0.equals( e[ d[19]]))) {
            var2 =  d[0];
            jebac_vexiaqb58506wt8o3.  ‏ ("", 1257846692).length();
            if (null != null) {
               return null;
            }
         }
      }

      switch(var2) {
      case 0:
         return jebac_vexiabjvb6fu2xswx. jk;
      case 1:
         return jebac_vexiabjvb6fu2xswx. ji;
      case 2:
         return jebac_vexiabjvb6fu2xswx. jg;
      default:
         return jebac_vexiabjvb6fu2xswx. jl;
      }
   }
}
