import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.resources.ResourcePackListEntry;
import net.minecraft.util.EnumChatFormatting;

public abstract class jebac_vexia6fd2eiv9yfhn extends jebac_vexiadrxrz0b4x3gp {
   // $FF: synthetic field
   protected final List field_148204_l;
   // $FF: synthetic field
   protected final Minecraft mc;

   // $FF: synthetic method
   protected int getScrollBarX() {
      return this.right - 6;
   }

   // $FF: synthetic method
   public List getList() {
      return this.field_148204_l;
   }

   // $FF: synthetic method
   public int getListWidth() {
      return this.width;
   }

   // $FF: synthetic method
   public jebac_vexia6fd2eiv9yfhn(Minecraft mcIn, int p_i45055_2_, int p_i45055_3_, List p_i45055_4_) {
      super(mcIn, p_i45055_2_, p_i45055_3_, 32, p_i45055_3_ - 55 + 4, 36);
      this.mc = mcIn;
      this.field_148204_l = p_i45055_4_;
      this.field_148163_i = false;
      this.setHasListHeader(true, (int)((float)mcIn.fontRendererObj.FONT_HEIGHT * 1.5F));
   }

   // $FF: synthetic method
   protected abstract String getListHeader();

   // $FF: synthetic method
   public ResourcePackListEntry getListEntry(int index) {
      return (ResourcePackListEntry)this.getList().get(index);
   }

   // $FF: synthetic method
   protected void drawListHeader(int p_148129_1_, int p_148129_2_, Tessellator p_148129_3_) {
      String s = EnumChatFormatting.UNDERLINE + "" + EnumChatFormatting.BOLD + this.getListHeader();
      this.mc.fontRendererObj.drawString(s, p_148129_1_ + this.width / 2 - this.mc.fontRendererObj.getStringWidth(s) / 2, Math.min(this.top + 3, p_148129_2_), 16777215);
   }

   // $FF: synthetic method
   protected int getSize() {
      return this.getList().size();
   }
}
