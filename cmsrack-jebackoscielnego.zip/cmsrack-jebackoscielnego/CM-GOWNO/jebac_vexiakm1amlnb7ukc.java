import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;

public class jebac_vexiakm1amlnb7ukc {
   private static final int[]  dq;

   // $FF: synthetic method
   private static void llIlllI() {
       dq = new int[1];
       dq[0] = 163 ^ 164;
   }

   // $FF: synthetic method
   public static void drawTexturedModalRect(int var0, int var1, int var2, int var3, int var4, int var5, float var6) {
      int var7 = 0.00390625F;
      int var8 = 0.00390625F;
      float var9 = Tessellator.getInstance();
      double var10 = var9.getWorldRenderer();
      var10.begin( dq[0], DefaultVertexFormats.POSITION_TEX);
      var10.pos((double)var0, (double)(var1 + var5), (double)var6).tex((double)((float)var2 * var7), (double)((float)(var3 + var5) * var8)).endVertex();
      var10.pos((double)(var0 + var4), (double)(var1 + var5), (double)var6).tex((double)((float)(var2 + var4) * var7), (double)((float)(var3 + var5) * var8)).endVertex();
      var10.pos((double)(var0 + var4), (double)var1, (double)var6).tex((double)((float)(var2 + var4) * var7), (double)((float)var3 * var8)).endVertex();
      var10.pos((double)var0, (double)var1, (double)var6).tex((double)((float)var2 * var7), (double)((float)var3 * var8)).endVertex();
      var9.draw();
   }

   static {
      llIlllI();
   }
}
