import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashSet;
import java.util.Properties;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.block.Block;
import net.minecraft.block.state.BlockStateBase;
import net.minecraft.client.renderer.texture.TextureUtil;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.biome.BiomeGenBase;

public class jebac_vexiajk9902f0o7fz implements jebac_vexia0yoti4mtffso {
   // $FF: synthetic field
   private int yVariance = 0;
   // $FF: synthetic field
   private int color = -1;
   // $FF: synthetic field
   private String source = null;
   // $FF: synthetic field
   public String name = null;
   // $FF: synthetic field
   private int[] colors = null;
   // $FF: synthetic field
   public String basePath = null;
   // $FF: synthetic field
   private int yOffset = 0;
   // $FF: synthetic field
   private int width = 0;
   // $FF: synthetic field
   public static final String[] FORMAT_STRINGS = new String[]{"vanilla", "grid", "fixed"};
   // $FF: synthetic field
   private int height = 0;
   // $FF: synthetic field
   private int format = -1;
   // $FF: synthetic field
   private float[][] colorsRgb = (float[][])null;
   // $FF: synthetic field
   private jebac_vexia2nnti3ppoopl[] matchBlocks = null;

   // $FF: synthetic method
   public int[] getMatchBlockIds() {
      if (this.matchBlocks == null) {
         return null;
      } else {
         Set set = new HashSet();
         jebac_vexia2nnti3ppoopl[] var2 = this.matchBlocks;
         int var3 = var2.length;

         int j;
         for(j = 0; j < var3; ++j) {
            jebac_vexia2nnti3ppoopl matchblock = var2[j];
            if (matchblock.getBlockId() >= 0) {
               set.add(matchblock.getBlockId());
            }
         }

         Integer[] ainteger = (Integer[])((Integer[])set.toArray(new Integer[0]));
         int[] aint = new int[ainteger.length];

         for(j = 0; j < ainteger.length; ++j) {
            aint[j] = ainteger[j];
         }

         return aint;
      }
   }

   // $FF: synthetic method
   public int getLength() {
      return this.format == 2 ? 1 : this.colors.length;
   }

   // $FF: synthetic method
   public boolean isValidMatchBlocks(String p_isValidMatchBlocks_1_) {
      if (this.matchBlocks == null) {
         this.matchBlocks = this.detectMatchBlocks();
         if (this.matchBlocks == null) {
            warn("Match blocks not defined: " + p_isValidMatchBlocks_1_);
            return false;
         }
      }

      return true;
   }

   // $FF: synthetic method
   private int parseFormat(String p_parseFormat_1_) {
      if (p_parseFormat_1_ == null) {
         return 0;
      } else if (p_parseFormat_1_.equals("vanilla")) {
         return 0;
      } else if (p_parseFormat_1_.equals("grid")) {
         return 1;
      } else if (p_parseFormat_1_.equals("fixed")) {
         return 2;
      } else {
         warn("Unknown format: " + p_parseFormat_1_);
         return -1;
      }
   }

   // $FF: synthetic method
   public float[][] getColorsRgb() {
      if (this.colorsRgb == null) {
         this.colorsRgb = toRgb(this.colors);
      }

      return this.colorsRgb;
   }

   // $FF: synthetic method
   public int getWidth() {
      return this.width;
   }

   // $FF: synthetic method
   private static String fixTextureName(String p_fixTextureName_0_, String p_fixTextureName_1_) {
      p_fixTextureName_0_ = jebac_vexiamg04e8zzk81s.fixResourcePath(p_fixTextureName_0_, p_fixTextureName_1_);
      if (!p_fixTextureName_0_.startsWith(p_fixTextureName_1_) && !p_fixTextureName_0_.startsWith("textures/") && !p_fixTextureName_0_.startsWith("mcpatcher/")) {
         p_fixTextureName_0_ = p_fixTextureName_1_ + "/" + p_fixTextureName_0_;
      }

      if (p_fixTextureName_0_.endsWith(".png")) {
         p_fixTextureName_0_ = p_fixTextureName_0_.substring(0, p_fixTextureName_0_.length() - 4);
      }

      String s = "textures/blocks/";
      if (p_fixTextureName_0_.startsWith(s)) {
         p_fixTextureName_0_ = p_fixTextureName_0_.substring(s.length());
      }

      if (p_fixTextureName_0_.startsWith("/")) {
         p_fixTextureName_0_ = p_fixTextureName_0_.substring(1);
      }

      return p_fixTextureName_0_;
   }

   // $FF: synthetic method
   private int getColorVanilla(BiomeGenBase p_getColorVanilla_1_, BlockPos p_getColorVanilla_2_) {
      double d0 = (double)MathHelper.clamp_float(p_getColorVanilla_1_.getFloatTemperature(p_getColorVanilla_2_), 0.0F, 1.0F);
      double d1 = (double)MathHelper.clamp_float(p_getColorVanilla_1_.getFloatRainfall(), 0.0F, 1.0F);
      d1 *= d0;
      int i = (int)((1.0D - d0) * (double)(this.width - 1));
      int j = (int)((1.0D - d1) * (double)(this.height - 1));
      return this.getColor(i, j);
   }

   // $FF: synthetic method
   public int getColor(IBlockAccess p_getColor_1_, BlockPos p_getColor_2_) {
      BiomeGenBase biomegenbase = jebac_vexianrqa4939v11c.getColorBiome(p_getColor_1_, p_getColor_2_);
      return this.getColor(biomegenbase, p_getColor_2_);
   }

   // $FF: synthetic method
   public jebac_vexiajk9902f0o7fz(Properties p_i33_1_, String p_i33_2_, int p_i33_3_, int p_i33_4_, String p_i33_5_) {
      jebac_vexiadw49qo6dh8al connectedparser = new jebac_vexiadw49qo6dh8al("Colormap");
      this.name = connectedparser.parseName(p_i33_2_);
      this.basePath = connectedparser.parseBasePath(p_i33_2_);
      this.format = this.parseFormat(p_i33_1_.getProperty("format", p_i33_5_));
      this.matchBlocks = connectedparser.parseMatchBlocks(p_i33_1_.getProperty("blocks"));
      this.source = parseTexture(p_i33_1_.getProperty("source"), p_i33_2_, this.basePath);
      this.color = jebac_vexiadw49qo6dh8al.parseColor(p_i33_1_.getProperty("color"), -1);
      this.yVariance = connectedparser.parseInt(p_i33_1_.getProperty("yVariance"), 0);
      this.yOffset = connectedparser.parseInt(p_i33_1_.getProperty("yOffset"), 0);
      this.width = p_i33_3_;
      this.height = p_i33_4_;
   }

   // $FF: synthetic method
   private int getColorGrid(BiomeGenBase p_getColorGrid_1_, BlockPos p_getColorGrid_2_) {
      int i = p_getColorGrid_1_.biomeID;
      int j = p_getColorGrid_2_.getY() - this.yOffset;
      if (this.yVariance > 0) {
         int k = p_getColorGrid_2_.getX() << 16 + p_getColorGrid_2_.getZ();
         int l = jebac_vexiakrwecfs16wve.intHash(k);
         int i1 = this.yVariance * 2 + 1;
         int j1 = (l & 255) % i1 - this.yVariance;
         j += j1;
      }

      return this.getColor(i, j);
   }

   // $FF: synthetic method
   public int getHeight() {
      return this.height;
   }

   // $FF: synthetic method
   public int getColorRandom() {
      if (this.format == 2) {
         return this.color;
      } else {
         int i = jebac_vexianrqa4939v11c.random.nextInt(this.colors.length);
         return this.colors[i];
      }
   }

   // $FF: synthetic method
   public boolean isColorConstant() {
      return this.format == 2;
   }

   // $FF: synthetic method
   public boolean matchesBlock(BlockStateBase p_matchesBlock_1_) {
      return jebac_vexiazz7bslggeoy9.block(p_matchesBlock_1_, this.matchBlocks);
   }

   // $FF: synthetic method
   private static float[][] toRgb(int[] p_toRgb_0_) {
      float[][] afloat = new float[p_toRgb_0_.length][3];

      for(int i = 0; i < p_toRgb_0_.length; ++i) {
         int j = p_toRgb_0_[i];
         float f = (float)(j >> 16 & 255) / 255.0F;
         float f1 = (float)(j >> 8 & 255) / 255.0F;
         float f2 = (float)(j & 255) / 255.0F;
         float[] afloat1 = afloat[i];
         afloat1[0] = f;
         afloat1[1] = f1;
         afloat1[2] = f2;
      }

      return afloat;
   }

   // $FF: synthetic method
   public void addMatchBlock(jebac_vexia2nnti3ppoopl p_addMatchBlock_1_) {
      if (this.matchBlocks == null) {
         this.matchBlocks = new jebac_vexia2nnti3ppoopl[0];
      }

      this.matchBlocks = (jebac_vexia2nnti3ppoopl[])((jebac_vexia2nnti3ppoopl[])jebac_vexiakrwecfs16wve.addObjectToArray(this.matchBlocks, p_addMatchBlock_1_));
   }

   // $FF: synthetic method
   private static void warn(String p_warn_0_) {
      jebac_vexiakrwecfs16wve.warn("CustomColors: " + p_warn_0_);
   }

   // $FF: synthetic method
   public int getColor(BiomeGenBase p_getColor_1_, BlockPos p_getColor_2_) {
      return this.format == 0 ? this.getColorVanilla(p_getColor_1_, p_getColor_2_) : (this.format == 1 ? this.getColorGrid(p_getColor_1_, p_getColor_2_) : this.color);
   }

   // $FF: synthetic method
   private void readColors() {
      try {
         this.colors = null;
         if (this.source == null) {
            return;
         }

         String s = this.source + ".png";
         ResourceLocation resourcelocation = new ResourceLocation(s);
         InputStream inputstream = jebac_vexiakrwecfs16wve.getResourceStream(resourcelocation);
         if (inputstream == null) {
            return;
         }

         BufferedImage bufferedimage = TextureUtil.readBufferedImage(inputstream);
         if (bufferedimage == null) {
            return;
         }

         int i = bufferedimage.getWidth();
         int j = bufferedimage.getHeight();
         boolean flag = this.width < 0 || this.width == i;
         boolean flag1 = this.height < 0 || this.height == j;
         if (!flag || !flag1) {
            dbg("Non-standard palette size: " + i + "x" + j + ", should be: " + this.width + "x" + this.height + ", path: " + s);
         }

         this.width = i;
         this.height = j;
         if (this.width <= 0 || this.height <= 0) {
            warn("Invalid palette size: " + i + "x" + j + ", path: " + s);
            return;
         }

         this.colors = new int[i * j];
         bufferedimage.getRGB(0, 0, i, j, this.colors, 0, i);
      } catch (IOException var9) {
         var9.printStackTrace();
      }

   }

   // $FF: synthetic method
   private jebac_vexia2nnti3ppoopl[] detectMatchBlocks() {
      Block block = Block.getBlockFromName(this.name);
      if (block != null) {
         return new jebac_vexia2nnti3ppoopl[]{new jebac_vexia2nnti3ppoopl(Block.getIdFromBlock(block))};
      } else {
         Pattern pattern = Pattern.compile("^block([0-9]+).*$");
         Matcher matcher = pattern.matcher(this.name);
         if (matcher.matches()) {
            String s = matcher.group(1);
            int i = jebac_vexiakrwecfs16wve.parseInt(s, -1);
            if (i >= 0) {
               return new jebac_vexia2nnti3ppoopl[]{new jebac_vexia2nnti3ppoopl(i)};
            }
         }

         jebac_vexiadw49qo6dh8al connectedparser = new jebac_vexiadw49qo6dh8al("Colormap");
         return connectedparser.parseMatchBlock(this.name);
      }
   }

   // $FF: synthetic method
   private static void dbg(String p_dbg_0_) {
      jebac_vexiakrwecfs16wve.dbg("CustomColors: " + p_dbg_0_);
   }

   // $FF: synthetic method
   public boolean isValid(String p_isValid_1_) {
      if (this.format != 0 && this.format != 1) {
         if (this.format != 2) {
            return false;
         }

         if (this.color < 0) {
            this.color = 16777215;
         }
      } else {
         if (this.source == null) {
            warn("Source not defined: " + p_isValid_1_);
            return false;
         }

         this.readColors();
         if (this.colors == null) {
            return false;
         }

         if (this.color < 0) {
            if (this.format == 0) {
               this.color = this.getColor(127, 127);
            }

            if (this.format == 1) {
               this.color = this.getColorGrid(BiomeGenBase.plains, new BlockPos(0, 64, 0));
            }
         }
      }

      return true;
   }

   // $FF: synthetic method
   public int getColor(int p_getColor_1_, int p_getColor_2_) {
      p_getColor_1_ = jebac_vexiakrwecfs16wve.limit(p_getColor_1_, 0, this.width - 1);
      p_getColor_2_ = jebac_vexiakrwecfs16wve.limit(p_getColor_2_, 0, this.height - 1);
      return this.colors[p_getColor_2_ * this.width + p_getColor_1_] & 16777215;
   }

   // $FF: synthetic method
   public int getColorSmooth(IBlockAccess p_getColorSmooth_1_, double p_getColorSmooth_2_, double p_getColorSmooth_4_, double p_getColorSmooth_6_, int p_getColorSmooth_8_) {
      if (this.format == 2) {
         return this.color;
      } else {
         int i = MathHelper.floor_double(p_getColorSmooth_2_);
         int j = MathHelper.floor_double(p_getColorSmooth_4_);
         int k = MathHelper.floor_double(p_getColorSmooth_6_);
         int l = 0;
         int i1 = 0;
         int j1 = 0;
         int k1 = 0;
         jebac_vexiaisxd96hccl8m blockposm = new jebac_vexiaisxd96hccl8m(0, 0, 0);

         int l1;
         int i2;
         int j2;
         for(l1 = i - p_getColorSmooth_8_; l1 <= i + p_getColorSmooth_8_; ++l1) {
            for(i2 = k - p_getColorSmooth_8_; i2 <= k + p_getColorSmooth_8_; ++i2) {
               blockposm.setXyz(l1, j, i2);
               j2 = this.getColor((IBlockAccess)p_getColorSmooth_1_, blockposm);
               l += j2 >> 16 & 255;
               i1 += j2 >> 8 & 255;
               j1 += j2 & 255;
               ++k1;
            }
         }

         l1 = l / k1;
         i2 = i1 / k1;
         j2 = j1 / k1;
         return l1 << 16 | i2 << 8 | j2;
      }
   }

   // $FF: synthetic method
   public String toString() {
      return "" + this.basePath + "/" + this.name + ", blocks: " + jebac_vexiakrwecfs16wve.arrayToString((Object[])this.matchBlocks) + ", source: " + this.source;
   }

   // $FF: synthetic method
   public int getColor(int p_getColor_1_) {
      p_getColor_1_ = jebac_vexiakrwecfs16wve.limit(p_getColor_1_, 0, this.colors.length - 1);
      return this.colors[p_getColor_1_] & 16777215;
   }

   // $FF: synthetic method
   private static String parseTexture(String p_parseTexture_0_, String p_parseTexture_1_, String p_parseTexture_2_) {
      String s;
      if (p_parseTexture_0_ != null) {
         s = ".png";
         if (p_parseTexture_0_.endsWith(s)) {
            p_parseTexture_0_ = p_parseTexture_0_.substring(0, p_parseTexture_0_.length() - s.length());
         }

         p_parseTexture_0_ = fixTextureName(p_parseTexture_0_, p_parseTexture_2_);
         return p_parseTexture_0_;
      } else {
         s = p_parseTexture_1_;
         int i = p_parseTexture_1_.lastIndexOf(47);
         if (i >= 0) {
            s = p_parseTexture_1_.substring(i + 1);
         }

         int j = s.lastIndexOf(46);
         if (j >= 0) {
            s = s.substring(0, j);
         }

         s = fixTextureName(s, p_parseTexture_2_);
         return s;
      }
   }
}
