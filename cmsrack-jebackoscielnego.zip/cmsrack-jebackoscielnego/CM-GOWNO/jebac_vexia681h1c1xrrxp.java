import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import net.minecraft.block.Block;
import net.minecraft.block.BlockPane;
import net.minecraft.block.BlockQuartz;
import net.minecraft.block.BlockRotatedPillar;
import net.minecraft.block.state.BlockStateBase;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.client.resources.IResourcePack;
import net.minecraft.client.resources.model.IBakedModel;
import net.minecraft.init.Blocks;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.biome.BiomeGenBase;

public class jebac_vexia681h1c1xrrxp {
   // $FF: synthetic field
   private static jebac_vexiayab0wp48ilc2[][] tileProperties = (jebac_vexiayab0wp48ilc2[][])null;
   // $FF: synthetic field
   private static TextureAtlasSprite emptySprite;
   // $FF: synthetic field
   public static final IBlockState AIR_DEFAULT_STATE;
   // $FF: synthetic field
   private static Map[] spriteQuadMaps = null;
   // $FF: synthetic field
   private static jebac_vexiayab0wp48ilc2[][] blockProperties = (jebac_vexiayab0wp48ilc2[][])null;
   // $FF: synthetic field
   private static boolean multipass = false;

   // $FF: synthetic method
   private static int fixSideByAxis(int p_fixSideByAxis_0_, int p_fixSideByAxis_1_) {
      switch(p_fixSideByAxis_1_) {
      case 1:
         switch(p_fixSideByAxis_0_) {
         case 0:
            return 2;
         case 1:
            return 3;
         case 2:
            return 1;
         case 3:
            return 0;
         default:
            return p_fixSideByAxis_0_;
         }
      case 2:
         switch(p_fixSideByAxis_0_) {
         case 0:
            return 4;
         case 1:
            return 5;
         case 2:
         case 3:
         default:
            return p_fixSideByAxis_0_;
         case 4:
            return 1;
         case 5:
            return 0;
         }
      default:
         return p_fixSideByAxis_0_;
      }
   }

   // $FF: synthetic method
   private static TextureAtlasSprite getConnectedTextureCtm(jebac_vexiayab0wp48ilc2 p_getConnectedTextureCtm_0_, IBlockAccess p_getConnectedTextureCtm_1_, IBlockState p_getConnectedTextureCtm_2_, BlockPos p_getConnectedTextureCtm_3_, int p_getConnectedTextureCtm_4_, int p_getConnectedTextureCtm_5_, TextureAtlasSprite p_getConnectedTextureCtm_6_, int p_getConnectedTextureCtm_7_, jebac_vexiai2kawx8j8o7a p_getConnectedTextureCtm_8_) {
      boolean[] aboolean = p_getConnectedTextureCtm_8_.getBorderFlags();
      switch(p_getConnectedTextureCtm_5_) {
      case 0:
         aboolean[0] = isNeighbour(p_getConnectedTextureCtm_0_, p_getConnectedTextureCtm_1_, p_getConnectedTextureCtm_2_, p_getConnectedTextureCtm_3_.west(), p_getConnectedTextureCtm_5_, p_getConnectedTextureCtm_6_, p_getConnectedTextureCtm_7_);
         aboolean[1] = isNeighbour(p_getConnectedTextureCtm_0_, p_getConnectedTextureCtm_1_, p_getConnectedTextureCtm_2_, p_getConnectedTextureCtm_3_.east(), p_getConnectedTextureCtm_5_, p_getConnectedTextureCtm_6_, p_getConnectedTextureCtm_7_);
         aboolean[2] = isNeighbour(p_getConnectedTextureCtm_0_, p_getConnectedTextureCtm_1_, p_getConnectedTextureCtm_2_, p_getConnectedTextureCtm_3_.north(), p_getConnectedTextureCtm_5_, p_getConnectedTextureCtm_6_, p_getConnectedTextureCtm_7_);
         aboolean[3] = isNeighbour(p_getConnectedTextureCtm_0_, p_getConnectedTextureCtm_1_, p_getConnectedTextureCtm_2_, p_getConnectedTextureCtm_3_.south(), p_getConnectedTextureCtm_5_, p_getConnectedTextureCtm_6_, p_getConnectedTextureCtm_7_);
         break;
      case 1:
         aboolean[0] = isNeighbour(p_getConnectedTextureCtm_0_, p_getConnectedTextureCtm_1_, p_getConnectedTextureCtm_2_, p_getConnectedTextureCtm_3_.west(), p_getConnectedTextureCtm_5_, p_getConnectedTextureCtm_6_, p_getConnectedTextureCtm_7_);
         aboolean[1] = isNeighbour(p_getConnectedTextureCtm_0_, p_getConnectedTextureCtm_1_, p_getConnectedTextureCtm_2_, p_getConnectedTextureCtm_3_.east(), p_getConnectedTextureCtm_5_, p_getConnectedTextureCtm_6_, p_getConnectedTextureCtm_7_);
         aboolean[2] = isNeighbour(p_getConnectedTextureCtm_0_, p_getConnectedTextureCtm_1_, p_getConnectedTextureCtm_2_, p_getConnectedTextureCtm_3_.south(), p_getConnectedTextureCtm_5_, p_getConnectedTextureCtm_6_, p_getConnectedTextureCtm_7_);
         aboolean[3] = isNeighbour(p_getConnectedTextureCtm_0_, p_getConnectedTextureCtm_1_, p_getConnectedTextureCtm_2_, p_getConnectedTextureCtm_3_.north(), p_getConnectedTextureCtm_5_, p_getConnectedTextureCtm_6_, p_getConnectedTextureCtm_7_);
         break;
      case 2:
         aboolean[0] = isNeighbour(p_getConnectedTextureCtm_0_, p_getConnectedTextureCtm_1_, p_getConnectedTextureCtm_2_, p_getConnectedTextureCtm_3_.east(), p_getConnectedTextureCtm_5_, p_getConnectedTextureCtm_6_, p_getConnectedTextureCtm_7_);
         aboolean[1] = isNeighbour(p_getConnectedTextureCtm_0_, p_getConnectedTextureCtm_1_, p_getConnectedTextureCtm_2_, p_getConnectedTextureCtm_3_.west(), p_getConnectedTextureCtm_5_, p_getConnectedTextureCtm_6_, p_getConnectedTextureCtm_7_);
         aboolean[2] = isNeighbour(p_getConnectedTextureCtm_0_, p_getConnectedTextureCtm_1_, p_getConnectedTextureCtm_2_, p_getConnectedTextureCtm_3_.down(), p_getConnectedTextureCtm_5_, p_getConnectedTextureCtm_6_, p_getConnectedTextureCtm_7_);
         aboolean[3] = isNeighbour(p_getConnectedTextureCtm_0_, p_getConnectedTextureCtm_1_, p_getConnectedTextureCtm_2_, p_getConnectedTextureCtm_3_.up(), p_getConnectedTextureCtm_5_, p_getConnectedTextureCtm_6_, p_getConnectedTextureCtm_7_);
         break;
      case 3:
         aboolean[0] = isNeighbour(p_getConnectedTextureCtm_0_, p_getConnectedTextureCtm_1_, p_getConnectedTextureCtm_2_, p_getConnectedTextureCtm_3_.west(), p_getConnectedTextureCtm_5_, p_getConnectedTextureCtm_6_, p_getConnectedTextureCtm_7_);
         aboolean[1] = isNeighbour(p_getConnectedTextureCtm_0_, p_getConnectedTextureCtm_1_, p_getConnectedTextureCtm_2_, p_getConnectedTextureCtm_3_.east(), p_getConnectedTextureCtm_5_, p_getConnectedTextureCtm_6_, p_getConnectedTextureCtm_7_);
         aboolean[2] = isNeighbour(p_getConnectedTextureCtm_0_, p_getConnectedTextureCtm_1_, p_getConnectedTextureCtm_2_, p_getConnectedTextureCtm_3_.down(), p_getConnectedTextureCtm_5_, p_getConnectedTextureCtm_6_, p_getConnectedTextureCtm_7_);
         aboolean[3] = isNeighbour(p_getConnectedTextureCtm_0_, p_getConnectedTextureCtm_1_, p_getConnectedTextureCtm_2_, p_getConnectedTextureCtm_3_.up(), p_getConnectedTextureCtm_5_, p_getConnectedTextureCtm_6_, p_getConnectedTextureCtm_7_);
         break;
      case 4:
         aboolean[0] = isNeighbour(p_getConnectedTextureCtm_0_, p_getConnectedTextureCtm_1_, p_getConnectedTextureCtm_2_, p_getConnectedTextureCtm_3_.north(), p_getConnectedTextureCtm_5_, p_getConnectedTextureCtm_6_, p_getConnectedTextureCtm_7_);
         aboolean[1] = isNeighbour(p_getConnectedTextureCtm_0_, p_getConnectedTextureCtm_1_, p_getConnectedTextureCtm_2_, p_getConnectedTextureCtm_3_.south(), p_getConnectedTextureCtm_5_, p_getConnectedTextureCtm_6_, p_getConnectedTextureCtm_7_);
         aboolean[2] = isNeighbour(p_getConnectedTextureCtm_0_, p_getConnectedTextureCtm_1_, p_getConnectedTextureCtm_2_, p_getConnectedTextureCtm_3_.down(), p_getConnectedTextureCtm_5_, p_getConnectedTextureCtm_6_, p_getConnectedTextureCtm_7_);
         aboolean[3] = isNeighbour(p_getConnectedTextureCtm_0_, p_getConnectedTextureCtm_1_, p_getConnectedTextureCtm_2_, p_getConnectedTextureCtm_3_.up(), p_getConnectedTextureCtm_5_, p_getConnectedTextureCtm_6_, p_getConnectedTextureCtm_7_);
         break;
      case 5:
         aboolean[0] = isNeighbour(p_getConnectedTextureCtm_0_, p_getConnectedTextureCtm_1_, p_getConnectedTextureCtm_2_, p_getConnectedTextureCtm_3_.south(), p_getConnectedTextureCtm_5_, p_getConnectedTextureCtm_6_, p_getConnectedTextureCtm_7_);
         aboolean[1] = isNeighbour(p_getConnectedTextureCtm_0_, p_getConnectedTextureCtm_1_, p_getConnectedTextureCtm_2_, p_getConnectedTextureCtm_3_.north(), p_getConnectedTextureCtm_5_, p_getConnectedTextureCtm_6_, p_getConnectedTextureCtm_7_);
         aboolean[2] = isNeighbour(p_getConnectedTextureCtm_0_, p_getConnectedTextureCtm_1_, p_getConnectedTextureCtm_2_, p_getConnectedTextureCtm_3_.down(), p_getConnectedTextureCtm_5_, p_getConnectedTextureCtm_6_, p_getConnectedTextureCtm_7_);
         aboolean[3] = isNeighbour(p_getConnectedTextureCtm_0_, p_getConnectedTextureCtm_1_, p_getConnectedTextureCtm_2_, p_getConnectedTextureCtm_3_.up(), p_getConnectedTextureCtm_5_, p_getConnectedTextureCtm_6_, p_getConnectedTextureCtm_7_);
      }

      int i = 0;
      if (aboolean[0] & !aboolean[1] & !aboolean[2] & !aboolean[3]) {
         i = 3;
      } else if (!aboolean[0] & aboolean[1] & !aboolean[2] & !aboolean[3]) {
         i = 1;
      } else if (!aboolean[0] & !aboolean[1] & aboolean[2] & !aboolean[3]) {
         i = 12;
      } else if (!aboolean[0] & !aboolean[1] & !aboolean[2] & aboolean[3]) {
         i = 36;
      } else if (aboolean[0] & aboolean[1] & !aboolean[2] & !aboolean[3]) {
         i = 2;
      } else if (!aboolean[0] & !aboolean[1] & aboolean[2] & aboolean[3]) {
         i = 24;
      } else if (aboolean[0] & !aboolean[1] & aboolean[2] & !aboolean[3]) {
         i = 15;
      } else if (aboolean[0] & !aboolean[1] & !aboolean[2] & aboolean[3]) {
         i = 39;
      } else if (!aboolean[0] & aboolean[1] & aboolean[2] & !aboolean[3]) {
         i = 13;
      } else if (!aboolean[0] & aboolean[1] & !aboolean[2] & aboolean[3]) {
         i = 37;
      } else if (!aboolean[0] & aboolean[1] & aboolean[2] & aboolean[3]) {
         i = 25;
      } else if (aboolean[0] & !aboolean[1] & aboolean[2] & aboolean[3]) {
         i = 27;
      } else if (aboolean[0] & aboolean[1] & !aboolean[2] & aboolean[3]) {
         i = 38;
      } else if (aboolean[0] & aboolean[1] & aboolean[2] & !aboolean[3]) {
         i = 14;
      } else if (aboolean[0] & aboolean[1] & aboolean[2] & aboolean[3]) {
         i = 26;
      }

      if (i == 0) {
         return p_getConnectedTextureCtm_0_.tileIcons[i];
      } else if (!jebac_vexiakrwecfs16wve.isConnectedTexturesFancy()) {
         return p_getConnectedTextureCtm_0_.tileIcons[i];
      } else {
         switch(p_getConnectedTextureCtm_5_) {
         case 0:
            aboolean[0] = !isNeighbour(p_getConnectedTextureCtm_0_, p_getConnectedTextureCtm_1_, p_getConnectedTextureCtm_2_, p_getConnectedTextureCtm_3_.east().north(), p_getConnectedTextureCtm_5_, p_getConnectedTextureCtm_6_, p_getConnectedTextureCtm_7_);
            aboolean[1] = !isNeighbour(p_getConnectedTextureCtm_0_, p_getConnectedTextureCtm_1_, p_getConnectedTextureCtm_2_, p_getConnectedTextureCtm_3_.west().north(), p_getConnectedTextureCtm_5_, p_getConnectedTextureCtm_6_, p_getConnectedTextureCtm_7_);
            aboolean[2] = !isNeighbour(p_getConnectedTextureCtm_0_, p_getConnectedTextureCtm_1_, p_getConnectedTextureCtm_2_, p_getConnectedTextureCtm_3_.east().south(), p_getConnectedTextureCtm_5_, p_getConnectedTextureCtm_6_, p_getConnectedTextureCtm_7_);
            aboolean[3] = !isNeighbour(p_getConnectedTextureCtm_0_, p_getConnectedTextureCtm_1_, p_getConnectedTextureCtm_2_, p_getConnectedTextureCtm_3_.west().south(), p_getConnectedTextureCtm_5_, p_getConnectedTextureCtm_6_, p_getConnectedTextureCtm_7_);
            break;
         case 1:
            aboolean[0] = !isNeighbour(p_getConnectedTextureCtm_0_, p_getConnectedTextureCtm_1_, p_getConnectedTextureCtm_2_, p_getConnectedTextureCtm_3_.east().south(), p_getConnectedTextureCtm_5_, p_getConnectedTextureCtm_6_, p_getConnectedTextureCtm_7_);
            aboolean[1] = !isNeighbour(p_getConnectedTextureCtm_0_, p_getConnectedTextureCtm_1_, p_getConnectedTextureCtm_2_, p_getConnectedTextureCtm_3_.west().south(), p_getConnectedTextureCtm_5_, p_getConnectedTextureCtm_6_, p_getConnectedTextureCtm_7_);
            aboolean[2] = !isNeighbour(p_getConnectedTextureCtm_0_, p_getConnectedTextureCtm_1_, p_getConnectedTextureCtm_2_, p_getConnectedTextureCtm_3_.east().north(), p_getConnectedTextureCtm_5_, p_getConnectedTextureCtm_6_, p_getConnectedTextureCtm_7_);
            aboolean[3] = !isNeighbour(p_getConnectedTextureCtm_0_, p_getConnectedTextureCtm_1_, p_getConnectedTextureCtm_2_, p_getConnectedTextureCtm_3_.west().north(), p_getConnectedTextureCtm_5_, p_getConnectedTextureCtm_6_, p_getConnectedTextureCtm_7_);
            break;
         case 2:
            aboolean[0] = !isNeighbour(p_getConnectedTextureCtm_0_, p_getConnectedTextureCtm_1_, p_getConnectedTextureCtm_2_, p_getConnectedTextureCtm_3_.west().down(), p_getConnectedTextureCtm_5_, p_getConnectedTextureCtm_6_, p_getConnectedTextureCtm_7_);
            aboolean[1] = !isNeighbour(p_getConnectedTextureCtm_0_, p_getConnectedTextureCtm_1_, p_getConnectedTextureCtm_2_, p_getConnectedTextureCtm_3_.east().down(), p_getConnectedTextureCtm_5_, p_getConnectedTextureCtm_6_, p_getConnectedTextureCtm_7_);
            aboolean[2] = !isNeighbour(p_getConnectedTextureCtm_0_, p_getConnectedTextureCtm_1_, p_getConnectedTextureCtm_2_, p_getConnectedTextureCtm_3_.west().up(), p_getConnectedTextureCtm_5_, p_getConnectedTextureCtm_6_, p_getConnectedTextureCtm_7_);
            aboolean[3] = !isNeighbour(p_getConnectedTextureCtm_0_, p_getConnectedTextureCtm_1_, p_getConnectedTextureCtm_2_, p_getConnectedTextureCtm_3_.east().up(), p_getConnectedTextureCtm_5_, p_getConnectedTextureCtm_6_, p_getConnectedTextureCtm_7_);
            break;
         case 3:
            aboolean[0] = !isNeighbour(p_getConnectedTextureCtm_0_, p_getConnectedTextureCtm_1_, p_getConnectedTextureCtm_2_, p_getConnectedTextureCtm_3_.east().down(), p_getConnectedTextureCtm_5_, p_getConnectedTextureCtm_6_, p_getConnectedTextureCtm_7_);
            aboolean[1] = !isNeighbour(p_getConnectedTextureCtm_0_, p_getConnectedTextureCtm_1_, p_getConnectedTextureCtm_2_, p_getConnectedTextureCtm_3_.west().down(), p_getConnectedTextureCtm_5_, p_getConnectedTextureCtm_6_, p_getConnectedTextureCtm_7_);
            aboolean[2] = !isNeighbour(p_getConnectedTextureCtm_0_, p_getConnectedTextureCtm_1_, p_getConnectedTextureCtm_2_, p_getConnectedTextureCtm_3_.east().up(), p_getConnectedTextureCtm_5_, p_getConnectedTextureCtm_6_, p_getConnectedTextureCtm_7_);
            aboolean[3] = !isNeighbour(p_getConnectedTextureCtm_0_, p_getConnectedTextureCtm_1_, p_getConnectedTextureCtm_2_, p_getConnectedTextureCtm_3_.west().up(), p_getConnectedTextureCtm_5_, p_getConnectedTextureCtm_6_, p_getConnectedTextureCtm_7_);
            break;
         case 4:
            aboolean[0] = !isNeighbour(p_getConnectedTextureCtm_0_, p_getConnectedTextureCtm_1_, p_getConnectedTextureCtm_2_, p_getConnectedTextureCtm_3_.down().south(), p_getConnectedTextureCtm_5_, p_getConnectedTextureCtm_6_, p_getConnectedTextureCtm_7_);
            aboolean[1] = !isNeighbour(p_getConnectedTextureCtm_0_, p_getConnectedTextureCtm_1_, p_getConnectedTextureCtm_2_, p_getConnectedTextureCtm_3_.down().north(), p_getConnectedTextureCtm_5_, p_getConnectedTextureCtm_6_, p_getConnectedTextureCtm_7_);
            aboolean[2] = !isNeighbour(p_getConnectedTextureCtm_0_, p_getConnectedTextureCtm_1_, p_getConnectedTextureCtm_2_, p_getConnectedTextureCtm_3_.up().south(), p_getConnectedTextureCtm_5_, p_getConnectedTextureCtm_6_, p_getConnectedTextureCtm_7_);
            aboolean[3] = !isNeighbour(p_getConnectedTextureCtm_0_, p_getConnectedTextureCtm_1_, p_getConnectedTextureCtm_2_, p_getConnectedTextureCtm_3_.up().north(), p_getConnectedTextureCtm_5_, p_getConnectedTextureCtm_6_, p_getConnectedTextureCtm_7_);
            break;
         case 5:
            aboolean[0] = !isNeighbour(p_getConnectedTextureCtm_0_, p_getConnectedTextureCtm_1_, p_getConnectedTextureCtm_2_, p_getConnectedTextureCtm_3_.down().north(), p_getConnectedTextureCtm_5_, p_getConnectedTextureCtm_6_, p_getConnectedTextureCtm_7_);
            aboolean[1] = !isNeighbour(p_getConnectedTextureCtm_0_, p_getConnectedTextureCtm_1_, p_getConnectedTextureCtm_2_, p_getConnectedTextureCtm_3_.down().south(), p_getConnectedTextureCtm_5_, p_getConnectedTextureCtm_6_, p_getConnectedTextureCtm_7_);
            aboolean[2] = !isNeighbour(p_getConnectedTextureCtm_0_, p_getConnectedTextureCtm_1_, p_getConnectedTextureCtm_2_, p_getConnectedTextureCtm_3_.up().north(), p_getConnectedTextureCtm_5_, p_getConnectedTextureCtm_6_, p_getConnectedTextureCtm_7_);
            aboolean[3] = !isNeighbour(p_getConnectedTextureCtm_0_, p_getConnectedTextureCtm_1_, p_getConnectedTextureCtm_2_, p_getConnectedTextureCtm_3_.up().south(), p_getConnectedTextureCtm_5_, p_getConnectedTextureCtm_6_, p_getConnectedTextureCtm_7_);
         }

         if (i == 13 && aboolean[0]) {
            i = 4;
         } else if (i == 15 && aboolean[1]) {
            i = 5;
         } else if (i == 37 && aboolean[2]) {
            i = 16;
         } else if (i == 39 && aboolean[3]) {
            i = 17;
         } else if (i == 14 && aboolean[0] && aboolean[1]) {
            i = 7;
         } else if (i == 25 && aboolean[0] && aboolean[2]) {
            i = 6;
         } else if (i == 27 && aboolean[3] && aboolean[1]) {
            i = 19;
         } else if (i == 38 && aboolean[3] && aboolean[2]) {
            i = 18;
         } else if (i == 14 && !aboolean[0] && aboolean[1]) {
            i = 31;
         } else if (i == 25 && aboolean[0]) {
            i = 30;
         } else if (i == 27 && !aboolean[3] && aboolean[1]) {
            i = 41;
         } else if (i == 38 && aboolean[3]) {
            i = 40;
         } else if (i == 14 && aboolean[0]) {
            i = 29;
         } else if (i == 25 && aboolean[2]) {
            i = 28;
         } else if (i == 27 && aboolean[3]) {
            i = 43;
         } else if (i == 38 && aboolean[2]) {
            i = 42;
         } else if (i == 26 && aboolean[0] && aboolean[1] && aboolean[2] && aboolean[3]) {
            i = 46;
         } else if (i == 26 && !aboolean[0] && aboolean[1] && aboolean[2] && aboolean[3]) {
            i = 9;
         } else if (i == 26 && aboolean[0] && !aboolean[1] && aboolean[2] && aboolean[3]) {
            i = 21;
         } else if (i == 26 && aboolean[0] && aboolean[1] && !aboolean[2] && aboolean[3]) {
            i = 8;
         } else if (i == 26 && aboolean[0] && aboolean[1] && aboolean[2]) {
            i = 20;
         } else if (i == 26 && aboolean[0] && aboolean[1]) {
            i = 11;
         } else if (i == 26 && !aboolean[0] && !aboolean[1] && aboolean[2] && aboolean[3]) {
            i = 22;
         } else if (i == 26 && !aboolean[0] && aboolean[1] && !aboolean[2] && aboolean[3]) {
            i = 23;
         } else if (i == 26 && aboolean[0] && aboolean[2]) {
            i = 10;
         } else if (i == 26 && aboolean[0] && !aboolean[2] && aboolean[3]) {
            i = 34;
         } else if (i == 26 && !aboolean[0] && aboolean[1] && aboolean[2]) {
            i = 35;
         } else if (i == 26 && aboolean[0] && !aboolean[2]) {
            i = 32;
         } else if (i == 26 && aboolean[1] && !aboolean[2]) {
            i = 33;
         } else if (i == 26 && !aboolean[1] && aboolean[2]) {
            i = 44;
         } else if (i == 26 && !aboolean[1] && !aboolean[2] && aboolean[3]) {
            i = 45;
         }

         return p_getConnectedTextureCtm_0_.tileIcons[i];
      }
   }

   // $FF: synthetic method
   private static int getQuartzAxis(int p_getQuartzAxis_1_) {
      switch(p_getQuartzAxis_1_) {
      case 3:
         return 2;
      case 4:
         return 1;
      default:
         return 0;
      }
   }

   // $FF: synthetic method
   private static List makePropertyList(jebac_vexiayab0wp48ilc2[][] p_makePropertyList_0_) {
      List list = new ArrayList();
      if (p_makePropertyList_0_ != null) {
         jebac_vexiayab0wp48ilc2[][] var2 = p_makePropertyList_0_;
         int var3 = p_makePropertyList_0_.length;

         for(int var4 = 0; var4 < var3; ++var4) {
            jebac_vexiayab0wp48ilc2[] aconnectedproperties = var2[var4];
            List list1 = null;
            if (aconnectedproperties != null) {
               list1 = new ArrayList(Arrays.asList(aconnectedproperties));
            }

            list.add(list1);
         }
      }

      return list;
   }

   // $FF: synthetic method
   private static TextureAtlasSprite getConnectedTexture(jebac_vexiayab0wp48ilc2 p_getConnectedTexture_0_, IBlockAccess p_getConnectedTexture_1_, BlockStateBase p_getConnectedTexture_2_, BlockPos p_getConnectedTexture_3_, int p_getConnectedTexture_4_, TextureAtlasSprite p_getConnectedTexture_5_, jebac_vexiai2kawx8j8o7a p_getConnectedTexture_6_) {
      int i = 0;
      int j = p_getConnectedTexture_2_.getMetadata();
      int k = j;
      Block block = p_getConnectedTexture_2_.getBlock();
      if (block instanceof BlockRotatedPillar) {
         i = getWoodAxis(j);
         if (p_getConnectedTexture_0_.getMetadataMax() <= 3) {
            k = j & 3;
         }
      }

      if (block instanceof BlockQuartz) {
         i = getQuartzAxis(j);
         if (p_getConnectedTexture_0_.getMetadataMax() <= 2 && k > 2) {
            k = 2;
         }
      }

      if (!p_getConnectedTexture_0_.matchesBlock(p_getConnectedTexture_2_.getBlockId(), k)) {
         return null;
      } else {
         int l;
         if (p_getConnectedTexture_4_ >= 0 && p_getConnectedTexture_0_.faces != 63) {
            l = p_getConnectedTexture_4_;
            if (i != 0) {
               l = fixSideByAxis(p_getConnectedTexture_4_, i);
            }

            if ((1 << l & p_getConnectedTexture_0_.faces) == 0) {
               return null;
            }
         }

         l = p_getConnectedTexture_3_.getY();
         if (l >= p_getConnectedTexture_0_.minHeight && l <= p_getConnectedTexture_0_.maxHeight) {
            if (p_getConnectedTexture_0_.biomes != null) {
               BiomeGenBase biomegenbase = p_getConnectedTexture_1_.getBiomeGenForCoords(p_getConnectedTexture_3_);
               if (!p_getConnectedTexture_0_.matchesBiome(biomegenbase)) {
                  return null;
               }
            }

            switch(p_getConnectedTexture_0_.method) {
            case 1:
               return getConnectedTextureCtm(p_getConnectedTexture_0_, p_getConnectedTexture_1_, p_getConnectedTexture_2_, p_getConnectedTexture_3_, i, p_getConnectedTexture_4_, p_getConnectedTexture_5_, j, p_getConnectedTexture_6_);
            case 2:
               return getConnectedTextureHorizontal(p_getConnectedTexture_0_, p_getConnectedTexture_1_, p_getConnectedTexture_2_, p_getConnectedTexture_3_, i, p_getConnectedTexture_4_, p_getConnectedTexture_5_, j);
            case 3:
               return getConnectedTextureTop(p_getConnectedTexture_0_, p_getConnectedTexture_1_, p_getConnectedTexture_2_, p_getConnectedTexture_3_, i, p_getConnectedTexture_4_, p_getConnectedTexture_5_, j);
            case 4:
               return getConnectedTextureRandom(p_getConnectedTexture_0_, p_getConnectedTexture_3_, p_getConnectedTexture_4_);
            case 5:
               return getConnectedTextureRepeat(p_getConnectedTexture_0_, p_getConnectedTexture_3_, p_getConnectedTexture_4_);
            case 6:
               return getConnectedTextureVertical(p_getConnectedTexture_0_, p_getConnectedTexture_1_, p_getConnectedTexture_2_, p_getConnectedTexture_3_, i, p_getConnectedTexture_4_, p_getConnectedTexture_5_, j);
            case 7:
               return getConnectedTextureFixed(p_getConnectedTexture_0_);
            case 8:
               return getConnectedTextureHorizontalVertical(p_getConnectedTexture_0_, p_getConnectedTexture_1_, p_getConnectedTexture_2_, p_getConnectedTexture_3_, i, p_getConnectedTexture_4_, p_getConnectedTexture_5_, j);
            case 9:
               return getConnectedTextureVerticalHorizontal(p_getConnectedTexture_0_, p_getConnectedTexture_1_, p_getConnectedTexture_2_, p_getConnectedTexture_3_, i, p_getConnectedTexture_4_, p_getConnectedTexture_5_, j);
            default:
               return null;
            }
         } else {
            return null;
         }
      }
   }

   // $FF: synthetic method
   private static TextureAtlasSprite getConnectedTextureHorizontal(jebac_vexiayab0wp48ilc2 p_getConnectedTextureHorizontal_0_, IBlockAccess p_getConnectedTextureHorizontal_1_, IBlockState p_getConnectedTextureHorizontal_2_, BlockPos p_getConnectedTextureHorizontal_3_, int p_getConnectedTextureHorizontal_4_, int p_getConnectedTextureHorizontal_5_, TextureAtlasSprite p_getConnectedTextureHorizontal_6_, int p_getConnectedTextureHorizontal_7_) {
      boolean flag;
      boolean flag1;
      flag = false;
      flag1 = false;
      label43:
      switch(p_getConnectedTextureHorizontal_4_) {
      case 0:
         switch(p_getConnectedTextureHorizontal_5_) {
         case 0:
         case 1:
            return null;
         case 2:
            flag = isNeighbour(p_getConnectedTextureHorizontal_0_, p_getConnectedTextureHorizontal_1_, p_getConnectedTextureHorizontal_2_, p_getConnectedTextureHorizontal_3_.east(), p_getConnectedTextureHorizontal_5_, p_getConnectedTextureHorizontal_6_, p_getConnectedTextureHorizontal_7_);
            flag1 = isNeighbour(p_getConnectedTextureHorizontal_0_, p_getConnectedTextureHorizontal_1_, p_getConnectedTextureHorizontal_2_, p_getConnectedTextureHorizontal_3_.west(), p_getConnectedTextureHorizontal_5_, p_getConnectedTextureHorizontal_6_, p_getConnectedTextureHorizontal_7_);
            break label43;
         case 3:
            flag = isNeighbour(p_getConnectedTextureHorizontal_0_, p_getConnectedTextureHorizontal_1_, p_getConnectedTextureHorizontal_2_, p_getConnectedTextureHorizontal_3_.west(), p_getConnectedTextureHorizontal_5_, p_getConnectedTextureHorizontal_6_, p_getConnectedTextureHorizontal_7_);
            flag1 = isNeighbour(p_getConnectedTextureHorizontal_0_, p_getConnectedTextureHorizontal_1_, p_getConnectedTextureHorizontal_2_, p_getConnectedTextureHorizontal_3_.east(), p_getConnectedTextureHorizontal_5_, p_getConnectedTextureHorizontal_6_, p_getConnectedTextureHorizontal_7_);
            break label43;
         case 4:
            flag = isNeighbour(p_getConnectedTextureHorizontal_0_, p_getConnectedTextureHorizontal_1_, p_getConnectedTextureHorizontal_2_, p_getConnectedTextureHorizontal_3_.north(), p_getConnectedTextureHorizontal_5_, p_getConnectedTextureHorizontal_6_, p_getConnectedTextureHorizontal_7_);
            flag1 = isNeighbour(p_getConnectedTextureHorizontal_0_, p_getConnectedTextureHorizontal_1_, p_getConnectedTextureHorizontal_2_, p_getConnectedTextureHorizontal_3_.south(), p_getConnectedTextureHorizontal_5_, p_getConnectedTextureHorizontal_6_, p_getConnectedTextureHorizontal_7_);
            break label43;
         case 5:
            flag = isNeighbour(p_getConnectedTextureHorizontal_0_, p_getConnectedTextureHorizontal_1_, p_getConnectedTextureHorizontal_2_, p_getConnectedTextureHorizontal_3_.south(), p_getConnectedTextureHorizontal_5_, p_getConnectedTextureHorizontal_6_, p_getConnectedTextureHorizontal_7_);
            flag1 = isNeighbour(p_getConnectedTextureHorizontal_0_, p_getConnectedTextureHorizontal_1_, p_getConnectedTextureHorizontal_2_, p_getConnectedTextureHorizontal_3_.north(), p_getConnectedTextureHorizontal_5_, p_getConnectedTextureHorizontal_6_, p_getConnectedTextureHorizontal_7_);
         default:
            break label43;
         }
      case 1:
         switch(p_getConnectedTextureHorizontal_5_) {
         case 0:
         case 1:
            flag = isNeighbour(p_getConnectedTextureHorizontal_0_, p_getConnectedTextureHorizontal_1_, p_getConnectedTextureHorizontal_2_, p_getConnectedTextureHorizontal_3_.west(), p_getConnectedTextureHorizontal_5_, p_getConnectedTextureHorizontal_6_, p_getConnectedTextureHorizontal_7_);
            flag1 = isNeighbour(p_getConnectedTextureHorizontal_0_, p_getConnectedTextureHorizontal_1_, p_getConnectedTextureHorizontal_2_, p_getConnectedTextureHorizontal_3_.east(), p_getConnectedTextureHorizontal_5_, p_getConnectedTextureHorizontal_6_, p_getConnectedTextureHorizontal_7_);
            break label43;
         case 2:
         case 3:
            return null;
         case 4:
            flag = isNeighbour(p_getConnectedTextureHorizontal_0_, p_getConnectedTextureHorizontal_1_, p_getConnectedTextureHorizontal_2_, p_getConnectedTextureHorizontal_3_.down(), p_getConnectedTextureHorizontal_5_, p_getConnectedTextureHorizontal_6_, p_getConnectedTextureHorizontal_7_);
            flag1 = isNeighbour(p_getConnectedTextureHorizontal_0_, p_getConnectedTextureHorizontal_1_, p_getConnectedTextureHorizontal_2_, p_getConnectedTextureHorizontal_3_.up(), p_getConnectedTextureHorizontal_5_, p_getConnectedTextureHorizontal_6_, p_getConnectedTextureHorizontal_7_);
            break label43;
         case 5:
            flag = isNeighbour(p_getConnectedTextureHorizontal_0_, p_getConnectedTextureHorizontal_1_, p_getConnectedTextureHorizontal_2_, p_getConnectedTextureHorizontal_3_.up(), p_getConnectedTextureHorizontal_5_, p_getConnectedTextureHorizontal_6_, p_getConnectedTextureHorizontal_7_);
            flag1 = isNeighbour(p_getConnectedTextureHorizontal_0_, p_getConnectedTextureHorizontal_1_, p_getConnectedTextureHorizontal_2_, p_getConnectedTextureHorizontal_3_.down(), p_getConnectedTextureHorizontal_5_, p_getConnectedTextureHorizontal_6_, p_getConnectedTextureHorizontal_7_);
         default:
            break label43;
         }
      case 2:
         switch(p_getConnectedTextureHorizontal_5_) {
         case 0:
         case 1:
            flag = isNeighbour(p_getConnectedTextureHorizontal_0_, p_getConnectedTextureHorizontal_1_, p_getConnectedTextureHorizontal_2_, p_getConnectedTextureHorizontal_3_.north(), p_getConnectedTextureHorizontal_5_, p_getConnectedTextureHorizontal_6_, p_getConnectedTextureHorizontal_7_);
            flag1 = isNeighbour(p_getConnectedTextureHorizontal_0_, p_getConnectedTextureHorizontal_1_, p_getConnectedTextureHorizontal_2_, p_getConnectedTextureHorizontal_3_.south(), p_getConnectedTextureHorizontal_5_, p_getConnectedTextureHorizontal_6_, p_getConnectedTextureHorizontal_7_);
            break;
         case 2:
            flag = isNeighbour(p_getConnectedTextureHorizontal_0_, p_getConnectedTextureHorizontal_1_, p_getConnectedTextureHorizontal_2_, p_getConnectedTextureHorizontal_3_.down(), p_getConnectedTextureHorizontal_5_, p_getConnectedTextureHorizontal_6_, p_getConnectedTextureHorizontal_7_);
            flag1 = isNeighbour(p_getConnectedTextureHorizontal_0_, p_getConnectedTextureHorizontal_1_, p_getConnectedTextureHorizontal_2_, p_getConnectedTextureHorizontal_3_.up(), p_getConnectedTextureHorizontal_5_, p_getConnectedTextureHorizontal_6_, p_getConnectedTextureHorizontal_7_);
            break;
         case 3:
            flag = isNeighbour(p_getConnectedTextureHorizontal_0_, p_getConnectedTextureHorizontal_1_, p_getConnectedTextureHorizontal_2_, p_getConnectedTextureHorizontal_3_.up(), p_getConnectedTextureHorizontal_5_, p_getConnectedTextureHorizontal_6_, p_getConnectedTextureHorizontal_7_);
            flag1 = isNeighbour(p_getConnectedTextureHorizontal_0_, p_getConnectedTextureHorizontal_1_, p_getConnectedTextureHorizontal_2_, p_getConnectedTextureHorizontal_3_.down(), p_getConnectedTextureHorizontal_5_, p_getConnectedTextureHorizontal_6_, p_getConnectedTextureHorizontal_7_);
            break;
         case 4:
         case 5:
            return null;
         }
      }

      int i = 3;
      if (flag) {
         if (flag1) {
            i = 1;
         } else {
            i = 2;
         }
      } else if (flag1) {
         i = 0;
      }

      return p_getConnectedTextureHorizontal_0_.tileIcons[i];
   }

   // $FF: synthetic method
   public static TextureAtlasSprite getConnectedTextureSingle(IBlockAccess p_getConnectedTextureSingle_0_, IBlockState p_getConnectedTextureSingle_1_, BlockPos p_getConnectedTextureSingle_2_, EnumFacing p_getConnectedTextureSingle_3_, TextureAtlasSprite p_getConnectedTextureSingle_4_, boolean p_getConnectedTextureSingle_5_, jebac_vexiai2kawx8j8o7a p_getConnectedTextureSingle_6_) {
      if (!(p_getConnectedTextureSingle_1_ instanceof BlockStateBase)) {
         return p_getConnectedTextureSingle_4_;
      } else {
         BlockStateBase blockstatebase = (BlockStateBase)p_getConnectedTextureSingle_1_;
         int l;
         jebac_vexiayab0wp48ilc2[] aconnectedproperties1;
         int i1;
         jebac_vexiayab0wp48ilc2[] var11;
         int var12;
         int var13;
         jebac_vexiayab0wp48ilc2 connectedproperties1;
         TextureAtlasSprite textureatlassprite1;
         if (tileProperties != null) {
            l = p_getConnectedTextureSingle_4_.getIndexInMap();
            if (l >= 0 && l < tileProperties.length) {
               aconnectedproperties1 = tileProperties[l];
               if (aconnectedproperties1 != null) {
                  i1 = getSide(p_getConnectedTextureSingle_3_);
                  var11 = aconnectedproperties1;
                  var12 = aconnectedproperties1.length;

                  for(var13 = 0; var13 < var12; ++var13) {
                     connectedproperties1 = var11[var13];
                     if (connectedproperties1 != null && connectedproperties1.matchesBlockId(blockstatebase.getBlockId())) {
                        textureatlassprite1 = getConnectedTexture(connectedproperties1, p_getConnectedTextureSingle_0_, blockstatebase, p_getConnectedTextureSingle_2_, i1, p_getConnectedTextureSingle_4_, p_getConnectedTextureSingle_6_);
                        if (textureatlassprite1 != null) {
                           return textureatlassprite1;
                        }
                     }
                  }
               }
            }
         }

         if (blockProperties != null && p_getConnectedTextureSingle_5_) {
            l = p_getConnectedTextureSingle_6_.getBlockId();
            if (l >= 0 && l < blockProperties.length) {
               aconnectedproperties1 = blockProperties[l];
               if (aconnectedproperties1 != null) {
                  i1 = getSide(p_getConnectedTextureSingle_3_);
                  var11 = aconnectedproperties1;
                  var12 = aconnectedproperties1.length;

                  for(var13 = 0; var13 < var12; ++var13) {
                     connectedproperties1 = var11[var13];
                     if (connectedproperties1 != null && connectedproperties1.matchesIcon(p_getConnectedTextureSingle_4_)) {
                        textureatlassprite1 = getConnectedTexture(connectedproperties1, p_getConnectedTextureSingle_0_, blockstatebase, p_getConnectedTextureSingle_2_, i1, p_getConnectedTextureSingle_4_, p_getConnectedTextureSingle_6_);
                        if (textureatlassprite1 != null) {
                           return textureatlassprite1;
                        }
                     }
                  }
               }
            }
         }

         return p_getConnectedTextureSingle_4_;
      }
   }

   // $FF: synthetic method
   private static EnumFacing getFacing(int p_getFacing_0_) {
      switch(p_getFacing_0_) {
      case 0:
         return EnumFacing.DOWN;
      case 1:
      default:
         return EnumFacing.UP;
      case 2:
         return EnumFacing.NORTH;
      case 3:
         return EnumFacing.SOUTH;
      case 4:
         return EnumFacing.WEST;
      case 5:
         return EnumFacing.EAST;
      }
   }

   // $FF: synthetic method
   private static TextureAtlasSprite getConnectedTextureHorizontalVertical(jebac_vexiayab0wp48ilc2 p_getConnectedTextureHorizontalVertical_0_, IBlockAccess p_getConnectedTextureHorizontalVertical_1_, IBlockState p_getConnectedTextureHorizontalVertical_2_, BlockPos p_getConnectedTextureHorizontalVertical_3_, int p_getConnectedTextureHorizontalVertical_4_, int p_getConnectedTextureHorizontalVertical_5_, TextureAtlasSprite p_getConnectedTextureHorizontalVertical_6_, int p_getConnectedTextureHorizontalVertical_7_) {
      TextureAtlasSprite[] atextureatlassprite = p_getConnectedTextureHorizontalVertical_0_.tileIcons;
      TextureAtlasSprite textureatlassprite = getConnectedTextureHorizontal(p_getConnectedTextureHorizontalVertical_0_, p_getConnectedTextureHorizontalVertical_1_, p_getConnectedTextureHorizontalVertical_2_, p_getConnectedTextureHorizontalVertical_3_, p_getConnectedTextureHorizontalVertical_4_, p_getConnectedTextureHorizontalVertical_5_, p_getConnectedTextureHorizontalVertical_6_, p_getConnectedTextureHorizontalVertical_7_);
      if (textureatlassprite != null && textureatlassprite != p_getConnectedTextureHorizontalVertical_6_ && textureatlassprite != atextureatlassprite[3]) {
         return textureatlassprite;
      } else {
         TextureAtlasSprite textureatlassprite1 = getConnectedTextureVertical(p_getConnectedTextureHorizontalVertical_0_, p_getConnectedTextureHorizontalVertical_1_, p_getConnectedTextureHorizontalVertical_2_, p_getConnectedTextureHorizontalVertical_3_, p_getConnectedTextureHorizontalVertical_4_, p_getConnectedTextureHorizontalVertical_5_, p_getConnectedTextureHorizontalVertical_6_, p_getConnectedTextureHorizontalVertical_7_);
         return textureatlassprite1 == atextureatlassprite[0] ? atextureatlassprite[4] : (textureatlassprite1 == atextureatlassprite[1] ? atextureatlassprite[5] : (textureatlassprite1 == atextureatlassprite[2] ? atextureatlassprite[6] : textureatlassprite1));
      }
   }

   // $FF: synthetic method
   private static jebac_vexiayab0wp48ilc2[][] propertyListToArray(List p_propertyListToArray_0_) {
      jebac_vexiayab0wp48ilc2[][] aconnectedproperties = new jebac_vexiayab0wp48ilc2[p_propertyListToArray_0_.size()][];

      for(int i = 0; i < p_propertyListToArray_0_.size(); ++i) {
         List list = (List)p_propertyListToArray_0_.get(i);
         if (list != null) {
            jebac_vexiayab0wp48ilc2[] aconnectedproperties1 = (jebac_vexiayab0wp48ilc2[])((jebac_vexiayab0wp48ilc2[])list.toArray(new jebac_vexiayab0wp48ilc2[list.size()]));
            aconnectedproperties[i] = aconnectedproperties1;
         }
      }

      return aconnectedproperties;
   }

   // $FF: synthetic method
   private static void addToTileList(jebac_vexiayab0wp48ilc2 p_addToTileList_0_, List p_addToTileList_1_) {
      if (p_addToTileList_0_.matchTileIcons != null) {
         for(int i = 0; i < p_addToTileList_0_.matchTileIcons.length; ++i) {
            TextureAtlasSprite textureatlassprite = p_addToTileList_0_.matchTileIcons[i];
            if (!(textureatlassprite instanceof TextureAtlasSprite)) {
               jebac_vexiakrwecfs16wve.warn("TextureAtlasSprite is not TextureAtlasSprite: " + textureatlassprite + ", name: " + textureatlassprite.getIconName());
            } else {
               int j = textureatlassprite.getIndexInMap();
               if (j < 0) {
                  jebac_vexiakrwecfs16wve.warn("Invalid tile ID: " + j + ", icon: " + textureatlassprite.getIconName());
               } else {
                  addToList(p_addToTileList_0_, p_addToTileList_1_, j);
               }
            }
         }
      }

   }

   // $FF: synthetic method
   private static TextureAtlasSprite getConnectedTextureRepeat(jebac_vexiayab0wp48ilc2 p_getConnectedTextureRepeat_0_, BlockPos p_getConnectedTextureRepeat_1_, int p_getConnectedTextureRepeat_2_) {
      if (p_getConnectedTextureRepeat_0_.tileIcons.length == 1) {
         return p_getConnectedTextureRepeat_0_.tileIcons[0];
      } else {
         int i = p_getConnectedTextureRepeat_1_.getX();
         int j = p_getConnectedTextureRepeat_1_.getY();
         int k = p_getConnectedTextureRepeat_1_.getZ();
         int l = 0;
         int i1 = 0;
         switch(p_getConnectedTextureRepeat_2_) {
         case 0:
         case 1:
            l = i;
            i1 = k;
            break;
         case 2:
            l = -i - 1;
            i1 = -j;
            break;
         case 3:
            l = i;
            i1 = -j;
            break;
         case 4:
            l = k;
            i1 = -j;
            break;
         case 5:
            l = -k - 1;
            i1 = -j;
         }

         l %= p_getConnectedTextureRepeat_0_.width;
         i1 %= p_getConnectedTextureRepeat_0_.height;
         if (l < 0) {
            l += p_getConnectedTextureRepeat_0_.width;
         }

         if (i1 < 0) {
            i1 += p_getConnectedTextureRepeat_0_.height;
         }

         int j1 = i1 * p_getConnectedTextureRepeat_0_.width + l;
         return p_getConnectedTextureRepeat_0_.tileIcons[j1];
      }
   }

   // $FF: synthetic method
   private static BakedQuad makeSpriteQuad(BakedQuad p_makeSpriteQuad_0_, TextureAtlasSprite p_makeSpriteQuad_1_) {
      int[] aint = (int[])p_makeSpriteQuad_0_.getVertexData().clone();
      TextureAtlasSprite textureatlassprite = p_makeSpriteQuad_0_.getSprite();

      for(int i = 0; i < 4; ++i) {
         fixVertex(aint, i, textureatlassprite, p_makeSpriteQuad_1_);
      }

      return new BakedQuad(aint, p_makeSpriteQuad_0_.getTintIndex(), p_makeSpriteQuad_0_.getFace(), p_makeSpriteQuad_1_);
   }

   // $FF: synthetic method
   private static TextureAtlasSprite getConnectedTextureVerticalHorizontal(jebac_vexiayab0wp48ilc2 p_getConnectedTextureVerticalHorizontal_0_, IBlockAccess p_getConnectedTextureVerticalHorizontal_1_, IBlockState p_getConnectedTextureVerticalHorizontal_2_, BlockPos p_getConnectedTextureVerticalHorizontal_3_, int p_getConnectedTextureVerticalHorizontal_4_, int p_getConnectedTextureVerticalHorizontal_5_, TextureAtlasSprite p_getConnectedTextureVerticalHorizontal_6_, int p_getConnectedTextureVerticalHorizontal_7_) {
      TextureAtlasSprite[] atextureatlassprite = p_getConnectedTextureVerticalHorizontal_0_.tileIcons;
      TextureAtlasSprite textureatlassprite = getConnectedTextureVertical(p_getConnectedTextureVerticalHorizontal_0_, p_getConnectedTextureVerticalHorizontal_1_, p_getConnectedTextureVerticalHorizontal_2_, p_getConnectedTextureVerticalHorizontal_3_, p_getConnectedTextureVerticalHorizontal_4_, p_getConnectedTextureVerticalHorizontal_5_, p_getConnectedTextureVerticalHorizontal_6_, p_getConnectedTextureVerticalHorizontal_7_);
      if (textureatlassprite != null && textureatlassprite != p_getConnectedTextureVerticalHorizontal_6_ && textureatlassprite != atextureatlassprite[3]) {
         return textureatlassprite;
      } else {
         TextureAtlasSprite textureatlassprite1 = getConnectedTextureHorizontal(p_getConnectedTextureVerticalHorizontal_0_, p_getConnectedTextureVerticalHorizontal_1_, p_getConnectedTextureVerticalHorizontal_2_, p_getConnectedTextureVerticalHorizontal_3_, p_getConnectedTextureVerticalHorizontal_4_, p_getConnectedTextureVerticalHorizontal_5_, p_getConnectedTextureVerticalHorizontal_6_, p_getConnectedTextureVerticalHorizontal_7_);
         return textureatlassprite1 == atextureatlassprite[0] ? atextureatlassprite[4] : (textureatlassprite1 == atextureatlassprite[1] ? atextureatlassprite[5] : (textureatlassprite1 == atextureatlassprite[2] ? atextureatlassprite[6] : textureatlassprite1));
      }
   }

   // $FF: synthetic method
   public static synchronized BakedQuad getConnectedTexture(IBlockAccess p_getConnectedTexture_0_, IBlockState p_getConnectedTexture_1_, BlockPos p_getConnectedTexture_2_, BakedQuad p_getConnectedTexture_3_, jebac_vexiai2kawx8j8o7a p_getConnectedTexture_4_) {
      TextureAtlasSprite textureatlassprite = p_getConnectedTexture_3_.getSprite();
      if (textureatlassprite == null) {
         return p_getConnectedTexture_3_;
      } else {
         Block block = p_getConnectedTexture_1_.getBlock();
         EnumFacing enumfacing = p_getConnectedTexture_3_.getFace();
         if (block instanceof BlockPane && textureatlassprite.getIconName().startsWith("minecraft:blocks/glass_pane_top")) {
            IBlockState iblockstate = p_getConnectedTexture_0_.getBlockState(p_getConnectedTexture_2_.offset(p_getConnectedTexture_3_.getFace()));
            if (iblockstate == p_getConnectedTexture_1_) {
               return getQuad(emptySprite, p_getConnectedTexture_3_);
            }
         }

         TextureAtlasSprite textureatlassprite1 = getConnectedTextureMultiPass(p_getConnectedTexture_0_, p_getConnectedTexture_1_, p_getConnectedTexture_2_, enumfacing, textureatlassprite, p_getConnectedTexture_4_);
         return textureatlassprite1 == textureatlassprite ? p_getConnectedTexture_3_ : getQuad(textureatlassprite1, p_getConnectedTexture_3_);
      }
   }

   // $FF: synthetic method
   private static BakedQuad getQuad(TextureAtlasSprite p_getQuad_0_, BakedQuad p_getQuad_3_) {
      if (spriteQuadMaps == null) {
         return p_getQuad_3_;
      } else {
         int i = p_getQuad_0_.getIndexInMap();
         if (i >= 0 && i < spriteQuadMaps.length) {
            Map map = spriteQuadMaps[i];
            if (map == null) {
               map = new IdentityHashMap(1);
               spriteQuadMaps[i] = (Map)map;
            }

            BakedQuad bakedquad = (BakedQuad)((Map)map).get(p_getQuad_3_);
            if (bakedquad == null) {
               bakedquad = makeSpriteQuad(p_getQuad_3_, p_getQuad_0_);
               ((Map)map).put(p_getQuad_3_, bakedquad);
            }

            return bakedquad;
         } else {
            return p_getQuad_3_;
         }
      }
   }

   static {
      AIR_DEFAULT_STATE = Blocks.air.getDefaultState();
      emptySprite = null;
   }

   // $FF: synthetic method
   private static String[] getDefaultCtmPaths() {
      List list = new ArrayList();
      String s = "mcpatcher/ctm/default/";
      if (jebac_vexiakrwecfs16wve.isFromDefaultResourcePack(new ResourceLocation("textures/blocks/glass.png"))) {
         list.add(s + "glass.properties");
         list.add(s + "glasspane.properties");
      }

      if (jebac_vexiakrwecfs16wve.isFromDefaultResourcePack(new ResourceLocation("textures/blocks/bookshelf.png"))) {
         list.add(s + "bookshelf.properties");
      }

      if (jebac_vexiakrwecfs16wve.isFromDefaultResourcePack(new ResourceLocation("textures/blocks/sandstone_normal.png"))) {
         list.add(s + "sandstone.properties");
      }

      String[] astring = new String[]{"white", "orange", "magenta", "light_blue", "yellow", "lime", "pink", "gray", "silver", "cyan", "purple", "blue", "brown", "green", "red", "black"};

      for(int i = 0; i < astring.length; ++i) {
         String s1 = astring[i];
         if (jebac_vexiakrwecfs16wve.isFromDefaultResourcePack(new ResourceLocation("textures/blocks/glass_" + s1 + ".png"))) {
            list.add(s + i + "_glass_" + s1 + "/glass_" + s1 + ".properties");
            list.add(s + i + "_glass_" + s1 + "/glass_pane_" + s1 + ".properties");
         }
      }

      return (String[])((String[])list.toArray(new String[0]));
   }

   // $FF: synthetic method
   private static int getWoodAxis(int p_getWoodAxis_1_) {
      int i = (p_getWoodAxis_1_ & 12) >> 2;
      switch(i) {
      case 1:
         return 2;
      case 2:
         return 1;
      default:
         return 0;
      }
   }

   // $FF: synthetic method
   private static void fixVertex(int[] p_fixVertex_0_, int p_fixVertex_1_, TextureAtlasSprite p_fixVertex_2_, TextureAtlasSprite p_fixVertex_3_) {
      int i = p_fixVertex_0_.length / 4;
      int j = i * p_fixVertex_1_;
      float f = Float.intBitsToFloat(p_fixVertex_0_[j + 4]);
      float f1 = Float.intBitsToFloat(p_fixVertex_0_[j + 4 + 1]);
      double d0 = p_fixVertex_2_.getSpriteU16(f);
      double d1 = p_fixVertex_2_.getSpriteV16(f1);
      p_fixVertex_0_[j + 4] = Float.floatToRawIntBits(p_fixVertex_3_.getInterpolatedU(d0));
      p_fixVertex_0_[j + 4 + 1] = Float.floatToRawIntBits(p_fixVertex_3_.getInterpolatedV(d1));
   }

   // $FF: synthetic method
   private static TextureAtlasSprite getConnectedTextureVertical(jebac_vexiayab0wp48ilc2 p_getConnectedTextureVertical_0_, IBlockAccess p_getConnectedTextureVertical_1_, IBlockState p_getConnectedTextureVertical_2_, BlockPos p_getConnectedTextureVertical_3_, int p_getConnectedTextureVertical_4_, int p_getConnectedTextureVertical_5_, TextureAtlasSprite p_getConnectedTextureVertical_6_, int p_getConnectedTextureVertical_7_) {
      boolean flag = false;
      boolean flag1 = false;
      switch(p_getConnectedTextureVertical_4_) {
      case 0:
         if (p_getConnectedTextureVertical_5_ == 1 || p_getConnectedTextureVertical_5_ == 0) {
            return null;
         }

         flag = isNeighbour(p_getConnectedTextureVertical_0_, p_getConnectedTextureVertical_1_, p_getConnectedTextureVertical_2_, p_getConnectedTextureVertical_3_.down(), p_getConnectedTextureVertical_5_, p_getConnectedTextureVertical_6_, p_getConnectedTextureVertical_7_);
         flag1 = isNeighbour(p_getConnectedTextureVertical_0_, p_getConnectedTextureVertical_1_, p_getConnectedTextureVertical_2_, p_getConnectedTextureVertical_3_.up(), p_getConnectedTextureVertical_5_, p_getConnectedTextureVertical_6_, p_getConnectedTextureVertical_7_);
         break;
      case 1:
         if (p_getConnectedTextureVertical_5_ == 3 || p_getConnectedTextureVertical_5_ == 2) {
            return null;
         }

         flag = isNeighbour(p_getConnectedTextureVertical_0_, p_getConnectedTextureVertical_1_, p_getConnectedTextureVertical_2_, p_getConnectedTextureVertical_3_.south(), p_getConnectedTextureVertical_5_, p_getConnectedTextureVertical_6_, p_getConnectedTextureVertical_7_);
         flag1 = isNeighbour(p_getConnectedTextureVertical_0_, p_getConnectedTextureVertical_1_, p_getConnectedTextureVertical_2_, p_getConnectedTextureVertical_3_.north(), p_getConnectedTextureVertical_5_, p_getConnectedTextureVertical_6_, p_getConnectedTextureVertical_7_);
         break;
      case 2:
         if (p_getConnectedTextureVertical_5_ == 5 || p_getConnectedTextureVertical_5_ == 4) {
            return null;
         }

         flag = isNeighbour(p_getConnectedTextureVertical_0_, p_getConnectedTextureVertical_1_, p_getConnectedTextureVertical_2_, p_getConnectedTextureVertical_3_.west(), p_getConnectedTextureVertical_5_, p_getConnectedTextureVertical_6_, p_getConnectedTextureVertical_7_);
         flag1 = isNeighbour(p_getConnectedTextureVertical_0_, p_getConnectedTextureVertical_1_, p_getConnectedTextureVertical_2_, p_getConnectedTextureVertical_3_.east(), p_getConnectedTextureVertical_5_, p_getConnectedTextureVertical_6_, p_getConnectedTextureVertical_7_);
      }

      int i = true;
      byte i;
      if (flag) {
         if (flag1) {
            i = 1;
         } else {
            i = 2;
         }
      } else if (flag1) {
         i = 0;
      } else {
         i = 3;
      }

      return p_getConnectedTextureVertical_0_.tileIcons[i];
   }

   // $FF: synthetic method
   private static void addToBlockList(jebac_vexiayab0wp48ilc2 p_addToBlockList_0_, List p_addToBlockList_1_) {
      if (p_addToBlockList_0_.matchBlocks != null) {
         for(int i = 0; i < p_addToBlockList_0_.matchBlocks.length; ++i) {
            int j = p_addToBlockList_0_.matchBlocks[i].getBlockId();
            if (j < 0) {
               jebac_vexiakrwecfs16wve.warn("Invalid block ID: " + j);
            } else {
               addToList(p_addToBlockList_0_, p_addToBlockList_1_, j);
            }
         }
      }

   }

   // $FF: synthetic method
   private static boolean isNeighbour(jebac_vexiayab0wp48ilc2 p_isNeighbour_0_, IBlockAccess p_isNeighbour_1_, IBlockState p_isNeighbour_2_, BlockPos p_isNeighbour_3_, int p_isNeighbour_4_, TextureAtlasSprite p_isNeighbour_5_, int p_isNeighbour_6_) {
      IBlockState iblockstate = p_isNeighbour_1_.getBlockState(p_isNeighbour_3_);
      if (p_isNeighbour_2_ == iblockstate) {
         return true;
      } else if (p_isNeighbour_0_.connect == 2) {
         if (iblockstate == null) {
            return false;
         } else if (iblockstate == AIR_DEFAULT_STATE) {
            return false;
         } else {
            TextureAtlasSprite textureatlassprite = getNeighbourIcon(p_isNeighbour_1_, p_isNeighbour_3_, iblockstate, p_isNeighbour_4_);
            return textureatlassprite == p_isNeighbour_5_;
         }
      } else {
         return p_isNeighbour_0_.connect == 3 && iblockstate != null && iblockstate != AIR_DEFAULT_STATE && iblockstate.getBlock().getMaterial() == p_isNeighbour_2_.getBlock().getMaterial();
      }
   }

   // $FF: synthetic method
   private static TextureAtlasSprite getConnectedTextureTop(jebac_vexiayab0wp48ilc2 p_getConnectedTextureTop_0_, IBlockAccess p_getConnectedTextureTop_1_, IBlockState p_getConnectedTextureTop_2_, BlockPos p_getConnectedTextureTop_3_, int p_getConnectedTextureTop_4_, int p_getConnectedTextureTop_5_, TextureAtlasSprite p_getConnectedTextureTop_6_, int p_getConnectedTextureTop_7_) {
      boolean flag = false;
      switch(p_getConnectedTextureTop_4_) {
      case 0:
         if (p_getConnectedTextureTop_5_ == 1 || p_getConnectedTextureTop_5_ == 0) {
            return null;
         }

         flag = isNeighbour(p_getConnectedTextureTop_0_, p_getConnectedTextureTop_1_, p_getConnectedTextureTop_2_, p_getConnectedTextureTop_3_.up(), p_getConnectedTextureTop_5_, p_getConnectedTextureTop_6_, p_getConnectedTextureTop_7_);
         break;
      case 1:
         if (p_getConnectedTextureTop_5_ != 3 && p_getConnectedTextureTop_5_ != 2) {
            flag = isNeighbour(p_getConnectedTextureTop_0_, p_getConnectedTextureTop_1_, p_getConnectedTextureTop_2_, p_getConnectedTextureTop_3_.south(), p_getConnectedTextureTop_5_, p_getConnectedTextureTop_6_, p_getConnectedTextureTop_7_);
            break;
         }

         return null;
      case 2:
         if (p_getConnectedTextureTop_5_ == 5 || p_getConnectedTextureTop_5_ == 4) {
            return null;
         }

         flag = isNeighbour(p_getConnectedTextureTop_0_, p_getConnectedTextureTop_1_, p_getConnectedTextureTop_2_, p_getConnectedTextureTop_3_.east(), p_getConnectedTextureTop_5_, p_getConnectedTextureTop_6_, p_getConnectedTextureTop_7_);
      }

      if (flag) {
         return p_getConnectedTextureTop_0_.tileIcons[0];
      } else {
         return null;
      }
   }

   // $FF: synthetic method
   private static TextureAtlasSprite getConnectedTextureMultiPass(IBlockAccess p_getConnectedTextureMultiPass_0_, IBlockState p_getConnectedTextureMultiPass_1_, BlockPos p_getConnectedTextureMultiPass_2_, EnumFacing p_getConnectedTextureMultiPass_3_, TextureAtlasSprite p_getConnectedTextureMultiPass_4_, jebac_vexiai2kawx8j8o7a p_getConnectedTextureMultiPass_5_) {
      TextureAtlasSprite textureatlassprite = getConnectedTextureSingle(p_getConnectedTextureMultiPass_0_, p_getConnectedTextureMultiPass_1_, p_getConnectedTextureMultiPass_2_, p_getConnectedTextureMultiPass_3_, p_getConnectedTextureMultiPass_4_, true, p_getConnectedTextureMultiPass_5_);
      if (!multipass) {
         return textureatlassprite;
      } else if (textureatlassprite == p_getConnectedTextureMultiPass_4_) {
         return textureatlassprite;
      } else {
         TextureAtlasSprite textureatlassprite1 = textureatlassprite;

         for(int i = 0; i < 3; ++i) {
            TextureAtlasSprite textureatlassprite2 = getConnectedTextureSingle(p_getConnectedTextureMultiPass_0_, p_getConnectedTextureMultiPass_1_, p_getConnectedTextureMultiPass_2_, p_getConnectedTextureMultiPass_3_, textureatlassprite1, false, p_getConnectedTextureMultiPass_5_);
            if (textureatlassprite2 == textureatlassprite1) {
               break;
            }

            textureatlassprite1 = textureatlassprite2;
         }

         return textureatlassprite1;
      }
   }

   // $FF: synthetic method
   private static TextureAtlasSprite getConnectedTextureRandom(jebac_vexiayab0wp48ilc2 p_getConnectedTextureRandom_0_, BlockPos p_getConnectedTextureRandom_1_, int p_getConnectedTextureRandom_2_) {
      if (p_getConnectedTextureRandom_0_.tileIcons.length == 1) {
         return p_getConnectedTextureRandom_0_.tileIcons[0];
      } else {
         int i = p_getConnectedTextureRandom_2_ / p_getConnectedTextureRandom_0_.symmetry * p_getConnectedTextureRandom_0_.symmetry;
         int j = jebac_vexiakrwecfs16wve.getRandom(p_getConnectedTextureRandom_1_, i) & Integer.MAX_VALUE;
         int k = 0;
         if (p_getConnectedTextureRandom_0_.weights == null) {
            k = j % p_getConnectedTextureRandom_0_.tileIcons.length;
         } else {
            int l = j % p_getConnectedTextureRandom_0_.sumAllWeights;
            int[] aint = p_getConnectedTextureRandom_0_.sumWeights;

            for(int i1 = 0; i1 < aint.length; ++i1) {
               if (l < aint[i1]) {
                  k = i1;
                  break;
               }
            }
         }

         return p_getConnectedTextureRandom_0_.tileIcons[k];
      }
   }

   // $FF: synthetic method
   public static int getSide(EnumFacing p_getSide_0_) {
      if (p_getSide_0_ == null) {
         return -1;
      } else {
         switch(p_getSide_0_) {
         case DOWN:
            return 0;
         case UP:
            return 1;
         case EAST:
            return 5;
         case WEST:
            return 4;
         case NORTH:
            return 2;
         case SOUTH:
            return 3;
         default:
            return -1;
         }
      }
   }

   // $FF: synthetic method
   private static TextureAtlasSprite getNeighbourIcon(IBlockAccess p_getNeighbourIcon_0_, BlockPos p_getNeighbourIcon_1_, IBlockState p_getNeighbourIcon_2_, int p_getNeighbourIcon_3_) {
      p_getNeighbourIcon_2_ = p_getNeighbourIcon_2_.getBlock().getActualState(p_getNeighbourIcon_2_, p_getNeighbourIcon_0_, p_getNeighbourIcon_1_);
      IBakedModel ibakedmodel = Minecraft.getMinecraft().getBlockRendererDispatcher().getBlockModelShapes().getModelForState(p_getNeighbourIcon_2_);
      if (ibakedmodel == null) {
         return null;
      } else {
         EnumFacing enumfacing = getFacing(p_getNeighbourIcon_3_);
         List list = ibakedmodel.getFaceQuads(enumfacing);
         if (list.size() > 0) {
            BakedQuad bakedquad1 = (BakedQuad)list.get(0);
            return bakedquad1.getSprite();
         } else {
            List list1 = ibakedmodel.getGeneralQuads();
            Iterator var8 = list1.iterator();

            BakedQuad bakedquad;
            do {
               if (!var8.hasNext()) {
                  return null;
               }

               Object o = var8.next();
               bakedquad = (BakedQuad)o;
            } while(bakedquad.getFace() != enumfacing);

            return bakedquad.getSprite();
         }
      }
   }

   // $FF: synthetic method
   private static boolean detectMultipass() {
      List list = new ArrayList();
      jebac_vexiayab0wp48ilc2[][] var1 = tileProperties;
      int var2 = var1.length;

      int var3;
      jebac_vexiayab0wp48ilc2[] aconnectedproperties2;
      for(var3 = 0; var3 < var2; ++var3) {
         aconnectedproperties2 = var1[var3];
         if (aconnectedproperties2 != null) {
            list.addAll(Arrays.asList(aconnectedproperties2));
         }
      }

      var1 = blockProperties;
      var2 = var1.length;

      for(var3 = 0; var3 < var2; ++var3) {
         aconnectedproperties2 = var1[var3];
         if (aconnectedproperties2 != null) {
            list.addAll(Arrays.asList(aconnectedproperties2));
         }
      }

      jebac_vexiayab0wp48ilc2[] aconnectedproperties1 = (jebac_vexiayab0wp48ilc2[])((jebac_vexiayab0wp48ilc2[])list.toArray(new jebac_vexiayab0wp48ilc2[list.size()]));
      Set set1 = new HashSet();
      Set set = new HashSet();
      aconnectedproperties2 = aconnectedproperties1;
      int var5 = aconnectedproperties1.length;

      for(int var6 = 0; var6 < var5; ++var6) {
         jebac_vexiayab0wp48ilc2 connectedproperties = aconnectedproperties2[var6];
         if (connectedproperties.matchTileIcons != null) {
            set1.addAll(Arrays.asList(connectedproperties.matchTileIcons));
         }

         if (connectedproperties.tileIcons != null) {
            set.addAll(Arrays.asList(connectedproperties.tileIcons));
         }
      }

      set1.retainAll(set);
      return !set1.isEmpty();
   }

   // $FF: synthetic method
   private static TextureAtlasSprite getConnectedTextureFixed(jebac_vexiayab0wp48ilc2 p_getConnectedTextureFixed_0_) {
      return p_getConnectedTextureFixed_0_.tileIcons[0];
   }

   // $FF: synthetic method
   public static void updateIcons(TextureMap p_updateIcons_0_, IResourcePack p_updateIcons_1_) {
      String[] astring = jebac_vexiavx2mofavvrsa.collectFiles(p_updateIcons_1_, "mcpatcher/ctm/", ".properties", getDefaultCtmPaths());
      Arrays.sort(astring);
      List list = makePropertyList(tileProperties);
      List list1 = makePropertyList(blockProperties);

      for(int i = 0; i < astring.length; ++i) {
         String s = astring[i];
         jebac_vexiakrwecfs16wve.dbg("ConnectedTextures: " + s);

         try {
            ResourceLocation resourcelocation = new ResourceLocation(s);
            InputStream inputstream = p_updateIcons_1_.getInputStream(resourcelocation);
            if (inputstream == null) {
               jebac_vexiakrwecfs16wve.warn("ConnectedTextures file not found: " + s);
            } else {
               Properties properties = new Properties();
               properties.load(inputstream);
               jebac_vexiayab0wp48ilc2 connectedproperties = new jebac_vexiayab0wp48ilc2(properties, s);
               if (connectedproperties.isValid(s)) {
                  connectedproperties.updateIcons(p_updateIcons_0_);
                  addToTileList(connectedproperties, list);
                  addToBlockList(connectedproperties, list1);
               }
            }
         } catch (FileNotFoundException var11) {
            jebac_vexiakrwecfs16wve.warn("ConnectedTextures file not found: " + s);
         } catch (Exception var12) {
            var12.printStackTrace();
         }
      }

      blockProperties = propertyListToArray(list1);
      tileProperties = propertyListToArray(list);
      multipass = detectMultipass();
      jebac_vexiakrwecfs16wve.dbg("Multipass connected textures: " + multipass);
   }

   // $FF: synthetic method
   public static void updateIcons(TextureMap p_updateIcons_0_) {
      blockProperties = (jebac_vexiayab0wp48ilc2[][])null;
      tileProperties = (jebac_vexiayab0wp48ilc2[][])null;
      spriteQuadMaps = null;
      if (jebac_vexiakrwecfs16wve.isConnectedTextures()) {
         IResourcePack[] airesourcepack = jebac_vexiakrwecfs16wve.getResourcePacks();

         for(int i = airesourcepack.length - 1; i >= 0; --i) {
            IResourcePack iresourcepack = airesourcepack[i];
            updateIcons(p_updateIcons_0_, iresourcepack);
         }

         updateIcons(p_updateIcons_0_, jebac_vexiakrwecfs16wve.getDefaultResourcePack());
         ResourceLocation resourcelocation = new ResourceLocation("mcpatcher/ctm/default/empty");
         emptySprite = p_updateIcons_0_.registerSprite(resourcelocation);
         spriteQuadMaps = new Map[p_updateIcons_0_.getCountRegisteredSprites() + 1];
         if (blockProperties.length <= 0) {
            blockProperties = (jebac_vexiayab0wp48ilc2[][])null;
         }

         if (tileProperties.length <= 0) {
            tileProperties = (jebac_vexiayab0wp48ilc2[][])null;
         }
      }

   }

   // $FF: synthetic method
   private static void addToList(jebac_vexiayab0wp48ilc2 p_addToList_0_, List p_addToList_1_, int p_addToList_2_) {
      while(p_addToList_2_ >= p_addToList_1_.size()) {
         p_addToList_1_.add((Object)null);
      }

      List list = (List)p_addToList_1_.get(p_addToList_2_);
      if (list == null) {
         list = new ArrayList();
         p_addToList_1_.set(p_addToList_2_, list);
      }

      ((List)list).add(p_addToList_0_);
   }
}
