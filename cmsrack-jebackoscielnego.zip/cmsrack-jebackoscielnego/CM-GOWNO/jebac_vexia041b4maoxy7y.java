import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.util.Iterator;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.settings.GameSettings;
import org.lwjgl.Sys;

public class jebac_vexia041b4maoxy7y extends jebac_vexiakl614w3uw0xg {
   // $FF: synthetic field
   private jebac_vexiawid5dsmfcra8 shaderList;
   // $FF: synthetic field
   public static final int EnumOS_WINDOWS = 1;
   // $FF: synthetic field
   private boolean saved = false;
   // $FF: synthetic field
   public static final int EnumOS_LINUX = 4;
   // $FF: synthetic field
   protected jebac_vexiakl614w3uw0xg parentGui;
   // $FF: synthetic field
   private static String[] HAND_DEPTH_NAMES = new String[]{"0.5x", "1x", "2x"};
   // $FF: synthetic field
   public static final int EnumOS_SOLARIS = 3;
   // $FF: synthetic field
   public static final int EnumOS_OSX = 2;
   // $FF: synthetic field
   public static final int EnumOS_UNKNOWN = 0;
   // $FF: synthetic field
   protected String screenTitle = "Shaders";
   // $FF: synthetic field
   private static String[] QUALITY_MULTIPLIER_NAMES = new String[]{"0.5x", "0.7x", "1x", "1.5x", "2x"};
   // $FF: synthetic field
   private static float[] HAND_DEPTH_VALUES = new float[]{0.0625F, 0.125F, 0.25F};
   // $FF: synthetic field
   private static float[] QUALITY_MULTIPLIERS = new float[]{0.5F, 0.70710677F, 1.0F, 1.4142135F, 2.0F};
   // $FF: synthetic field
   private int updateTimer = -1;

   // $FF: synthetic method
   public jebac_vexia041b4maoxy7y(jebac_vexiakl614w3uw0xg par1GuiScreen, GameSettings par2GameSettings) {
      this.parentGui = par1GuiScreen;
   }

   // $FF: synthetic method
   public static int getOSType() {
      String s = System.getProperty("os.name").toLowerCase();
      return s.contains("win") ? 1 : (s.contains("mac") ? 2 : (s.contains("solaris") ? 3 : (s.contains("sunos") ? 3 : (s.contains("linux") ? 4 : (s.contains("unix") ? 4 : 0)))));
   }

   // $FF: synthetic method
   public static String toStringQuality(float val) {
      return toStringValue(val, QUALITY_MULTIPLIERS, QUALITY_MULTIPLIER_NAMES);
   }

   // $FF: synthetic method
   public void drawCenteredString(String text, int x, int y, int color) {
      this.drawCenteredString(this.fontRendererObj, text, x, y, color);
   }

   // $FF: synthetic method
   public Minecraft getMc() {
      return this.mc;
   }

   // $FF: synthetic method
   public void updateScreen() {
      super.updateScreen();
      --this.updateTimer;
   }

   // $FF: synthetic method
   public void initGui() {
      this.screenTitle = I18n.format("of.options.shadersTitle");
      if (jebac_vexiaflhnh80r1906.shadersConfig == null) {
         jebac_vexiaflhnh80r1906.loadConfig();
      }

      int i = 120;
      int j = 20;
      int k = this.width - i - 10;
      int l = 30;
      int i1 = 20;
      int j1 = this.width - i - 20;
      this.shaderList = new jebac_vexiawid5dsmfcra8(this, j1, this.height, l, this.height - 50, 16);
      this.shaderList.registerScrollButtons(7, 8);
      this.buttonList.add(new jebac_vexiadqmms1d1glhl(jebac_vexiavrks9g79h9kq.ANTIALIASING, k, 0 * i1 + l, i, j));
      this.buttonList.add(new jebac_vexiadqmms1d1glhl(jebac_vexiavrks9g79h9kq.NORMAL_MAP, k, 1 * i1 + l, i, j));
      this.buttonList.add(new jebac_vexiadqmms1d1glhl(jebac_vexiavrks9g79h9kq.SPECULAR_MAP, k, 2 * i1 + l, i, j));
      this.buttonList.add(new jebac_vexiadqmms1d1glhl(jebac_vexiavrks9g79h9kq.RENDER_RES_MUL, k, 3 * i1 + l, i, j));
      this.buttonList.add(new jebac_vexiadqmms1d1glhl(jebac_vexiavrks9g79h9kq.SHADOW_RES_MUL, k, 4 * i1 + l, i, j));
      this.buttonList.add(new jebac_vexiadqmms1d1glhl(jebac_vexiavrks9g79h9kq.HAND_DEPTH_MUL, k, 5 * i1 + l, i, j));
      this.buttonList.add(new jebac_vexiadqmms1d1glhl(jebac_vexiavrks9g79h9kq.OLD_HAND_LIGHT, k, 6 * i1 + l, i, j));
      this.buttonList.add(new jebac_vexiadqmms1d1glhl(jebac_vexiavrks9g79h9kq.OLD_LIGHTING, k, 7 * i1 + l, i, j));
      int k1 = Math.min(150, j1 / 2 - 10);
      this.buttonList.add(new jebac_vexia4oibzo50ubf0(201, j1 / 4 - k1 / 2, this.height - 25, k1, j, jebac_vexia7gzdvsc1kfyf.get("of.options.shaders.shadersFolder")));
      this.buttonList.add(new jebac_vexia4oibzo50ubf0(202, j1 / 4 * 3 - k1 / 2, this.height - 25, k1, j, I18n.format("gui.done")));
      this.buttonList.add(new jebac_vexia4oibzo50ubf0(203, k, this.height - 25, i, j, jebac_vexia7gzdvsc1kfyf.get("of.options.shaders.shaderOptions")));
      this.updateButtons();
   }

   // $FF: synthetic method
   public static String toStringAa(int value) {
      return value == 2 ? "FXAA 2x" : (value == 4 ? "FXAA 4x" : jebac_vexia7gzdvsc1kfyf.getOff());
   }

   // $FF: synthetic method
   public void updateButtons() {
      boolean flag = jebac_vexiakrwecfs16wve.isShaders();
      Iterator var2 = this.buttonList.iterator();

      while(var2.hasNext()) {
         jebac_vexia4oibzo50ubf0 guibutton = (jebac_vexia4oibzo50ubf0)var2.next();
         if (guibutton.id != 201 && guibutton.id != 202 && guibutton.id != jebac_vexiavrks9g79h9kq.ANTIALIASING.ordinal()) {
            guibutton.enabled = flag;
         }
      }

   }

   // $FF: synthetic method
   public static String toStringHandDepth(float val) {
      return toStringValue(val, HAND_DEPTH_VALUES, HAND_DEPTH_NAMES);
   }

   // $FF: synthetic method
   public static String toStringValue(float val, float[] values, String[] names) {
      int i = getValueIndex(val, values);
      return names[i];
   }

   // $FF: synthetic method
   protected void actionPerformed(jebac_vexia4oibzo50ubf0 button) {
      if (button.enabled) {
         if (button instanceof jebac_vexiadqmms1d1glhl) {
            jebac_vexiadqmms1d1glhl guibuttonenumshaderoption = (jebac_vexiadqmms1d1glhl)button;
            switch(guibuttonenumshaderoption.getEnumShaderOption()) {
            case ANTIALIASING:
               jebac_vexiaflhnh80r1906.nextAntialiasingLevel();
               jebac_vexiaflhnh80r1906.uninit();
               break;
            case NORMAL_MAP:
               jebac_vexiaflhnh80r1906.configNormalMap = !jebac_vexiaflhnh80r1906.configNormalMap;
               this.mc.scheduleResourcesRefresh();
               break;
            case SPECULAR_MAP:
               jebac_vexiaflhnh80r1906.configSpecularMap = !jebac_vexiaflhnh80r1906.configSpecularMap;
               this.mc.scheduleResourcesRefresh();
               break;
            case RENDER_RES_MUL:
               float f2 = jebac_vexiaflhnh80r1906.configRenderResMul;
               float[] afloat2 = QUALITY_MULTIPLIERS;
               int k = getValueIndex(f2, afloat2);
               if (isShiftKeyDown()) {
                  --k;
                  if (k < 0) {
                     k = afloat2.length - 1;
                  }
               } else {
                  ++k;
                  if (k >= afloat2.length) {
                     k = 0;
                  }
               }

               jebac_vexiaflhnh80r1906.configRenderResMul = afloat2[k];
               jebac_vexiaflhnh80r1906.scheduleResize();
               break;
            case SHADOW_RES_MUL:
               float f1 = jebac_vexiaflhnh80r1906.configShadowResMul;
               float[] afloat1 = QUALITY_MULTIPLIERS;
               String[] astring1 = QUALITY_MULTIPLIER_NAMES;
               int j = getValueIndex(f1, afloat1);
               if (isShiftKeyDown()) {
                  --j;
                  if (j < 0) {
                     j = afloat1.length - 1;
                  }
               } else {
                  ++j;
                  if (j >= afloat1.length) {
                     j = 0;
                  }
               }

               jebac_vexiaflhnh80r1906.configShadowResMul = afloat1[j];
               jebac_vexiaflhnh80r1906.scheduleResizeShadow();
               break;
            case HAND_DEPTH_MUL:
               float f = jebac_vexiaflhnh80r1906.configHandDepthMul;
               float[] afloat = HAND_DEPTH_VALUES;
               int i = getValueIndex(f, afloat);
               if (isShiftKeyDown()) {
                  --i;
                  if (i < 0) {
                     i = afloat.length - 1;
                  }
               } else {
                  ++i;
                  if (i >= afloat.length) {
                     i = 0;
                  }
               }

               jebac_vexiaflhnh80r1906.configHandDepthMul = afloat[i];
               break;
            case CLOUD_SHADOW:
               jebac_vexiaflhnh80r1906.configCloudShadow = !jebac_vexiaflhnh80r1906.configCloudShadow;
               break;
            case OLD_HAND_LIGHT:
               jebac_vexiaflhnh80r1906.configOldHandLight.nextValue();
               break;
            case OLD_LIGHTING:
               jebac_vexiaflhnh80r1906.configOldLighting.nextValue();
               jebac_vexiaflhnh80r1906.updateBlockLightLevel();
               this.mc.scheduleResourcesRefresh();
               break;
            case TWEAK_BLOCK_DAMAGE:
               jebac_vexiaflhnh80r1906.configTweakBlockDamage = !jebac_vexiaflhnh80r1906.configTweakBlockDamage;
               break;
            case TEX_MIN_FIL_B:
               jebac_vexiaflhnh80r1906.configTexMinFilB = (jebac_vexiaflhnh80r1906.configTexMinFilB + 1) % 3;
               jebac_vexiaflhnh80r1906.configTexMinFilN = jebac_vexiaflhnh80r1906.configTexMinFilS = jebac_vexiaflhnh80r1906.configTexMinFilB;
               button.displayString = "Tex Min: " + jebac_vexiaflhnh80r1906.texMinFilDesc[jebac_vexiaflhnh80r1906.configTexMinFilB];
               jebac_vexia7sfwuu82ucnu.updateTextureMinMagFilter();
               break;
            case TEX_MAG_FIL_N:
               jebac_vexiaflhnh80r1906.configTexMagFilN = (jebac_vexiaflhnh80r1906.configTexMagFilN + 1) % 2;
               button.displayString = "Tex_n Mag: " + jebac_vexiaflhnh80r1906.texMagFilDesc[jebac_vexiaflhnh80r1906.configTexMagFilN];
               jebac_vexia7sfwuu82ucnu.updateTextureMinMagFilter();
               break;
            case TEX_MAG_FIL_S:
               jebac_vexiaflhnh80r1906.configTexMagFilS = (jebac_vexiaflhnh80r1906.configTexMagFilS + 1) % 2;
               button.displayString = "Tex_s Mag: " + jebac_vexiaflhnh80r1906.texMagFilDesc[jebac_vexiaflhnh80r1906.configTexMagFilS];
               jebac_vexia7sfwuu82ucnu.updateTextureMinMagFilter();
               break;
            case SHADOW_CLIP_FRUSTRUM:
               jebac_vexiaflhnh80r1906.configShadowClipFrustrum = !jebac_vexiaflhnh80r1906.configShadowClipFrustrum;
               button.displayString = "ShadowClipFrustrum: " + toStringOnOff(jebac_vexiaflhnh80r1906.configShadowClipFrustrum);
               jebac_vexia7sfwuu82ucnu.updateTextureMinMagFilter();
            }

            guibuttonenumshaderoption.updateButtonText();
         } else {
            switch(button.id) {
            case 201:
               switch(getOSType()) {
               case 1:
                  String s = String.format("cmd.exe /C start \"Open file\" \"%s\"", jebac_vexiaflhnh80r1906.shaderpacksdir.getAbsolutePath());

                  try {
                     Runtime.getRuntime().exec(s);
                     return;
                  } catch (IOException var15) {
                     var15.printStackTrace();
                     break;
                  }
               case 2:
                  try {
                     Runtime.getRuntime().exec(new String[]{"/usr/bin/open", jebac_vexiaflhnh80r1906.shaderpacksdir.getAbsolutePath()});
                     return;
                  } catch (IOException var14) {
                     var14.printStackTrace();
                  }
               }

               boolean flag = false;

               try {
                  Class oclass = Class.forName("java.awt.Desktop");
                  Object object = oclass.getMethod("getDesktop").invoke((Object)null);
                  oclass.getMethod("browse", URI.class).invoke(object, (new File(this.mc.mcDataDir, jebac_vexiaflhnh80r1906.shaderpacksdirname)).toURI());
               } catch (Throwable var13) {
                  var13.printStackTrace();
                  flag = true;
               }

               if (flag) {
                  jebac_vexiakrwecfs16wve.dbg("Opening via system class!");
                  Sys.openURL("file://" + jebac_vexiaflhnh80r1906.shaderpacksdir.getAbsolutePath());
               }
               break;
            case 202:
               new File(jebac_vexiaflhnh80r1906.shadersdir, "current.cfg");
               jebac_vexiaflhnh80r1906.storeConfig();
               this.saved = true;
               this.mc.displayGuiScreen(this.parentGui);
               break;
            case 203:
               jebac_vexia2de4v6mq5qwa guishaderoptions = new jebac_vexia2de4v6mq5qwa(this, jebac_vexiakrwecfs16wve.getGameSettings());
               jebac_vexiakrwecfs16wve.getMinecraft().displayGuiScreen(guishaderoptions);
               break;
            default:
               this.shaderList.actionPerformed(button);
            }
         }
      }

   }

   // $FF: synthetic method
   public static String toStringOnOff(boolean value) {
      String s = jebac_vexia7gzdvsc1kfyf.getOn();
      String s1 = jebac_vexia7gzdvsc1kfyf.getOff();
      return value ? s : s1;
   }

   // $FF: synthetic method
   public void onGuiClosed() {
      super.onGuiClosed();
      if (!this.saved) {
         jebac_vexiaflhnh80r1906.storeConfig();
      }

   }

   // $FF: synthetic method
   public void drawScreen(int mouseX, int mouseY, float partialTicks) {
      this.drawDefaultBackground();
      this.shaderList.drawScreen(mouseX, mouseY, partialTicks);
      if (this.updateTimer <= 0) {
         this.shaderList.updateList();
         this.updateTimer += 20;
      }

      this.drawCenteredString(this.fontRendererObj, this.screenTitle + " ", this.width / 2, 15, 16777215);
      String s = "OpenGL: " + jebac_vexiaflhnh80r1906.glVersionString + ", " + jebac_vexiaflhnh80r1906.glVendorString + ", " + jebac_vexiaflhnh80r1906.glRendererString;
      int i = this.fontRendererObj.getStringWidth(s);
      if (i < this.width - 5) {
         this.drawCenteredString(this.fontRendererObj, s, this.width / 2, this.height - 40, 8421504);
      } else {
         this.drawString(this.fontRendererObj, s, 5, this.height - 40, 8421504);
      }

      super.drawScreen(mouseX, mouseY, partialTicks);
   }

   // $FF: synthetic method
   public static int getValueIndex(float val, float[] values) {
      for(int i = 0; i < values.length; ++i) {
         float f = values[i];
         if (f >= val) {
            return i;
         }
      }

      return values.length - 1;
   }

   // $FF: synthetic method
   public void handleMouseInput() throws IOException {
      super.handleMouseInput();
      this.shaderList.handleMouseInput();
   }
}
