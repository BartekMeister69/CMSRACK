import java.util.Date;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.I18n;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.world.storage.SaveFormatComparator;
import org.apache.commons.lang3.StringUtils;

class jebac_vexiayn9aahmsh9n8 extends jebac_vexiado18oeh2l9bq {
   final jebac_vexia9ykc8q9mn07o this$0;

   // $FF: synthetic method
   protected void drawSlot(int entryID, int p_180791_2_, int p_180791_3_, int p_180791_4_, int mouseXIn, int mouseYIn) {
      SaveFormatComparator saveformatcomparator = (SaveFormatComparator)jebac_vexia9ykc8q9mn07o.access$000(this.this$0).get(entryID);
      String s = saveformatcomparator.getDisplayName();
      if (StringUtils.isEmpty(s)) {
         s = jebac_vexia9ykc8q9mn07o.access$600(this.this$0) + " " + (entryID + 1);
      }

      String s1 = saveformatcomparator.getFileName();
      s1 = s1 + " (" + jebac_vexia9ykc8q9mn07o.access$700(this.this$0).format(new Date(saveformatcomparator.getLastTimePlayed()));
      s1 = s1 + ")";
      String s2 = "";
      if (saveformatcomparator.requiresConversion()) {
         s2 = jebac_vexia9ykc8q9mn07o.access$800(this.this$0) + " " + s2;
      } else {
         s2 = jebac_vexia9ykc8q9mn07o.access$900(this.this$0)[saveformatcomparator.getEnumGameType().getID()];
         if (saveformatcomparator.isHardcoreModeEnabled()) {
            s2 = EnumChatFormatting.DARK_RED + I18n.format("gameMode.hardcore") + EnumChatFormatting.RESET;
         }

         if (saveformatcomparator.getCheatsEnabled()) {
            s2 = s2 + ", " + I18n.format("selectWorld.cheats");
         }
      }

      this.this$0.drawString(this.this$0.fontRendererObj, s, p_180791_2_ + 2, p_180791_3_ + 1, 16777215);
      this.this$0.drawString(this.this$0.fontRendererObj, s1, p_180791_2_ + 2, p_180791_3_ + 12, 8421504);
      this.this$0.drawString(this.this$0.fontRendererObj, s2, p_180791_2_ + 2, p_180791_3_ + 12 + 10, 8421504);
   }

   // $FF: synthetic method
   protected void elementClicked(int slotIndex, boolean isDoubleClick, int mouseX, int mouseY) {
      jebac_vexia9ykc8q9mn07o.access$102(this.this$0, slotIndex);
      boolean flag = jebac_vexia9ykc8q9mn07o.access$100(this.this$0) >= 0 && jebac_vexia9ykc8q9mn07o.access$100(this.this$0) < this.getSize();
      jebac_vexia9ykc8q9mn07o.access$200(this.this$0).enabled = flag;
      jebac_vexia9ykc8q9mn07o.access$300(this.this$0).enabled = flag;
      jebac_vexia9ykc8q9mn07o.access$400(this.this$0).enabled = flag;
      jebac_vexia9ykc8q9mn07o.access$500(this.this$0).enabled = flag;
      if (isDoubleClick && flag) {
         this.this$0.func_146615_e(slotIndex);
      }

   }

   // $FF: synthetic method
   public jebac_vexiayn9aahmsh9n8(jebac_vexia9ykc8q9mn07o this$0, Minecraft mcIn) {
      super(mcIn, this$0.width, this$0.height, 32, this$0.height - 64, 36);
      this.this$0 = this$0;
   }

   // $FF: synthetic method
   protected int getSize() {
      return jebac_vexia9ykc8q9mn07o.access$000(this.this$0).size();
   }

   // $FF: synthetic method
   protected void drawBackground() {
      this.this$0.drawDefaultBackground();
   }

   // $FF: synthetic method
   protected boolean isSelected(int slotIndex) {
      return slotIndex == jebac_vexia9ykc8q9mn07o.access$100(this.this$0);
   }

   // $FF: synthetic method
   protected int getContentHeight() {
      return jebac_vexia9ykc8q9mn07o.access$000(this.this$0).size() * 36;
   }
}
