import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

public class jebac_vexiay8z9zu33s6p6 {
   // $FF: synthetic field
   private static jebac_vexia04diwvmiz29c[][] blockAliases = (jebac_vexia04diwvmiz29c[][])((jebac_vexia04diwvmiz29c[][])null);

   // $FF: synthetic method
   public static void update(jebac_vexiab8fgirhwov0i shaderPack) {
      reset();
      String s = "/shaders/block.properties";

      try {
         InputStream inputstream = shaderPack.getResourceAsStream(s);
         if (inputstream == null) {
            return;
         }

         Properties properties = new jebac_vexia5eksztcfhr81();
         properties.load(inputstream);
         inputstream.close();
         jebac_vexiakrwecfs16wve.dbg("[Shaders] Parsing block mappings: " + s);
         List list = new ArrayList();
         jebac_vexiadw49qo6dh8al connectedparser = new jebac_vexiadw49qo6dh8al("Shaders");
         Iterator var6 = properties.keySet().iterator();

         while(true) {
            while(var6.hasNext()) {
               Object s10 = var6.next();
               String s1 = (String)s10;
               String s2 = properties.getProperty(s1);
               String s3 = "block.";
               if (!s1.startsWith(s3)) {
                  jebac_vexiakrwecfs16wve.warn("[Shaders] Invalid block ID: " + s1);
               } else {
                  String s4 = jebac_vexianzkdk43wtdrt.removePrefix(s1, s3);
                  int i = jebac_vexiakrwecfs16wve.parseInt(s4, -1);
                  if (i < 0) {
                     jebac_vexiakrwecfs16wve.warn("[Shaders] Invalid block ID: " + s1);
                  } else {
                     jebac_vexia2nnti3ppoopl[] amatchblock = connectedparser.parseMatchBlocks(s2);
                     if (amatchblock != null && amatchblock.length >= 1) {
                        jebac_vexia04diwvmiz29c blockalias = new jebac_vexia04diwvmiz29c(i, amatchblock);
                        addToList(list, blockalias);
                     } else {
                        jebac_vexiakrwecfs16wve.warn("[Shaders] Invalid block ID mapping: " + s1 + "=" + s2);
                     }
                  }
               }
            }

            if (list.size() <= 0) {
               return;
            }

            blockAliases = toArrays(list);
            break;
         }
      } catch (IOException var15) {
         jebac_vexiakrwecfs16wve.warn("[Shaders] Error reading: " + s);
      }

   }

   // $FF: synthetic method
   private static jebac_vexia04diwvmiz29c[][] toArrays(List listBlocksAliases) {
      jebac_vexia04diwvmiz29c[][] ablockalias = new jebac_vexia04diwvmiz29c[listBlocksAliases.size()][];

      for(int i = 0; i < ablockalias.length; ++i) {
         List list = (List)listBlocksAliases.get(i);
         if (list != null) {
            ablockalias[i] = (jebac_vexia04diwvmiz29c[])((jebac_vexia04diwvmiz29c[])((jebac_vexia04diwvmiz29c[])list.toArray(new jebac_vexia04diwvmiz29c[list.size()])));
         }
      }

      return ablockalias;
   }

   // $FF: synthetic method
   private static void addToList(List blocksAliases, jebac_vexia04diwvmiz29c ba) {
      int[] aint = ba.getMatchBlockIds();

      for(int i = 0; i < aint.length; ++i) {
         int j = aint[i];

         while(j >= blocksAliases.size()) {
            blocksAliases.add((Object)null);
         }

         List list = (List)blocksAliases.get(j);
         if (list == null) {
            list = new ArrayList();
            blocksAliases.set(j, list);
         }

         ((List)list).add(ba);
      }

   }

   // $FF: synthetic method
   public static void reset() {
      blockAliases = (jebac_vexia04diwvmiz29c[][])((jebac_vexia04diwvmiz29c[][])null);
   }

   // $FF: synthetic method
   public static int getMappedBlockId(int blockId, int metadata) {
      if (blockAliases == null) {
         return blockId;
      } else if (blockId >= 0 && blockId < blockAliases.length) {
         jebac_vexia04diwvmiz29c[] ablockalias = blockAliases[blockId];
         if (ablockalias == null) {
            return blockId;
         } else {
            for(int i = 0; i < ablockalias.length; ++i) {
               jebac_vexia04diwvmiz29c blockalias = ablockalias[i];
               if (blockalias.matches(blockId, metadata)) {
                  return blockalias.getBlockId();
               }
            }

            return blockId;
         }
      } else {
         return blockId;
      }
   }
}
