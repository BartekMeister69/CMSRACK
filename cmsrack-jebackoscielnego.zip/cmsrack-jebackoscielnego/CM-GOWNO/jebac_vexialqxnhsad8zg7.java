import java.util.List;
import net.minecraft.util.IChatComponent;

public interface jebac_vexialqxnhsad8zg7 {
   // $FF: synthetic method
   List func_178669_a();

   // $FF: synthetic method
   IChatComponent func_178670_b();
}
