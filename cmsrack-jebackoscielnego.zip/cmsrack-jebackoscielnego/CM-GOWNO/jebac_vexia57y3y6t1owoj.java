import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

public class jebac_vexia57y3y6t1owoj {
   private static final int[]  ec;
   private static final String[]  ed;

   // $FF: synthetic method
   private static int lIIllIIII(float var0, float var1) {
      float var2;
      return (var2 = var0 - var1) == 0.0F ? 0 : (var2 < 0.0F ? -1 : 1);
   }

   // $FF: synthetic method
   private static void lIIIIIIll() {
       ed = new String[ ec[4]];
       ed[ ec[0]] = lIIIIIIIl(jebac_vexiaqb58506wt8o3.  ‏ ("\u1a9b\u1acc᪓᪐᪻᪕᪾᪪᪖᪰᪰\u1ac5\u1acd\u1acd᪹\u1acd\u1a9b\u1a8b᪗\u1ac5᪪\u1acb᪴᪻᪭\u1ad7\u1a8f\u1ac9᪶\u1a9a᪬᪲\u1a9f\u1ad3\u1ac4᪪᪽\u1acc\u1a9d᪫\u1aaf᪬᪓᪔᪹\u1a9b᪘᪫\u1ad3᪄᪥᪤\u1a8b\u1a8b\u1ac1\u1ac1", 750918396), jebac_vexiaqb58506wt8o3.  ‏ ("苼苿苅苉苟", 1249673900));
       ed[ ec[1]] = lIIIIIIlI(jebac_vexiaqb58506wt8o3.  ‏ ("蛟蛆蚆蛖蛷蛉蚃蚃", -1085372738), jebac_vexiaqb58506wt8o3.  ‏ ("햨햂햢햩햧", -1336683027));
   }

   static {
      lIIlIlIIl();
      lIIIIIIll();
   }

   private static void lambda$render$0(EntityPlayer var0, ResourceLocation var1) {
      var0.wings = var1;
   }

   // $FF: synthetic method
   private static int lIIlIlIlI(long var0, long var2) {
      long var4;
      return (var4 = var0 - var2) == 0L ? 0 : (var4 < 0L ? -1 : 1);
   }

   // $FF: synthetic method
   private static String lIIIIIIIl(String var0, String var1) {
      try {
         long var2 = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("\ue153\ue15a\ue12b", 1044570398)).digest(var1.getBytes(StandardCharsets.UTF_8)),  ec[5]), jebac_vexiaqb58506wt8o3.  ‏ ("큉큈큞", 549310477));
         String var3 = Cipher.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("䁓䁒䁄", 2065842199));
         var3.init( ec[4], var2);
         return new String(var3.doFinal(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var9) {
         var9.printStackTrace();
         return null;
      }
   }

   // $FF: synthetic method
   public void render(EntityPlayer var1, int var2) {
      if (lIIlIlIll(var1.wings) && lIIlIllII(var1.triedDownloadWings)) {
         jebac_vexiagwvukypcaxyp.downloadAndSetTexture(String.valueOf((new StringBuilder()).append( ed[ ec[0]]).append(var2).append( ed[ ec[1]])), jebac_vexia57y3y6t1owoj::lambda$render$0);
         var1.triedDownloadWings = (boolean) ec[1];
      }

      if (lIIlIllIl(var1.wings)) {
         boolean var3 = Tessellator.getInstance();
         GL11.glPushMatrix();
         GL11.glScalef(1.1F, 1.1F, 1.1F);
         if (lIIlIlllI(var1.isSneaking())) {
            GL11.glTranslatef(0.0F, 0.185F, 0.175F);
            jebac_vexiaqb58506wt8o3.  ‏ ("", 531108871).length();
            if (-jebac_vexiaqb58506wt8o3.  ‏ ("拑拑拑", -1820105999).length() >= 0) {
               return;
            }
         } else {
            GL11.glTranslatef(0.0F, 0.2F, 0.125F);
         }

         GL11.glRotatef(90.0F, 1.0F, 0.0F, 0.0F);
         GL11.glPushMatrix();
         if (lIIlIllll(lIIlIlIlI(System.currentTimeMillis(), var1.animation))) {
            if (lIIlIlllI(var1.isSneaking())) {
               var1.airTicks = (float)((double)var1.airTicks - 0.094D);
            }

            if (lIIlIlllI(var1.isAirBorne) && lIIlIllII(var1.onGround)) {
               var1.airTicks = (float)((double)var1.airTicks + 0.45D);
               jebac_vexiaqb58506wt8o3.  ‏ ("", 1764420668).length();
               if (((89 + 66 - 20 + 1 ^ 52 + 108 - 79 + 52) & (138 ^ 166 ^ 170 ^ 139 ^ -jebac_vexiaqb58506wt8o3.  ‏ ("\uf124", 1329983748).length())) > jebac_vexiaqb58506wt8o3.  ‏ ("鯎鯎", 959028206).length()) {
                  return;
               }
            } else {
               var1.airTicks = (float)((double)var1.airTicks + 0.05D);
            }

            var1.animation = System.currentTimeMillis() + 10L;
         }

         if (lIIlIlllI(var1.isSneaking())) {
            GL11.glRotatef(33.0F + (float)Math.sin((double)var1.airTicks / 4.0D) * 20.0F, 1.5F, 0.0F, 2.5F);
            jebac_vexiaqb58506wt8o3.  ‏ ("", 2047196928).length();
            if (jebac_vexiaqb58506wt8o3.  ‏ ("ᆍ", -496758355).length() >= (58 + 11 - 10 + 84 ^ 33 + 21 - 41 + 126)) {
               return;
            }
         } else {
            GL11.glRotatef(24.0F + (float)Math.sin((double)var1.airTicks / 4.0D) * 20.0F, 0.0F, 0.0F, 1.0F);
         }

         GL11.glTranslatef(-0.125F, 0.125F, 0.18F);
         Minecraft.getMinecraft().getTextureManager().bindTexture(var1.wings);
         GL11.glRotatef(100.0F, 0.0F, 1.0F, 0.0F);
         this.render3D(var3.getWorldRenderer());
         GL11.glPopMatrix();
         GL11.glPushMatrix();
         if (lIIlIlllI(var1.isSneaking())) {
            GL11.glRotatef(-30.0F - (float)Math.sin((double)var1.airTicks / 4.0D) * 20.0F, -1.5F, 0.0F, 2.5F);
            jebac_vexiaqb58506wt8o3.  ‏ ("", 1855602032).length();
            if (-jebac_vexiaqb58506wt8o3.  ‏ ("ᕱᕱᕱ", -437447343).length() >= 0) {
               return;
            }
         } else {
            GL11.glRotatef(-24.0F - (float)Math.sin((double)var1.airTicks / 4.0D) * 20.0F, 0.0F, 0.0F, 1.0F);
         }

         GL11.glTranslatef(0.0F, 0.125F, 0.18F);
         Minecraft.getMinecraft().getTextureManager().bindTexture(var1.wings);
         GL11.glRotatef(80.0F, 0.0F, 1.0F, 0.0F);
         this.render3D(var3.getWorldRenderer());
         GL11.glPopMatrix();
         GL11.glPopMatrix();
      }

   }

   // $FF: synthetic method
   private static boolean lIIlIllll(int var0) {
      return var0 > 0;
   }

   // $FF: synthetic method
   private static void lIIlIlIIl() {
       ec = new int[6];
       ec[0] = (241 ^ 166) & ~(102 ^ 49);
       ec[1] = jebac_vexiaqb58506wt8o3.  ‏ ("ᓕ", -1433398027).length();
       ec[2] = -(-2073 & 32669) & -2049 & 'ﾾ';
       ec[3] = 55 ^ 48;
       ec[4] = jebac_vexiaqb58506wt8o3.  ‏ ("竩竩", 1026980553).length();
       ec[5] = 168 ^ 160;
   }

   // $FF: synthetic method
   private void render3D(WorldRenderer var1) {
      Tessellator var2 = Tessellator.getInstance();
      GL11.glPushMatrix();
      GL11.glTranslated(0.0D, 0.0D, 0.0D);
      GL11.glEnable( ec[2]);
      GL11.glTranslatef(1.0F, -0.10000001F, 0.1F);
      GL11.glScalef(1.875F, 1.875F, 1.0F);
      GL11.glRotatef(0.0F, 0.0F, 200.0F, 0.0F);
      GL11.glRotatef(0.0F, 0.0F, 0.0F, 1.0F);
      GL11.glTranslatef(-0.9375F, -0.0625F, 0.0F);
      GL11.glScaled(1.0D, 1.0D, 0.7D);
      var1.begin( ec[3], DefaultVertexFormats.POSITION_TEX_NORMAL);
      var1.pos(0.0D, 0.0D, 0.0D).tex(1.0D, 1.0D).normal(0.0F, 0.0F, 1.0F).endVertex();
      var1.pos(1.0D, 0.0D, 0.0D).tex(0.0D, 1.0D).normal(0.0F, 0.0F, 1.0F).endVertex();
      var1.pos(1.0D, 1.0D, 0.0D).tex(0.0D, 0.0D).normal(0.0F, 0.0F, 1.0F).endVertex();
      var1.pos(0.0D, 1.0D, 0.0D).tex(1.0D, 0.0D).normal(0.0F, 0.0F, 1.0F).endVertex();
      var2.draw();
      var1.begin( ec[3], DefaultVertexFormats.POSITION_TEX_NORMAL);
      var1.pos(0.0D, 1.0D, -0.078125D).tex(1.0D, 0.0D).normal(0.0F, 0.0F, -1.0F).endVertex();
      var1.pos(1.0D, 1.0D, -0.078125D).tex(0.0D, 0.0D).normal(0.0F, 0.0F, -1.0F).endVertex();
      var1.pos(1.0D, 0.0D, -0.078125D).tex(0.0D, 1.0D).normal(0.0F, 0.0F, -1.0F).endVertex();
      var1.pos(0.0D, 0.0D, -0.078125D).tex(1.0D, 1.0D).normal(0.0F, 0.0F, -1.0F).endVertex();
      var2.draw();
      var1.begin( ec[3], DefaultVertexFormats.POSITION_TEX_NORMAL);
      int var3 =  ec[0];

      do {
         float var4;
         float var5;
         if (!lIIllIIIl(lIIllIIII((float)var3, 32.0F))) {
            var2.draw();
            var1.begin( ec[3], DefaultVertexFormats.POSITION_TEX_NORMAL);
            var3 =  ec[0];

            do {
               if (!lIIllIIIl(lIIllIIII((float)var3, 32.0F))) {
                  var2.draw();
                  GL11.glDisable( ec[2]);
                  GL11.glPopMatrix();
                  return;
               }

               var4 = (float)var3 / 32.0F;
               var5 = 1.0F + -1.0F * var4 - 0.015625F;
               var4 += 0.03125F;
               var1.pos(0.0D, (double)var4, 0.0D).tex(1.0D, (double)var5).normal(0.0F, 1.0F, 0.0F).endVertex();
               var1.pos(1.0D, (double)var4, 0.0D).tex(0.0D, (double)var5).normal(0.0F, 1.0F, 0.0F).endVertex();
               var1.pos(1.0D, (double)var4, -0.078125D).tex(0.0D, (double)var5).normal(0.0F, 1.0F, 0.0F).endVertex();
               var1.pos(0.0D, (double)var4, -0.078125D).tex(1.0D, (double)var5).normal(0.0F, 1.0F, 0.0F).endVertex();
               ++var3;
               jebac_vexiaqb58506wt8o3.  ‏ ("", 883366091).length();
            } while(jebac_vexiaqb58506wt8o3.  ‏ ("瞧瞧", 198113981).length() > ((28 + 55 - 82 + 185 ^ 74 + 46 - -16 + 10) & (195 ^ 154 ^ 193 ^ 176 ^ -jebac_vexiaqb58506wt8o3.  ‏ ("忱", -1694998575).length())));

            return;
         }

         var4 = (float)var3 / 32.0F;
         var5 = 1.0F + -1.0F * var4 - 0.015625F;
         var4 += 0.03125F;
         var1.pos((double)var4, 1.0D, -0.078125D).tex((double)var5, 0.0D).normal(1.0F, 0.0F, 0.0F).endVertex();
         var1.pos((double)var4, 1.0D, 0.0D).tex((double)var5, 0.0D).normal(1.0F, 0.0F, 0.0F).endVertex();
         var1.pos((double)var4, 0.0D, 0.0D).tex((double)var5, 1.0D).normal(1.0F, 0.0F, 0.0F).endVertex();
         var1.pos((double)var4, 0.0D, -0.078125D).tex((double)var5, 1.0D).normal(1.0F, 0.0F, 0.0F).endVertex();
         ++var3;
         jebac_vexiaqb58506wt8o3.  ‏ ("", -2011451812).length();
      } while(jebac_vexiaqb58506wt8o3.  ‏ ("漊", -1692569814).length() <= jebac_vexiaqb58506wt8o3.  ‏ ("땯땯땯", -138758833).length());

   }

   // $FF: synthetic method
   private static boolean lIIlIlllI(int var0) {
      return var0 != 0;
   }

   // $FF: synthetic method
   private static String lIIIIIIlI(String var0, String var1) {
      var0 = new String(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder var2 = new StringBuilder();
      String var3 = var1.toCharArray();
      int var4 =  ec[0];
      boolean var5 = var0.toCharArray();
      short var6 = var5.length;
      int var7 =  ec[0];

      do {
         if (!lIIllIIlI(var7, var6)) {
            return String.valueOf(var2);
         }

         float var8 = var5[var7];
         var2.append((char)(var8 ^ var3[var4 % var3.length]));
         jebac_vexiaqb58506wt8o3.  ‏ ("", -1048791772).length();
         ++var4;
         ++var7;
         jebac_vexiaqb58506wt8o3.  ‏ ("", 1327700214).length();
      } while(jebac_vexiaqb58506wt8o3.  ‏ ("ᘯᘯᘯ", -786360817).length() >= ((112 ^ 90) & ~(95 ^ 117)));

      return null;
   }

   // $FF: synthetic method
   private static boolean lIIllIIIl(int var0) {
      return var0 < 0;
   }

   // $FF: synthetic method
   private static boolean lIIlIllII(int var0) {
      return var0 == 0;
   }

   // $FF: synthetic method
   private static boolean lIIlIlIll(Object var0) {
      return var0 == null;
   }

   // $FF: synthetic method
   private static boolean lIIlIllIl(Object var0) {
      return var0 != null;
   }

   // $FF: synthetic method
   private static boolean lIIllIIlI(int var0, int var1) {
      return var0 < var1;
   }
}
