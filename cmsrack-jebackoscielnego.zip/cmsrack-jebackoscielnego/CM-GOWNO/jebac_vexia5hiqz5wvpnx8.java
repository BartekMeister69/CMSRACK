import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.util.ResourceLocation;

public class jebac_vexia5hiqz5wvpnx8 {
   private int  in;
   private static final String[]  ip;
   private final int  io;
   private static final int[]  ir;
   private final int  iq;

   // $FF: synthetic method
   private static String llllIIl(String var0, String var1) {
      var0 = new String(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      boolean var2 = new StringBuilder();
      long var3 = var1.toCharArray();
      long var4 =  ir[1];
      String var5 = var0.toCharArray();
      String var6 = var5.length;
      int var7 =  ir[1];

      do {
         if (!lllllII(var7, var6)) {
            return String.valueOf(var2);
         }

         String var8 = var5[var7];
         var2.append((char)(var8 ^ var3[var4 % var3.length]));
         jebac_vexiaqb58506wt8o3.  ‏ ("", 1309221864).length();
         ++var4;
         ++var7;
         jebac_vexiaqb58506wt8o3.  ‏ ("", -157816527).length();
      } while((146 ^ 150) >= jebac_vexiaqb58506wt8o3.  ‏ ("訞訞", -1859483074).length());

      return null;
   }

   static {
      llllIll();
      llllIlI();
   }

   // $FF: synthetic method
   public void tick() {
      this. in +=  ir[0];
      if (!lllllII(this. in, this. io)) {
         this. in =  ir[1];
      }
   }

   // $FF: synthetic method
   private static void llllIll() {
       ir = new int[5];
       ir[0] = jebac_vexiaqb58506wt8o3.  ‏ ("ⴅ", -1291440859).length();
       ir[1] = (234 ^ 177) & ~(121 ^ 34);
       ir[2] = jebac_vexiaqb58506wt8o3.  ‏ ("俌俌", -411283476).length();
       ir[3] = jebac_vexiaqb58506wt8o3.  ‏ ("귨귨귨", -896750136).length();
       ir[4] = 8 ^ 0;
   }

   // $FF: synthetic method
   private static String llllIII(String var0, String var1) {
      try {
         SecretKeySpec var2 = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("\uf86b\uf862\uf813", 1376319526)).digest(var1.getBytes(StandardCharsets.UTF_8)),  ir[4]), jebac_vexiaqb58506wt8o3.  ‏ ("\udfcf\udfce\udfd8", -1546330229));
         SecretKeySpec var3 = Cipher.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("睙睘睎", 814315293));
         var3.init( ir[2], var2);
         return new String(var3.doFinal(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var9) {
         var9.printStackTrace();
         return null;
      }
   }

   // $FF: synthetic method
   private static void llllIlI() {
       ip = new String[ ir[3]];
       ip[ ir[1]] = lllIlll(jebac_vexiaqb58506wt8o3.  ‏ ("栟栗桜栍桛桝栭核桄栁根栤栊桜栭栾栦栻栿栅栌栞标标栫栣标样栍桟栩栎", 1212049519), jebac_vexiaqb58506wt8o3.  ‏ ("硡硓硏硬硛", 537491498));
       ip[ ir[0]] = llllIII(jebac_vexiaqb58506wt8o3.  ‏ ("홒혁홹혃혍홺홼홅홍홟홼혈", 232052277), jebac_vexiaqb58506wt8o3.  ‏ ("揺揗提揼揲", -906796097));
       ip[ ir[2]] = llllIIl(jebac_vexiaqb58506wt8o3.  ‏ ("걶걵걥개걧걓같같", 1869720612), jebac_vexiaqb58506wt8o3.  ‏ ("铹铢铀链铂", 1216451730));
   }

   // $FF: synthetic method
   private static String lllIlll(String var0, String var1) {
      try {
         String var2 = new SecretKeySpec(MessageDigest.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("㳬㳥㲔", -796509023)).digest(var1.getBytes(StandardCharsets.UTF_8)), jebac_vexiaqb58506wt8o3.  ‏ ("\u2435␛␘␀␑␞␄␟", -872864649));
         int var3 = Cipher.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("⭠⭎⭍⭕⭄⭋⭑⭊", -2031211742));
         var3.init( ir[2], var2);
         return new String(var3.doFinal(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var9) {
         var9.printStackTrace();
         return null;
      }
   }

   // $FF: synthetic method
   private static boolean lllllII(int var0, int var1) {
      return var0 < var1;
   }

   // $FF: synthetic method
   public jebac_vexia5hiqz5wvpnx8(int var1, int var2) {
      this. iq = var1;
      this. io = var2;
   }

   // $FF: synthetic method
   public ResourceLocation toResource() {
      return new ResourceLocation(String.valueOf((new StringBuilder()).append( ip[ ir[1]]).append(this. iq).append( ip[ ir[0]]).append(this. in).append( ip[ ir[2]])));
   }
}
