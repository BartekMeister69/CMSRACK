import java.util.Iterator;
import net.minecraft.client.renderer.ViewFrustum;
import net.minecraft.client.renderer.chunk.RenderChunk;
import net.minecraft.util.BlockPos;

public class jebac_vexia0w4pevwbujuf implements Iterator {
   // $FF: synthetic field
   private jebac_vexiaisxd96hccl8m posBlock = new jebac_vexiaisxd96hccl8m(0, 0, 0);
   // $FF: synthetic field
   private ViewFrustum viewFrustum;
   // $FF: synthetic field
   private jebac_vexiaofeelg9ae69d Iterator3d;

   // $FF: synthetic method
   public RenderChunk next() {
      BlockPos blockpos = this.Iterator3d.next();
      this.posBlock.setXyz(blockpos.getX() << 4, blockpos.getY() << 4, blockpos.getZ() << 4);
      RenderChunk renderchunk = this.viewFrustum.getRenderChunk(this.posBlock);
      return renderchunk;
   }

   // $FF: synthetic method
   public jebac_vexia0w4pevwbujuf(ViewFrustum viewFrustum, BlockPos posStart, BlockPos posEnd, int width, int height) {
      this.viewFrustum = viewFrustum;
      this.Iterator3d = new jebac_vexiaofeelg9ae69d(posStart, posEnd, width, height);
   }

   // $FF: synthetic method
   public void remove() {
      throw new RuntimeException("Not implemented");
   }

   // $FF: synthetic method
   public boolean hasNext() {
      return this.Iterator3d.hasNext();
   }
}
