import org.lwjgl.opengl.ARBShaderObjects;

public class jebac_vexiaxxpj2xpwsvuf extends jebac_vexiayjlmwpsmx1qc {
   // $FF: synthetic field
   private int value = -1;

   // $FF: synthetic method
   protected void onProgramChanged() {
      this.value = -1;
   }

   // $FF: synthetic method
   public jebac_vexiaxxpj2xpwsvuf(String name) {
      super(name);
   }

   // $FF: synthetic method
   public int getValue() {
      return this.value;
   }

   // $FF: synthetic method
   public void setValue(int value) {
      if (this.getLocation() >= 0 && this.value != value) {
         ARBShaderObjects.glUniform1iARB(this.getLocation(), value);
         jebac_vexiaflhnh80r1906.checkGLError(this.getName());
         this.value = value;
      }

   }
}
