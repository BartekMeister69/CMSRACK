import net.minecraft.client.resources.I18n;
import net.minecraft.potion.Potion;

class jebac_vexiav195hg2n24di extends jebac_vexia72k5sdirsh7v {
   // $FF: synthetic field
   private final int field_146148_q;
   final jebac_vexiajrsmxgnpvxgq this$0;
   // $FF: synthetic field
   private final int field_146149_p;

   // $FF: synthetic method
   public void drawButtonForegroundLayer(int mouseX, int mouseY) {
      String s = I18n.format(Potion.potionTypes[this.field_146149_p].getName());
      if (this.field_146148_q >= 3 && this.field_146149_p != Potion.regeneration.id) {
         s = s + " II";
      }

      jebac_vexiajrsmxgnpvxgq.access$300(this.this$0, s, mouseX, mouseY);
   }

   // $FF: synthetic method
   public jebac_vexiav195hg2n24di(jebac_vexiajrsmxgnpvxgq this$0, int p_i1076_2_, int p_i1076_3_, int p_i1076_4_, int p_i1076_5_, int p_i1076_6_) {
      super(p_i1076_2_, p_i1076_3_, p_i1076_4_, jebac_vexiaeojg9sk3h8nx.inventoryBackground, 0 + Potion.potionTypes[p_i1076_5_].getStatusIconIndex() % 8 * 18, 198 + Potion.potionTypes[p_i1076_5_].getStatusIconIndex() / 8 * 18);
      this.this$0 = this$0;
      this.field_146149_p = p_i1076_5_;
      this.field_146148_q = p_i1076_6_;
   }
}
