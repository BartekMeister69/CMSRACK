import java.io.IOException;
import net.minecraft.client.resources.I18n;
import net.minecraft.world.gen.FlatGeneratorInfo;

public class jebac_vexia0o9cuuh5axo5 extends jebac_vexiakl614w3uw0xg {
   // $FF: synthetic field
   private jebac_vexia4oibzo50ubf0 field_146386_v;
   // $FF: synthetic field
   private jebac_vexia4oibzo50ubf0 field_146389_t;
   // $FF: synthetic field
   private jebac_vexia4oibzo50ubf0 field_146388_u;
   // $FF: synthetic field
   private String flatWorldTitle;
   // $FF: synthetic field
   private FlatGeneratorInfo theFlatGeneratorInfo = FlatGeneratorInfo.getDefaultFlatGenerator();
   // $FF: synthetic field
   private String field_146394_i;
   // $FF: synthetic field
   private jebac_vexiarys0g590uyie createFlatWorldListSlotGui;
   // $FF: synthetic field
   private final jebac_vexiac6d627d28q0h createWorldGui;
   // $FF: synthetic field
   private String field_146391_r;

   static FlatGeneratorInfo access$000(jebac_vexia0o9cuuh5axo5 x0) {
      return x0.theFlatGeneratorInfo;
   }

   // $FF: synthetic method
   public void func_146375_g() {
      boolean flag = this.func_146382_i();
      this.field_146386_v.enabled = flag;
      this.field_146388_u.enabled = flag;
      this.field_146388_u.enabled = false;
      this.field_146389_t.enabled = false;
   }

   // $FF: synthetic method
   public void initGui() {
      this.buttonList.clear();
      this.flatWorldTitle = I18n.format("createWorld.customize.flat.title");
      this.field_146394_i = I18n.format("createWorld.customize.flat.tile");
      this.field_146391_r = I18n.format("createWorld.customize.flat.height");
      this.createFlatWorldListSlotGui = new jebac_vexiarys0g590uyie(this);
      this.buttonList.add(this.field_146389_t = new jebac_vexia4oibzo50ubf0(2, this.width / 2 - 154, this.height - 52, 100, 20, I18n.format("createWorld.customize.flat.addLayer") + " (NYI)"));
      this.buttonList.add(this.field_146388_u = new jebac_vexia4oibzo50ubf0(3, this.width / 2 - 50, this.height - 52, 100, 20, I18n.format("createWorld.customize.flat.editLayer") + " (NYI)"));
      this.buttonList.add(this.field_146386_v = new jebac_vexia4oibzo50ubf0(4, this.width / 2 - 155, this.height - 52, 150, 20, I18n.format("createWorld.customize.flat.removeLayer")));
      this.buttonList.add(new jebac_vexia4oibzo50ubf0(0, this.width / 2 - 155, this.height - 28, 150, 20, I18n.format("gui.done")));
      this.buttonList.add(new jebac_vexia4oibzo50ubf0(5, this.width / 2 + 5, this.height - 52, 150, 20, I18n.format("createWorld.customize.presets")));
      this.buttonList.add(new jebac_vexia4oibzo50ubf0(1, this.width / 2 + 5, this.height - 28, 150, 20, I18n.format("gui.cancel")));
      this.field_146389_t.visible = this.field_146388_u.visible = false;
      this.theFlatGeneratorInfo.func_82645_d();
      this.func_146375_g();
   }

   // $FF: synthetic method
   public void drawScreen(int mouseX, int mouseY, float partialTicks) {
      this.drawDefaultBackground();
      this.createFlatWorldListSlotGui.drawScreen(mouseX, mouseY, partialTicks);
      this.drawCenteredString(this.fontRendererObj, this.flatWorldTitle, this.width / 2, 8, 16777215);
      int i = this.width / 2 - 92 - 16;
      this.drawString(this.fontRendererObj, this.field_146394_i, i, 32, 16777215);
      this.drawString(this.fontRendererObj, this.field_146391_r, i + 2 + 213 - this.fontRendererObj.getStringWidth(this.field_146391_r), 32, 16777215);
      super.drawScreen(mouseX, mouseY, partialTicks);
   }

   // $FF: synthetic method
   public jebac_vexia0o9cuuh5axo5(jebac_vexiac6d627d28q0h createWorldGuiIn, String p_i1029_2_) {
      this.createWorldGui = createWorldGuiIn;
      this.func_146383_a(p_i1029_2_);
   }

   // $FF: synthetic method
   public String func_146384_e() {
      return this.theFlatGeneratorInfo.toString();
   }

   // $FF: synthetic method
   public void handleMouseInput() throws IOException {
      super.handleMouseInput();
      this.createFlatWorldListSlotGui.handleMouseInput();
   }

   // $FF: synthetic method
   public void func_146383_a(String p_146383_1_) {
      this.theFlatGeneratorInfo = FlatGeneratorInfo.createFlatGeneratorFromString(p_146383_1_);
   }

   // $FF: synthetic method
   private boolean func_146382_i() {
      return this.createFlatWorldListSlotGui.field_148228_k > -1 && this.createFlatWorldListSlotGui.field_148228_k < this.theFlatGeneratorInfo.getFlatLayers().size();
   }

   // $FF: synthetic method
   protected void actionPerformed(jebac_vexia4oibzo50ubf0 button) throws IOException {
      int i = this.theFlatGeneratorInfo.getFlatLayers().size() - this.createFlatWorldListSlotGui.field_148228_k - 1;
      if (button.id == 1) {
         this.mc.displayGuiScreen(this.createWorldGui);
      } else if (button.id == 0) {
         this.createWorldGui.chunkProviderSettingsJson = this.func_146384_e();
         this.mc.displayGuiScreen(this.createWorldGui);
      } else if (button.id == 5) {
         this.mc.displayGuiScreen(new jebac_vexiamd58vwqnzad3(this));
      } else if (button.id == 4 && this.func_146382_i()) {
         this.theFlatGeneratorInfo.getFlatLayers().remove(i);
         this.createFlatWorldListSlotGui.field_148228_k = Math.min(this.createFlatWorldListSlotGui.field_148228_k, this.theFlatGeneratorInfo.getFlatLayers().size() - 1);
      }

      this.theFlatGeneratorInfo.func_82645_d();
      this.func_146375_g();
   }
}
