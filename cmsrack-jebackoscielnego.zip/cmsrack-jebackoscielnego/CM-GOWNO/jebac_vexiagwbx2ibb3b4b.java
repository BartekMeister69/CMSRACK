import net.minecraft.client.resources.I18n;
import net.minecraft.client.settings.GameSettings;

public class jebac_vexiagwbx2ibb3b4b extends jebac_vexiakl614w3uw0xg {
   // $FF: synthetic field
   private GameSettings settings;
   // $FF: synthetic field
   protected String title;
   // $FF: synthetic field
   private jebac_vexiakl614w3uw0xg prevScreen;
   // $FF: synthetic field
   private jebac_vexiapguljx25lc0b tooltipManager = new jebac_vexiapguljx25lc0b(this);
   // $FF: synthetic field
   private static GameSettings.Options[] enumOptions;

   // $FF: synthetic method
   public void drawScreen(int mouseX, int mouseY, float partialTicks) {
      this.drawDefaultBackground();
      this.drawCenteredString(this.fontRendererObj, this.title, this.width / 2, 15, 16777215);
      super.drawScreen(mouseX, mouseY, partialTicks);
      this.tooltipManager.drawTooltips(mouseX, mouseY, this.buttonList);
   }

   // $FF: synthetic method
   public jebac_vexiagwbx2ibb3b4b(jebac_vexiakl614w3uw0xg p_i52_1_, GameSettings p_i52_2_) {
      this.prevScreen = p_i52_1_;
      this.settings = p_i52_2_;
   }

   static {
      enumOptions = new GameSettings.Options[]{GameSettings.Options.SMOOTH_FPS, GameSettings.Options.SMOOTH_WORLD, GameSettings.Options.FAST_RENDER, GameSettings.Options.FAST_MATH, GameSettings.Options.CHUNK_UPDATES, GameSettings.Options.CHUNK_UPDATES_DYNAMIC, GameSettings.Options.LAZY_CHUNK_LOADING};
   }

   // $FF: synthetic method
   protected void actionPerformed(jebac_vexia4oibzo50ubf0 button) {
      if (button.enabled) {
         if (button.id < 200 && button instanceof jebac_vexiatgc7sxy17ln0) {
            this.settings.setOptionValue(((jebac_vexiatgc7sxy17ln0)button).returnEnumOptions(), 1);
            button.displayString = this.settings.getKeyBinding(GameSettings.Options.getEnumOptions(button.id));
         }

         if (button.id == 200) {
            this.mc.gameSettings.saveOptions();
            this.mc.displayGuiScreen(this.prevScreen);
         }
      }

   }

   // $FF: synthetic method
   public void initGui() {
      this.title = I18n.format("of.options.performanceTitle");
      this.buttonList.clear();

      for(int i = 0; i < enumOptions.length; ++i) {
         GameSettings.Options gamesettings$options = enumOptions[i];
         int j = this.width / 2 - 155 + i % 2 * 160;
         int k = this.height / 6 + 21 * (i / 2) - 12;
         if (!gamesettings$options.getEnumFloat()) {
            this.buttonList.add(new jebac_vexia93dz1y66pwuy(gamesettings$options.returnEnumOrdinal(), j, k, gamesettings$options, this.settings.getKeyBinding(gamesettings$options)));
         } else {
            this.buttonList.add(new jebac_vexiaildxyx0dfrwq(gamesettings$options.returnEnumOrdinal(), j, k, gamesettings$options));
         }
      }

      this.buttonList.add(new jebac_vexia4oibzo50ubf0(200, this.width / 2 - 100, this.height / 6 + 168 + 11, I18n.format("gui.done")));
   }
}
