import java.io.IOException;
import net.minecraft.client.resources.I18n;

public class jebac_vexiaq0vye1pkzt1z extends jebac_vexiakl614w3uw0xg {
   // $FF: synthetic field
   private String field_146313_a;
   // $FF: synthetic field
   private String field_146312_f;

   // $FF: synthetic method
   public void drawScreen(int mouseX, int mouseY, float partialTicks) {
      this.drawGradientRect(0, 0, this.width, this.height, -12574688, -11530224);
      this.drawCenteredString(this.fontRendererObj, this.field_146313_a, this.width / 2, 90, 16777215);
      this.drawCenteredString(this.fontRendererObj, this.field_146312_f, this.width / 2, 110, 16777215);
      super.drawScreen(mouseX, mouseY, partialTicks);
   }

   // $FF: synthetic method
   public jebac_vexiaq0vye1pkzt1z(String p_i46319_1_, String p_i46319_2_) {
      this.field_146313_a = p_i46319_1_;
      this.field_146312_f = p_i46319_2_;
   }

   // $FF: synthetic method
   protected void actionPerformed(jebac_vexia4oibzo50ubf0 button) throws IOException {
      this.mc.displayGuiScreen((jebac_vexiakl614w3uw0xg)null);
   }

   // $FF: synthetic method
   protected void keyTyped(char typedChar, int keyCode) throws IOException {
   }

   // $FF: synthetic method
   public void initGui() {
      super.initGui();
      this.buttonList.add(new jebac_vexia4oibzo50ubf0(0, this.width / 2 - 100, 140, I18n.format("gui.cancel")));
   }
}
