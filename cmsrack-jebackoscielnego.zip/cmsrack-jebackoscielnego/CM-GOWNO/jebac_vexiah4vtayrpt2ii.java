import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class jebac_vexiah4vtayrpt2ii extends jebac_vexiazrxtvwdcml9w {
   // $FF: synthetic field
   private static final Pattern PATTERN_VARIABLE = Pattern.compile("^\\s*#define\\s+(\\w+)\\s+(-?[0-9\\.Ff]+|\\w+)\\s*(//.*)?$");

   // $FF: synthetic method
   public boolean matchesLine(String line) {
      Matcher matcher = PATTERN_VARIABLE.matcher(line);
      if (!matcher.matches()) {
         return false;
      } else {
         String s = matcher.group(1);
         return s.matches(this.getName());
      }
   }

   // $FF: synthetic method
   public String getValueColor(String val) {
      return "§a";
   }

   // $FF: synthetic method
   public jebac_vexiah4vtayrpt2ii(String name, String description, String value, String[] values, String path) {
      super(name, description, value, values, value, path);
      this.setVisible(this.getValues().length > 1);
   }

   // $FF: synthetic method
   public static jebac_vexiazrxtvwdcml9w parseOption(String line, String path) {
      Matcher matcher = PATTERN_VARIABLE.matcher(line);
      if (!matcher.matches()) {
         return null;
      } else {
         String s = matcher.group(1);
         String s1 = matcher.group(2);
         String s2 = matcher.group(3);
         String s3 = jebac_vexianzkdk43wtdrt.getSegment(s2, "[", "]");
         if (s3 != null && s3.length() > 0) {
            s2 = s2.replace(s3, "").trim();
         }

         String[] astring = parseValues(s1, s3);
         if (s != null && s.length() > 0) {
            path = jebac_vexianzkdk43wtdrt.removePrefix(path, "/shaders/");
            jebac_vexiazrxtvwdcml9w shaderoption = new jebac_vexiah4vtayrpt2ii(s, s2, s1, astring, path);
            return shaderoption;
         } else {
            return null;
         }
      }
   }

   // $FF: synthetic method
   public static String[] parseValues(String value, String valuesStr) {
      String[] astring = new String[]{value};
      if (valuesStr == null) {
         return astring;
      } else {
         valuesStr = valuesStr.trim();
         valuesStr = jebac_vexianzkdk43wtdrt.removePrefix(valuesStr, "[");
         valuesStr = jebac_vexianzkdk43wtdrt.removeSuffix(valuesStr, "]");
         valuesStr = valuesStr.trim();
         if (valuesStr.length() <= 0) {
            return astring;
         } else {
            String[] astring1 = jebac_vexiakrwecfs16wve.tokenize(valuesStr, " ");
            if (astring1.length <= 0) {
               return astring;
            } else {
               if (!Arrays.asList(astring1).contains(value)) {
                  astring1 = (String[])((String[])jebac_vexiakrwecfs16wve.addObjectToArray(astring1, value, 0));
               }

               return astring1;
            }
         }
      }
   }

   // $FF: synthetic method
   public String getSourceLine() {
      return "#define " + this.getName() + " " + this.getValue() + " // Shader option " + this.getValue();
   }
}
