import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Enumeration;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import net.minecraft.client.resources.AbstractResourcePack;
import net.minecraft.client.resources.DefaultResourcePack;
import net.minecraft.client.resources.IResourcePack;
import net.minecraft.util.ResourceLocation;

public class jebac_vexiavx2mofavvrsa {
   // $FF: synthetic method
   private static String[] collectFilesZIP(File p_collectFilesZIP_0_, String[] p_collectFilesZIP_1_, String[] p_collectFilesZIP_2_) {
      List list = new ArrayList();
      String s = "assets/minecraft/";

      try {
         ZipFile zipfile = new ZipFile(p_collectFilesZIP_0_);
         Enumeration enumeration = zipfile.entries();

         while(enumeration.hasMoreElements()) {
            ZipEntry zipentry = (ZipEntry)enumeration.nextElement();
            String s1 = zipentry.getName();
            if (s1.startsWith(s)) {
               s1 = s1.substring(s.length());
               if (jebac_vexianzkdk43wtdrt.startsWith(s1, p_collectFilesZIP_1_) && jebac_vexianzkdk43wtdrt.endsWith(s1, p_collectFilesZIP_2_)) {
                  list.add(s1);
               }
            }
         }

         zipfile.close();
         return (String[])((String[])list.toArray(new String[0]));
      } catch (IOException var9) {
         var9.printStackTrace();
         return new String[0];
      }
   }

   // $FF: synthetic method
   public static String[] collectFiles(IResourcePack p_collectFiles_0_, String[] p_collectFiles_1_, String[] p_collectFiles_2_) {
      return collectFiles(p_collectFiles_0_, (String[])p_collectFiles_1_, (String[])p_collectFiles_2_, (String[])null);
   }

   // $FF: synthetic method
   private static String[] collectFilesFixed(IResourcePack p_collectFilesFixed_0_, String[] p_collectFilesFixed_1_) {
      if (p_collectFilesFixed_1_ == null) {
         return new String[0];
      } else {
         List list = new ArrayList();
         String[] var3 = p_collectFilesFixed_1_;
         int var4 = p_collectFilesFixed_1_.length;

         for(int var5 = 0; var5 < var4; ++var5) {
            String s = var3[var5];
            ResourceLocation resourcelocation = new ResourceLocation(s);
            if (p_collectFilesFixed_0_.resourceExists(resourcelocation)) {
               list.add(s);
            }
         }

         return (String[])((String[])list.toArray(new String[0]));
      }
   }

   // $FF: synthetic method
   private static String[] collectFilesFolder(File p_collectFilesFolder_0_, String p_collectFilesFolder_1_, String[] p_collectFilesFolder_2_, String[] p_collectFilesFolder_3_) {
      List list = new ArrayList();
      String s = "assets/minecraft/";
      File[] afile = p_collectFilesFolder_0_.listFiles();
      if (afile == null) {
         return new String[0];
      } else {
         File[] var7 = afile;
         int var8 = afile.length;

         for(int var9 = 0; var9 < var8; ++var9) {
            File file1 = var7[var9];
            String s3;
            if (file1.isFile()) {
               s3 = p_collectFilesFolder_1_ + file1.getName();
               if (s3.startsWith(s)) {
                  s3 = s3.substring(s.length());
                  if (jebac_vexianzkdk43wtdrt.startsWith(s3, p_collectFilesFolder_2_) && jebac_vexianzkdk43wtdrt.endsWith(s3, p_collectFilesFolder_3_)) {
                     list.add(s3);
                  }
               }
            } else if (file1.isDirectory()) {
               s3 = p_collectFilesFolder_1_ + file1.getName() + "/";
               String[] astring = collectFilesFolder(file1, s3, p_collectFilesFolder_2_, p_collectFilesFolder_3_);
               Collections.addAll(list, astring);
            }
         }

         return (String[])((String[])list.toArray(new String[0]));
      }
   }

   // $FF: synthetic method
   public static String[] collectFiles(String p_collectFiles_0_, String p_collectFiles_1_) {
      return collectFiles(new String[]{p_collectFiles_0_}, new String[]{p_collectFiles_1_});
   }

   // $FF: synthetic method
   public static String[] collectFiles(IResourcePack p_collectFiles_0_, String p_collectFiles_1_, String p_collectFiles_2_, String[] p_collectFiles_3_) {
      return collectFiles(p_collectFiles_0_, new String[]{p_collectFiles_1_}, new String[]{p_collectFiles_2_}, p_collectFiles_3_);
   }

   // $FF: synthetic method
   public static String[] collectFiles(String[] p_collectFiles_0_, String[] p_collectFiles_1_) {
      Set set = new LinkedHashSet();
      IResourcePack[] airesourcepack = jebac_vexiakrwecfs16wve.getResourcePacks();

      for(int i = 0; i < airesourcepack.length; ++i) {
         IResourcePack iresourcepack = airesourcepack[i];
         String[] astring = collectFiles(iresourcepack, (String[])p_collectFiles_0_, (String[])p_collectFiles_1_, (String[])null);
         set.addAll(Arrays.asList(astring));
      }

      return (String[])set.toArray(new String[0]);
   }

   // $FF: synthetic method
   public static String[] collectFiles(IResourcePack p_collectFiles_0_, String[] p_collectFiles_1_, String[] p_collectFiles_2_, String[] p_collectFiles_3_) {
      if (p_collectFiles_0_ instanceof DefaultResourcePack) {
         return collectFilesFixed(p_collectFiles_0_, p_collectFiles_3_);
      } else if (!(p_collectFiles_0_ instanceof AbstractResourcePack)) {
         return new String[0];
      } else {
         AbstractResourcePack abstractresourcepack = (AbstractResourcePack)p_collectFiles_0_;
         File file1 = abstractresourcepack.resourcePackFile;
         return file1 == null ? new String[0] : (file1.isDirectory() ? collectFilesFolder(file1, "", p_collectFiles_1_, p_collectFiles_2_) : (file1.isFile() ? collectFilesZIP(file1, p_collectFiles_1_, p_collectFiles_2_) : new String[0]));
      }
   }
}
