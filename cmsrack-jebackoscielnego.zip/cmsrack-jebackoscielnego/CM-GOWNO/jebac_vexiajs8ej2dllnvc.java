public class jebac_vexiajs8ej2dllnvc {
   // $FF: synthetic field
   private String targetClassName;
   // $FF: synthetic field
   private Class targetClass;
   // $FF: synthetic field
   private boolean checked;

   // $FF: synthetic method
   public jebac_vexiajs8ej2dllnvc(Class p_i83_1_) {
      this.targetClassName = null;
      this.checked = false;
      this.targetClass = null;
      this.targetClass = p_i83_1_;
      this.targetClassName = p_i83_1_.getName();
      this.checked = true;
   }

   // $FF: synthetic method
   public Class getTargetClass() {
      if (this.checked) {
         return this.targetClass;
      } else {
         this.checked = true;

         try {
            this.targetClass = Class.forName(this.targetClassName);
         } catch (ClassNotFoundException var2) {
            jebac_vexiakrwecfs16wve.log("(Reflector) Class not present: " + this.targetClassName);
         } catch (Throwable var3) {
            var3.printStackTrace();
         }

         return this.targetClass;
      }
   }

   // $FF: synthetic method
   public boolean exists() {
      return this.getTargetClass() != null;
   }

   // $FF: synthetic method
   public jebac_vexiajs8ej2dllnvc(String p_i82_1_, boolean p_i82_2_) {
      this.targetClassName = null;
      this.checked = false;
      this.targetClass = null;
      this.targetClassName = p_i82_1_;
      if (!p_i82_2_) {
         Class var3 = this.getTargetClass();
      }

   }

   // $FF: synthetic method
   public jebac_vexiajs8ej2dllnvc(String p_i81_1_) {
      this(p_i81_1_, false);
   }

   // $FF: synthetic method
   public boolean isInstance(Object p_isInstance_1_) {
      return this.getTargetClass() == null ? false : this.getTargetClass().isInstance(p_isInstance_1_);
   }
}
