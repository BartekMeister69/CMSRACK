package net.minecraft.block;

public class BlockDoubleWoodSlab extends BlockWoodSlab {
   // $FF: synthetic method
   public boolean isDouble() {
      return true;
   }
}
