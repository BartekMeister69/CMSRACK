package net.minecraft.block;

public class BlockButtonStone extends BlockButton {
   // $FF: synthetic method
   protected BlockButtonStone() {
      super(false);
   }
}
