package net.minecraft.block;

import net.minecraft.init.Items;
import net.minecraft.item.Item;

public class BlockCarrot extends BlockCrops {
   // $FF: synthetic method
   protected Item getCrop() {
      return Items.carrot;
   }

   // $FF: synthetic method
   protected Item getSeed() {
      return Items.carrot;
   }
}
