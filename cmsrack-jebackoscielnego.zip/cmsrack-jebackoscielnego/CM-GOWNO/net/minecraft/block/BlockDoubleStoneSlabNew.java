package net.minecraft.block;

public class BlockDoubleStoneSlabNew extends BlockStoneSlabNew {
   // $FF: synthetic method
   public boolean isDouble() {
      return true;
   }
}
