package net.minecraft.block;

public class BlockDoubleStoneSlab extends BlockStoneSlab {
   // $FF: synthetic method
   public boolean isDouble() {
      return true;
   }
}
