package net.minecraft.block;

import net.minecraft.util.BlockPos;

public class BlockEventData {
   // $FF: synthetic field
   private int eventID;
   // $FF: synthetic field
   private Block blockType;
   // $FF: synthetic field
   private BlockPos position;
   // $FF: synthetic field
   private int eventParameter;

   // $FF: synthetic method
   public int getEventID() {
      return this.eventID;
   }

   // $FF: synthetic method
   public boolean equals(Object p_equals_1_) {
      if (!(p_equals_1_ instanceof BlockEventData)) {
         return false;
      } else {
         BlockEventData blockeventdata = (BlockEventData)p_equals_1_;
         return this.position.equals(blockeventdata.position) && this.eventID == blockeventdata.eventID && this.eventParameter == blockeventdata.eventParameter && this.blockType == blockeventdata.blockType;
      }
   }

   // $FF: synthetic method
   public BlockEventData(BlockPos pos, Block blockType, int eventId, int p_i45756_4_) {
      this.position = pos;
      this.eventID = eventId;
      this.eventParameter = p_i45756_4_;
      this.blockType = blockType;
   }

   // $FF: synthetic method
   public BlockPos getPosition() {
      return this.position;
   }

   // $FF: synthetic method
   public int getEventParameter() {
      return this.eventParameter;
   }

   // $FF: synthetic method
   public Block getBlock() {
      return this.blockType;
   }

   // $FF: synthetic method
   public String toString() {
      return "TE(" + this.position + ")," + this.eventID + "," + this.eventParameter + "," + this.blockType;
   }
}
