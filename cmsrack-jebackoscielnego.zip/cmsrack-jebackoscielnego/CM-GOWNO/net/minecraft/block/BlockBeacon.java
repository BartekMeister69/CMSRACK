package net.minecraft.block;

import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.stats.StatList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityBeacon;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumWorldBlockLayer;
import net.minecraft.util.HttpUtil;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraft.world.chunk.Chunk;

public class BlockBeacon extends BlockContainer {
   // $FF: synthetic method
   public void onBlockPlacedBy(World worldIn, BlockPos pos, IBlockState state, EntityLivingBase placer, ItemStack stack) {
      super.onBlockPlacedBy(worldIn, pos, state, placer, stack);
      if (stack.hasDisplayName()) {
         TileEntity tileentity = worldIn.getTileEntity(pos);
         if (tileentity instanceof TileEntityBeacon) {
            ((TileEntityBeacon)tileentity).setName(stack.getDisplayName());
         }
      }

   }

   // $FF: synthetic method
   public TileEntity createNewTileEntity(World worldIn, int meta) {
      return new TileEntityBeacon();
   }

   // $FF: synthetic method
   public static void updateColorAsync(World worldIn, BlockPos glassPos) {
      HttpUtil.field_180193_a.submit(new Runnable(worldIn, glassPos) {
         final World val$worldIn;
         final BlockPos val$glassPos;

         // $FF: synthetic method
         public void run() {
            Chunk chunk = this.val$worldIn.getChunkFromBlockCoords(this.val$glassPos);

            for(int i = this.val$glassPos.getY() - 1; i >= 0; --i) {
               BlockPos blockpos = new BlockPos(this.val$glassPos.getX(), i, this.val$glassPos.getZ());
               if (!chunk.canSeeSky(blockpos)) {
                  break;
               }

               IBlockState iblockstate = this.val$worldIn.getBlockState(blockpos);
               if (iblockstate.getBlock() == Blocks.beacon) {
                  ((WorldServer)this.val$worldIn).addScheduledTask(new Runnable(this, blockpos) {
                     final BlockPos val$blockpos;
                     final <undefinedtype> this$0;

                     // $FF: synthetic method
                     {
                        this.this$0 = this$0;
                        this.val$blockpos = var2;
                     }

                     // $FF: synthetic method
                     public void run() {
                        TileEntity tileentity = this.this$0.val$worldIn.getTileEntity(this.val$blockpos);
                        if (tileentity instanceof TileEntityBeacon) {
                           ((TileEntityBeacon)tileentity).updateBeacon();
                           this.this$0.val$worldIn.addBlockEvent(this.val$blockpos, Blocks.beacon, 1, 0);
                        }

                     }
                  });
               }
            }

         }

         // $FF: synthetic method
         {
            this.val$worldIn = var1;
            this.val$glassPos = var2;
         }
      });
   }

   // $FF: synthetic method
   public BlockBeacon() {
      super(Material.glass, MapColor.diamondColor);
      this.setHardness(3.0F);
      this.setCreativeTab(CreativeTabs.tabMisc);
   }

   // $FF: synthetic method
   public int getRenderType() {
      return 3;
   }

   // $FF: synthetic method
   public boolean isFullCube() {
      return false;
   }

   // $FF: synthetic method
   public EnumWorldBlockLayer getBlockLayer() {
      return EnumWorldBlockLayer.CUTOUT;
   }

   // $FF: synthetic method
   public boolean onBlockActivated(World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumFacing side, float hitX, float hitY, float hitZ) {
      if (worldIn.isRemote) {
         return true;
      } else {
         TileEntity tileentity = worldIn.getTileEntity(pos);
         if (tileentity instanceof TileEntityBeacon) {
            playerIn.displayGUIChest((TileEntityBeacon)tileentity);
            playerIn.triggerAchievement(StatList.field_181730_N);
         }

         return true;
      }
   }

   // $FF: synthetic method
   public void onNeighborBlockChange(World worldIn, BlockPos pos, IBlockState state, Block neighborBlock) {
      TileEntity tileentity = worldIn.getTileEntity(pos);
      if (tileentity instanceof TileEntityBeacon) {
         ((TileEntityBeacon)tileentity).updateBeacon();
         worldIn.addBlockEvent(pos, this, 1, 0);
      }

   }

   // $FF: synthetic method
   public boolean isOpaqueCube() {
      return false;
   }
}
