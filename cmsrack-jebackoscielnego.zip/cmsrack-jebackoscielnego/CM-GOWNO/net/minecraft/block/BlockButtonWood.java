package net.minecraft.block;

public class BlockButtonWood extends BlockButton {
   // $FF: synthetic method
   protected BlockButtonWood() {
      super(true);
   }
}
