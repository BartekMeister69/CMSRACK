package net.minecraft.block;

import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.world.World;

public class BlockAir extends Block {
   // $FF: synthetic method
   public void dropBlockAsItemWithChance(World worldIn, BlockPos pos, IBlockState state, float chance, int fortune) {
   }

   // $FF: synthetic method
   public boolean canCollideCheck(IBlockState state, boolean hitIfLiquid) {
      return false;
   }

   // $FF: synthetic method
   public boolean isReplaceable(World worldIn, BlockPos pos) {
      return true;
   }

   // $FF: synthetic method
   protected BlockAir() {
      super(Material.air);
   }

   // $FF: synthetic method
   public int getRenderType() {
      return -1;
   }

   // $FF: synthetic method
   public AxisAlignedBB getCollisionBoundingBox(World worldIn, BlockPos pos, IBlockState state) {
      return null;
   }

   // $FF: synthetic method
   public boolean isOpaqueCube() {
      return false;
   }
}
