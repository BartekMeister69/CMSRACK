package net.minecraftforge.client.model;

import javax.vecmath.Matrix4f;
import net.minecraft.util.EnumFacing;

public interface ITransformation {
   // $FF: synthetic method
   int rotate(EnumFacing var1, int var2);

   // $FF: synthetic method
   Matrix4f getMatrix();

   // $FF: synthetic method
   EnumFacing rotate(EnumFacing var1);
}
