import com.google.common.collect.Lists;
import java.util.List;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;

class jebac_vexiaqkbxv1zazazp extends Container {
   // $FF: synthetic field
   public List itemList = Lists.newArrayList();

   // $FF: synthetic method
   public ItemStack transferStackInSlot(EntityPlayer playerIn, int index) {
      if (index >= this.inventorySlots.size() - 9 && index < this.inventorySlots.size()) {
         Slot slot = (Slot)this.inventorySlots.get(index);
         if (slot != null && slot.getHasStack()) {
            slot.putStack((ItemStack)null);
         }
      }

      return null;
   }

   // $FF: synthetic method
   public void scrollTo(float p_148329_1_) {
      int i = (this.itemList.size() + 9 - 1) / 9 - 5;
      int j = (int)((double)(p_148329_1_ * (float)i) + 0.5D);
      if (j < 0) {
         j = 0;
      }

      for(int k = 0; k < 5; ++k) {
         for(int l = 0; l < 9; ++l) {
            int i1 = l + (k + j) * 9;
            if (i1 >= 0 && i1 < this.itemList.size()) {
               jebac_vexiaenf0dnsihb5s.access$100().setInventorySlotContents(l + k * 9, (ItemStack)this.itemList.get(i1));
            } else {
               jebac_vexiaenf0dnsihb5s.access$100().setInventorySlotContents(l + k * 9, (ItemStack)null);
            }
         }
      }

   }

   // $FF: synthetic method
   public boolean canMergeSlot(ItemStack stack, Slot p_94530_2_) {
      return p_94530_2_.yDisplayPosition > 90;
   }

   // $FF: synthetic method
   public jebac_vexiaqkbxv1zazazp(EntityPlayer p_i1086_1_) {
      InventoryPlayer inventoryplayer = p_i1086_1_.inventory;

      int k;
      for(k = 0; k < 5; ++k) {
         for(int j = 0; j < 9; ++j) {
            this.addSlotToContainer(new Slot(jebac_vexiaenf0dnsihb5s.access$100(), k * 9 + j, 9 + j * 18, 18 + k * 18));
         }
      }

      for(k = 0; k < 9; ++k) {
         this.addSlotToContainer(new Slot(inventoryplayer, k, 9 + k * 18, 112));
      }

      this.scrollTo(0.0F);
   }

   // $FF: synthetic method
   public boolean canDragIntoSlot(Slot p_94531_1_) {
      return p_94531_1_.inventory instanceof InventoryPlayer || p_94531_1_.yDisplayPosition > 90 && p_94531_1_.xDisplayPosition <= 162;
   }

   // $FF: synthetic method
   public boolean func_148328_e() {
      return this.itemList.size() > 45;
   }

   // $FF: synthetic method
   protected void retrySlotClick(int slotId, int clickedButton, boolean mode, EntityPlayer playerIn) {
   }

   // $FF: synthetic method
   public boolean canInteractWith(EntityPlayer playerIn) {
      return true;
   }
}
