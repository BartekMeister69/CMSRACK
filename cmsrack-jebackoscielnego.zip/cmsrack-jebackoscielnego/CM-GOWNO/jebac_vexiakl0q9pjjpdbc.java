import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import org.lwjgl.input.Keyboard;

public class jebac_vexiakl0q9pjjpdbc {
   private int  co;
   private long  cs;
   private static final int[]  cu;
   private double  cv;
   private final KeyBinding  cq;
   private boolean  ct;
   private final int  cr;
   private final int  cp;

   // $FF: synthetic method
   private static void llllIlII() {
       cu = new int[8];
       cu[0] = jebac_vexiaqb58506wt8o3.  ‏ ("䠹", 1147291673).length();
       cu[1] = 153 + 149 - 85 + 38;
       cu[2] = (71 ^ 74) & ~(187 ^ 182);
       cu[3] = 113 + 36 - 47 + 60 ^ 70 + 25 - 15 + 100;
       cu[4] = -28788 & 2013294707;
       cu[5] = 87 ^ 18 ^ 250 ^ 175;
       cu[6] = 62 ^ 26 ^ 130 ^ 174;
       cu[7] = -(-(-2117 & 8175) & -2049 & 16785322);
   }

   static {
      llllIlII();
   }

   // $FF: synthetic method
   private static boolean llllIllI(int var0) {
      return var0 != 0;
   }

   // $FF: synthetic method
   private static boolean llllIlIl(int var0, int var1) {
      return var0 != var1;
   }

   // $FF: synthetic method
   public void render(int var1, int var2, Color var3) {
      String var4 = this. cq.isKeyDown();
      Color var5 = Keyboard.getKeyName(this. cq.getKeyCode());
      if (llllIlIl(var4, this. ct)) {
         this. ct = (boolean)var4;
         this. cs = System.currentTimeMillis();
      }

      if (llllIllI(var4)) {
         this. co = Math.min( cu[1], (int)(2L * (System.currentTimeMillis() - this. cs)));
         this. cv = Math.max(0.0D, 1.0D - (double)(System.currentTimeMillis() - this. cs) / 20.0D);
         jebac_vexiaqb58506wt8o3.  ‏ ("", 1277947031).length();
         if (null != null) {
            return;
         }
      } else {
         this. co = Math.max( cu[2],  cu[1] - (int)(2L * (System.currentTimeMillis() - this. cs)));
         this. cv = Math.min(1.0D, (double)(System.currentTimeMillis() - this. cs) / 20.0D);
      }

      jebac_vexiabhi02xzapwrh.drawRect(var1 + this. cr, var2 + this. cp, var1 + this. cr +  cu[3], var2 + this. cp +  cu[3],  cu[4] + (this. co <<  cu[5]) + (this. co <<  cu[6]) + this. co);
      long var6 = var3.getRed();
      int var7 = var3.getGreen();
      String var8 = var3.getBlue();
      int var10002 = var1 + this. cr +  cu[6];
      int var10003 = var2 + this. cp +  cu[6];
      int var10004 =  cu[7] + ((int)((double)var6 * this. cv) <<  cu[5]) + ((int)((double)var7 * this. cv) <<  cu[6]);
      int var10005 = (int)((double)var8 * this. cv);
      Minecraft.getMinecraft().fontRendererObj.drawString(var5, var10002, var10003, var10004 + var10005);
      jebac_vexiaqb58506wt8o3.  ‏ ("", -333782182).length();
   }

   // $FF: synthetic method
   jebac_vexiakl0q9pjjpdbc(KeyBinding var1, int var2, int var3) {
      this. cq = var1;
      this. cr = var2;
      this. cp = var3;
      this. ct = (boolean) cu[0];
      this. cs = 0L;
      this. co =  cu[1];
      this. cv = 1.0D;
   }
}
