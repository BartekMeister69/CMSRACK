import net.minecraft.util.IChatComponent;

public interface jebac_vexia9nzh0zm3n32z {
   // $FF: synthetic method
   void func_178663_a(float var1, int var2);

   // $FF: synthetic method
   void func_178661_a(jebac_vexiabhmyylutxyzx var1);

   // $FF: synthetic method
   IChatComponent getSpectatorName();

   // $FF: synthetic method
   boolean func_178662_A_();
}
