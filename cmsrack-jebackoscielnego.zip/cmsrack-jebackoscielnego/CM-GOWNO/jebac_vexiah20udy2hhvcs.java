import java.awt.Color;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;

public class jebac_vexiah20udy2hhvcs {
   private final KeyBinding  iw;
   private int  jc;
   private static final String[]  iz;
   private double  ja;
   private static final int[]  ix;
   private long  iv;
   private boolean  iy;
   private final int  jb;
   private final int  jd;

   // $FF: synthetic method
   private static void lllIlIII() {
       iz = new String[ ix[0]];
       iz[ ix[2]] = lllIIlll(jebac_vexiaqb58506wt8o3.  ‏ ("绖统纗纻绅纈纠绘纴统纡纄纟纙纥给纅纍纊绁给线结结", -1332969746), jebac_vexiaqb58506wt8o3.  ‏ ("ќхцўу", 1328874537));
   }

   // $FF: synthetic method
   jebac_vexiah20udy2hhvcs(KeyBinding var1, int var2, int var3) {
      this. iw = var1;
      this. jd = var2;
      this. jb = var3;
      this. iy = (boolean) ix[0];
      this. iv = 0L;
      this. jc =  ix[1];
      this. ja = 1.0D;
   }

   // $FF: synthetic method
   public void render(int var1, int var2, Color var3) {
      Color var4 = this. iw.isKeyDown();
      if (lllIllII(var4, this. iy)) {
         this. iy = (boolean)var4;
         this. iv = System.currentTimeMillis();
      }

      if (lllIllIl(var4)) {
         this. jc = Math.min( ix[1], (int)(2L * (System.currentTimeMillis() - this. iv)));
         this. ja = Math.max(0.0D, 1.0D - (double)(System.currentTimeMillis() - this. iv) / 20.0D);
         jebac_vexiaqb58506wt8o3.  ‏ ("", 24509698).length();
         if (jebac_vexiaqb58506wt8o3.  ‏ ("盃盃盃", 1166505699).length() < 0) {
            return;
         }
      } else {
         this. jc = Math.max( ix[2],  ix[1] - (int)(2L * (System.currentTimeMillis() - this. iv)));
         this. ja = Math.min(1.0D, (double)(System.currentTimeMillis() - this. iv) / 20.0D);
      }

      jebac_vexiabhi02xzapwrh.drawRect(var1 + this. jd, var2 + this. jb, var1 + this. jd +  ix[3], var2 + this. jb +  ix[4],  ix[5] + (this. jc <<  ix[4]) + (this. jc <<  ix[6]) + this. jc);
      int var5 = var3.getRed();
      int var6 = var3.getGreen();
      String var7 = var3.getBlue();
      String var10001 =  iz[ ix[2]];
      int var10002 = var1 + this. jd +  ix[7];
      int var10003 = var2 + this. jb +  ix[8];
      int var10004 =  ix[9] + ((int)((double)var5 * this. ja) <<  ix[4]) + ((int)((double)var6 * this. ja) <<  ix[6]);
      int var10005 = (int)((double)var7 * this. ja);
      Minecraft.getMinecraft().fontRendererObj.drawString(var10001, var10002, var10003, var10004 + var10005);
      jebac_vexiaqb58506wt8o3.  ‏ ("", 467435125).length();
   }

   // $FF: synthetic method
   private static boolean lllIllII(int var0, int var1) {
      return var0 != var1;
   }

   // $FF: synthetic method
   private static String lllIIlll(String var0, String var1) {
      try {
         String var2 = new SecretKeySpec(MessageDigest.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("䫸䫱䪀", -1346024779)).digest(var1.getBytes(StandardCharsets.UTF_8)), jebac_vexiaqb58506wt8o3.  ‏ ("䠔䠺䠹䠡䠰䠿䠥䠾", -1345566634));
         String var3 = Cipher.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("鞖鞸鞻鞣鞲鞽鞧鞼", 114726868));
         var3.init( ix[10], var2);
         return new String(var3.doFinal(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var9) {
         var9.printStackTrace();
         return null;
      }
   }

   // $FF: synthetic method
   private static void lllIlIll() {
       ix = new int[11];
       ix[0] = jebac_vexiaqb58506wt8o3.  ‏ ("餌", 899455276).length();
       ix[1] = 227 + 113 - 100 + 15;
       ix[2] = (218 ^ 167 ^ 193 ^ 187) & (13 + 13 - -14 + 147 ^ 171 + 69 - 225 + 173 ^ -jebac_vexiaqb58506wt8o3.  ‏ ("ｒ", 323157874).length());
       ix[3] = 99 ^ 37;
       ix[4] = 108 ^ 124;
       ix[5] = -12425 & 2013278344;
       ix[6] = 64 ^ 72;
       ix[7] = 152 ^ 140;
       ix[8] = 64 + 48 - -32 + 22 ^ 16 + 69 - 70 + 147;
       ix[9] = -(-3070 & 16780285);
       ix[10] = jebac_vexiaqb58506wt8o3.  ‏ ("ꝤꝤ", 1270654788).length();
   }

   // $FF: synthetic method
   private static boolean lllIllIl(int var0) {
      return var0 != 0;
   }

   static {
      lllIlIll();
      lllIlIII();
   }
}
