import java.util.Map;

public class jebac_vexiahx0fynbv9rl1 {
   // $FF: synthetic field
   private int status;
   // $FF: synthetic field
   private byte[] body;
   // $FF: synthetic field
   private Map headers;

   // $FF: synthetic method
   public String getHeader(String p_getHeader_1_) {
      return (String)this.headers.get(p_getHeader_1_);
   }

   // $FF: synthetic method
   public int getStatus() {
      return this.status;
   }

   // $FF: synthetic method
   public byte[] getBody() {
      return this.body;
   }

   // $FF: synthetic method
   public jebac_vexiahx0fynbv9rl1(int p_i61_1_, Map p_i61_3_, byte[] p_i61_4_) {
      this.status = p_i61_1_;
      this.headers = p_i61_3_;
      this.body = p_i61_4_;
   }
}
