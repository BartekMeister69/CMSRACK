import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

public class jebac_vexiad5ih6npt6tn4 {
   // $FF: synthetic field
   private String targetMethodName;
   // $FF: synthetic field
   private jebac_vexiajs8ej2dllnvc reflectorClass;
   // $FF: synthetic field
   private Class[] targetMethodParameterTypes;
   // $FF: synthetic field
   private Method targetMethod;
   // $FF: synthetic field
   private boolean checked;

   // $FF: synthetic method
   public jebac_vexiad5ih6npt6tn4(jebac_vexiajs8ej2dllnvc p_i93_1_, String p_i93_2_, Class[] p_i93_3_, boolean p_i93_4_) {
      this.reflectorClass = null;
      this.targetMethodName = null;
      this.targetMethodParameterTypes = null;
      this.checked = false;
      this.targetMethod = null;
      this.reflectorClass = p_i93_1_;
      this.targetMethodName = p_i93_2_;
      this.targetMethodParameterTypes = p_i93_3_;
      if (!p_i93_4_) {
         Method var5 = this.getTargetMethod();
      }

   }

   // $FF: synthetic method
   public jebac_vexiad5ih6npt6tn4(jebac_vexiajs8ej2dllnvc p_i91_1_, String p_i91_2_) {
      this(p_i91_1_, p_i91_2_, (Class[])null, false);
   }

   // $FF: synthetic method
   public boolean exists() {
      return this.checked ? this.targetMethod != null : this.getTargetMethod() != null;
   }

   // $FF: synthetic method
   public static Method[] getMethods(Class p_getMethods_0_, String p_getMethods_1_) {
      List list = new ArrayList();
      Method[] amethod = p_getMethods_0_.getDeclaredMethods();

      for(int i = 0; i < amethod.length; ++i) {
         Method method = amethod[i];
         if (method.getName().equals(p_getMethods_1_)) {
            list.add(method);
         }
      }

      Method[] amethod1 = (Method[])((Method[])((Method[])list.toArray(new Method[list.size()])));
      return amethod1;
   }

   // $FF: synthetic method
   public void deactivate() {
      this.checked = true;
      this.targetMethod = null;
   }

   // $FF: synthetic method
   public jebac_vexiad5ih6npt6tn4(jebac_vexiajs8ej2dllnvc p_i92_1_, String p_i92_2_, Class[] p_i92_3_) {
      this(p_i92_1_, p_i92_2_, p_i92_3_, false);
   }

   // $FF: synthetic method
   public Method getTargetMethod() {
      if (this.checked) {
         return this.targetMethod;
      } else {
         this.checked = true;
         Class oclass = this.reflectorClass.getTargetClass();
         if (oclass == null) {
            return null;
         } else {
            try {
               if (this.targetMethodParameterTypes == null) {
                  Method[] amethod = getMethods(oclass, this.targetMethodName);
                  if (amethod.length <= 0) {
                     jebac_vexiakrwecfs16wve.log("(Reflector) Method not present: " + oclass.getName() + "." + this.targetMethodName);
                     return null;
                  }

                  if (amethod.length > 1) {
                     jebac_vexiakrwecfs16wve.warn("(Reflector) More than one method found: " + oclass.getName() + "." + this.targetMethodName);

                     for(int i = 0; i < amethod.length; ++i) {
                        Method method = amethod[i];
                        jebac_vexiakrwecfs16wve.warn("(Reflector)  - " + method);
                     }

                     return null;
                  }

                  this.targetMethod = amethod[0];
               } else {
                  this.targetMethod = getMethod(oclass, this.targetMethodName, this.targetMethodParameterTypes);
               }

               if (this.targetMethod == null) {
                  jebac_vexiakrwecfs16wve.log("(Reflector) Method not present: " + oclass.getName() + "." + this.targetMethodName);
                  return null;
               } else {
                  this.targetMethod.setAccessible(true);
                  return this.targetMethod;
               }
            } catch (Throwable var5) {
               var5.printStackTrace();
               return null;
            }
         }
      }
   }

   // $FF: synthetic method
   public Class getReturnType() {
      Method method = this.getTargetMethod();
      return method == null ? null : method.getReturnType();
   }

   // $FF: synthetic method
   public static Method getMethod(Class p_getMethod_0_, String p_getMethod_1_, Class[] p_getMethod_2_) {
      Method[] amethod = p_getMethod_0_.getDeclaredMethods();

      for(int i = 0; i < amethod.length; ++i) {
         Method method = amethod[i];
         if (method.getName().equals(p_getMethod_1_)) {
            Class[] aclass = method.getParameterTypes();
            if (jebac_vexiawp5rpzl0e6ma.matchesTypes(p_getMethod_2_, aclass)) {
               return method;
            }
         }
      }

      return null;
   }
}
