import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.GameSettings;

public class jebac_vexiapguljx25lc0b {
   // $FF: synthetic field
   private int lastMouseX = 0;
   // $FF: synthetic field
   private jebac_vexiakl614w3uw0xg guiScreen;
   // $FF: synthetic field
   private int lastMouseY = 0;
   // $FF: synthetic field
   private long mouseStillTime = 0L;

   // $FF: synthetic method
   private jebac_vexia4oibzo50ubf0 getSelectedButton(int p_getSelectedButton_1_, int p_getSelectedButton_2_, List p_getSelectedButton_3_) {
      Iterator var4 = p_getSelectedButton_3_.iterator();

      jebac_vexia4oibzo50ubf0 guibutton;
      boolean flag;
      do {
         if (!var4.hasNext()) {
            return null;
         }

         Object o = var4.next();
         guibutton = (jebac_vexia4oibzo50ubf0)o;
         int j = jebac_vexiahqnin1pyjn10.getButtonWidth(guibutton);
         int k = jebac_vexiahqnin1pyjn10.getButtonHeight(guibutton);
         flag = p_getSelectedButton_1_ >= guibutton.xPosition && p_getSelectedButton_2_ >= guibutton.yPosition && p_getSelectedButton_1_ < guibutton.xPosition + j && p_getSelectedButton_2_ < guibutton.yPosition + k;
      } while(!flag);

      return guibutton;
   }

   // $FF: synthetic method
   public void drawTooltips(int p_drawTooltips_1_, int p_drawTooltips_2_, List p_drawTooltips_3_) {
      if (Math.abs(p_drawTooltips_1_ - this.lastMouseX) <= 5 && Math.abs(p_drawTooltips_2_ - this.lastMouseY) <= 5) {
         int i = 700;
         if (System.currentTimeMillis() >= this.mouseStillTime + (long)i) {
            int j = this.guiScreen.width / 2 - 150;
            int k = this.guiScreen.height / 6 - 7;
            if (p_drawTooltips_2_ <= k + 98) {
               k += 105;
            }

            int l = j + 150 + 150;
            int i1 = k + 84 + 10;
            jebac_vexia4oibzo50ubf0 guibutton = this.getSelectedButton(p_drawTooltips_1_, p_drawTooltips_2_, p_drawTooltips_3_);
            if (guibutton instanceof jebac_vexia7qn8thb33dce) {
               jebac_vexia7qn8thb33dce ioptioncontrol = (jebac_vexia7qn8thb33dce)guibutton;
               GameSettings.Options gamesettings$options = ioptioncontrol.getOption();
               String[] astring = getTooltipLines(gamesettings$options);
               if (astring == null) {
                  return;
               }

               jebac_vexiahqnin1pyjn10.drawGradientRect(this.guiScreen, j, k, l, i1, -536870912, -536870912);

               for(int j1 = 0; j1 < astring.length; ++j1) {
                  String s = astring[j1];
                  int k1 = 14540253;
                  if (s.endsWith("!")) {
                     k1 = 16719904;
                  }

                  jebac_vexiav0ttj7we8byq fontrenderer = Minecraft.getMinecraft().fontRendererObj;
                  fontrenderer.drawStringWithShadow(s, (float)(j + 5), (float)(k + 5 + j1 * 11), k1);
               }
            }
         }
      } else {
         this.lastMouseX = p_drawTooltips_1_;
         this.lastMouseY = p_drawTooltips_2_;
         this.mouseStillTime = System.currentTimeMillis();
      }

   }

   // $FF: synthetic method
   private static String[] getTooltipLines(GameSettings.Options p_getTooltipLines_0_) {
      return getTooltipLines(p_getTooltipLines_0_.getEnumString());
   }

   // $FF: synthetic method
   public jebac_vexiapguljx25lc0b(jebac_vexiakl614w3uw0xg p_i97_1_) {
      this.guiScreen = p_i97_1_;
   }

   // $FF: synthetic method
   private static String[] getTooltipLines(String p_getTooltipLines_0_) {
      List list = new ArrayList();

      for(int i = 0; i < 10; ++i) {
         String s = p_getTooltipLines_0_ + ".tooltip." + (i + 1);
         String s1 = jebac_vexia7gzdvsc1kfyf.get(s, (String)null);
         if (s1 == null) {
            break;
         }

         list.add(s1);
      }

      return list.size() <= 0 ? null : (String[])list.toArray(new String[0]);
   }
}
