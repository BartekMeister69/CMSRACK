import net.minecraft.client.resources.I18n;

public class jebac_vexiaw7psy44d35ek implements jebac_vexia68uke90d57nv {
   // $FF: synthetic field
   private final int labelWidth;
   final jebac_vexiac2ntje0zuqwe this$0;
   // $FF: synthetic field
   private final String labelText;

   // $FF: synthetic method
   public jebac_vexiaw7psy44d35ek(jebac_vexiac2ntje0zuqwe this$0, String p_i45028_2_) {
      this.this$0 = this$0;
      this.labelText = I18n.format(p_i45028_2_);
      this.labelWidth = jebac_vexiac2ntje0zuqwe.access$100(this$0).fontRendererObj.getStringWidth(this.labelText);
   }

   // $FF: synthetic method
   public void mouseReleased(int slotIndex, int x, int y, int mouseEvent, int relativeX, int relativeY) {
   }

   // $FF: synthetic method
   public void drawEntry(int slotIndex, int x, int y, int listWidth, int slotHeight, int mouseX, int mouseY, boolean isSelected) {
      jebac_vexiac2ntje0zuqwe.access$100(this.this$0).fontRendererObj.drawString(this.labelText, jebac_vexiac2ntje0zuqwe.access$100(this.this$0).currentScreen.width / 2 - this.labelWidth / 2, y + slotHeight - jebac_vexiac2ntje0zuqwe.access$100(this.this$0).fontRendererObj.FONT_HEIGHT - 1, 16777215);
   }

   // $FF: synthetic method
   public void setSelected(int p_178011_1_, int p_178011_2_, int p_178011_3_) {
   }

   // $FF: synthetic method
   public boolean mousePressed(int slotIndex, int p_148278_2_, int p_148278_3_, int p_148278_4_, int p_148278_5_, int p_148278_6_) {
      return false;
   }
}
