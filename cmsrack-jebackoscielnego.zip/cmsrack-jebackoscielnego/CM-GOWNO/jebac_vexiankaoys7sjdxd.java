import java.util.Properties;
import org.apache.commons.lang3.ArrayUtils;

public class jebac_vexiankaoys7sjdxd {
   // $FF: synthetic field
   private int value = 0;
   // $FF: synthetic field
   private int[] values = null;
   // $FF: synthetic field
   private String propertyName = null;
   // $FF: synthetic field
   private String[] propertyValues = null;
   // $FF: synthetic field
   private String userName = null;
   // $FF: synthetic field
   private String[] userValues = null;
   // $FF: synthetic field
   private int defaultValue = 0;

   // $FF: synthetic method
   public String getUserName() {
      return this.userName;
   }

   // $FF: synthetic method
   public int getValue() {
      return this.value;
   }

   // $FF: synthetic method
   public String toString() {
      return "" + this.propertyName + "=" + this.getPropertyValue() + " [" + jebac_vexiakrwecfs16wve.arrayToString((Object[])this.propertyValues) + "], value: " + this.value;
   }

   // $FF: synthetic method
   public String getUserValue() {
      return this.userValues[this.value];
   }

   // $FF: synthetic method
   public jebac_vexiankaoys7sjdxd(String propertyName, String[] propertyValues, String userName, String[] userValues, int defaultValue) {
      this.propertyName = propertyName;
      this.propertyValues = propertyValues;
      this.userName = userName;
      this.userValues = userValues;
      this.defaultValue = defaultValue;
      if (propertyValues.length != userValues.length) {
         throw new IllegalArgumentException("Property and user values have different lengths: " + propertyValues.length + " != " + userValues.length);
      } else if (defaultValue >= 0 && defaultValue < propertyValues.length) {
         this.value = defaultValue;
      } else {
         throw new IllegalArgumentException("Invalid default value: " + defaultValue);
      }
   }

   // $FF: synthetic method
   public String getPropertyValue() {
      return this.propertyValues[this.value];
   }

   // $FF: synthetic method
   public void resetValue() {
      this.value = this.defaultValue;
   }

   // $FF: synthetic method
   public void saveTo(Properties props) {
      if (props != null) {
         props.setProperty(this.getPropertyName(), this.getPropertyValue());
      }

   }

   // $FF: synthetic method
   public boolean loadFrom(Properties props) {
      this.resetValue();
      if (props == null) {
         return false;
      } else {
         String s = props.getProperty(this.propertyName);
         return s == null ? false : this.setPropertyValue(s);
      }
   }

   // $FF: synthetic method
   public void nextValue() {
      ++this.value;
      if (this.value < 0 || this.value >= this.propertyValues.length) {
         this.value = 0;
      }

   }

   // $FF: synthetic method
   public String getPropertyName() {
      return this.propertyName;
   }

   // $FF: synthetic method
   public void setValue(int val) {
      this.value = val;
      if (this.value < 0 || this.value >= this.propertyValues.length) {
         this.value = this.defaultValue;
      }

   }

   // $FF: synthetic method
   public boolean setPropertyValue(String propVal) {
      if (propVal == null) {
         this.value = this.defaultValue;
         return false;
      } else {
         this.value = ArrayUtils.indexOf(this.propertyValues, propVal);
         if (this.value >= 0 && this.value < this.propertyValues.length) {
            return true;
         } else {
            this.value = this.defaultValue;
            return false;
         }
      }
   }
}
