import java.util.Arrays;
import java.util.List;

public abstract class jebac_vexiazrxtvwdcml9w {
   // $FF: synthetic field
   private String value = null;
   // $FF: synthetic field
   private String name = null;
   // $FF: synthetic field
   private String description = null;
   // $FF: synthetic field
   private String[] values = null;
   // $FF: synthetic field
   private String[] paths = null;
   // $FF: synthetic field
   private boolean visible = true;
   // $FF: synthetic field
   private String valueDefault = null;
   // $FF: synthetic field
   private boolean enabled = true;

   // $FF: synthetic method
   public void prevValue() {
      int i = getIndex(this.value, this.values);
      if (i >= 0) {
         i = (i - 1 + this.values.length) % this.values.length;
         this.value = this.values[i];
      }

   }

   // $FF: synthetic method
   public String getValueDefault() {
      return this.valueDefault;
   }

   // $FF: synthetic method
   public String getDescription() {
      return this.description;
   }

   // $FF: synthetic method
   public boolean isVisible() {
      return this.visible;
   }

   // $FF: synthetic method
   public void nextValue() {
      int i = getIndex(this.value, this.values);
      if (i >= 0) {
         i = (i + 1) % this.values.length;
         this.value = this.values[i];
      }

   }

   // $FF: synthetic method
   public String getNameText() {
      return jebac_vexiaflhnh80r1906.translate("option." + this.name, this.name);
   }

   // $FF: synthetic method
   public String[] getPaths() {
      return this.paths;
   }

   // $FF: synthetic method
   public String[] getValues() {
      return (String[])this.values.clone();
   }

   // $FF: synthetic method
   public boolean isChanged() {
      return !jebac_vexiakrwecfs16wve.equals(this.value, this.valueDefault);
   }

   // $FF: synthetic method
   private static int getIndex(String str, String[] strs) {
      for(int i = 0; i < strs.length; ++i) {
         String s = strs[i];
         if (s.equals(str)) {
            return i;
         }
      }

      return -1;
   }

   // $FF: synthetic method
   public void addPaths(String[] newPaths) {
      List list = Arrays.asList(this.paths);

      for(int i = 0; i < newPaths.length; ++i) {
         String s = newPaths[i];
         if (!list.contains(s)) {
            this.paths = (String[])((String[])jebac_vexiakrwecfs16wve.addObjectToArray(this.paths, s));
         }
      }

   }

   // $FF: synthetic method
   public void setDescription(String description) {
      this.description = description;
   }

   // $FF: synthetic method
   public String toString() {
      return "" + this.name + ", value: " + this.value + ", valueDefault: " + this.valueDefault + ", paths: " + jebac_vexiakrwecfs16wve.arrayToString((Object[])this.paths);
   }

   // $FF: synthetic method
   public String getName() {
      return this.name;
   }

   // $FF: synthetic method
   public String getDescriptionText() {
      String s = jebac_vexiakrwecfs16wve.normalize(this.description);
      s = jebac_vexianzkdk43wtdrt.removePrefix(s, "//");
      s = jebac_vexiaflhnh80r1906.translate("option." + this.getName() + ".comment", s);
      return s;
   }

   // $FF: synthetic method
   public String getValueColor(String val) {
      return "";
   }

   // $FF: synthetic method
   public boolean isValidValue(String val) {
      return getIndex(val, this.values) >= 0;
   }

   // $FF: synthetic method
   public String getValue() {
      return this.value;
   }

   // $FF: synthetic method
   public String getSourceLine() {
      return null;
   }

   // $FF: synthetic method
   public boolean matchesLine(String line) {
      return false;
   }

   // $FF: synthetic method
   public boolean checkUsed() {
      return false;
   }

   // $FF: synthetic method
   public void resetValue() {
      this.value = this.valueDefault;
   }

   // $FF: synthetic method
   public boolean isEnabled() {
      return this.enabled;
   }

   // $FF: synthetic method
   public boolean isUsedInLine(String line) {
      return false;
   }

   // $FF: synthetic method
   public boolean setValue(String value) {
      int i = getIndex(value, this.values);
      if (i < 0) {
         return false;
      } else {
         this.value = value;
         return true;
      }
   }

   // $FF: synthetic method
   public void setVisible(boolean visible) {
      this.visible = visible;
   }

   // $FF: synthetic method
   public String getValueText(String val) {
      return jebac_vexiaflhnh80r1906.translate("value." + this.name + "." + val, val);
   }

   // $FF: synthetic method
   public jebac_vexiazrxtvwdcml9w(String name, String description, String value, String[] values, String valueDefault, String path) {
      this.name = name;
      this.description = description;
      this.value = value;
      this.values = values;
      this.valueDefault = valueDefault;
      if (path != null) {
         this.paths = new String[]{path};
      }

   }

   // $FF: synthetic method
   public void setEnabled(boolean enabled) {
      this.enabled = enabled;
   }
}
