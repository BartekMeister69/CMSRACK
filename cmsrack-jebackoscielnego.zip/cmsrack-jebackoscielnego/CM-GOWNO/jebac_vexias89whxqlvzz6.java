import com.google.common.collect.Lists;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.EntityList;

class jebac_vexias89whxqlvzz6 extends jebac_vexiado18oeh2l9bq {
   final jebac_vexiazwfkkk4iev4c this$0;
   // $FF: synthetic field
   private final List field_148222_l;

   // $FF: synthetic method
   protected void elementClicked(int slotIndex, boolean isDoubleClick, int mouseX, int mouseY) {
   }

   // $FF: synthetic method
   protected int getContentHeight() {
      return this.getSize() * jebac_vexiazwfkkk4iev4c.access$1700(this.this$0).FONT_HEIGHT * 4;
   }

   // $FF: synthetic method
   protected int getSize() {
      return this.field_148222_l.size();
   }

   // $FF: synthetic method
   protected boolean isSelected(int slotIndex) {
      return false;
   }

   // $FF: synthetic method
   public jebac_vexias89whxqlvzz6(jebac_vexiazwfkkk4iev4c this$0, Minecraft mcIn) {
      super(mcIn, this$0.width, this$0.height, 32, this$0.height - 64, jebac_vexiazwfkkk4iev4c.access$1600(this$0).FONT_HEIGHT * 4);
      this.this$0 = this$0;
      this.field_148222_l = Lists.newArrayList();
      this.setShowSelectionBox(false);
      Iterator var3 = EntityList.entityEggs.values().iterator();

      while(true) {
         EntityList.EntityEggInfo entitylist$entityegginfo;
         do {
            if (!var3.hasNext()) {
               return;
            }

            entitylist$entityegginfo = (EntityList.EntityEggInfo)var3.next();
         } while(jebac_vexiazwfkkk4iev4c.access$100(this$0).readStat(entitylist$entityegginfo.field_151512_d) <= 0 && jebac_vexiazwfkkk4iev4c.access$100(this$0).readStat(entitylist$entityegginfo.field_151513_e) <= 0);

         this.field_148222_l.add(entitylist$entityegginfo);
      }
   }

   // $FF: synthetic method
   protected void drawBackground() {
      this.this$0.drawDefaultBackground();
   }

   // $FF: synthetic method
   protected void drawSlot(int entryID, int p_180791_2_, int p_180791_3_, int p_180791_4_, int mouseXIn, int mouseYIn) {
      EntityList.EntityEggInfo entitylist$entityegginfo = (EntityList.EntityEggInfo)this.field_148222_l.get(entryID);
      String s = I18n.format("entity." + EntityList.getStringFromID(entitylist$entityegginfo.spawnedID) + ".name");
      int i = jebac_vexiazwfkkk4iev4c.access$100(this.this$0).readStat(entitylist$entityegginfo.field_151512_d);
      int j = jebac_vexiazwfkkk4iev4c.access$100(this.this$0).readStat(entitylist$entityegginfo.field_151513_e);
      String s1 = I18n.format("stat.entityKills", i, s);
      String s2 = I18n.format("stat.entityKilledBy", s, j);
      if (i == 0) {
         s1 = I18n.format("stat.entityKills.none", s);
      }

      if (j == 0) {
         s2 = I18n.format("stat.entityKilledBy.none", s);
      }

      this.this$0.drawString(jebac_vexiazwfkkk4iev4c.access$1800(this.this$0), s, p_180791_2_ + 2 - 10, p_180791_3_ + 1, 16777215);
      this.this$0.drawString(jebac_vexiazwfkkk4iev4c.access$1900(this.this$0), s1, p_180791_2_ + 2, p_180791_3_ + 1 + jebac_vexiazwfkkk4iev4c.access$2000(this.this$0).FONT_HEIGHT, i == 0 ? 6316128 : 9474192);
      this.this$0.drawString(jebac_vexiazwfkkk4iev4c.access$2100(this.this$0), s2, p_180791_2_ + 2, p_180791_3_ + 1 + jebac_vexiazwfkkk4iev4c.access$2200(this.this$0).FONT_HEIGHT * 2, j == 0 ? 6316128 : 9474192);
   }
}
