import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;

class jebac_vexiamkdihqtorvw3 extends jebac_vexia4oibzo50ubf0 {
   // $FF: synthetic field
   private final boolean field_146157_o;

   // $FF: synthetic method
   public void drawButton(Minecraft mc, int mouseX, int mouseY) {
      if (this.visible) {
         mc.getTextureManager().bindTexture(jebac_vexiacup81daarjub.access$000());
         GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
         boolean flag = mouseX >= this.xPosition && mouseY >= this.yPosition && mouseX < this.xPosition + this.width && mouseY < this.yPosition + this.height;
         int i = 0;
         int j = 176;
         if (!this.enabled) {
            j += this.width * 2;
         } else if (flag) {
            j += this.width;
         }

         if (!this.field_146157_o) {
            i += this.height;
         }

         this.drawTexturedModalRect(this.xPosition, this.yPosition, j, i, this.width, this.height);
      }

   }

   // $FF: synthetic method
   public jebac_vexiamkdihqtorvw3(int buttonID, int x, int y, boolean p_i1095_4_) {
      super(buttonID, x, y, 12, 19, "");
      this.field_146157_o = p_i1095_4_;
   }
}
