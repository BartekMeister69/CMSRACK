public interface jebac_vexias8mqy4rid1g7 {
   // $FF: synthetic field
   String[] lanSearchStates = new String[]{"oooooo", "Oooooo", "oOoooo", "ooOooo", "oooOoo", "ooooOo", "oooooO"};

   // $FF: synthetic method
   void doneLoading();
}
