import java.awt.Color;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import org.lwjgl.opengl.GL11;

public class jebac_vexia5c4je8aazc78 {
   public int  fk;
   public int  fn;
   private int  fi;
   public int  fp;
   public int  fo;
   private int  fv;
   public boolean  fr;
   private static final String[]  ft;
   public boolean  fw;
   private final Minecraft  fs;
   public boolean  fu;
   public int  fm;
   private static final int[]  fj;
   private int  fl;
   private int  fq;

   // $FF: synthetic method
   private static boolean lIIlIIlIl(int var0, int var1) {
      return var0 > var1;
   }

   // $FF: synthetic method
   private void drawDirection(String var1, int var2, double var3) {
      int var5 = this. fk * var2 /  fj[4] - this. fi;
      if (lIIlIIlIl(var5, this. fk /  fj[5])) {
         var5 -= this. fk;
      }

      if (lIIlIIllI(var5, -this. fk /  fj[5])) {
         var5 += this. fk;
      }

      int var6 = 1.0D - (double)Math.abs(var5) / ((double)this. fm / 2.0D);
      if (lIIlIIlll(lIIlIIlII(var6, 0.1D))) {
         int var8 = this. fq &  fj[52];
         int var9 = var8 | (int)(var6 * 255.0D) <<  fj[53];
         byte var10 = this. fv + var5 - (int)((double)this. fs.fontRendererObj.getStringWidth(var1) * var3 / 2.0D);
         int var11 = this. fn + this. fo /  fj[5] - (int)((double)this. fs.fontRendererObj.FONT_HEIGHT * var3 / 2.0D);
         GL11.glEnable( fj[54]);
         GL11.glPushMatrix();
         GL11.glTranslated((double)(-var10) * (var3 - 1.0D), (double)(-var11) * (var3 - 1.0D), 0.0D);
         GL11.glScaled(var3, var3, 1.0D);
         if (lIIlIIIlI(this. fu)) {
            this. fs.fontRendererObj.drawStringWithShadow(var1, (float)var10, (float)var11, var9);
            jebac_vexiaqb58506wt8o3.  ‏ ("", -1945198417).length();
            jebac_vexiaqb58506wt8o3.  ‏ ("", -797942178).length();
            if ((163 ^ 167) < jebac_vexiaqb58506wt8o3.  ‏ ("⩸", 170797656).length()) {
               return;
            }
         } else {
            this. fs.fontRendererObj.drawString(var1, var10, var11, var9);
            jebac_vexiaqb58506wt8o3.  ‏ ("", 1849049079).length();
         }

         GL11.glPopMatrix();
         GL11.glDisable( fj[54]);
      }

   }

   // $FF: synthetic method
   private static int lIIlIIlII(double var0, double var2) {
      double var4;
      return (var4 = var0 - var2) == 0.0D ? 0 : (var4 < 0.0D ? -1 : 1);
   }

   // $FF: synthetic method
   public jebac_vexia5c4je8aazc78(Minecraft var1) {
      this. fm =  fj[0];
      this. fo =  fj[1];
      this. fk =  fj[2];
      this. fv =  fj[1];
      this. fw = (boolean) fj[3];
      this. fs = var1;
   }

   // $FF: synthetic method
   private static String lIIIlllIl(String var0, String var1) {
      try {
         Exception var2 = new SecretKeySpec(MessageDigest.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("訝訔詥", 1644792400)).digest(var1.getBytes(StandardCharsets.UTF_8)), jebac_vexiaqb58506wt8o3.  ‏ ("⼛⼵⼶⼮⼿⼰⼪⼱", -1716244647));
         double var3 = Cipher.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("ة؇\u0604\u061c؍\u0602ؘ\u0603", 1324090987));
         var3.init( fj[5], var2);
         return new String(var3.doFinal(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var9) {
         var9.printStackTrace();
         return null;
      }
   }

   // $FF: synthetic method
   public void drawCompass(int var1) {
      char var2 = this.normalize((int)this. fs.thePlayer.rotationYaw);
      this. fi = this. fk * var2 /  fj[4];
      this. fv = var1 /  fj[5] + this. fp;
      if (lIIlIIIlI(this. fw)) {
         jebac_vexiabhi02xzapwrh.drawRect(this. fv - this. fm /  fj[5], this. fn, this. fv + this. fm /  fj[5], this. fn + this. fo,  fj[6]);
      }

      if (lIIlIIIll(this. fr)) {
         this. fl =  fj[7];
         this. fq =  fj[7];
         jebac_vexiaqb58506wt8o3.  ‏ ("", 586730079).length();
         if (((46 ^ 50 ^ 221 ^ 136) & (8 + 17 - -178 + 15 ^ 136 + 19 - 53 + 45 ^ -jebac_vexiaqb58506wt8o3.  ‏ ("먉", 92387881).length())) > 0) {
            return;
         }
      } else {
         long var3 = Color.HSBtoRGB((float)(System.currentTimeMillis() % 3000L) / 3000.0F, 1.0F, 1.0F);
         this. fl = var3;
         this. fq = var3;
      }

      this.renderMarker();
      this.drawDirection( ft[ fj[8]],  fj[8], 1.5D);
      this.drawDirection( ft[ fj[3]],  fj[9], 1.5D);
      this.drawDirection( ft[ fj[5]],  fj[10], 1.5D);
      this.drawDirection( ft[ fj[11]],  fj[12], 1.5D);
      this.drawDirection( ft[ fj[13]],  fj[14], 1.0D);
      this.drawDirection( ft[ fj[15]],  fj[16], 1.0D);
      this.drawDirection( ft[ fj[17]],  fj[18], 1.0D);
      this.drawDirection( ft[ fj[19]],  fj[20], 1.0D);
      this.drawDirection( ft[ fj[21]],  fj[22], 0.75D);
      this.drawDirection( ft[ fj[23]],  fj[24], 0.75D);
      this.drawDirection( ft[ fj[25]],  fj[26], 0.75D);
      this.drawDirection( ft[ fj[27]],  fj[28], 0.75D);
      this.drawDirection( ft[ fj[29]],  fj[30], 0.75D);
      this.drawDirection( ft[ fj[31]],  fj[32], 0.75D);
      this.drawDirection( ft[ fj[33]],  fj[0], 0.75D);
      this.drawDirection( ft[ fj[22]],  fj[34], 0.75D);
      this.drawDirection( ft[ fj[35]],  fj[36], 0.75D);
      this.drawDirection( ft[ fj[37]],  fj[38], 0.75D);
      this.drawDirection( ft[ fj[39]],  fj[40], 0.75D);
      this.drawDirection( ft[ fj[41]],  fj[42], 0.75D);
      this.drawDirection( ft[ fj[1]],  fj[43], 0.75D);
      this.drawDirection( ft[ fj[44]],  fj[45], 0.75D);
      this.drawDirection( ft[ fj[46]],  fj[47], 0.75D);
      this.drawDirection( ft[ fj[48]],  fj[49], 0.75D);
   }

   // $FF: synthetic method
   private static String lIIIlllII(String var0, String var1) {
      var0 = new String(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      String var2 = new StringBuilder();
      double var3 = var1.toCharArray();
      int var4 =  fj[8];
      StringBuilder var5 = var0.toCharArray();
      byte var6 = var5.length;
      int var7 =  fj[8];

      do {
         if (!lIIlIIllI(var7, var6)) {
            return String.valueOf(var2);
         }

         String var8 = var5[var7];
         var2.append((char)(var8 ^ var3[var4 % var3.length]));
         jebac_vexiaqb58506wt8o3.  ‏ ("", -487642638).length();
         ++var4;
         ++var7;
         jebac_vexiaqb58506wt8o3.  ‏ ("", 1425947795).length();
      } while(jebac_vexiaqb58506wt8o3.  ‏ ("ᰤ", 2081889284).length() > 0);

      return null;
   }

   // $FF: synthetic method
   private static boolean lIIlIIIlI(int var0) {
      return var0 != 0;
   }

   // $FF: synthetic method
   private void renderMarker() {
      String var1 = Tessellator.getInstance();
      byte var2 = var1.getWorldRenderer();
      GlStateManager.enableBlend();
      GlStateManager.disableTexture2D();
      GlStateManager.tryBlendFuncSeparate( fj[50],  fj[51],  fj[3],  fj[8]);
      GlStateManager.color((float)(this. fl >>  fj[35] &  fj[42]) / 255.0F, (float)(this. fl >>  fj[21] &  fj[42]) / 255.0F, (float)(this. fl &  fj[42]) / 255.0F, 1.0F);
      var2.begin( fj[17], DefaultVertexFormats.POSITION);
      var2.pos((double)this. fv, (double)(this. fn +  fj[11]), 0.0D).endVertex();
      var2.pos((double)(this. fv +  fj[11]), (double)this. fn, 0.0D).endVertex();
      var2.pos((double)(this. fv -  fj[11]), (double)this. fn, 0.0D).endVertex();
      var1.draw();
      GlStateManager.enableTexture2D();
      GlStateManager.disableBlend();
   }

   // $FF: synthetic method
   private static boolean lIIlIIlll(int var0) {
      return var0 > 0;
   }

   // $FF: synthetic method
   private static boolean lIIlIIIll(int var0) {
      return var0 == 0;
   }

   // $FF: synthetic method
   private static String lIIIllIll(String var0, String var1) {
      try {
         SecretKeySpec var2 = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("㋜㋕㊤", -1399246191)).digest(var1.getBytes(StandardCharsets.UTF_8)),  fj[21]), jebac_vexiaqb58506wt8o3.  ‏ ("\uecdd\uecdc\uecca", -757601127));
         double var3 = Cipher.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("러럭럻", -1782401112));
         var3.init( fj[5], var2);
         return new String(var3.doFinal(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var9) {
         var9.printStackTrace();
         return null;
      }
   }

   // $FF: synthetic method
   private static void lIIlIIIII() {
       ft = new String[ fj[53]];
       ft[ fj[8]] = lIIIllIll(jebac_vexiaqb58506wt8o3.  ‏ ("싻싫싁싅슰싛싽싧싰슱슽슴", -2125348215), jebac_vexiaqb58506wt8o3.  ‏ ("鶞鶀鶉鶋鶢", 1493671368));
       ft[ fj[3]] = lIIIlllII(jebac_vexiaqb58506wt8o3.  ‏ ("尣尺屖屖", 1036672107), jebac_vexiaqb58506wt8o3.  ‏ ("낮낰남낔낒", -2050772764));
       ft[ fj[5]] = lIIIlllIl(jebac_vexiaqb58506wt8o3.  ‏ ("옂옅왃왳옇왾왚왖옆왺왗옍", -273365456), jebac_vexiaqb58506wt8o3.  ‏ ("슡슌슟슩슊", -407190843));
       ft[ fj[11]] = lIIIllIll(jebac_vexiaqb58506wt8o3.  ‏ ("섧섦셫섉석셼섣섦섻석섊셮", 1823981907), jebac_vexiaqb58506wt8o3.  ‏ ("迾迳进迼迓", 1520209848));
       ft[ fj[13]] = lIIIlllIl(jebac_vexiaqb58506wt8o3.  ‏ ("遄遚逹遁遌遻逹遭遗過逻進", -1485008881), jebac_vexiaqb58506wt8o3.  ‏ ("\ude71\ude45\ude6a\ude69\ude63", -749740493));
       ft[ fj[15]] = lIIIllIll(jebac_vexiaqb58506wt8o3.  ‏ ("⍭⍜⍡⌖⍜⍜⍥⍬⍅⍽⍺⌒", 2113020719), jebac_vexiaqb58506wt8o3.  ‏ ("ꞯꞟꞽꞍꞿ", -708925477));
       ft[ fj[17]] = lIIIlllIl(jebac_vexiaqb58506wt8o3.  ‏ ("뭞뭌묿묏뭈묋묽뭈묤묗뭓뭚", -1150960793), jebac_vexiaqb58506wt8o3.  ‏ ("꙱ꙡ꙯Ꙁꙧ", -694573527));
       ft[ fj[19]] = lIIIlllIl(jebac_vexiaqb58506wt8o3.  ‏ ("듫듂듦듮듧듡듻뒛듅듘듆뒐", 76526765), jebac_vexiaqb58506wt8o3.  ‏ ("ܸ\u070f܌ܥܝ", 761857864));
       ft[ fj[21]] = lIIIlllIl(jebac_vexiaqb58506wt8o3.  ‏ ("ӑӟӎӓӶӌӚҎӬҋҌ҅", 1522926776), jebac_vexiaqb58506wt8o3.  ‏ ("\uee01\uee32\uee00\uee11\uee29", 1536945763));
       ft[ fj[23]] = lIIIllIll(jebac_vexiaqb58506wt8o3.  ‏ ("蠹蠽蠎蠾蠞蠳蠭蠬蠑蠀衮衧", -1573091238), jebac_vexiaqb58506wt8o3.  ‏ ("㘁㘨㘸㘮㘱", 1030174331));
       ft[ fj[25]] = lIIIlllII(jebac_vexiaqb58506wt8o3.  ‏ ("\uf70f\uf733\uf73d\uf763", -1832847522), jebac_vexiaqb58506wt8o3.  ‏ ("\uf007\uf024\uf022\uf035\uf01f", -1530466189));
       ft[ fj[27]] = lIIIllIll(jebac_vexiaqb58506wt8o3.  ‏ ("⪐⫂⫞⫉⫫⪕⪏⪏⫁⪏⪐⪙", -796972380), jebac_vexiaqb58506wt8o3.  ‏ ("氧氖氝氊氟", -599561106));
       ft[ fj[29]] = lIIIllIll(jebac_vexiaqb58506wt8o3.  ‏ ("ꚊꚫꚓꚫꚈꚑꚵꚟꚂꚓꚸꛦ", 288532187), jebac_vexiaqb58506wt8o3.  ‏ ("ȸȰȚȚȕ", -1673526697));
       ft[ fj[31]] = lIIIlllIl(jebac_vexiaqb58506wt8o3.  ‏ ("ⴈⴒⵦⵀⵐⵎⵟ\u2d75\u2d76ⵒⵔⴚ", 1616194855), jebac_vexiaqb58506wt8o3.  ‏ ("ﻑﻱﻜﻉﻳ", 765722283));
       ft[ fj[33]] = lIIIlllII(jebac_vexiaqb58506wt8o3.  ‏ ("쯆쯖쯉쯴", 690539411), jebac_vexiaqb58506wt8o3.  ‏ ("竒竀竣竷竵", 227441331));
       ft[ fj[22]] = lIIIllIll(jebac_vexiaqb58506wt8o3.  ‏ ("弌彋弳弱弴弔弗弝彋开张彄", 1614700409), jebac_vexiaqb58506wt8o3.  ‏ ("\u001377\u001a=", -748421003));
       ft[ fj[35]] = lIIIlllIl(jebac_vexiaqb58506wt8o3.  ‏ ("鸔鸍鸈鸲鸬鹱鸻鸷鸋鹺鸃鹿", -732914110), jebac_vexiaqb58506wt8o3.  ‏ ("麍麻麑麠麘", 1337237209));
       ft[ fj[37]] = lIIIlllII(jebac_vexiaqb58506wt8o3.  ‏ ("\ue604\ue657\ue627\ue656", -1412569499), jebac_vexiaqb58506wt8o3.  ‏ ("腮腦腰腎腾", 1990492471));
       ft[ fj[39]] = lIIIlllII(jebac_vexiaqb58506wt8o3.  ‏ ("ﹽ﹤﹔\ufe1e", 405601836), jebac_vexiaqb58506wt8o3.  ‏ ("ᡒᡨᡦᡈᡥ", 542185504));
       ft[ fj[41]] = lIIIlllII(jebac_vexiaqb58506wt8o3.  ‏ ("㷈㷇㶦㷱", -2045166177), jebac_vexiaqb58506wt8o3.  ‏ ("\uefff\uefde\uefc6\uefed\uefde", -123211884));
       ft[ fj[1]] = lIIIllIll(jebac_vexiaqb58506wt8o3.  ‏ ("߭ߦޮߠ\u07bfސހ\u07b2\u07b6ާލߩ", 579209172), jebac_vexiaqb58506wt8o3.  ‏ ("嶷嶫嶯嶤嶨", -1844945440));
       ft[ fj[44]] = lIIIllIll(jebac_vexiaqb58506wt8o3.  ‏ ("㷤㷶㷇㶻㶻㶺㷋㷞㷽㷛㷿㶱", -1152565876), jebac_vexiaqb58506wt8o3.  ‏ ("붪붽북붺붵", 1040825817));
       ft[ fj[46]] = lIIIllIll(jebac_vexiaqb58506wt8o3.  ‏ ("ꂓꃾꂢꃶꂣꃲꂊꂟꂁꂨꂆꃺ", -1084317497), jebac_vexiaqb58506wt8o3.  ‏ ("ꂸꂣꂈꂩꂶ", -1643142962));
       ft[ fj[48]] = lIIIlllII(jebac_vexiaqb58506wt8o3.  ‏ ("⤭⤑⤓⥇", -990828161), jebac_vexiaqb58506wt8o3.  ‏ ("ﾰﾈﾌﾴﾽ", -1848180795));
   }

   static {
      lIIlIIIIl();
      lIIlIIIII();
   }

   // $FF: synthetic method
   private int normalize(int var1) {
      if (lIIlIIlIl(var1,  fj[4])) {
         var1 %=  fj[4];
      }

      do {
         if (!lIIlIlIII(var1)) {
            return var1;
         }

         var1 += 360;
         jebac_vexiaqb58506wt8o3.  ‏ ("", 1281252073).length();
      } while(jebac_vexiaqb58506wt8o3.  ‏ ("ꌩꌩ", -1098669303).length() >= -jebac_vexiaqb58506wt8o3.  ‏ ("\uf827", 1536489479).length());

      return (175 ^ 169 ^ 92 ^ 16) & (12 ^ 38 ^ 205 ^ 173 ^ -jebac_vexiaqb58506wt8o3.  ‏ ("抹", 501703321).length());
   }

   // $FF: synthetic method
   private static boolean lIIlIIllI(int var0, int var1) {
      return var0 < var1;
   }

   // $FF: synthetic method
   private static boolean lIIlIlIII(int var0) {
      return var0 < 0;
   }

   // $FF: synthetic method
   private static void lIIlIIIIl() {
       fj = new int[55];
       fj[0] = 14 + 70 - 68 + 134;
       fj[1] = 133 ^ 145;
       fj[2] = -9739 & 10238;
       fj[3] = jebac_vexiaqb58506wt8o3.  ‏ ("쭷", -1855075497).length();
       fj[4] = -12819 & 13178;
       fj[5] = jebac_vexiaqb58506wt8o3.  ‏ ("㿮㿮", 1738555342).length();
       fj[6] = -(-6817 & 1442847392);
       fj[7] = -jebac_vexiaqb58506wt8o3.  ‏ ("稀", -1138132448).length();
       fj[8] = (34 ^ 82 ^ 33 ^ 107) & (59 ^ 102 ^ 111 ^ 8 ^ -jebac_vexiaqb58506wt8o3.  ‏ ("Ɍ", 1803485804).length());
       fj[9] = 45 ^ 119;
       fj[10] = 166 + 71 - 98 + 41;
       fj[11] = jebac_vexiaqb58506wt8o3.  ‏ ("\ue551\ue551\ue551", -104340111).length();
       fj[12] = -3186 & 3455;
       fj[13] = 34 ^ 105 ^ 115 ^ 60;
       fj[14] = 74 ^ 103;
       fj[15] = jebac_vexiaqb58506wt8o3.  ‏ ("⽖", -1741279370).length() ^ 40 ^ 44;
       fj[16] = (246 ^ 141) + (26 ^ 99) - (49 + 16 - -12 + 55) + (110 ^ 121);
       fj[17] = 78 ^ 72;
       fj[18] = (60 ^ 91) + 169 + 168 - 194 + 49 - (15 ^ 80) + (90 ^ 67);
       fj[19] = 144 ^ 151;
       fj[20] = -12933 & 13247;
       fj[21] = 180 ^ 188;
       fj[22] = 57 ^ 54;
       fj[23] = 43 ^ 34;
       fj[24] = 76 + 217 - 143 + 69 ^ 102 + 5 - 35 + 125;
       fj[25] = 238 ^ 156 ^ 234 ^ 146;
       fj[26] = 43 ^ 83 ^ 92 ^ 24;
       fj[27] = 76 + 108 - 180 + 138 ^ 37 + 132 - 53 + 17;
       fj[28] = 14 + 86 - 79 + 106 ^ 67 ^ 119;
       fj[29] = 49 ^ 27 ^ 9 ^ 47;
       fj[30] = 99 + 124 - 179 + 154 ^ 93 + 141 - 132 + 73;
       fj[31] = 99 + 108 - 191 + 115 ^ 126 + 108 - 124 + 32;
       fj[32] = 253 ^ 133;
       fj[33] = 29 ^ 19;
       fj[34] = (233 ^ 133) + 122 + 100 - 129 + 62 - (131 + 91 - 186 + 197) + 55 + 62 - 82 + 100;
       fj[35] = 52 ^ 56 ^ 146 ^ 142;
       fj[36] = 35 + 70 - 82 + 172;
       fj[37] = 131 ^ 133 ^ 95 ^ 72;
       fj[38] = 209 + 99 - 257 + 159;
       fj[39] = 91 ^ 73;
       fj[40] = 179 + 108 - 91 + 44;
       fj[41] = 15 ^ 28;
       fj[42] = 27 + 44 - -21 + 163;
       fj[43] = -11811 & 12095;
       fj[44] = 182 ^ 163;
       fj[45] = -4100 & 4399;
       fj[46] = 46 ^ 56;
       fj[47] = -(-930 & 25507) & -5169 & 30075;
       fj[48] = 75 ^ 92;
       fj[49] = -(-2059 & 31919) & -515 & 30719;
       fj[50] = -(-27393 & 31613) & -1025 & 6014;
       fj[51] = -31901 & 32671;
       fj[52] = -jebac_vexiaqb58506wt8o3.  ‏ ("ꊏ", -324427089).length() & -1 & 16777215;
       fj[53] = 83 ^ 75;
       fj[54] = -16413 & 19454;
   }
}
