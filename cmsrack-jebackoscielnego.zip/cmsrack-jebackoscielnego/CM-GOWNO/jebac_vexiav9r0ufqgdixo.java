public class jebac_vexiav9r0ufqgdixo {
   private static final int[]  r;
   private int  q;
   private int  s;
   private int  u;
   private boolean  v;
   private final int  t;

   // $FF: synthetic method
   private static boolean lIlllIII(int var0) {
      return var0 == 0;
   }

   // $FF: synthetic method
   public double getValue() {
      return lIllIllI(this. v) ? Math.sin((double)(this. s - this. u) / (double)(this. t - this. u) * 3.141592653589793D / 2.0D) : 1.0D - Math.cos((double)this. s / (double)this. q * 3.141592653589793D / 2.0D);
   }

   // $FF: synthetic method
   private static void lIllIlIl() {
       r = new int[2];
       r[0] = jebac_vexiaqb58506wt8o3.  ‏ ("랫랫", 1242478475).length() & ~jebac_vexiaqb58506wt8o3.  ‏ ("╎╎", 1685398894).length();
       r[1] = jebac_vexiaqb58506wt8o3.  ‏ ("扒", 180970098).length();
   }

   // $FF: synthetic method
   private static boolean lIlllIIl(int var0) {
      return var0 > 0;
   }

   // $FF: synthetic method
   public jebac_vexiav9r0ufqgdixo(int var1) {
      this. t = var1;
      this. q = var1;
      this. u =  r[0];
   }

   // $FF: synthetic method
   private static boolean lIllIlll(int var0, int var1) {
      return var0 < var1;
   }

   // $FF: synthetic method
   private static boolean lIllIllI(int var0) {
      return var0 != 0;
   }

   static {
      lIllIlIl();
   }

   // $FF: synthetic method
   public void update(boolean var1) {
      if (lIllIllI(var1)) {
         if (lIllIlll(this. s, this. t)) {
            if (lIlllIII(this. v)) {
               this. u = this. s;
            }

            this. s +=  r[1];
         }

         this. v = (boolean) r[1];
         jebac_vexiaqb58506wt8o3.  ‏ ("", -1959447016).length();
         if (jebac_vexiaqb58506wt8o3.  ‏ ("\uda96", -1673798986).length() > jebac_vexiaqb58506wt8o3.  ‏ ("뗢", 1013429698).length()) {
            return;
         }
      } else {
         if (lIlllIIl(this. s)) {
            if (lIllIllI(this. v)) {
               this. q = this. s;
            }

            this. s -=  r[1];
         }

         this. v = (boolean) r[0];
      }

   }
}
