import net.minecraft.block.state.BlockStateBase;

public class jebac_vexia2nnti3ppoopl {
   // $FF: synthetic field
   private int[] metadatas = null;
   // $FF: synthetic field
   private int blockId = -1;

   // $FF: synthetic method
   public boolean matches(int p_matches_1_, int p_matches_2_) {
      return p_matches_1_ == this.blockId && jebac_vexiazz7bslggeoy9.metadata(p_matches_2_, this.metadatas);
   }

   // $FF: synthetic method
   public boolean matches(BlockStateBase p_matches_1_) {
      return p_matches_1_.getBlockId() == this.blockId && jebac_vexiazz7bslggeoy9.metadata(p_matches_1_.getMetadata(), this.metadatas);
   }

   // $FF: synthetic method
   public int[] getMetadatas() {
      return this.metadatas;
   }

   // $FF: synthetic method
   public jebac_vexia2nnti3ppoopl(int p_i65_1_, int[] p_i65_2_) {
      this.blockId = p_i65_1_;
      this.metadatas = p_i65_2_;
   }

   // $FF: synthetic method
   public void addMetadata(int p_addMetadata_1_) {
      if (this.metadatas != null && p_addMetadata_1_ >= 0 && p_addMetadata_1_ <= 15) {
         int[] var2 = this.metadatas;
         int var3 = var2.length;

         for(int var4 = 0; var4 < var3; ++var4) {
            int metadata = var2[var4];
            if (metadata == p_addMetadata_1_) {
               return;
            }
         }

         this.metadatas = jebac_vexiakrwecfs16wve.addIntToArray(this.metadatas, p_addMetadata_1_);
      }

   }

   // $FF: synthetic method
   public jebac_vexia2nnti3ppoopl(int p_i64_1_, int p_i64_2_) {
      this.blockId = p_i64_1_;
      if (p_i64_2_ >= 0 && p_i64_2_ <= 15) {
         this.metadatas = new int[]{p_i64_2_};
      }

   }

   // $FF: synthetic method
   public int getBlockId() {
      return this.blockId;
   }

   // $FF: synthetic method
   public jebac_vexia2nnti3ppoopl(int p_i63_1_) {
      this.blockId = p_i63_1_;
   }

   // $FF: synthetic method
   public String toString() {
      return "" + this.blockId + ":" + jebac_vexiakrwecfs16wve.arrayToString(this.metadatas);
   }
}
