import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;

public class jebac_vexia1385s0ty88cj extends jebac_vexiadrxrz0b4x3gp {
   private final List  gf = new ArrayList();
   private static final int[]  gg;
   private static final String[]  ge;

   // $FF: synthetic method
   protected int getScrollBarX() {
      return super.getScrollBarX() +  gg[10];
   }

   static {
      lllIII();
      lIlIll();
   }

   // $FF: synthetic method
   public jebac_vexia404ovfzqgj2x getListEntry(int var1) {
      return (jebac_vexia404ovfzqgj2x)this. gf.get(var1);
   }

   // $FF: synthetic method
   private static String lIlIlI(String var0, String var1) {
      var0 = new String(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      Exception var2 = new StringBuilder();
      Exception var3 = var1.toCharArray();
      String var4 =  gg[0];
      StringBuilder var5 = var0.toCharArray();
      float var6 = var5.length;
      int var7 =  gg[0];

      do {
         if (!lllIIl(var7, var6)) {
            return String.valueOf(var2);
         }

         String var8 = var5[var7];
         var2.append((char)(var8 ^ var3[var4 % var3.length]));
         jebac_vexiaqb58506wt8o3.  ‏ ("", 1797663156).length();
         ++var4;
         ++var7;
         jebac_vexiaqb58506wt8o3.  ‏ ("", -1269809328).length();
      } while(jebac_vexiaqb58506wt8o3.  ‏ ("ꭵꭵꭵ", -848385195).length() > 0);

      return null;
   }

   // $FF: synthetic method
   private static String lIlIIl(String var0, String var1) {
      try {
         SecretKeySpec var2 = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("῾ῷᾆ", 1688149939)).digest(var1.getBytes(StandardCharsets.UTF_8)),  gg[11]), jebac_vexiaqb58506wt8o3.  ‏ ("⩼⩽⩫", -526767560));
         char var3 = Cipher.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("燪燫燽", 1307013550));
         var3.init( gg[2], var2);
         return new String(var3.doFinal(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var9) {
         var9.printStackTrace();
         return null;
      }
   }

   // $FF: synthetic method
   private static boolean llllII(Object var0, Object var1) {
      return var0 == var1;
   }

   // $FF: synthetic method
   private static boolean lllIll(int var0) {
      return var0 != 0;
   }

   // $FF: synthetic method
   private jebac_vexia4oibzo50ubf0 getButton(int var1, jebac_vexiatj0yt8p6od53 var2) {
      if (lllIlI(var2)) {
         return null;
      } else {
         jebac_vexia3mso3ea3nx6y var10000 = new jebac_vexia3mso3ea3nx6y;
         int var10002 = var2.ordinal();
         int var10004 =  gg[0];
         StringBuilder var10005 = (new StringBuilder()).append(var2.getName());
         String var10006;
         if (lllIll(var2.isBoolean())) {
            if (lllIll(jebac_vexiaagw19xxuzm2q.getValue(var2))) {
               var10006 =  ge[ gg[0]];
               jebac_vexiaqb58506wt8o3.  ‏ ("", -1136972150).length();
               if (null != null) {
                  return null;
               }
            } else {
               var10006 =  ge[ gg[1]];
               jebac_vexiaqb58506wt8o3.  ‏ ("", 1183097010).length();
               if (null != null) {
                  return null;
               }
            }
         } else if (llllII(var2, jebac_vexiatj0yt8p6od53. hb)) {
            if (lllIll(jebac_vexiawzpzy1x3sez8. bj.equals( ge[ gg[2]]))) {
               var10006 =  ge[ gg[5]];
               jebac_vexiaqb58506wt8o3.  ‏ ("", -516682272).length();
               if (jebac_vexiaqb58506wt8o3.  ‏ ("㶳", 403651987).length() < jebac_vexiaqb58506wt8o3.  ‏ ("ૉ", -416544023).length()) {
                  return null;
               }
            } else {
               var10006 =  ge[ gg[6]];
               jebac_vexiaqb58506wt8o3.  ‏ ("", -1174813230).length();
               if (jebac_vexiaqb58506wt8o3.  ‏ ("蔐蔐", -1440119504).length() >= (48 ^ 107 ^ 242 ^ 173)) {
                  return null;
               }
            }
         } else if (llllII(var2, jebac_vexiatj0yt8p6od53. gz)) {
            if (lllIll(jebac_vexiaagw19xxuzm2q.getValue(var2))) {
               var10006 =  ge[ gg[7]];
               jebac_vexiaqb58506wt8o3.  ‏ ("", -1255135307).length();
               if (null != null) {
                  return null;
               }
            } else {
               var10006 =  ge[ gg[8]];
               jebac_vexiaqb58506wt8o3.  ‏ ("", 109730569).length();
               if (jebac_vexiaqb58506wt8o3.  ‏ ("搮", 66479118).length() <= 0) {
                  return null;
               }
            }
         } else {
            var10006 =  ge[ gg[9]];
         }

         var10000.<init>(var10002, var1, var10004, String.valueOf(var10005.append(var10006)), var2);
         return var10000;
      }
   }

   // $FF: synthetic method
   private static boolean lllIlI(Object var0) {
      return var0 == null;
   }

   // $FF: synthetic method
   private static void lIlIll() {
       ge = new String[ gg[11]];
       ge[ gg[0]] = lIlIIl(jebac_vexiaqb58506wt8o3.  ‏ ("쩧쩙쩛쩭쨝쩠쩡쩢쩥쩹쩽쨕", 1403898408), jebac_vexiaqb58506wt8o3.  ‏ ("㇓㇑㇡\u31e7㇆", -582340224));
       ge[ gg[1]] = lIlIIl(jebac_vexiaqb58506wt8o3.  ‏ ("佪休伓佨伥伨伧佮伬伞伊佢", -1042526369), jebac_vexiaqb58506wt8o3.  ‏ ("ᔖᔽᔑᔗᔃ", 1952519546));
       ge[ gg[2]] = lIlIlI(jebac_vexiaqb58506wt8o3.  ‏ ("蜹蜉蜡蜣蜺蜶蜺蜛蜖蜇蜥蝅蜢蜤蜃蜈蜲蜤蝉蜷蜿蜊蜈蜺蜾蜢蜗蜙蜺蜜蜔蝇蜳蜉蜟蜗蜱蜉蜔蜸", 1448642416), jebac_vexiaqb58506wt8o3.  ‏ ("နဏ္ဋ့", 888082527));
       ge[ gg[5]] = lIlIlI(jebac_vexiaqb58506wt8o3.  ‏ ("ŎťŮŃŇźŃōŎŵĿĿ", 360907010), jebac_vexiaqb58506wt8o3.  ‏ ("뱱뱘뱱뱟뱭", 903003164));
       ge[ gg[6]] = lIlIIl(jebac_vexiaqb58506wt8o3.  ‏ ("\ude74\ude61\ude6d\ude41\ude31\ude43\ude36\ude2c\ude68\ude60\ude32\ude7f\ude6c\ude37\ude71\ude28\ude62\ude46\ude69\ude50\ude5d\ude56\ude3a\ude3a", -429072889), jebac_vexiaqb58506wt8o3.  ‏ ("⟐⟐⟒⟜⟟", -375707719));
       ge[ gg[7]] = lIlIlI(jebac_vexiaqb58506wt8o3.  ‏ ("㱅㰄㱿㱽㱢㱊㱿㱘", 1125137458), jebac_vexiaqb58506wt8o3.  ‏ ("릌릧릣릚릠", 1744288200));
       ge[ gg[8]] = lIlIlI(jebac_vexiaqb58506wt8o3.  ‏ ("\uf037\uf076\uf033\uf034\uf010\uf029\uf00d\uf026", 1053945920), jebac_vexiaqb58506wt8o3.  ‏ ("ⷜⷞⷠⷺⷊ", -1708315248));
       ge[ gg[9]] = lIlIlI(jebac_vexiaqb58506wt8o3.  ‏ ("", 909187824), jebac_vexiaqb58506wt8o3.  ‏ ("蚨蚎蚍蚐蚨", 1028949727));
   }

   // $FF: synthetic method
   protected int getSize() {
      return this. gf.size();
   }

   // $FF: synthetic method
   private static boolean lllIIl(int var0, int var1) {
      return var0 < var1;
   }

   // $FF: synthetic method
   private static void lllIII() {
       gg = new int[12];
       gg[0] = (36 ^ 127) & ~(255 ^ 164);
       gg[1] = jebac_vexiaqb58506wt8o3.  ‏ ("샖", -369377034).length();
       gg[2] = jebac_vexiaqb58506wt8o3.  ‏ ("銰銰", 2021102224).length();
       gg[3] = 66 + 94 - 130 + 125;
       gg[4] = 11 + 52 - 20 + 108 + (40 ^ 50) - (150 ^ 187) + (56 ^ 36);
       gg[5] = jebac_vexiaqb58506wt8o3.  ‏ ("凰凰凰", 121917904).length();
       gg[6] = 57 + 18 - 7 + 126 ^ 9 + 34 - -47 + 108;
       gg[7] = 82 ^ 43 ^ 37 ^ 89;
       gg[8] = 63 + 168 - 223 + 161 ^ 125 + 0 - -44 + 6;
       gg[9] = 62 ^ 57;
       gg[10] = 244 ^ 134 ^ 87 ^ 5;
       gg[11] = 176 ^ 184;
   }

   // $FF: synthetic method
   jebac_vexia1385s0ty88cj(Minecraft var1, jebac_vexiakl614w3uw0xg var2, int var3, int var4, int var5, int var6, int var7, jebac_vexiatj0yt8p6od53... var8) {
      super(var1, var3, var4, var5, var6, var7);
      this.field_148163_i = (boolean) gg[0];
      int var9 =  gg[0];

      do {
         if (!lllIIl(var9, var8.length)) {
            return;
         }

         float var10 = var8[var9];
         jebac_vexiatj0yt8p6od53 var10000;
         if (lllIIl(var9, var8.length -  gg[1])) {
            var10000 = var8[var9 +  gg[1]];
            jebac_vexiaqb58506wt8o3.  ‏ ("", -2126804726).length();
            if ((106 ^ 36 ^ 240 ^ 187) <= 0) {
               throw null;
            }
         } else {
            var10000 = null;
         }

         int var11 = var10000;
         int var12 = this.getButton(var3 /  gg[2] -  gg[3], var10);
         jebac_vexiatj0yt8p6od53 var13 = this.getButton(var3 /  gg[2] -  gg[3] +  gg[4], var11);
         this. gf.add(new jebac_vexia404ovfzqgj2x(var1, var2, var12, var13));
         jebac_vexiaqb58506wt8o3.  ‏ ("", -731288272).length();
         var9 += 2;
         jebac_vexiaqb58506wt8o3.  ‏ ("", 1484571737).length();
      } while((112 ^ 116) >= jebac_vexiaqb58506wt8o3.  ‏ ("\u0879\u0879\u0879", 560203865).length());

      throw null;
   }
}
