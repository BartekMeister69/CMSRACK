import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.util.BlockPos;
import net.minecraft.util.ResourceLocation;

public class jebac_vexia9hn6bt2nfrvd {
   // $FF: synthetic field
   private static jebac_vexiaruwj56mqrfk3[] propertiesByIndex = new jebac_vexiaruwj56mqrfk3[0];

   // $FF: synthetic method
   public static void update() {
      propertiesByIndex = new jebac_vexiaruwj56mqrfk3[0];
      if (jebac_vexiakrwecfs16wve.isNaturalTextures()) {
         String s = "optifine/natural.properties";

         try {
            ResourceLocation resourcelocation = new ResourceLocation(s);
            if (!jebac_vexiakrwecfs16wve.hasResource(resourcelocation)) {
               jebac_vexiakrwecfs16wve.dbg("NaturalTextures: configuration \"" + s + "\" not found");
               return;
            }

            boolean flag = jebac_vexiakrwecfs16wve.isFromDefaultResourcePack(resourcelocation);
            InputStream inputstream = jebac_vexiakrwecfs16wve.getResourceStream(resourcelocation);
            ArrayList arraylist = new ArrayList(256);
            String s1 = jebac_vexiakrwecfs16wve.readInputStream(inputstream);
            inputstream.close();
            String[] astring = jebac_vexiakrwecfs16wve.tokenize(s1, "\n\r");
            if (flag) {
               jebac_vexiakrwecfs16wve.dbg("Natural Textures: Parsing default configuration \"" + s + "\"");
               jebac_vexiakrwecfs16wve.dbg("Natural Textures: Valid only for textures from default resource pack");
            } else {
               jebac_vexiakrwecfs16wve.dbg("Natural Textures: Parsing configuration \"" + s + "\"");
            }

            TextureMap texturemap = jebac_vexiamg04e8zzk81s.getTextureMapBlocks();
            String[] var8 = astring;
            int var9 = astring.length;

            for(int var10 = 0; var10 < var9; ++var10) {
               String value = var8[var10];
               String s2 = value.trim();
               if (!s2.startsWith("#")) {
                  String[] astring1 = jebac_vexiakrwecfs16wve.tokenize(s2, "=");
                  if (astring1.length != 2) {
                     jebac_vexiakrwecfs16wve.warn("Natural Textures: Invalid \"" + s + "\" line: " + s2);
                  } else {
                     String s3 = astring1[0].trim();
                     String s4 = astring1[1].trim();
                     TextureAtlasSprite textureatlassprite = texturemap.getSpriteSafe("minecraft:blocks/" + s3);
                     if (textureatlassprite == null) {
                        jebac_vexiakrwecfs16wve.warn("Natural Textures: Texture not found: \"" + s + "\" line: " + s2);
                     } else {
                        int j = textureatlassprite.getIndexInMap();
                        if (j < 0) {
                           jebac_vexiakrwecfs16wve.warn("Natural Textures: Invalid \"" + s + "\" line: " + s2);
                        } else {
                           if (flag && !jebac_vexiakrwecfs16wve.isFromDefaultResourcePack(new ResourceLocation("textures/blocks/" + s3 + ".png"))) {
                              return;
                           }

                           jebac_vexiaruwj56mqrfk3 naturalproperties = new jebac_vexiaruwj56mqrfk3(s4);
                           if (naturalproperties.isValid()) {
                              while(arraylist.size() <= j) {
                                 arraylist.add((Object)null);
                              }

                              arraylist.set(j, naturalproperties);
                              jebac_vexiakrwecfs16wve.dbg("NaturalTextures: " + s3 + " = " + s4);
                           }
                        }
                     }
                  }
               }
            }

            propertiesByIndex = (jebac_vexiaruwj56mqrfk3[])((jebac_vexiaruwj56mqrfk3[])arraylist.toArray(new jebac_vexiaruwj56mqrfk3[0]));
         } catch (FileNotFoundException var19) {
            jebac_vexiakrwecfs16wve.warn("NaturalTextures: configuration \"" + s + "\" not found");
         } catch (Exception var20) {
            var20.printStackTrace();
         }
      }

   }

   // $FF: synthetic method
   public static BakedQuad getNaturalTexture(BlockPos p_getNaturalTexture_0_, BakedQuad p_getNaturalTexture_1_) {
      TextureAtlasSprite textureatlassprite = p_getNaturalTexture_1_.getSprite();
      if (textureatlassprite == null) {
         return p_getNaturalTexture_1_;
      } else {
         jebac_vexiaruwj56mqrfk3 naturalproperties = getNaturalProperties(textureatlassprite);
         if (naturalproperties == null) {
            return p_getNaturalTexture_1_;
         } else {
            int i = jebac_vexia681h1c1xrrxp.getSide(p_getNaturalTexture_1_.getFace());
            int j = jebac_vexiakrwecfs16wve.getRandom(p_getNaturalTexture_0_, i);
            int k = 0;
            boolean flag = false;
            if (naturalproperties.rotation > 1) {
               k = j & 3;
            }

            if (naturalproperties.rotation == 2) {
               k = k / 2 * 2;
            }

            if (naturalproperties.flip) {
               flag = (j & 4) != 0;
            }

            return naturalproperties.getQuad(p_getNaturalTexture_1_, k, flag);
         }
      }
   }

   // $FF: synthetic method
   public static jebac_vexiaruwj56mqrfk3 getNaturalProperties(TextureAtlasSprite p_getNaturalProperties_0_) {
      if (p_getNaturalProperties_0_ == null) {
         return null;
      } else {
         int i = p_getNaturalProperties_0_.getIndexInMap();
         return i >= 0 && i < propertiesByIndex.length ? propertiesByIndex[i] : null;
      }
   }
}
