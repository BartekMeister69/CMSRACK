import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.resources.model.IBakedModel;
import net.minecraft.client.resources.model.ModelManager;
import net.minecraft.client.resources.model.ModelResourceLocation;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.ResourceLocation;

public class jebac_vexia4r7c8kisy9np {
   // $FF: synthetic field
   private static List generalQuadsCullSpruce = null;
   // $FF: synthetic field
   private static List generalQuadsCullAcacia = null;
   // $FF: synthetic field
   private static List generalQuadsCullOak = null;
   // $FF: synthetic field
   private static IBakedModel modelLeavesCullAcacia = null;
   // $FF: synthetic field
   private static IBakedModel modelLeavesDoubleAcacia = null;
   // $FF: synthetic field
   private static IBakedModel modelLeavesDoubleDarkOak = null;
   // $FF: synthetic field
   private static IBakedModel modelLeavesDoubleJungle = null;
   // $FF: synthetic field
   private static IBakedModel modelLeavesCullOak = null;
   // $FF: synthetic field
   private static IBakedModel modelLeavesCullBirch = null;
   // $FF: synthetic field
   private static IBakedModel modelLeavesCullSpruce = null;
   // $FF: synthetic field
   private static List generalQuadsCullBirch = null;
   // $FF: synthetic field
   private static IBakedModel modelLeavesDoubleBirch = null;
   // $FF: synthetic field
   private static IBakedModel modelLeavesCullJungle = null;
   // $FF: synthetic field
   private static IBakedModel modelLeavesCullDarkOak = null;
   // $FF: synthetic field
   private static IBakedModel modelLeavesDoubleOak = null;
   // $FF: synthetic field
   private static IBakedModel modelLeavesDoubleSpruce = null;
   // $FF: synthetic field
   private static List generalQuadsCullJungle = null;
   // $FF: synthetic field
   private static List generalQuadsCullDarkOak = null;

   // $FF: synthetic method
   static IBakedModel getModelCull(String p_getModelCull_0_, List p_getModelCull_1_) {
      ModelManager modelmanager = jebac_vexiakrwecfs16wve.getModelManager();
      if (modelmanager == null) {
         return null;
      } else {
         ResourceLocation resourcelocation = new ResourceLocation("blockstates/" + p_getModelCull_0_ + "_leaves.json");
         if (jebac_vexiakrwecfs16wve.getDefiningResourcePack(resourcelocation) != jebac_vexiakrwecfs16wve.getDefaultResourcePack()) {
            return null;
         } else {
            ResourceLocation resourcelocation1 = new ResourceLocation("models/block/" + p_getModelCull_0_ + "_leaves.json");
            if (jebac_vexiakrwecfs16wve.getDefiningResourcePack(resourcelocation1) != jebac_vexiakrwecfs16wve.getDefaultResourcePack()) {
               return null;
            } else {
               ModelResourceLocation modelresourcelocation = new ModelResourceLocation(p_getModelCull_0_ + "_leaves", "normal");
               IBakedModel ibakedmodel = modelmanager.getModel(modelresourcelocation);
               if (ibakedmodel != null && ibakedmodel != modelmanager.getMissingModel()) {
                  List list = ibakedmodel.getGeneralQuads();
                  if (list.size() == 0) {
                     return ibakedmodel;
                  } else if (list.size() != 6) {
                     return null;
                  } else {
                     Iterator var8 = list.iterator();

                     while(var8.hasNext()) {
                        Object bakedquad = var8.next();
                        List list1 = ibakedmodel.getFaceQuads(((BakedQuad)bakedquad).getFace());
                        if (list1.size() > 0) {
                           return null;
                        }

                        list1.add(bakedquad);
                     }

                     list.clear();
                     p_getModelCull_1_.add(p_getModelCull_0_ + "_leaves");
                     return ibakedmodel;
                  }
               } else {
                  return null;
               }
            }
         }
      }
   }

   // $FF: synthetic method
   private static List getGeneralQuadsSafe(IBakedModel p_getGeneralQuadsSafe_0_) {
      return p_getGeneralQuadsSafe_0_ == null ? null : p_getGeneralQuadsSafe_0_.getGeneralQuads();
   }

   // $FF: synthetic method
   public static IBakedModel getLeavesModel(IBakedModel p_getLeavesModel_0_) {
      if (!jebac_vexiakrwecfs16wve.isTreesSmart()) {
         return p_getLeavesModel_0_;
      } else {
         List list = p_getLeavesModel_0_.getGeneralQuads();
         return list == generalQuadsCullAcacia ? modelLeavesDoubleAcacia : (list == generalQuadsCullBirch ? modelLeavesDoubleBirch : (list == generalQuadsCullDarkOak ? modelLeavesDoubleDarkOak : (list == generalQuadsCullJungle ? modelLeavesDoubleJungle : (list == generalQuadsCullOak ? modelLeavesDoubleOak : (list == generalQuadsCullSpruce ? modelLeavesDoubleSpruce : p_getLeavesModel_0_)))));
      }
   }

   // $FF: synthetic method
   public static void updateLeavesModels() {
      List list = new ArrayList();
      modelLeavesCullAcacia = getModelCull("acacia", list);
      modelLeavesCullBirch = getModelCull("birch", list);
      modelLeavesCullDarkOak = getModelCull("dark_oak", list);
      modelLeavesCullJungle = getModelCull("jungle", list);
      modelLeavesCullOak = getModelCull("oak", list);
      modelLeavesCullSpruce = getModelCull("spruce", list);
      generalQuadsCullAcacia = getGeneralQuadsSafe(modelLeavesCullAcacia);
      generalQuadsCullBirch = getGeneralQuadsSafe(modelLeavesCullBirch);
      generalQuadsCullDarkOak = getGeneralQuadsSafe(modelLeavesCullDarkOak);
      generalQuadsCullJungle = getGeneralQuadsSafe(modelLeavesCullJungle);
      generalQuadsCullOak = getGeneralQuadsSafe(modelLeavesCullOak);
      generalQuadsCullSpruce = getGeneralQuadsSafe(modelLeavesCullSpruce);
      modelLeavesDoubleAcacia = getModelDoubleFace(modelLeavesCullAcacia);
      modelLeavesDoubleBirch = getModelDoubleFace(modelLeavesCullBirch);
      modelLeavesDoubleDarkOak = getModelDoubleFace(modelLeavesCullDarkOak);
      modelLeavesDoubleJungle = getModelDoubleFace(modelLeavesCullJungle);
      modelLeavesDoubleOak = getModelDoubleFace(modelLeavesCullOak);
      modelLeavesDoubleSpruce = getModelDoubleFace(modelLeavesCullSpruce);
      if (list.size() > 0) {
         jebac_vexiakrwecfs16wve.dbg("Enable face culling: " + jebac_vexiakrwecfs16wve.arrayToString(list.toArray()));
      }

   }

   // $FF: synthetic method
   private static IBakedModel getModelDoubleFace(IBakedModel p_getModelDoubleFace_0_) {
      if (p_getModelDoubleFace_0_ == null) {
         return null;
      } else if (p_getModelDoubleFace_0_.getGeneralQuads().size() > 0) {
         jebac_vexiakrwecfs16wve.warn("SmartLeaves: Model is not cube, general quads: " + p_getModelDoubleFace_0_.getGeneralQuads().size() + ", model: " + p_getModelDoubleFace_0_);
         return p_getModelDoubleFace_0_;
      } else {
         EnumFacing[] aenumfacing = EnumFacing.VALUES;
         EnumFacing[] var2 = aenumfacing;
         int var3 = aenumfacing.length;

         int var4;
         for(var4 = 0; var4 < var3; ++var4) {
            EnumFacing enumfacing = var2[var4];
            List list = p_getModelDoubleFace_0_.getFaceQuads(enumfacing);
            if (list.size() != 1) {
               jebac_vexiakrwecfs16wve.warn("SmartLeaves: Model is not cube, side: " + enumfacing + ", quads: " + list.size() + ", model: " + p_getModelDoubleFace_0_);
               return p_getModelDoubleFace_0_;
            }
         }

         IBakedModel ibakedmodel = jebac_vexiav9hukj6qy0k5.duplicateModel(p_getModelDoubleFace_0_);
         EnumFacing[] var14 = aenumfacing;
         var4 = aenumfacing.length;

         for(int var15 = 0; var15 < var4; ++var15) {
            EnumFacing enumfacing1 = var14[var15];
            List list1 = ibakedmodel.getFaceQuads(enumfacing1);
            BakedQuad bakedquad = (BakedQuad)list1.get(0);
            BakedQuad bakedquad1 = new BakedQuad((int[])bakedquad.getVertexData().clone(), bakedquad.getTintIndex(), bakedquad.getFace(), bakedquad.getSprite());
            int[] aint = bakedquad1.getVertexData();
            int[] aint1 = (int[])aint.clone();
            int j = aint.length / 4;
            System.arraycopy(aint, 0, aint1, 3 * j, j);
            System.arraycopy(aint, j, aint1, 2 * j, j);
            System.arraycopy(aint, 2 * j, aint1, j, j);
            System.arraycopy(aint, 3 * j, aint1, 0, j);
            System.arraycopy(aint1, 0, aint, 0, aint1.length);
            list1.add(bakedquad1);
         }

         return ibakedmodel;
      }
   }
}
