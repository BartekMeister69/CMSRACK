import java.io.IOException;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;

public class jebac_vexiagvtc62j0hqov extends jebac_vexiakl614w3uw0xg {
   // $FF: synthetic field
   private GameSettings options;
   // $FF: synthetic field
   protected String screenTitle = "Controls";
   // $FF: synthetic field
   private jebac_vexia4oibzo50ubf0 buttonReset;
   // $FF: synthetic field
   private jebac_vexiakl614w3uw0xg parentScreen;
   // $FF: synthetic field
   private static final GameSettings.Options[] optionsArr;
   // $FF: synthetic field
   public long time;
   // $FF: synthetic field
   private jebac_vexiac2ntje0zuqwe keyBindingList;
   // $FF: synthetic field
   public KeyBinding buttonId = null;

   // $FF: synthetic method
   protected void actionPerformed(jebac_vexia4oibzo50ubf0 button) throws IOException {
      if (button.id == 200) {
         this.mc.displayGuiScreen(this.parentScreen);
      } else if (button.id == 201) {
         KeyBinding[] var2 = this.mc.gameSettings.keyBindings;
         int var3 = var2.length;

         for(int var4 = 0; var4 < var3; ++var4) {
            KeyBinding keybinding = var2[var4];
            keybinding.setKeyCode(keybinding.getKeyCodeDefault());
         }

         KeyBinding.resetKeyBindingArrayAndHash();
      } else if (button.id < 100 && button instanceof jebac_vexiatgc7sxy17ln0) {
         this.options.setOptionValue(((jebac_vexiatgc7sxy17ln0)button).returnEnumOptions(), 1);
         button.displayString = this.options.getKeyBinding(GameSettings.Options.getEnumOptions(button.id));
      }

   }

   // $FF: synthetic method
   protected void mouseReleased(int mouseX, int mouseY, int state) {
      if (state != 0 || !this.keyBindingList.mouseReleased(mouseX, mouseY, state)) {
         super.mouseReleased(mouseX, mouseY, state);
      }

   }

   // $FF: synthetic method
   public void handleMouseInput() throws IOException {
      super.handleMouseInput();
      this.keyBindingList.handleMouseInput();
   }

   // $FF: synthetic method
   public jebac_vexiagvtc62j0hqov(jebac_vexiakl614w3uw0xg screen, GameSettings settings) {
      this.parentScreen = screen;
      this.options = settings;
   }

   // $FF: synthetic method
   protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
      if (this.buttonId != null) {
         this.options.setOptionKeyBinding(this.buttonId, -100 + mouseButton);
         this.buttonId = null;
         KeyBinding.resetKeyBindingArrayAndHash();
      } else if (mouseButton != 0 || !this.keyBindingList.mouseClicked(mouseX, mouseY, mouseButton)) {
         super.mouseClicked(mouseX, mouseY, mouseButton);
      }

   }

   // $FF: synthetic method
   public void initGui() {
      this.keyBindingList = new jebac_vexiac2ntje0zuqwe(this, this.mc);
      this.buttonList.add(new jebac_vexia4oibzo50ubf0(200, this.width / 2 - 155, this.height - 29, 150, 20, I18n.format("gui.done")));
      this.buttonList.add(this.buttonReset = new jebac_vexia4oibzo50ubf0(201, this.width / 2 - 155 + 160, this.height - 29, 150, 20, I18n.format("controls.resetAll")));
      this.screenTitle = I18n.format("controls.title");
      int i = 0;
      GameSettings.Options[] var2 = optionsArr;
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         GameSettings.Options gamesettings$options = var2[var4];
         if (gamesettings$options.getEnumFloat()) {
            this.buttonList.add(new jebac_vexiakfzkq5wmes2e(gamesettings$options.returnEnumOrdinal(), this.width / 2 - 155 + i % 2 * 160, 18 + 24 * (i >> 1), gamesettings$options));
         } else {
            this.buttonList.add(new jebac_vexiatgc7sxy17ln0(gamesettings$options.returnEnumOrdinal(), this.width / 2 - 155 + i % 2 * 160, 18 + 24 * (i >> 1), gamesettings$options, this.options.getKeyBinding(gamesettings$options)));
         }

         ++i;
      }

   }

   // $FF: synthetic method
   protected void keyTyped(char typedChar, int keyCode) throws IOException {
      if (this.buttonId != null) {
         if (keyCode == 1) {
            this.options.setOptionKeyBinding(this.buttonId, 0);
         } else if (keyCode != 0) {
            this.options.setOptionKeyBinding(this.buttonId, keyCode);
         } else if (typedChar > 0) {
            this.options.setOptionKeyBinding(this.buttonId, typedChar + 256);
         }

         this.buttonId = null;
         this.time = Minecraft.getSystemTime();
         KeyBinding.resetKeyBindingArrayAndHash();
      } else {
         super.keyTyped(typedChar, keyCode);
      }

   }

   static {
      optionsArr = new GameSettings.Options[]{GameSettings.Options.INVERT_MOUSE, GameSettings.Options.SENSITIVITY, GameSettings.Options.TOUCHSCREEN};
   }

   // $FF: synthetic method
   public void drawScreen(int mouseX, int mouseY, float partialTicks) {
      this.drawDefaultBackground();
      this.keyBindingList.drawScreen(mouseX, mouseY, partialTicks);
      this.drawCenteredString(this.fontRendererObj, this.screenTitle, this.width / 2, 8, 16777215);
      boolean flag = true;
      KeyBinding[] var5 = this.options.keyBindings;
      int var6 = var5.length;

      for(int var7 = 0; var7 < var6; ++var7) {
         KeyBinding keybinding = var5[var7];
         if (keybinding.getKeyCode() != keybinding.getKeyCodeDefault()) {
            flag = false;
            break;
         }
      }

      this.buttonReset.enabled = !flag;
      super.drawScreen(mouseX, mouseY, partialTicks);
   }
}
