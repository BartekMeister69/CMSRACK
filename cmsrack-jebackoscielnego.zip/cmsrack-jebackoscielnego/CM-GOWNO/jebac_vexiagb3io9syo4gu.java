import java.io.IOException;
import java.util.Iterator;
import java.util.List;

public class jebac_vexiagb3io9syo4gu extends jebac_vexiakl614w3uw0xg {
   // $FF: synthetic method
   protected void actionPerformedRightClick(jebac_vexia4oibzo50ubf0 p_actionPerformedRightClick_1_) throws IOException {
   }

   // $FF: synthetic method
   protected static jebac_vexia4oibzo50ubf0 getSelectedButton(List p_getSelectedButton_0_, int p_getSelectedButton_1_, int p_getSelectedButton_2_) {
      Iterator var3 = p_getSelectedButton_0_.iterator();

      while(var3.hasNext()) {
         jebac_vexia4oibzo50ubf0 guiButton = (jebac_vexia4oibzo50ubf0)var3.next();
         if (guiButton.visible) {
            int j = jebac_vexiahqnin1pyjn10.getButtonWidth(guiButton);
            int k = jebac_vexiahqnin1pyjn10.getButtonHeight(guiButton);
            if (p_getSelectedButton_1_ >= guiButton.xPosition && p_getSelectedButton_2_ >= guiButton.yPosition && p_getSelectedButton_1_ < guiButton.xPosition + j && p_getSelectedButton_2_ < guiButton.yPosition + k) {
               return guiButton;
            }
         }
      }

      return null;
   }

   // $FF: synthetic method
   protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
      super.mouseClicked(mouseX, mouseY, mouseButton);
      if (mouseButton == 1) {
         jebac_vexia4oibzo50ubf0 guibutton = getSelectedButton(this.buttonList, mouseX, mouseY);
         if (guibutton != null && guibutton.enabled) {
            guibutton.playPressSound(this.mc.getSoundHandler());
            this.actionPerformedRightClick(guibutton);
         }
      }

   }
}
