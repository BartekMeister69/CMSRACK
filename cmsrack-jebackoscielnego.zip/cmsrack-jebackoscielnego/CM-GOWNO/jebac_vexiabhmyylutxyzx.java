import com.google.common.base.Objects;
import com.google.common.collect.Lists;
import java.util.List;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.IChatComponent;

public class jebac_vexiabhmyylutxyzx {
   // $FF: synthetic field
   private final List field_178652_g = Lists.newArrayList();
   // $FF: synthetic field
   private int field_178658_j;
   // $FF: synthetic field
   private final jebac_vexia2ut457nkbgny field_178651_f;
   // $FF: synthetic field
   private static final jebac_vexia9nzh0zm3n32z field_178655_b = new jebac_vexia73a0lnekw3k0();
   // $FF: synthetic field
   public static final jebac_vexia9nzh0zm3n32z field_178657_a = new jebac_vexia9nzh0zm3n32z() {
      // $FF: synthetic method
      public void func_178663_a(float p_178663_1_, int alpha) {
      }

      // $FF: synthetic method
      public boolean func_178662_A_() {
         return false;
      }

      // $FF: synthetic method
      public IChatComponent getSpectatorName() {
         return new ChatComponentText("");
      }

      // $FF: synthetic method
      public void func_178661_a(jebac_vexiabhmyylutxyzx menu) {
      }
   };
   // $FF: synthetic field
   private static final jebac_vexia9nzh0zm3n32z field_178654_e = new jebac_vexia4tjvy6pwo8ll(1, false);
   // $FF: synthetic field
   private static final jebac_vexia9nzh0zm3n32z field_178653_d = new jebac_vexia4tjvy6pwo8ll(1, true);
   // $FF: synthetic field
   private int field_178660_i = -1;
   // $FF: synthetic field
   private jebac_vexialqxnhsad8zg7 field_178659_h = new jebac_vexiaar53v6g455cg();
   // $FF: synthetic field
   private static final jebac_vexia9nzh0zm3n32z field_178656_c = new jebac_vexia4tjvy6pwo8ll(-1, true);

   // $FF: synthetic method
   public void func_178641_d() {
      this.field_178651_f.func_175257_a(this);
   }

   // $FF: synthetic method
   public List func_178642_a() {
      List list = Lists.newArrayList();

      for(int i = 0; i <= 8; ++i) {
         list.add(this.func_178643_a(i));
      }

      return list;
   }

   static int access$102(jebac_vexiabhmyylutxyzx x0, int x1) {
      return x0.field_178658_j = x1;
   }

   // $FF: synthetic method
   public void func_178644_b(int p_178644_1_) {
      jebac_vexia9nzh0zm3n32z ispectatormenuobject = this.func_178643_a(p_178644_1_);
      if (ispectatormenuobject != field_178657_a) {
         if (this.field_178660_i == p_178644_1_ && ispectatormenuobject.func_178662_A_()) {
            ispectatormenuobject.func_178661_a(this);
         } else {
            this.field_178660_i = p_178644_1_;
         }
      }

   }

   // $FF: synthetic method
   public jebac_vexiam1glxj46m3t5 func_178646_f() {
      return new jebac_vexiam1glxj46m3t5(this.field_178659_h, this.func_178642_a(), this.field_178660_i);
   }

   // $FF: synthetic method
   public jebac_vexiabhmyylutxyzx(jebac_vexia2ut457nkbgny p_i45497_1_) {
      this.field_178651_f = p_i45497_1_;
   }

   // $FF: synthetic method
   public jebac_vexia9nzh0zm3n32z func_178643_a(int p_178643_1_) {
      int i = p_178643_1_ + this.field_178658_j * 6;
      return this.field_178658_j > 0 && p_178643_1_ == 0 ? field_178656_c : (p_178643_1_ == 7 ? (i < this.field_178659_h.func_178669_a().size() ? field_178653_d : field_178654_e) : (p_178643_1_ == 8 ? field_178655_b : (i >= 0 && i < this.field_178659_h.func_178669_a().size() ? (jebac_vexia9nzh0zm3n32z)Objects.firstNonNull(this.field_178659_h.func_178669_a().get(i), field_178657_a) : field_178657_a)));
   }

   // $FF: synthetic method
   public void func_178647_a(jebac_vexialqxnhsad8zg7 p_178647_1_) {
      this.field_178652_g.add(this.func_178646_f());
      this.field_178659_h = p_178647_1_;
      this.field_178660_i = -1;
      this.field_178658_j = 0;
   }

   // $FF: synthetic method
   public int func_178648_e() {
      return this.field_178660_i;
   }

   // $FF: synthetic method
   public jebac_vexia9nzh0zm3n32z func_178645_b() {
      return this.func_178643_a(this.field_178660_i);
   }

   // $FF: synthetic method
   public jebac_vexialqxnhsad8zg7 func_178650_c() {
      return this.field_178659_h;
   }
}
