import net.minecraft.client.settings.GameSettings;

public class jebac_vexiaildxyx0dfrwq extends jebac_vexiakfzkq5wmes2e implements jebac_vexia7qn8thb33dce {
   // $FF: synthetic field
   private GameSettings.Options option;

   // $FF: synthetic method
   public jebac_vexiaildxyx0dfrwq(int p_i50_1_, int p_i50_2_, int p_i50_3_, GameSettings.Options p_i50_4_) {
      super(p_i50_1_, p_i50_2_, p_i50_3_, p_i50_4_);
      this.option = p_i50_4_;
   }

   // $FF: synthetic method
   public GameSettings.Options getOption() {
      return this.option;
   }
}
