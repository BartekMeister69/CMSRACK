import net.minecraft.client.resources.I18n;

class jebac_vexiakccnrrck7p2v extends jebac_vexia72k5sdirsh7v {
   final jebac_vexiajrsmxgnpvxgq this$0;

   // $FF: synthetic method
   public jebac_vexiakccnrrck7p2v(jebac_vexiajrsmxgnpvxgq this$0, int p_i1075_2_, int p_i1075_3_, int p_i1075_4_) {
      super(p_i1075_2_, p_i1075_3_, p_i1075_4_, jebac_vexiajrsmxgnpvxgq.access$000(), 90, 220);
      this.this$0 = this$0;
   }

   // $FF: synthetic method
   public void drawButtonForegroundLayer(int mouseX, int mouseY) {
      jebac_vexiajrsmxgnpvxgq.access$200(this.this$0, I18n.format("gui.done"), mouseX, mouseY);
   }
}
