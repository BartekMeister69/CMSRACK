import java.io.IOException;
import net.minecraft.client.audio.SoundCategory;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.settings.GameSettings;

public class jebac_vexia0kvkbrbbz0rd extends jebac_vexiakl614w3uw0xg {
   // $FF: synthetic field
   private String field_146508_h;
   // $FF: synthetic field
   protected String field_146507_a = "Options";
   // $FF: synthetic field
   private final jebac_vexiakl614w3uw0xg field_146505_f;
   // $FF: synthetic field
   private final GameSettings game_settings_4;

   // $FF: synthetic method
   public jebac_vexia0kvkbrbbz0rd(jebac_vexiakl614w3uw0xg p_i45025_1_, GameSettings p_i45025_2_) {
      this.field_146505_f = p_i45025_1_;
      this.game_settings_4 = p_i45025_2_;
   }

   // $FF: synthetic method
   protected String getSoundVolume(SoundCategory p_146504_1_) {
      float f = this.game_settings_4.getSoundLevel(p_146504_1_);
      return f == 0.0F ? this.field_146508_h : (int)(f * 100.0F) + "%";
   }

   // $FF: synthetic method
   protected void actionPerformed(jebac_vexia4oibzo50ubf0 button) throws IOException {
      if (button.enabled && button.id == 200) {
         this.mc.gameSettings.saveOptions();
         this.mc.displayGuiScreen(this.field_146505_f);
      }

   }

   // $FF: synthetic method
   public void initGui() {
      int i = 0;
      this.field_146507_a = I18n.format("options.sounds.title");
      this.field_146508_h = I18n.format("options.off");
      this.buttonList.add(new jebac_vexiajhc6jsudlpn2(this, SoundCategory.MASTER.getCategoryId(), this.width / 2 - 155 + i % 2 * 160, this.height / 6 - 12 + 24 * (i >> 1), SoundCategory.MASTER, true));
      int i = i + 2;
      SoundCategory[] var2 = SoundCategory.values();
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         SoundCategory soundcategory = var2[var4];
         if (soundcategory != SoundCategory.MASTER) {
            this.buttonList.add(new jebac_vexiajhc6jsudlpn2(this, soundcategory.getCategoryId(), this.width / 2 - 155 + i % 2 * 160, this.height / 6 - 12 + 24 * (i >> 1), soundcategory, false));
            ++i;
         }
      }

      this.buttonList.add(new jebac_vexia4oibzo50ubf0(200, this.width / 2 - 100, this.height / 6 + 168, I18n.format("gui.done")));
   }

   static GameSettings access$000(jebac_vexia0kvkbrbbz0rd x0) {
      return x0.game_settings_4;
   }

   // $FF: synthetic method
   public void drawScreen(int mouseX, int mouseY, float partialTicks) {
      this.drawDefaultBackground();
      this.drawCenteredString(this.fontRendererObj, this.field_146507_a, this.width / 2, 15, 16777215);
      super.drawScreen(mouseX, mouseY, partialTicks);
   }
}
