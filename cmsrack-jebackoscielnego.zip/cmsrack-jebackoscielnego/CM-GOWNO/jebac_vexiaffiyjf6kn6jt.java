import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import java.awt.Dimension;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class jebac_vexiaffiyjf6kn6jt {
   // $FF: synthetic method
   public static jebac_vexiaygbu8cvjfpcg parseItemModel(JsonObject p_parseItemModel_0_) {
      String s = jebac_vexia10ed95amnpom.getString(p_parseItemModel_0_, "type");
      if (!jebac_vexiakrwecfs16wve.equals(s, "PlayerItem")) {
         throw new JsonParseException("Unknown model type: " + s);
      } else {
         int[] aint = jebac_vexia10ed95amnpom.parseIntArray(p_parseItemModel_0_.get("textureSize"), 2);
         checkNull(aint, "Missing texture size");
         Dimension dimension = new Dimension(aint[0], aint[1]);
         boolean flag = jebac_vexia10ed95amnpom.getBoolean(p_parseItemModel_0_, "usePlayerTexture", false);
         JsonArray jsonarray = (JsonArray)p_parseItemModel_0_.get("models");
         checkNull(jsonarray, "Missing elements");
         Map map = new HashMap();
         List list = new ArrayList();
         new ArrayList();

         for(int i = 0; i < jsonarray.size(); ++i) {
            JsonObject jsonobject = (JsonObject)jsonarray.get(i);
            String s1 = jebac_vexia10ed95amnpom.getString(jsonobject, "baseId");
            if (s1 != null) {
               JsonObject jsonobject1 = (JsonObject)map.get(s1);
               if (jsonobject1 == null) {
                  jebac_vexiakrwecfs16wve.warn("BaseID not found: " + s1);
                  continue;
               }

               Iterator var12 = jsonobject1.entrySet().iterator();

               while(var12.hasNext()) {
                  Entry entry = (Entry)var12.next();
                  if (!jsonobject.has((String)entry.getKey())) {
                     jsonobject.add((String)entry.getKey(), (JsonElement)entry.getValue());
                  }
               }
            }

            String s2 = jebac_vexia10ed95amnpom.getString(jsonobject, "id");
            if (s2 != null) {
               if (!map.containsKey(s2)) {
                  map.put(s2, jsonobject);
               } else {
                  jebac_vexiakrwecfs16wve.warn("Duplicate model ID: " + s2);
               }
            }

            jebac_vexianytr9dqjsedo playeritemrenderer = parseItemRenderer(jsonobject, dimension);
            if (playeritemrenderer != null) {
               list.add(playeritemrenderer);
            }
         }

         jebac_vexianytr9dqjsedo[] aplayeritemrenderer = (jebac_vexianytr9dqjsedo[])((jebac_vexianytr9dqjsedo[])list.toArray(new jebac_vexianytr9dqjsedo[0]));
         return new jebac_vexiaygbu8cvjfpcg(flag, aplayeritemrenderer);
      }
   }

   // $FF: synthetic method
   private static jebac_vexiau47ipgjckapi parseModelRenderer(JsonObject p_parseModelRenderer_0_, jebac_vexiat51dq4htxchd p_parseModelRenderer_1_) {
      jebac_vexiau47ipgjckapi modelrenderer = new jebac_vexiau47ipgjckapi(p_parseModelRenderer_1_);
      String s = jebac_vexia10ed95amnpom.getString(p_parseModelRenderer_0_, "invertAxis", "").toLowerCase();
      boolean flag = s.contains("x");
      boolean flag1 = s.contains("y");
      boolean flag2 = s.contains("z");
      float[] afloat = jebac_vexia10ed95amnpom.parseFloatArray(p_parseModelRenderer_0_.get("translate"), 3, new float[3]);
      if (flag) {
         afloat[0] = -afloat[0];
      }

      if (flag1) {
         afloat[1] = -afloat[1];
      }

      if (flag2) {
         afloat[2] = -afloat[2];
      }

      float[] afloat1 = jebac_vexia10ed95amnpom.parseFloatArray(p_parseModelRenderer_0_.get("rotate"), 3, new float[3]);

      for(int i = 0; i < afloat1.length; ++i) {
         afloat1[i] = afloat1[i] / 180.0F * 3.1415927F;
      }

      if (flag) {
         afloat1[0] = -afloat1[0];
      }

      if (flag1) {
         afloat1[1] = -afloat1[1];
      }

      if (flag2) {
         afloat1[2] = -afloat1[2];
      }

      modelrenderer.setRotationPoint(afloat[0], afloat[1], afloat[2]);
      modelrenderer.rotateAngleX = afloat1[0];
      modelrenderer.rotateAngleY = afloat1[1];
      modelrenderer.rotateAngleZ = afloat1[2];
      String s1 = jebac_vexia10ed95amnpom.getString(p_parseModelRenderer_0_, "mirrorTexture", "").toLowerCase();
      boolean flag3 = s1.contains("u");
      boolean flag4 = s1.contains("v");
      if (flag3) {
         modelrenderer.mirror = true;
      }

      if (flag4) {
         modelrenderer.mirrorV = true;
      }

      JsonArray jsonarray = p_parseModelRenderer_0_.getAsJsonArray("boxes");
      JsonObject jsonobject;
      if (jsonarray != null) {
         for(int j = 0; j < jsonarray.size(); ++j) {
            jsonobject = jsonarray.get(j).getAsJsonObject();
            int[] aint = jebac_vexia10ed95amnpom.parseIntArray(jsonobject.get("textureOffset"), 2);
            if (aint == null) {
               throw new JsonParseException("Texture offset not specified");
            }

            float[] afloat2 = jebac_vexia10ed95amnpom.parseFloatArray(jsonobject.get("coordinates"), 6);
            if (afloat2 == null) {
               throw new JsonParseException("Coordinates not specified");
            }

            if (flag) {
               afloat2[0] = -afloat2[0] - afloat2[3];
            }

            if (flag1) {
               afloat2[1] = -afloat2[1] - afloat2[4];
            }

            if (flag2) {
               afloat2[2] = -afloat2[2] - afloat2[5];
            }

            float f = jebac_vexia10ed95amnpom.getFloat(jsonobject, "sizeAdd", 0.0F);
            modelrenderer.setTextureOffset(aint[0], aint[1]);
            modelrenderer.addBox(afloat2[0], afloat2[1], afloat2[2], (int)afloat2[3], (int)afloat2[4], (int)afloat2[5], f);
         }
      }

      JsonArray jsonarray1 = p_parseModelRenderer_0_.getAsJsonArray("sprites");
      if (jsonarray1 != null) {
         for(int k = 0; k < jsonarray1.size(); ++k) {
            JsonObject jsonobject2 = jsonarray1.get(k).getAsJsonObject();
            int[] aint1 = jebac_vexia10ed95amnpom.parseIntArray(jsonobject2.get("textureOffset"), 2);
            if (aint1 == null) {
               throw new JsonParseException("Texture offset not specified");
            }

            float[] afloat3 = jebac_vexia10ed95amnpom.parseFloatArray(jsonobject2.get("coordinates"), 6);
            if (afloat3 == null) {
               throw new JsonParseException("Coordinates not specified");
            }

            if (flag) {
               afloat3[0] = -afloat3[0] - afloat3[3];
            }

            if (flag1) {
               afloat3[1] = -afloat3[1] - afloat3[4];
            }

            if (flag2) {
               afloat3[2] = -afloat3[2] - afloat3[5];
            }

            float f1 = jebac_vexia10ed95amnpom.getFloat(jsonobject2, "sizeAdd", 0.0F);
            modelrenderer.setTextureOffset(aint1[0], aint1[1]);
            modelrenderer.addSprite(afloat3[0], afloat3[1], afloat3[2], (int)afloat3[3], (int)afloat3[4], (int)afloat3[5], f1);
         }
      }

      jsonobject = (JsonObject)p_parseModelRenderer_0_.get("submodel");
      if (jsonobject != null) {
         jebac_vexiau47ipgjckapi modelrenderer1 = parseModelRenderer(jsonobject, p_parseModelRenderer_1_);
         modelrenderer.addChild(modelrenderer1);
      }

      JsonArray jsonarray2 = (JsonArray)p_parseModelRenderer_0_.get("submodels");
      if (jsonarray2 != null) {
         for(int l = 0; l < jsonarray2.size(); ++l) {
            JsonObject jsonobject3 = (JsonObject)jsonarray2.get(l);
            jebac_vexiau47ipgjckapi modelrenderer2 = parseModelRenderer(jsonobject3, p_parseModelRenderer_1_);
            modelrenderer.addChild(modelrenderer2);
         }
      }

      return modelrenderer;
   }

   // $FF: synthetic method
   private static int parseAttachModel(String p_parseAttachModel_0_) {
      if (p_parseAttachModel_0_ == null) {
         return 0;
      } else if (p_parseAttachModel_0_.equals("body")) {
         return 0;
      } else if (p_parseAttachModel_0_.equals("head")) {
         return 1;
      } else if (p_parseAttachModel_0_.equals("leftArm")) {
         return 2;
      } else if (p_parseAttachModel_0_.equals("rightArm")) {
         return 3;
      } else if (p_parseAttachModel_0_.equals("leftLeg")) {
         return 4;
      } else if (p_parseAttachModel_0_.equals("rightLeg")) {
         return 5;
      } else if (p_parseAttachModel_0_.equals("cape")) {
         return 6;
      } else {
         jebac_vexiakrwecfs16wve.warn("Unknown attachModel: " + p_parseAttachModel_0_);
         return 0;
      }
   }

   // $FF: synthetic method
   private static void checkNull(Object p_checkNull_0_, String p_checkNull_1_) {
      if (p_checkNull_0_ == null) {
         throw new JsonParseException(p_checkNull_1_);
      }
   }

   // $FF: synthetic method
   private static jebac_vexianytr9dqjsedo parseItemRenderer(JsonObject p_parseItemRenderer_0_, Dimension p_parseItemRenderer_1_) {
      String s = jebac_vexia10ed95amnpom.getString(p_parseItemRenderer_0_, "type");
      if (!jebac_vexiakrwecfs16wve.equals(s, "ModelBox")) {
         jebac_vexiakrwecfs16wve.warn("Unknown model type: " + s);
         return null;
      } else {
         String s1 = jebac_vexia10ed95amnpom.getString(p_parseItemRenderer_0_, "attachTo");
         int i = parseAttachModel(s1);
         float f = jebac_vexia10ed95amnpom.getFloat(p_parseItemRenderer_0_, "scale", 1.0F);
         jebac_vexiat51dq4htxchd modelbase = new jebac_vexiaq6f3ga4k74sq();
         modelbase.textureWidth = p_parseItemRenderer_1_.width;
         modelbase.textureHeight = p_parseItemRenderer_1_.height;
         jebac_vexiau47ipgjckapi modelrenderer = parseModelRenderer(p_parseItemRenderer_0_, modelbase);
         return new jebac_vexianytr9dqjsedo(i, f, modelrenderer);
      }
   }
}
