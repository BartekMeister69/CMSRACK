import java.util.Properties;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.world.World;

public class jebac_vexia6uw791mvay6k {
   // $FF: synthetic field
   private int startFadeOut = -1;
   // $FF: synthetic field
   private int endFadeOut = -1;
   // $FF: synthetic field
   public int textureId;
   // $FF: synthetic field
   public static final float[] DEFAULT_AXIS = new float[]{1.0F, 0.0F, 0.0F};
   // $FF: synthetic field
   private float[] axis;
   // $FF: synthetic field
   private float speed = 1.0F;
   // $FF: synthetic field
   private int startFadeIn = -1;
   // $FF: synthetic field
   private jebac_vexiauw6xjpymnteq days;
   // $FF: synthetic field
   private int daysLoop;
   // $FF: synthetic field
   private int endFadeIn = -1;
   // $FF: synthetic field
   public String source = null;
   // $FF: synthetic field
   private boolean rotate = false;
   // $FF: synthetic field
   private int blend = 1;

   // $FF: synthetic method
   public jebac_vexia6uw791mvay6k(Properties p_i35_1_, String p_i35_2_) {
      this.axis = DEFAULT_AXIS;
      this.days = null;
      this.daysLoop = 8;
      this.textureId = -1;
      jebac_vexiadw49qo6dh8al connectedparser = new jebac_vexiadw49qo6dh8al("CustomSky");
      this.source = p_i35_1_.getProperty("source", p_i35_2_);
      this.startFadeIn = this.parseTime(p_i35_1_.getProperty("startFadeIn"));
      this.endFadeIn = this.parseTime(p_i35_1_.getProperty("endFadeIn"));
      this.startFadeOut = this.parseTime(p_i35_1_.getProperty("startFadeOut"));
      this.endFadeOut = this.parseTime(p_i35_1_.getProperty("endFadeOut"));
      this.blend = jebac_vexiau5kgy2fm1nlm.parseBlend(p_i35_1_.getProperty("blend"));
      this.rotate = this.parseBoolean(p_i35_1_.getProperty("rotate"));
      this.speed = this.parseFloat(p_i35_1_.getProperty("speed"));
      this.axis = this.parseAxis(p_i35_1_.getProperty("axis"));
      this.days = connectedparser.parseRangeListInt(p_i35_1_.getProperty("days"));
      this.daysLoop = connectedparser.parseInt(p_i35_1_.getProperty("daysLoop"), 8);
   }

   // $FF: synthetic method
   private int normalizeTime(int p_normalizeTime_1_) {
      while(p_normalizeTime_1_ >= 24000) {
         p_normalizeTime_1_ -= 24000;
      }

      while(p_normalizeTime_1_ < 0) {
         p_normalizeTime_1_ += 24000;
      }

      return p_normalizeTime_1_;
   }

   // $FF: synthetic method
   private boolean timeBetween(int p_timeBetween_1_, int p_timeBetween_2_, int p_timeBetween_3_) {
      return p_timeBetween_2_ <= p_timeBetween_3_ ? p_timeBetween_1_ >= p_timeBetween_2_ && p_timeBetween_1_ <= p_timeBetween_3_ : p_timeBetween_1_ >= p_timeBetween_2_ || p_timeBetween_1_ <= p_timeBetween_3_;
   }

   // $FF: synthetic method
   public boolean isValid(String p_isValid_1_) {
      if (this.source == null) {
         jebac_vexiakrwecfs16wve.warn("No source texture: " + p_isValid_1_);
         return false;
      } else {
         this.source = jebac_vexiamg04e8zzk81s.fixResourcePath(this.source, jebac_vexiamg04e8zzk81s.getBasePath(p_isValid_1_));
         if (this.startFadeIn >= 0 && this.endFadeIn >= 0 && this.endFadeOut >= 0) {
            int i = this.normalizeTime(this.endFadeIn - this.startFadeIn);
            if (this.startFadeOut < 0) {
               this.startFadeOut = this.normalizeTime(this.endFadeOut - i);
               if (this.timeBetween(this.startFadeOut, this.startFadeIn, this.endFadeIn)) {
                  this.startFadeOut = this.endFadeIn;
               }
            }

            int j = this.normalizeTime(this.startFadeOut - this.endFadeIn);
            int k = this.normalizeTime(this.endFadeOut - this.startFadeOut);
            int l = this.normalizeTime(this.startFadeIn - this.endFadeOut);
            int i1 = i + j + k + l;
            if (i1 != 24000) {
               jebac_vexiakrwecfs16wve.warn("Invalid fadeIn/fadeOut times, sum is not 24h: " + i1);
               return false;
            } else if (this.speed < 0.0F) {
               jebac_vexiakrwecfs16wve.warn("Invalid speed: " + this.speed);
               return false;
            } else if (this.daysLoop <= 0) {
               jebac_vexiakrwecfs16wve.warn("Invalid daysLoop: " + this.daysLoop);
               return false;
            } else {
               return true;
            }
         } else {
            jebac_vexiakrwecfs16wve.warn("Invalid times, required are: startFadeIn, endFadeIn and endFadeOut.");
            return false;
         }
      }
   }

   // $FF: synthetic method
   private float[] parseAxis(String p_parseAxis_1_) {
      if (p_parseAxis_1_ == null) {
         return DEFAULT_AXIS;
      } else {
         String[] astring = jebac_vexiakrwecfs16wve.tokenize(p_parseAxis_1_, " ");
         if (astring.length != 3) {
            jebac_vexiakrwecfs16wve.warn("Invalid axis: " + p_parseAxis_1_);
            return DEFAULT_AXIS;
         } else {
            float[] afloat = new float[3];

            for(int i = 0; i < astring.length; ++i) {
               afloat[i] = jebac_vexiakrwecfs16wve.parseFloat(astring[i], Float.MIN_VALUE);
               if (afloat[i] == Float.MIN_VALUE) {
                  jebac_vexiakrwecfs16wve.warn("Invalid axis: " + p_parseAxis_1_);
                  return DEFAULT_AXIS;
               }

               if (afloat[i] < -1.0F || afloat[i] > 1.0F) {
                  jebac_vexiakrwecfs16wve.warn("Invalid axis values: " + p_parseAxis_1_);
                  return DEFAULT_AXIS;
               }
            }

            float f2 = afloat[0];
            float f = afloat[1];
            float f1 = afloat[2];
            if (f2 * f2 + f * f + f1 * f1 < 1.0E-5F) {
               jebac_vexiakrwecfs16wve.warn("Invalid axis values: " + p_parseAxis_1_);
               return DEFAULT_AXIS;
            } else {
               return new float[]{f1, f, -f2};
            }
         }
      }
   }

   // $FF: synthetic method
   public boolean isActive(World p_isActive_1_, int p_isActive_2_) {
      if (this.timeBetween(p_isActive_2_, this.endFadeOut, this.startFadeIn)) {
         return false;
      } else if (this.days == null) {
         return true;
      } else {
         long i = p_isActive_1_.getWorldTime();

         long j;
         for(j = i - (long)this.startFadeIn; j < 0L; j += (long)(24000 * this.daysLoop)) {
         }

         int k = (int)(j / 24000L);
         int l = k % this.daysLoop;
         return this.days.isInRange(l);
      }
   }

   // $FF: synthetic method
   private int parseTime(String p_parseTime_1_) {
      if (p_parseTime_1_ == null) {
         return -1;
      } else {
         String[] astring = jebac_vexiakrwecfs16wve.tokenize(p_parseTime_1_, ":");
         if (astring.length != 2) {
            jebac_vexiakrwecfs16wve.warn("Invalid time: " + p_parseTime_1_);
            return -1;
         } else {
            String s = astring[0];
            String s1 = astring[1];
            int i = jebac_vexiakrwecfs16wve.parseInt(s, -1);
            int j = jebac_vexiakrwecfs16wve.parseInt(s1, -1);
            if (i >= 0 && i <= 23 && j >= 0 && j <= 59) {
               i -= 6;
               if (i < 0) {
                  i += 24;
               }

               return i * 1000 + (int)((double)j / 60.0D * 1000.0D);
            } else {
               jebac_vexiakrwecfs16wve.warn("Invalid time: " + p_parseTime_1_);
               return -1;
            }
         }
      }
   }

   // $FF: synthetic method
   private boolean parseBoolean(String p_parseBoolean_1_) {
      if (p_parseBoolean_1_ == null) {
         return true;
      } else if (p_parseBoolean_1_.toLowerCase().equals("true")) {
         return true;
      } else if (p_parseBoolean_1_.toLowerCase().equals("false")) {
         return false;
      } else {
         jebac_vexiakrwecfs16wve.warn("Unknown boolean: " + p_parseBoolean_1_);
         return true;
      }
   }

   // $FF: synthetic method
   private float parseFloat(String p_parseFloat_1_) {
      if (p_parseFloat_1_ == null) {
         return 1.0F;
      } else {
         float f = jebac_vexiakrwecfs16wve.parseFloat(p_parseFloat_1_, Float.MIN_VALUE);
         if (f == Float.MIN_VALUE) {
            jebac_vexiakrwecfs16wve.warn("Invalid value: " + p_parseFloat_1_);
            return 1.0F;
         } else {
            return f;
         }
      }
   }

   // $FF: synthetic method
   public void render(int p_render_1_, float p_render_2_, float p_render_3_) {
      float f = p_render_3_ * this.getFadeBrightness(p_render_1_);
      f = jebac_vexiakrwecfs16wve.limit(f, 0.0F, 1.0F);
      if (f >= 1.0E-4F) {
         GlStateManager.bindTexture(this.textureId);
         jebac_vexiau5kgy2fm1nlm.setupBlend(this.blend, f);
         GlStateManager.pushMatrix();
         if (this.rotate) {
            GlStateManager.rotate(p_render_2_ * 360.0F * this.speed, this.axis[0], this.axis[1], this.axis[2]);
         }

         Tessellator tessellator = Tessellator.getInstance();
         GlStateManager.rotate(90.0F, 1.0F, 0.0F, 0.0F);
         GlStateManager.rotate(-90.0F, 0.0F, 0.0F, 1.0F);
         this.renderSide(tessellator, 4);
         GlStateManager.pushMatrix();
         GlStateManager.rotate(90.0F, 1.0F, 0.0F, 0.0F);
         this.renderSide(tessellator, 1);
         GlStateManager.popMatrix();
         GlStateManager.pushMatrix();
         GlStateManager.rotate(-90.0F, 1.0F, 0.0F, 0.0F);
         this.renderSide(tessellator, 0);
         GlStateManager.popMatrix();
         GlStateManager.rotate(90.0F, 0.0F, 0.0F, 1.0F);
         this.renderSide(tessellator, 5);
         GlStateManager.rotate(90.0F, 0.0F, 0.0F, 1.0F);
         this.renderSide(tessellator, 2);
         GlStateManager.rotate(90.0F, 0.0F, 0.0F, 1.0F);
         this.renderSide(tessellator, 3);
         GlStateManager.popMatrix();
      }

   }

   // $FF: synthetic method
   private float getFadeBrightness(int p_getFadeBrightness_1_) {
      int i;
      int j;
      if (this.timeBetween(p_getFadeBrightness_1_, this.startFadeIn, this.endFadeIn)) {
         i = this.normalizeTime(this.endFadeIn - this.startFadeIn);
         j = this.normalizeTime(p_getFadeBrightness_1_ - this.startFadeIn);
         return (float)j / (float)i;
      } else if (this.timeBetween(p_getFadeBrightness_1_, this.endFadeIn, this.startFadeOut)) {
         return 1.0F;
      } else if (this.timeBetween(p_getFadeBrightness_1_, this.startFadeOut, this.endFadeOut)) {
         i = this.normalizeTime(this.endFadeOut - this.startFadeOut);
         j = this.normalizeTime(p_getFadeBrightness_1_ - this.startFadeOut);
         return 1.0F - (float)j / (float)i;
      } else {
         return 0.0F;
      }
   }

   // $FF: synthetic method
   private void renderSide(Tessellator p_renderSide_1_, int p_renderSide_2_) {
      WorldRenderer worldrenderer = p_renderSide_1_.getWorldRenderer();
      double d0 = (double)(p_renderSide_2_ % 3) / 3.0D;
      double d1 = (double)(p_renderSide_2_ / 3) / 2.0D;
      worldrenderer.begin(7, DefaultVertexFormats.POSITION_TEX);
      worldrenderer.pos(-100.0D, -100.0D, -100.0D).tex(d0, d1).endVertex();
      worldrenderer.pos(-100.0D, -100.0D, 100.0D).tex(d0, d1 + 0.5D).endVertex();
      worldrenderer.pos(100.0D, -100.0D, 100.0D).tex(d0 + 0.3333333333333333D, d1 + 0.5D).endVertex();
      worldrenderer.pos(100.0D, -100.0D, -100.0D).tex(d0 + 0.3333333333333333D, d1).endVertex();
      p_renderSide_1_.draw();
   }
}
