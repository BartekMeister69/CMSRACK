import com.google.common.collect.Lists;
import java.io.IOException;
import java.util.Iterator;
import java.util.TreeMap;
import java.util.Map.Entry;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.settings.GameSettings;

public class jebac_vexialkppcl8ymvgi extends jebac_vexiakl614w3uw0xg {
   // $FF: synthetic field
   private final java.util.List field_146609_h = Lists.newArrayList();
   // $FF: synthetic field
   private final GameSettings game_settings_2;
   // $FF: synthetic field
   private final jebac_vexiakl614w3uw0xg field_146608_a;
   // $FF: synthetic field
   private final java.util.List field_146604_g = Lists.newArrayList();
   // $FF: synthetic field
   private jebac_vexiauraeepzco20r field_146606_s;
   // $FF: synthetic field
   private jebac_vexia4oibzo50ubf0 field_146605_t;
   // $FF: synthetic field
   private String[] field_146607_r;
   // $FF: synthetic field
   private String field_146610_i;

   // $FF: synthetic method
   public jebac_vexialkppcl8ymvgi(jebac_vexiakl614w3uw0xg p_i1061_1_, GameSettings p_i1061_2_) {
      this.field_146608_a = p_i1061_1_;
      this.game_settings_2 = p_i1061_2_;
   }

   // $FF: synthetic method
   public void handleMouseInput() throws IOException {
      super.handleMouseInput();
      this.field_146606_s.handleMouseInput();
   }

   static java.util.List access$100(jebac_vexialkppcl8ymvgi x0) {
      return x0.field_146609_h;
   }

   // $FF: synthetic method
   protected void actionPerformed(jebac_vexia4oibzo50ubf0 button) throws IOException {
      if (button.enabled) {
         if (button.id == 2) {
            this.game_settings_2.saveOptions();
            this.game_settings_2.saveOptions();
            this.mc.displayGuiScreen(this.field_146608_a);
         }

         if (button.id == 1) {
            this.game_settings_2.setOptionValue(GameSettings.Options.SNOOPER_ENABLED, 1);
            this.field_146605_t.displayString = this.game_settings_2.getKeyBinding(GameSettings.Options.SNOOPER_ENABLED);
         }
      }

   }

   static java.util.List access$000(jebac_vexialkppcl8ymvgi x0) {
      return x0.field_146604_g;
   }

   // $FF: synthetic method
   public void initGui() {
      this.field_146610_i = I18n.format("options.snooper.title");
      String s = I18n.format("options.snooper.desc");
      java.util.List list = Lists.newArrayList();
      Iterator var3 = this.fontRendererObj.listFormattedStringToWidth(s, this.width - 30).iterator();

      while(var3.hasNext()) {
         Object s1 = var3.next();
         list.add((String)s1);
      }

      this.field_146607_r = (String[])list.toArray(new String[0]);
      this.field_146604_g.clear();
      this.field_146609_h.clear();
      this.buttonList.add(this.field_146605_t = new jebac_vexia4oibzo50ubf0(1, this.width / 2 - 152, this.height - 30, 150, 20, this.game_settings_2.getKeyBinding(GameSettings.Options.SNOOPER_ENABLED)));
      this.buttonList.add(new jebac_vexia4oibzo50ubf0(2, this.width / 2 + 2, this.height - 30, 150, 20, I18n.format("gui.done")));
      var3 = (new TreeMap(this.mc.getPlayerUsageSnooper().getCurrentStats())).entrySet().iterator();

      while(var3.hasNext()) {
         Entry entry = (Entry)var3.next();
         this.field_146604_g.add(entry.getKey());
         this.field_146609_h.add(this.fontRendererObj.trimStringToWidth((String)entry.getValue(), this.width - 220));
      }

      this.field_146606_s = new jebac_vexiauraeepzco20r(this);
   }

   // $FF: synthetic method
   public void drawScreen(int mouseX, int mouseY, float partialTicks) {
      this.drawDefaultBackground();
      this.field_146606_s.drawScreen(mouseX, mouseY, partialTicks);
      this.drawCenteredString(this.fontRendererObj, this.field_146610_i, this.width / 2, 8, 16777215);
      int i = 22;
      String[] var5 = this.field_146607_r;
      int var6 = var5.length;

      for(int var7 = 0; var7 < var6; ++var7) {
         String s = var5[var7];
         this.drawCenteredString(this.fontRendererObj, s, this.width / 2, i, 8421504);
         i += this.fontRendererObj.FONT_HEIGHT;
      }

      super.drawScreen(mouseX, mouseY, partialTicks);
   }
}
