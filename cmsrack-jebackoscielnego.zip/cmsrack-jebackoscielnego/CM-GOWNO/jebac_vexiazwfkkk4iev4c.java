import java.io.IOException;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.resources.I18n;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.C16PacketClientStatus;
import net.minecraft.stats.StatFileWriter;

public class jebac_vexiazwfkkk4iev4c extends jebac_vexiakl614w3uw0xg implements jebac_vexias8mqy4rid1g7 {
   // $FF: synthetic field
   protected String screenTitle = "Select world";
   // $FF: synthetic field
   private jebac_vexia838cb3ocv584 blockStats;
   // $FF: synthetic field
   private final StatFileWriter field_146546_t;
   // $FF: synthetic field
   private jebac_vexiado18oeh2l9bq displaySlot;
   // $FF: synthetic field
   private jebac_vexias89whxqlvzz6 mobStats;
   // $FF: synthetic field
   private jebac_vexia8en3b6qi5og2 generalStats;
   // $FF: synthetic field
   private jebac_vexiaemblsqysdl65 itemStats;
   // $FF: synthetic field
   protected jebac_vexiakl614w3uw0xg parentScreen;
   // $FF: synthetic field
   private boolean doesGuiPauseGame = true;

   // $FF: synthetic method
   public void handleMouseInput() throws IOException {
      super.handleMouseInput();
      if (this.displaySlot != null) {
         this.displaySlot.handleMouseInput();
      }

   }

   // $FF: synthetic method
   protected void actionPerformed(jebac_vexia4oibzo50ubf0 button) throws IOException {
      if (button.enabled) {
         if (button.id == 0) {
            this.mc.displayGuiScreen(this.parentScreen);
         } else if (button.id == 1) {
            this.displaySlot = this.generalStats;
         } else if (button.id == 3) {
            this.displaySlot = this.itemStats;
         } else if (button.id == 2) {
            this.displaySlot = this.blockStats;
         } else if (button.id == 4) {
            this.displaySlot = this.mobStats;
         } else {
            this.displaySlot.actionPerformed(button);
         }
      }

   }

   static void access$1000(jebac_vexiazwfkkk4iev4c x0, int x1, int x2, int x3, int x4, int x5, int x6) {
      x0.drawGradientRect(x1, x2, x3, x4, x5, x6);
   }

   static jebac_vexiav0ttj7we8byq access$1700(jebac_vexiazwfkkk4iev4c x0) {
      return x0.fontRendererObj;
   }

   // $FF: synthetic method
   public boolean doesGuiPauseGame() {
      return !this.doesGuiPauseGame;
   }

   static jebac_vexiav0ttj7we8byq access$300(jebac_vexiazwfkkk4iev4c x0) {
      return x0.fontRendererObj;
   }

   // $FF: synthetic method
   public void initGui() {
      this.screenTitle = I18n.format("gui.stats");
      this.doesGuiPauseGame = true;
      this.mc.getNetHandler().addToSendQueue(new C16PacketClientStatus(C16PacketClientStatus.EnumState.REQUEST_STATS));
   }

   // $FF: synthetic method
   public void drawScreen(int mouseX, int mouseY, float partialTicks) {
      if (this.doesGuiPauseGame) {
         this.drawDefaultBackground();
         this.drawCenteredString(this.fontRendererObj, I18n.format("multiplayer.downloadingStats"), this.width / 2, this.height / 2, 16777215);
         this.drawCenteredString(this.fontRendererObj, lanSearchStates[(int)(Minecraft.getSystemTime() / 150L % (long)lanSearchStates.length)], this.width / 2, this.height / 2 + this.fontRendererObj.FONT_HEIGHT * 2, 16777215);
      } else {
         this.displaySlot.drawScreen(mouseX, mouseY, partialTicks);
         this.drawCenteredString(this.fontRendererObj, this.screenTitle, this.width / 2, 20, 16777215);
         super.drawScreen(mouseX, mouseY, partialTicks);
      }

   }

   static jebac_vexiav0ttj7we8byq access$200(jebac_vexiazwfkkk4iev4c x0) {
      return x0.fontRendererObj;
   }

   static void access$700(jebac_vexiazwfkkk4iev4c x0, int x1, int x2, int x3, int x4, int x5, int x6) {
      x0.drawGradientRect(x1, x2, x3, x4, x5, x6);
   }

   // $FF: synthetic method
   public void createButtons() {
      this.buttonList.add(new jebac_vexia4oibzo50ubf0(0, this.width / 2 + 4, this.height - 28, 150, 20, I18n.format("gui.done")));
      this.buttonList.add(new jebac_vexia4oibzo50ubf0(1, this.width / 2 - 160, this.height - 52, 80, 20, I18n.format("stat.generalButton")));
      jebac_vexia4oibzo50ubf0 guibutton;
      this.buttonList.add(guibutton = new jebac_vexia4oibzo50ubf0(2, this.width / 2 - 80, this.height - 52, 80, 20, I18n.format("stat.blocksButton")));
      jebac_vexia4oibzo50ubf0 guibutton1;
      this.buttonList.add(guibutton1 = new jebac_vexia4oibzo50ubf0(3, this.width / 2, this.height - 52, 80, 20, I18n.format("stat.itemsButton")));
      jebac_vexia4oibzo50ubf0 guibutton2;
      this.buttonList.add(guibutton2 = new jebac_vexia4oibzo50ubf0(4, this.width / 2 + 80, this.height - 52, 80, 20, I18n.format("stat.mobsButton")));
      if (this.blockStats.getSize() == 0) {
         guibutton.enabled = false;
      }

      if (this.itemStats.getSize() == 0) {
         guibutton1.enabled = false;
      }

      if (this.mobStats.getSize() == 0) {
         guibutton2.enabled = false;
      }

   }

   // $FF: synthetic method
   private void drawSprite(int p_146527_1_, int p_146527_2_, int p_146527_3_, int p_146527_4_) {
      GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
      this.mc.getTextureManager().bindTexture(statIcons);
      Tessellator tessellator = Tessellator.getInstance();
      WorldRenderer worldrenderer = tessellator.getWorldRenderer();
      worldrenderer.begin(7, DefaultVertexFormats.POSITION_TEX);
      worldrenderer.pos((double)p_146527_1_, (double)(p_146527_2_ + 18), (double)this.zLevel).tex((double)((float)p_146527_3_ * 0.0078125F), (double)((float)(p_146527_4_ + 18) * 0.0078125F)).endVertex();
      worldrenderer.pos((double)(p_146527_1_ + 18), (double)(p_146527_2_ + 18), (double)this.zLevel).tex((double)((float)(p_146527_3_ + 18) * 0.0078125F), (double)((float)(p_146527_4_ + 18) * 0.0078125F)).endVertex();
      worldrenderer.pos((double)(p_146527_1_ + 18), (double)p_146527_2_, (double)this.zLevel).tex((double)((float)(p_146527_3_ + 18) * 0.0078125F), (double)((float)p_146527_4_ * 0.0078125F)).endVertex();
      worldrenderer.pos((double)p_146527_1_, (double)p_146527_2_, (double)this.zLevel).tex((double)((float)p_146527_3_ * 0.0078125F), (double)((float)p_146527_4_ * 0.0078125F)).endVertex();
      tessellator.draw();
   }

   static jebac_vexiav0ttj7we8byq access$1100(jebac_vexiazwfkkk4iev4c x0) {
      return x0.fontRendererObj;
   }

   static StatFileWriter access$100(jebac_vexiazwfkkk4iev4c x0) {
      return x0.field_146546_t;
   }

   static jebac_vexiav0ttj7we8byq access$1500(jebac_vexiazwfkkk4iev4c x0) {
      return x0.fontRendererObj;
   }

   // $FF: synthetic method
   private void drawStatsScreen(int p_146521_1_, int p_146521_2_, Item p_146521_3_) {
      this.drawButtonBackground(p_146521_1_ + 1, p_146521_2_ + 1);
      GlStateManager.enableRescaleNormal();
      RenderHelper.enableGUIStandardItemLighting();
      this.itemRender.renderItemIntoGUI(new ItemStack(p_146521_3_, 1, 0), p_146521_1_ + 2, p_146521_2_ + 2);
      RenderHelper.disableStandardItemLighting();
      GlStateManager.disableRescaleNormal();
   }

   static jebac_vexiav0ttj7we8byq access$900(jebac_vexiazwfkkk4iev4c x0) {
      return x0.fontRendererObj;
   }

   static jebac_vexiav0ttj7we8byq access$400(jebac_vexiazwfkkk4iev4c x0) {
      return x0.fontRendererObj;
   }

   static jebac_vexiav0ttj7we8byq access$800(jebac_vexiazwfkkk4iev4c x0) {
      return x0.fontRendererObj;
   }

   static void access$1200(jebac_vexiazwfkkk4iev4c x0, int x1, int x2, Item x3) {
      x0.drawStatsScreen(x1, x2, x3);
   }

   static jebac_vexiav0ttj7we8byq access$1900(jebac_vexiazwfkkk4iev4c x0) {
      return x0.fontRendererObj;
   }

   static jebac_vexiav0ttj7we8byq access$2200(jebac_vexiazwfkkk4iev4c x0) {
      return x0.fontRendererObj;
   }

   static jebac_vexiav0ttj7we8byq access$500(jebac_vexiazwfkkk4iev4c x0) {
      return x0.fontRendererObj;
   }

   // $FF: synthetic method
   private void drawButtonBackground(int p_146531_1_, int p_146531_2_) {
      this.drawSprite(p_146531_1_, p_146531_2_, 0, 0);
   }

   static void access$000(jebac_vexiazwfkkk4iev4c x0, int x1, int x2, int x3, int x4) {
      x0.drawSprite(x1, x2, x3, x4);
   }

   // $FF: synthetic method
   public void func_175366_f() {
      this.generalStats = new jebac_vexia8en3b6qi5og2(this, this.mc);
      this.generalStats.registerScrollButtons(1, 1);
      this.itemStats = new jebac_vexiaemblsqysdl65(this, this.mc);
      this.itemStats.registerScrollButtons(1, 1);
      this.blockStats = new jebac_vexia838cb3ocv584(this, this.mc);
      this.blockStats.registerScrollButtons(1, 1);
      this.mobStats = new jebac_vexias89whxqlvzz6(this, this.mc);
      this.mobStats.registerScrollButtons(1, 1);
   }

   // $FF: synthetic method
   public void doneLoading() {
      if (this.doesGuiPauseGame) {
         this.func_175366_f();
         this.createButtons();
         this.displaySlot = this.generalStats;
         this.doesGuiPauseGame = false;
      }

   }

   static jebac_vexiav0ttj7we8byq access$600(jebac_vexiazwfkkk4iev4c x0) {
      return x0.fontRendererObj;
   }

   static jebac_vexiav0ttj7we8byq access$1600(jebac_vexiazwfkkk4iev4c x0) {
      return x0.fontRendererObj;
   }

   static jebac_vexiav0ttj7we8byq access$2000(jebac_vexiazwfkkk4iev4c x0) {
      return x0.fontRendererObj;
   }

   static jebac_vexiav0ttj7we8byq access$1300(jebac_vexiazwfkkk4iev4c x0) {
      return x0.fontRendererObj;
   }

   static jebac_vexiav0ttj7we8byq access$1800(jebac_vexiazwfkkk4iev4c x0) {
      return x0.fontRendererObj;
   }

   // $FF: synthetic method
   public jebac_vexiazwfkkk4iev4c(jebac_vexiakl614w3uw0xg p_i1071_1_, StatFileWriter p_i1071_2_) {
      this.parentScreen = p_i1071_1_;
      this.field_146546_t = p_i1071_2_;
   }

   static jebac_vexiav0ttj7we8byq access$1400(jebac_vexiazwfkkk4iev4c x0) {
      return x0.fontRendererObj;
   }

   static jebac_vexiav0ttj7we8byq access$2100(jebac_vexiazwfkkk4iev4c x0) {
      return x0.fontRendererObj;
   }
}
