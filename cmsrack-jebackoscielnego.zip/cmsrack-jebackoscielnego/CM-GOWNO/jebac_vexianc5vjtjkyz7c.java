public class jebac_vexianc5vjtjkyz7c {
   // $FF: synthetic field
   public int norm;
   // $FF: synthetic field
   public int base;
   // $FF: synthetic field
   public int spec;

   // $FF: synthetic method
   public jebac_vexianc5vjtjkyz7c(int baseTex, int normTex, int specTex) {
      this.base = baseTex;
      this.norm = normTex;
      this.spec = specTex;
   }
}
