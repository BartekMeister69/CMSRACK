import java.io.IOException;
import net.minecraft.client.resources.I18n;

public class jebac_vexiakrvc8n4z8a8o extends jebac_vexiakl614w3uw0xg {
   // $FF: synthetic field
   private final jebac_vexiakl614w3uw0xg parentScreen;

   // $FF: synthetic method
   protected void actionPerformed(jebac_vexia4oibzo50ubf0 button) throws IOException {
      this.mc.displayGuiScreen(this.parentScreen);
   }

   // $FF: synthetic method
   public jebac_vexiakrvc8n4z8a8o(jebac_vexiakl614w3uw0xg parentScreen) {
      this.parentScreen = parentScreen;
   }

   // $FF: synthetic method
   public void initGui() {
      this.buttonList.add(new jebac_vexia4oibzo50ubf0(0, this.width / 2 - 75, this.height - 50, 150, 20, I18n.format("gui.cancel")));
   }

   // $FF: synthetic method
   public void drawScreen(int mouseX, int mouseY, float partialTicks) {
      this.drawDefaultBackground();
      int i = Math.max((int)((double)this.height * 0.85D / 2.0D - (double)((float)this.fontRendererObj.FONT_HEIGHT / 2.0F)), 50);
      this.drawCenteredString(this.fontRendererObj, I18n.format("stream.unavailable.title"), this.width / 2, i - this.fontRendererObj.FONT_HEIGHT * 2, 16777215);
      super.drawScreen(mouseX, mouseY, partialTicks);
   }
}
