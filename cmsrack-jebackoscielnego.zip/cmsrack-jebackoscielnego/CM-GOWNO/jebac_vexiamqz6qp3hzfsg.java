import java.awt.Color;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class jebac_vexiamqz6qp3hzfsg extends jebac_vexiakl614w3uw0xg {
   private int  gh;
   private boolean  gn;
   private static final String[]  gk;
   private boolean  gm;
   private boolean  gj;
   private int  gi;
   private static final int[]  gl;

   static {
      lIlIIlIl();
      lIlIIIlI();
   }

   // $FF: synthetic method
   protected void mouseReleased(int var1, int var2, int var3) {
      super.mouseReleased(var1, var2, var3);
      this. gj = (boolean) gl[7];
      this. gn = (boolean) gl[7];
      this. gm = (boolean) gl[7];
   }

   // $FF: synthetic method
   private static boolean lIlIlIII(int var0) {
      return var0 != 0;
   }

   // $FF: synthetic method
   public void drawScreen(int var1, int var2, float var3) {
      this.drawVerticalLine(this.width /  gl[4],  gl[7], this.height, Color.GREEN.getRGB());
      this.drawHorizontalLine( gl[7], this.width, this.height /  gl[4], Color.GREEN.getRGB());
      int var10001 = jebac_vexiaau3mg1q92fzj. dy. jq;
      int var10002 = jebac_vexiaau3mg1q92fzj. dy. jn;
      int var10003 =  gl[8];
      int var10004;
      if (lIlIlIII(jebac_vexiaau3mg1q92fzj. dy. jp)) {
         var10004 =  gl[1];
         jebac_vexiaqb58506wt8o3.  ‏ ("", -902601768).length();
         if (null != null) {
            return;
         }
      } else {
         var10004 =  gl[2];
      }

      this.drawBorder(var10001, var10002, var10003, var10004, Color.GREEN.getRGB());
      this.drawBorder(jebac_vexiaau3mg1q92fzj. eb. gq, jebac_vexiaau3mg1q92fzj. eb. go,  gl[5], this.mc.thePlayer.getActivePotionEffects().size() *  gl[6], Color.GREEN.getRGB());
      String var8 =  gk[ gl[7]];
      var10002 = jebac_vexiaau3mg1q92fzj. dy. jq +  gl[9];
      var10003 = jebac_vexiaau3mg1q92fzj. dy. jn;
      if (lIlIlIII(jebac_vexiaau3mg1q92fzj. dy. jp)) {
         var10004 =  gl[1];
         jebac_vexiaqb58506wt8o3.  ‏ ("", -158810164).length();
         if (jebac_vexiaqb58506wt8o3.  ‏ ("꤬", 1523230988).length() <= 0) {
            return;
         }
      } else {
         var10004 =  gl[2];
      }

      this.drawRainbowString(var8, var10002, var10003 + var10004 +  gl[10]);
      this.drawRainbowString( gk[ gl[3]], jebac_vexiaau3mg1q92fzj. eb. gq +  gl[9], jebac_vexiaau3mg1q92fzj. eb. go + this.mc.thePlayer.getActivePotionEffects().size() *  gl[6] +  gl[10]);
      if (lIlIlIII(this. gj)) {
         jebac_vexiaffroustvvf49 var10000 = jebac_vexiaau3mg1q92fzj. dy;
         var10000. jq += var1 - this. gh;
         var10000 = jebac_vexiaau3mg1q92fzj. dy;
         var10000. jn += var2 - this. gi;
         jebac_vexiaqb58506wt8o3.  ‏ ("", -812741949).length();
         if (jebac_vexiaqb58506wt8o3.  ‏ ("囏", -1156950289).length() <= 0) {
            return;
         }
      } else if (lIlIlIII(this. gn)) {
         jebac_vexia5c4je8aazc78 var7 = jebac_vexiaau3mg1q92fzj. ea;
         var7. fp += var1 - this. gh;
         var7 = jebac_vexiaau3mg1q92fzj. ea;
         var7. fn += var2 - this. gi;
         jebac_vexiaqb58506wt8o3.  ‏ ("", 808264492).length();
         if ((14 ^ 10) <= ((103 ^ 77) & ~(142 ^ 164))) {
            return;
         }
      } else if (lIlIlIII(this. gm)) {
         jebac_vexiawjtwglazxj7a var9 = jebac_vexiaau3mg1q92fzj. eb;
         var9. gq += var1 - this. gh;
         var9 = jebac_vexiaau3mg1q92fzj. eb;
         var9. go += var2 - this. gi;
      }

      this. gh = var1;
      this. gi = var2;
   }

   // $FF: synthetic method
   private static boolean lIlIIllI(int var0, int var1) {
      return var0 >= var1;
   }

   // $FF: synthetic method
   private static boolean lIlIllII(int var0, int var1) {
      return var0 < var1;
   }

   // $FF: synthetic method
   private static String lIlIIIIl(String var0, String var1) {
      try {
         String var2 = new SecretKeySpec(MessageDigest.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("強弾彏", -1060675718)).digest(var1.getBytes(StandardCharsets.UTF_8)), jebac_vexiaqb58506wt8o3.  ‏ ("⤗⤹⤺⤢⤳⤼⤦⤽", 84224341));
         SecretKeySpec var3 = Cipher.getInstance(jebac_vexiaqb58506wt8o3.  ‏ ("蚟蚱蚲蚪蚻蚴蚮蚵", 1310033629));
         var3.init( gl[4], var2);
         return new String(var3.doFinal(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception var9) {
         var9.printStackTrace();
         return null;
      }
   }

   // $FF: synthetic method
   protected void mouseClicked(int var1, int var2, int var3) throws IOException {
      label48: {
         super.mouseClicked(var1, var2, var3);
         if (lIlIIllI(var1, jebac_vexiaau3mg1q92fzj. dy. jq) && lIlIIlll(var1, jebac_vexiaau3mg1q92fzj. dy. jq +  gl[0]) && lIlIIllI(var2, jebac_vexiaau3mg1q92fzj. dy. jn)) {
            int var10001 = jebac_vexiaau3mg1q92fzj. dy. jn;
            int var10002;
            if (lIlIlIII(jebac_vexiaau3mg1q92fzj. dy. jp)) {
               var10002 =  gl[1];
               jebac_vexiaqb58506wt8o3.  ‏ ("", -1901849571).length();
               if (-jebac_vexiaqb58506wt8o3.  ‏ ("辁", 14847905).length() > 0) {
                  return;
               }
            } else {
               var10002 =  gl[2];
            }

            if (lIlIIlll(var2, var10001 + var10002)) {
               this. gj = (boolean) gl[3];
               jebac_vexiaqb58506wt8o3.  ‏ ("", -55770780).length();
               if (jebac_vexiaqb58506wt8o3.  ‏ ("⢀⢀", -201185120).length() == ((158 ^ 160 ^ 48 ^ 58) & (130 ^ 184 ^ 44 ^ 34 ^ -jebac_vexiaqb58506wt8o3.  ‏ ("\udb1e", 348511038).length()))) {
                  return;
               }
               break label48;
            }
         }

         if (lIlIIllI(var1, (this.width - jebac_vexiaau3mg1q92fzj. ea. fm) /  gl[4] + jebac_vexiaau3mg1q92fzj. ea. fp) && lIlIIllI(var2, jebac_vexiaau3mg1q92fzj. ea. fn) && lIlIIlll(var1, (this.width + jebac_vexiaau3mg1q92fzj. ea. fm) /  gl[4] + jebac_vexiaau3mg1q92fzj. ea. fp) && lIlIIlll(var2, jebac_vexiaau3mg1q92fzj. ea. fn + jebac_vexiaau3mg1q92fzj. ea. fo)) {
            this. gn = (boolean) gl[3];
            jebac_vexiaqb58506wt8o3.  ‏ ("", -991476631).length();
            if ((116 ^ 6 ^ 193 ^ 183) < (247 ^ 164 ^ 46 ^ 121)) {
               return;
            }
         } else if (lIlIIllI(var1, jebac_vexiaau3mg1q92fzj. eb. gq) && lIlIIlll(var1, jebac_vexiaau3mg1q92fzj. eb. gq +  gl[5]) && lIlIIllI(var2, jebac_vexiaau3mg1q92fzj. eb. go) && lIlIIlll(var2, jebac_vexiaau3mg1q92fzj. eb. go + this.mc.thePlayer.getActivePotionEffects().size() *  gl[6])) {
            this. gm = (boolean) gl[3];
         }
      }

      this. gh = var1;
      this. gi = var2;
   }

   // $FF: synthetic method
   public void drawBorder(int var1, int var2, int var3, int var4, int var5) {
      this.drawHorizontalLine(var1, var1 + var3, var2, var5);
      this.drawVerticalLine(var1, var2 + var4, var2, var5);
      this.drawHorizontalLine(var1, var1 + var3, var2 + var4, var5);
      this.drawVerticalLine(var1 + var3, var2 + var4, var2, var5);
   }

   // $FF: synthetic method
   private static String lIlIIIII(String var0, String var1) {
      var0 = new String(Base64.getDecoder().decode(var0.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      String var2 = new StringBuilder();
      Exception var3 = var1.toCharArray();
      int var4 =  gl[7];
      StringBuilder var5 = var0.toCharArray();
      String var6 = var5.length;
      int var7 =  gl[7];

      do {
         if (!lIlIllII(var7, var6)) {
            return String.valueOf(var2);
         }

         double var8 = var5[var7];
         var2.append((char)(var8 ^ var3[var4 % var3.length]));
         jebac_vexiaqb58506wt8o3.  ‏ ("", -263987362).length();
         ++var4;
         ++var7;
         jebac_vexiaqb58506wt8o3.  ‏ ("", -2031225992).length();
      } while(-(18 + 51 - 1 + 63 ^ 19 + 128 - 40 + 28) <= 0);

      return null;
   }

   // $FF: synthetic method
   private static boolean lIlIIlll(int var0, int var1) {
      return var0 <= var1;
   }

   // $FF: synthetic method
   private static void lIlIIlIl() {
       gl = new int[12];
       gl[0] = 147 ^ 131 ^ 35 ^ 121;
       gl[1] = 142 ^ 147 ^ 241 ^ 181;
       gl[2] = 88 ^ 11;
       gl[3] = jebac_vexiaqb58506wt8o3.  ‏ ("塳", -138586029).length();
       gl[4] = jebac_vexiaqb58506wt8o3.  ‏ ("虗虗", 2036303479).length();
       gl[5] = 181 + 107 - 281 + 239 ^ 89 + 133 - 205 + 146;
       gl[6] = 15 ^ 46;
       gl[7] = (99 ^ 57) & ~(232 ^ 178);
       gl[8] = 105 ^ 32;
       gl[9] = 120 ^ 54 ^ 252 ^ 186;
       gl[10] = jebac_vexiaqb58506wt8o3.  ‏ ("軺軺軺", 2147454682).length();
       gl[11] = 139 ^ 168 ^ 73 ^ 96;
   }

   // $FF: synthetic method
   private void drawRainbowString(String var1, int var2, int var3) {
      short var4 = var2;
      Exception var5 = var1.toCharArray();
      long var6 = var5.length;
      int var7 =  gl[7];

      do {
         if (!lIlIllII(var7, var6)) {
            return;
         }

         char var8 = var5[var7];
         String var9 = System.currentTimeMillis() - (long)(var4 *  gl[11] - var3 *  gl[11]);
         int var11 = String.valueOf(var8);
         this.mc.fontRendererObj.drawString(var11, (float)var4, (float)var3, Color.HSBtoRGB((float)(var9 % 2000L) / 2000.0F, 0.8F, 0.8F), (boolean) gl[3]);
         jebac_vexiaqb58506wt8o3.  ‏ ("", 117461214).length();
         var4 += this.mc.fontRendererObj.getCharWidth(var8);
         ++var7;
         jebac_vexiaqb58506wt8o3.  ‏ ("", 934239899).length();
      } while(jebac_vexiaqb58506wt8o3.  ‏ ("즮즮", 593938830).length() != jebac_vexiaqb58506wt8o3.  ‏ ("ؙ", 1630078521).length());

   }

   // $FF: synthetic method
   private static void lIlIIIlI() {
       gk = new String[ gl[4]];
       gk[ gl[7]] = lIlIIIII(jebac_vexiaqb58506wt8o3.  ‏ ("憤憑憪憊憠憺憜憨憤憌憌懄憨憜懖懖", -327523861), jebac_vexiaqb58506wt8o3.  ‏ ("\uf011\uf034\uf002\uf03b\uf019", -1679429535));
       gk[ gl[3]] = lIlIIIIl(jebac_vexiaqb58506wt8o3.  ‏ ("텂텷텩텠텉턁턉텅텦텅텧턄텪텂텚턇텼텛텞텸텥텡턍턍", -770125520), jebac_vexiaqb58506wt8o3.  ‏ ("똍똛똊똜똡", 1219278409));
   }
}
