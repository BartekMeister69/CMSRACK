public interface jebac_vexiaknlf2gexq698 {
   // $FF: synthetic method
   void failed(jebac_vexiahtrnwedo9ob6 var1, Exception var2);

   // $FF: synthetic method
   void finished(jebac_vexiahtrnwedo9ob6 var1, jebac_vexiahx0fynbv9rl1 var2);
}
